-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1285190's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:56:10 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 5
-- Total DLCs: 0
-- Blacklisted Depots: 6
--   Depot 1285431: Blacklisted
--   Depot 1285432: Blacklisted
--   Depot 1285271: Blacklisted
--   Depot 1285434: Blacklisted
--   Depot 1285435: Blacklisted
--   Depot 1285433: Blacklisted

addappid(1285190)
addappid(2013850,0,"f0f6f03e213ec6effac974bc92309dc05e11e8d49013fabccdc253f8479d1c44")
--setManifestid(2013850,"1885194575676718061")
addappid(1285191,0,"aabb315ef5573fc2633c461cd2ac9b553e2713ca90a67ad2df09781274cbb20f")
--setManifestid(1285191,"8461162535071036430")
addappid(1285192,0,"3e212ce90691e4e8f2f1418c35495c50a725bb0d012d9f415b0a8a9119dfb0f4")
--setManifestid(1285192,"8593814336479478264")
addappid(1285193,0,"5c38ce39a639096877f707cb88dea4250f2a4b53ae5e1b67654e243d2b988ede")
--setManifestid(1285193,"1587472964084640951")
addappid(1285195,0,"ccf45efe0bf7e329f6b3fa0b29af3c0c7a609c49f6e9b7018bf644fe2f158a82")
--setManifestid(1285195,"218636985744352584")
addappid(3829670)
addappid(3802370)
addappid(3802360)
addappid(3829680)
addappid(3802420)
addappid(3802450)
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1771300's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:53 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 10
-- Blacklisted Depots: 0

addappid(1771300)
addappid(1771300,0,"3caed047b77bd7be8e68f818a3a6729b75371e0f67c871728c7a19de18aa6f53")
addappid(4075290,0,"5719ab17163fb31ff02aedc90c95c0b06a0a0d66b687706cbef92a539a773b1b")
--setManifestid(4075290,"7365651604166421259")
addappid(1771302,0,"41bc41c39ce79db318e98b533bab1fe71bfd294c4e8c90f90e4f8efa5fcc2a91")
--setManifestid(1771302,"4826030030885942644")
addappid(1771303,0,"397ab2e5c59bbb75f716c30dba3374be8af7ff49a2fc45c621e0bc23bafbd5f3")
--setManifestid(1771303,"3222098045559364073")
addappid(1771305,0,"66d5a42e0171363eac9b79352c78401952d616880979d26967c385d2d7a88368")
--setManifestid(1771305,"4358917877440417639")
addappid(1771306,0,"120aed0e767afa1ac85539240704d613b82c13473fcd7136d3cea555a784783e")
--setManifestid(1771306,"5397320021951793241")
addappid(1771307,0,"8d47328b0b82d9b9ba25bfb199c69ea2dd005954298bd2aff2b448321569b727")
--setManifestid(1771307,"8613193015287904206")
addappid(1771308,0,"b457fdf0e78f3465b9ccbfed5f8ecbb85f22428ba321534ee0df4a0d08754d02")
--setManifestid(1771308,"2880986098495496633")
addappid(1771309,0,"1f8b55f9f4ac27eac8ffa310ca46163ee5aaad0937438035274a30b78de4e81a")
--setManifestid(1771309,"4150090098201849413")
addappid(3118101,0,"69d3aecd16754fea50cf46182e56be5d29647e571e45c1dd1ef3294b966d0ee4")
--setManifestid(3118101,"459359545350465778")
addappid(3119920)
addappid(3118100)
addappid(3368620)
addappid(3118110)
addappid(3118120)
addappid(3368600)
addappid(3368610)
addappid(4075290)
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2131650's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:59 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 6
-- Total DLCs: 0
-- Blacklisted Depots: 7
--   Depot 2131633: Blacklisted
--   Depot 2131682: Blacklisted
--   Depot 2131632: Blacklisted
--   Depot 2131681: Blacklisted
--   Depot 2131011: Blacklisted
--   Depot 2131644: Blacklisted
--   Depot 2131642: Blacklisted

addappid(2131650)
addappid(2314280)
addappid(2314281)
addappid(2314282)
addappid(2131651,0,"0073fe0583da7d2329aee1439801c51c48ee664444fa0f669155c1e51d331fe8")
--setManifestid(2131651,"6695587154341534306")
addappid(2131652,0,"65ab5efe73d2ad271b6038a0632621f95755aa433619ed4223eb115634d035ff")
--setManifestid(2131652,"7645578694842454403")
addappid(2131654,0,"5a546c87b8553c36c0b7c7ad9ea7aed11c225ff288a3077f0ce9236dababfa09")
--setManifestid(2131654,"1288863419166058256")
addappid(2314280,0,"1741d8bab672cba92e86f4f476a811e7e9e39685a9269a7040437c907492d334")
--setManifestid(2314280,"5445412728386120678")
addappid(2314281,0,"5267831e9c74001101fdcd5e5987108b01c2c9fc3a3ad44c53f9bce2a3468e77")
--setManifestid(2314281,"2259101554323948940")
addappid(2314282,0,"9584e2a3c4196fe4ad8bb6abefbce60a06710eb351f832abbec0be982d06f789")
--setManifestid(2314282,"4435371496659335891")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 333640's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:25 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 5
-- Blacklisted Depots: 0

addappid(333640)
addappid(333640,0,"d2425b61bc066d719a233440d51335e77b8a984f4736a809b6825dec5c553943")
addappid(3252660,0,"137e2fd7d6a5c375a7eea682b95a6b37cbdf772049a52d98950825257d6ac627")
--setManifestid(3252660,"8893803301824573414")
addappid(333641,0,"dfa108b3e863b583a4e9f5c4fc602f2f16e97315239913e06a4612f9c6349fff")
--setManifestid(333641,"6923890922841034135")
addappid(333642,0,"4a233a3d219ce8a7545847bc4511e7851296b4bf58fdf4c488331515f6288be7")
--setManifestid(333642,"2694404800116894246")
addappid(333643,0,"bbc326e4462b214e78177f87ab19f17aa09b86bc373fd6f9440f2757711f90f5")
--setManifestid(333643,"6463879429433896508")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1617400's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:56:46 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 5
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(1617400)
addappid(3884450)
addappid(3884460)
addappid(4082620)
addappid(4418930)
addappid(1617401,0,"a292c6146bb27fdff3a3d3c2c4fe0aef9d6a4fdf13c7550bfc051f386b57b947")
--setManifestid(1617401,"13263768017005040")
addappid(1617402,0,"e324353bb453459d674c0ff0a818181b8ab9f2fc5ec833e6fb278cd246806ff2")
--setManifestid(1617402,"5387864853511428543")
addappid(3884450,0,"02056fe24cf190cd27a59ae79daaad4de58e9421567972cf7e0fbfb3fe838ab3")
--setManifestid(3884450,"3077317331335822420")
addappid(3884460,0,"b56902114196b609019a6aa5f5683bcab71df6c54ebf2344f15138cb2e4a83fd")
--setManifestid(3884460,"938778916917637845")
addappid(4082620,0,"43cb2ef5b2a7bb09bef4def9faf6c6d4da3e74df048980d77b1beacab1dc491c")
--setManifestid(4082620,"7752478361948969535")
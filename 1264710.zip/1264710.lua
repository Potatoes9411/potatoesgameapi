-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1264710's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:56:07 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 5
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 1264971: Blacklisted

addappid(1264710)
addappid(2225950,0,"54dfaaea9941c9f9631ced6bb006da2c4e7e9612fbe5e6a0fedabfb00d292bd5")
-- setManifestid(2225950,"6385799425974488443")
addappid(2257530,0,"dd9800ead2d38720ca309e39d471a398b33689153461a43b79ac131f24ff9231")
-- setManifestid(2257530,"4507839528174525784")
addappid(2945780,0,"67303b9cdca0ca902343f4e43f633c4174ded09b0d2aa16e9e1f9c4aa2239821")
-- setManifestid(2945780,"8281708694012831075")
addappid(4190290,0,"5422816fb3431e19dc1e8b88ea2be09c267a81aa1f2cf438af68ad969f2e9234")
-- setManifestid(4190290,"4946518597545775979")
addappid(1264711,0,"4a897a7db879588d36357b800d783e7ed104f944548cdcaedce7945bd26ed272")
-- setManifestid(1264711,"1971414229794248799")
addappid(4190270)
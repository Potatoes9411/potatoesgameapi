-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 47890's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 07:00:00 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 24
-- Blacklisted Depots: 0

addappid(47890)
addappid(47892)
addappid(47893)
addappid(47894)
addappid(47895)
addappid(47896)
addappid(47897)
addappid(47898)
addappid(47899)
addappid(47930)
addappid(47931)
addappid(47932)
addappid(47933)
addappid(47934)
addappid(47935)
addappid(47936)
addappid(223590)
addappid(223591)
addappid(223592)
addappid(223593)
addappid(223594)
addappid(223595)
addappid(223597)
addappid(223598)
addappid(249180)
addappid(249181)
addappid(47891,0,"ce9076947fda1deda2c759d3bca13ae69c9b63851058859691955ba5793bea33")
--setManifestid(47891,"6449742215339092050")
addappid(47892,0,"db70a0bfcbf2a1e84434a40fa385baa20892ad05229ebc57dd8c2ac349fe01f2")
--setManifestid(47892,"5210990044831934212")
addappid(47893,0,"b93c02b316f310c5711e1b88cdf72b7371b5b342cec7f2b489d6de9884f3cf19")
--setManifestid(47893,"1383601199894519430")
addappid(47894,0,"b8c17fb0403da429d459e6e24f7f0c2dc139e905dfa70e4a41e6fc719fde1ee3")
--setManifestid(47894,"5712783841505770475")
addappid(47895,0,"6a6b33263ab86068a8a77e362b93baabbe30ad4b13fbcc55ab8b42a44411fff4")
--setManifestid(47895,"8690491428650273709")
addappid(47896,0,"49e7dc28acd1b79e90a824e5ff4db2afef37c8f81ab545cd7a9fa1eb82c8b1dd")
--setManifestid(47896,"1815991579821947356")
addappid(47897,0,"508fd7f6a6e9a2b65c685a6eebc658358825d86b1b2321b5e4a4ccf0323dceb8")
--setManifestid(47897,"7385800270121409409")
addappid(47898,0,"a71b99a9207b0c52368e5593ab20265e21687b2b77ec7cb3c177f14e8957584a")
--setManifestid(47898,"2816072955094907546")
addappid(47899,0,"21f7377312b7512d37a49845730960ea9c463414f0908c3c359a782057f8d5f2")
--setManifestid(47899,"1519651747507852766")
addappid(47930,0,"2ac9e2a0f0cd913a0beda53cf06c129567470287b5867923ba01bbbf8f5f5137")
--setManifestid(47930,"4192738063127107487")
addappid(47931,0,"bb01ec270d7c9a2dfabdcc2b302b57eccdc692f27d31e45016d54b443104c869")
--setManifestid(47931,"8578941594536965640")
addappid(47932,0,"8b4a6891ac0a51a8b4114b4b5e2d3a9a87b6f7a652a55836cec952c47a1d6c53")
--setManifestid(47932,"3209310309147485782")
addappid(47933,0,"5e35e7d0cef6a5ec568701ec2762219c639cb65b979a2747b6c0f431ac384335")
--setManifestid(47933,"4137894498034652142")
addappid(47934,0,"390d9b2de5bdd04ec3de9cd32aca8fee521855e1f0fcc0b67407b0397e2417aa")
--setManifestid(47934,"1225643595751997760")
addappid(47937,0,"a52d9b413b5336854bb6c392669c5cb3a2784bdfea0c55fc18d2c18d339191cb")
--setManifestid(47937,"8475364932992983050")
addappid(223591,0,"351cb512187b892df16ef53e31415041e76b6197808fbd0231acfc14378c3983")
--setManifestid(223591,"8531534622214638606")
addappid(223592,0,"61fe3b561e9887e3c4c58b8c9a41f44dfc3dd00ce084bea2da46d9c2bd612fc7")
--setManifestid(223592,"4103626455141543917")
addappid(223593,0,"d076a0b23a85d0ab0103a821813f17fabcc799b39b8c3feddfcb58ec7e9bd020")
--setManifestid(223593,"5165165866507747385")
addappid(223594,0,"47e6c00c02d338af15bd2e61860e06d3dfe15f8e621d4670d4eaddb44b5c6378")
--setManifestid(223594,"748761765483127845")
addappid(223595,0,"06c3554d775af55fba77a3a757f267ab7af0adf10e41e8c59bbaba285daabd89")
--setManifestid(223595,"4294534884160303553")
addappid(223597,0,"eb63b6cf434e8cd303653555d7bd13d272a71dde0cb2f0d67d3b6815f8ed5950")
--setManifestid(223597,"9094751074353643994")
addappid(223598,0,"79e6a9fe983dc014ccceb599961eece10450258aef66b3904fbe339faf628bff")
--setManifestid(223598,"8828328589406509932")
addappid(249180,0,"25461e4c60918d3e35cd458841067298504c2b0c9fac074fe90adce00bcbdd9d")
--setManifestid(249180,"8006096104699758003")
addappid(249181,0,"a78d4298d959bb74b2b19ce2bf157f1188f3d8ab729bbb0c069d6ddebf8656b5")
--setManifestid(249181,"330202481147075394")
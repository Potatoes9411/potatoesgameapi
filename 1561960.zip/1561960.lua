-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1561960's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:56:40 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(1561960)
addappid(3372030)
addappid(1561962,0,"0660405628a3843952e55a1c68adde5756fc35f494c32eec8f30a7ee10e63125")
--setManifestid(1561962,"5982346706666367286")
addappid(1561963,0,"3226137c81eb9f51c29e9ec4a1a7491650d811a63575bbd670d78914e6b1dd52")
--setManifestid(1561963,"1275902447085592798")
addappid(3372030,0,"6879ab82d6eafbad1b970c3efe19aa47409251de5cf3e3e6c38f11d90364c0ec")
--setManifestid(3372030,"329408780299180320")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 266310's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:00:30 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 9
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 2663: Blacklisted

addappid(266310)
addappid(228983)
--setManifestid(228983,"8124929965194586177")
addappid(266311,0,"c7c5a17cf2167455b6e5dcc635910ae5271171445f4456caf294d9f2ff5ec665")
--setManifestid(266311,"671079632653861021")
addappid(451370,0,"c60bd200fdf6dbdaa3f294172905b8a3c282b2badba60b40b660922fa4b23cb4")
--setManifestid(451370,"177175013964933120")
addappid(321140,0,"e68528d0ee1b4b7c8d46c5a83df84d1c4957a98eb5eeec5f75bf9253f033f4e8")
--setManifestid(321140,"883603378483681200")
addappid(321141,0,"d657286975c9960912e6839fbe1aa16925e25415188c74f78954f648ca827aa3")
--setManifestid(321141,"7613612883485684566")
addappid(321142,0,"27df1cb778dfea0601adcd690d6c9de1ae76d2c511017d19079bfa77ac5cb4e9")
--setManifestid(321142,"8053152552503260126")
addappid(365520,0,"11ae2bbd7af4bba99131214cfad98b46d841313a608c3fee7a0d0afa59f96526")
--setManifestid(365520,"7828855718254455429")
addappid(365530,0,"fd16f02d86b7d2e848c4a13d778a264bf7959e153bb92f9f27fec67c9e127af4")
--setManifestid(365530,"6987326408433425723")
addappid(365540,0,"066ca04b9aa35d7e46c88ec4bb74b62a3a730ea6a82ffe7cf63878fa2a8da1eb")
--setManifestid(365540,"923308570436860670")
addappid(496580,0,"d3ab96cacd64fea95eae66f1f397807ae87836a322597e72bd6458d20fee7a84")
--setManifestid(496580,"1768123728023658715")
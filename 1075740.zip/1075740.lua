-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1075740's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:55:27 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 5
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 1075870: Blacklisted

addappid(1075740)
addappid(1359660)
addappid(1937690)
addappid(2191860)
addappid(2523180)
addappid(1075741,0,"9bc9bfdf1f759e30836770ebac7f161939e8645ad95c657701c7f5e32709e2b0")
--setManifestid(1075741,"6100765673859813045")
addappid(1359660,0,"f8d817e1173dedce9eeab445da2d08411104caa18aff86c1d5a490a36f17a991")
--setManifestid(1359660,"7392394569065003340")
addappid(1937690,0,"b07c471e677227c5f7260970b41c76be61f1bf1c8064583f66085a4291d2889b")
--setManifestid(1937690,"4749735177163290957")
addappid(2191860,0,"378ac5144f87cfbfc90a87ff42be384f991c31ef99e6904b5627ef53fda76c92")
--setManifestid(2191860,"6161108191045738446")
addappid(2523180,0,"c36afb2ac310b8faed4a260b0e57682bd282ac2d25f1281265b8b0f9205b3c0f")
--setManifestid(2523180,"3175458939006870025")
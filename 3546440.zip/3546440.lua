-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3546440's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:34 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(3546440)
addappid(3546441,0,"f303e6656cf9ab575ee79e1a326af48358d9efb35bf85df55ccf125a2079f491")
--setManifestid(3546441,"6470273854625296413")
addappid(3546442,0,"6F5ECA04B830290AAE7412E26D2D6F33F6024A238ABF290408132187DF1E2EDC")
--setManifestid(3546442,"5733785144310347057")
addappid(3546443,0,"809A534F463DC5CBEEB2FA2431F4B4AFCD7E348FBB7C58305CCD54B3432B1590")
--setManifestid(3546443,"1757300413626261094")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 560430's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 07:00:02 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 5
-- Blacklisted Depots: 0

addappid(560430)
addappid(560431,0,"817ebb2b7864788bafca445ba418190f10f6fc455cb9c83ef989b7483d15437a")
--setManifestid(560431,"9153990256698493855")
addappid(560432,0,"967e62d5dd689f01fe4e210c2ce7f25d4b8d0e18ba8601a2ebb844448abb577f")
--setManifestid(560432,"5705564255085531857")
addappid(560433,0,"68b9609460e65caebe6d865398a2b2cc85804ede39f338593250af8a52c1ed37")
--setManifestid(560433,"4419452725959813560")
addappid(560434,0,"307092cb017811f905a3d3d64472c6d5887f9ee43ff85677b1715f4ce8f4f0da")
--setManifestid(560434,"666762243073242654")
addappid(560435,0,"be21f3a3c25d60afa37a2d4773a27ca1921088f65e6ce7d86a0eb3fb05275120")
--setManifestid(560435,"1811739143403280135")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 785790's Lua and Manifest Created by Potatoes9411
-- WHAT THE GOLF?
-- Created: May 16, 2026 at 04:46:33 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 11
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(785790, 1, "Unknown")
addappid(785791, 1, "90d9930e8ba20789717d8c3380395f583a8bd0104bb8413f4b16718a94a6df14")
setManifestid(785791, "6507149591620824302", 0)
addappid(785792, 1, "Unknown")
setManifestid(785792, "Unknown", 0)
addappid(785793, 1, "Unknown")
setManifestid(785793, "Unknown", 0)
addappid(785794, 1, "Unknown")
setManifestid(785794, "Unknown", 0)
addappid(785795, 1, "Unknown")
setManifestid(785795, "Unknown", 0)
addappid(785796, 1, "Unknown")
setManifestid(785796, "Unknown", 0)
addappid(785797, 1, "Unknown")
setManifestid(785797, "Unknown", 0)
addappid(785798, 1, "Unknown")
setManifestid(785798, "Unknown", 0)
addappid(785799, 1, "Unknown")
setManifestid(785799, "Unknown", 0)
addappid(1620450, 1, "Unknown")
setManifestid(1620450, "Unknown", 0)
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 12220's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:55:48 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 7
-- Total DLCs: 0
-- Blacklisted Depots: 9
--   Depot 1222678: Blacklisted
--   Depot 1222673: Blacklisted
--   Depot 1222672: Blacklisted
--   Depot 1222677: Blacklisted
--   Depot 1222671: Blacklisted
--   Depot 1222679: Blacklisted
--   Depot 1222675: Blacklisted
--   Depot 1222674: Blacklisted
--   Depot 1222676: Blacklisted

addappid(12220)
addappid(12221,0,"81ddb2112e643bbd3b6ba2afb6cb5befc29e6af279417b1fe869a913e6fb2131")
--setManifestid(12221,"3724368639462495704")
addappid(12222,0,"b5b5eda30f092696af90c38dececf04ce645b6c719190650068bddce5c49de1e")
--setManifestid(12222,"4873137157423983930")
addappid(12223,0,"982592ab99db3254cf53eba6b7cc8fb969d6bb444701a5b69d9c4013980153e6")
--setManifestid(12223,"5864218123665864372")
addappid(12224,0,"eafa2330ab55d5ac009bc764b5a743ca0f8b066908589f75687b2f72ba2d5466")
--setManifestid(12224,"5159865615262522368")
addappid(12225,0,"17e188ec9aeb7eeee849a65b009787a8cc415781466a517ce5f6c27cbc9e4136")
--setManifestid(12225,"2410949247245578384")
addappid(12226,0,"b9c2812297b896cbe17d5d14a9b74e93b2b99b1f86dd3b4e21342f7a61b32fca")
--setManifestid(12226,"1134841128184410844")
addappid(12227,0,"dc52bbe1b3329b150a53b9cad3c71ee6ab502b81e18b87b293f98a811a600515")
--setManifestid(12227,"1563319131398911718")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3622640's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:39 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(3622640)
addappid(4585810)
addappid(3622641,0,"beec5643a86ba10a04c36be36408f578c8e8301c3124f89d23ebda5560435f82")
--setManifestid(3622641,"8010878768968104504")
addappid(3622642,0,"2ae50ee58e5bd34c28da3decb3eeffe67a47f15779949c47a3971bf72602bfd4")
--setManifestid(3622642,"3499059537317363577")
addappid(3622643,0,"d9364417551ab197e230f2ee66596010e6a29472b04ac80c8bc1baf3fedc6f51")
--setManifestid(3622643,"7368819242018137240")
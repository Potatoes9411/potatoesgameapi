-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 814380's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 07:00:06 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 5
-- Blacklisted Depots: 0

addappid(814380)
addappid(1039230,0,"fdf0783fc1f1f3ee832c2912beffe0982e4f6d2abb1b63c8266fade7ad7f4493")
--setManifestid(1039230,"1077830899885356469")
addappid(814381,0,"84db6d0cd0648c885d471541b83416e460f07ad6b71e1b86b2fa26926514d874")
--setManifestid(814381,"7598923580425802222")
addappid(814382,0,"742e0660742d90e8f827db3e00bcbf594970e97e76f8fb90ec74a54562ef5502")
--setManifestid(814382,"8495754623934990551")
addappid(814383,0,"3f8022efca09175e6bef77385ece0b5693e94d829d50baab66f9e249b996992b")
--setManifestid(814383,"1996592192490629382")
addappid(814385,0,"8689daaad42496510eb7b2fc6f6de095af54aae85e481998eb4746d2fad6b9af")
--setManifestid(814385,"1613271962634429538")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1314000's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:43 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(1314000)
addappid(2445710)
addappid(2705610)
addappid(1314001,0,"f8ea6ebbef185079adc617c41c6c867f04dcd43446d42aed3ca43a18a39ef4f8")
--setManifestid(1314001,"4948090529120183160")
addappid(2445710,0,"db02dd0af8eaee425e4a0e14ef9e5c37fb529fd028cfbbfaaab96401e50020c0")
--setManifestid(2445710,"1222008679826958043")
addappid(2705610,0,"8e4168ed36e387b02f0eebb736f984892f7613b9283f77eb15efd68055049456")
--setManifestid(2705610,"3732485595865581976")
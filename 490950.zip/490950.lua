-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 490950's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 07:00:00 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(490950)
addappid(490952,0,"947c5b26dfcc63a99113b4f9fd95e324fd2bd3a1fb7ba0db465847c5e7ff29af")
--setManifestid(490952,"7085661247946229377")
addappid(490953,0,"b7870690cb6f5f36d89b1a12f1d0487b956c80592d5ab4ffe010921fb197d77c")
--setManifestid(490953,"7348215173255053820")
addappid(490954,0,"3b52156be7150493ce00dbf39ca45759a5bcaa9a978b2b4810f125083fa0ba7f")
--setManifestid(490954,"8193577221124260177")
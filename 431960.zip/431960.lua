-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 431960's Lua and Manifest Created by Potatoes9411
-- Wallpaper Engine
-- Created: May 17, 2026 at 06:59:56 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(431960)
addappid(431960,0,"db983bc58a8cb46d89d1d70cc962cc733956e6124c4025a0c932f82b3c37144a")
addappid(1790230)
addappid(431961,0,"62ac71786b9fbeecc473fccb8a14da04ea676371addd8820638ee6cddac8c344")
--setManifestid(431961,"5641376293592905073")
addappid(431966,0,"3217352ccc45b8943d6af58c14d359a38f2897bcf4d2f7f7eb117f79f1887fc4")
--setManifestid(431966,"2667361956895452971")
addappid(1790230,0,"28aacfb757c396f07f861f189a2c2ec78653123de2177c05f94a792d1a3c8bfd")
--setManifestid(1790230,"4193888996927260780")
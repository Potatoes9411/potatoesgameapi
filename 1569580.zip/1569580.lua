-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1569580's Lua and Manifest Created by Potatoes9411
-- Blue Prince
-- Created: June 17, 2026 at 06:56:41 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 2
--   Depot 1569092: Blacklisted
--   Depot 1569091: Blacklisted

addappid(1569580)
addappid(1569581,0,"31965c819c33220b429da9fb8d633a2620f3b2b9e5f7ad47380878b719d85861")
--setManifestid(1569581,"9132564410772864984")
addappid(1569582,0,"cd0afbef3ec1283eefbab01fed34936a9d624cfdb0061bbed4662097d0d9d66e")
--setManifestid(1569582,"6514168308904611575")
addappid(1569583,0,"6dc8f52fe7e1127a4c9a0da6a7fee1874d73046b9b1678d92037c85e7feaef9a")
--setManifestid(1569583,"7704131677881731816")
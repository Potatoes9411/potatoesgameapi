-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1569580's Lua and Manifest Created by Potatoes9411
-- Blue Prince
-- Created: May 16, 2026 at 04:45:49 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 11
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(1569580, 1, "Unknown")
addappid(1569581, 1, "31965c819c33220b429da9fb8d633a2620f3b2b9e5f7ad47380878b719d85861")
setManifestid(1569581, "1303858350153209814", 0)
addappid(1569582, 1, "Unknown")
setManifestid(1569582, "Unknown", 0)
addappid(1569583, 1, "Unknown")
setManifestid(1569583, "Unknown", 0)
addappid(1569584, 1, "Unknown")
setManifestid(1569584, "Unknown", 0)
addappid(1569585, 1, "Unknown")
setManifestid(1569585, "Unknown", 0)
addappid(1569586, 1, "Unknown")
setManifestid(1569586, "Unknown", 0)
addappid(1569587, 1, "Unknown")
setManifestid(1569587, "Unknown", 0)
addappid(1569588, 1, "Unknown")
setManifestid(1569588, "Unknown", 0)
addappid(1569589, 1, "Unknown")
setManifestid(1569589, "Unknown", 0)
addappid(3711820, 1, "Unknown")
setManifestid(3711820, "Unknown", 0)
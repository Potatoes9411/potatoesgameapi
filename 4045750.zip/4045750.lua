-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 4045750's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:53 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 5
-- Blacklisted Depots: 0

addappid(4045750)
addappid(4045750,0,"7292294ea87a8320a4bf9731512c6b855e910e958e32bf67b75509ff23851095")
addappid(4045751,0,"0b09a6323362eb6bda1279c8790a9b9faed511ae10b479b7b5a46c33e609d0a3")
--setManifestid(4045751,"8862685196536544040")
addappid(4045754,0,"c7ed0aafddefa68c4660d766e924ae42bfa9af66c0b583de3ad6d66ac617d2cf")
--setManifestid(4045754,"809842075671574782")
addappid(4045755,0,"d3b14eed0e970855d5e2df26c78847df9be3f4da9ac40475472debd350298f28")
--setManifestid(4045755,"2530352793748856015")
addappid(4045756,0,"11bff2c5c774b201b508f057b9d702716844e71811fb8585df98b1717f2db944")
--setManifestid(4045756,"6034438425758270223")
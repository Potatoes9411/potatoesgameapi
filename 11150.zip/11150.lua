-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 11150's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:55:36 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 10
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(11150)
addappid(11151,0,"6b8194c797de2d281e6c2b55c62461a778d731328a5269a796e35edc29a75221")
--setManifestid(11151,"7547194125679736244")
addappid(11152,0,"2cf07cc119e87a96f368c25fa74a86fc080dcc216878aede55928c5d4297b124")
--setManifestid(11152,"3623180116095449921")
addappid(11153,0,"79df239022e2206f5af118f08fdf999ee7546739ea8198ffd5e9554daf312617")
--setManifestid(11153,"2964504932638963053")
addappid(11154,0,"ef39e64e61d55817f911832ee7e5c063feaab1311b93612ad09c84c398f9249f")
--setManifestid(11154,"2739481447202062897")
addappid(11155,0,"bf05245884cd5cb93a53900fb9dc4f04f640762df345ff559a6f7897d21c01ba")
--setManifestid(11155,"6243124326530683514")
addappid(11156,0,"52af241c2df73eef471fefb71b4fe3dabe8c46b51e04e1e7fa3cea6e5e78e5cd")
--setManifestid(11156,"8248282478733966925")
addappid(11157,0,"aeb858a2069d493719ef5d93ba9563c3cde8eeaffc3bc457c9b820f668a238ea")
--setManifestid(11157,"7344101483694084551")
addappid(11158,0,"0ceb8b472e4ec7086cc632c02a8f45afe656760faea2ea5f6205a185457001fd")
--setManifestid(11158,"5911043117879378202")
addappid(11159,0,"8a1cd43e13e1b4e5732682a14dd901a62f87d3c347ea0fe89fbe5c12cf6a4904")
--setManifestid(11159,"1224818727493631833")
addappid(212331,0,"5b470445487deb606012aea378cd061b9930382d172ae06b2e631e8512f8e222")
--setManifestid(212331,"5656265049979908692")
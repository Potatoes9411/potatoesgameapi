-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3595270's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:37 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 47
-- Blacklisted Depots: 0

addappid(3595270)

addappid(3603450,0,"729168405a0d1171f42a3d94541d9e17a0c4f42fbac19df315ec777e49c1b239")

--setManifestid(3603450,"8580219281574796647")

addappid(3603460,0,"9d1af2a2772c7609f565db8dafd7b69bab4852bb988208cdb670e6a52729fd80")

--setManifestid(3603460,"7511090104467066801")

addappid(3595272,0,"4086d876414362977890e32aeb7aabcce058599bd6a954808d6604011a4c77b1")

--setManifestid(3595272,"9053682250443204265")

addappid(3595273,0,"dae927e306ed94b925fdb577c5a2eea433edc1a9ea4d2fb4014c4f5bdb9a665d")

--setManifestid(3595273,"5004507027799148762")

addappid(3595274,0,"e90b253c7eb92b7993543dbc20b89149d04b50bdfd5e2773e2fbd086ff3f2c54")

--setManifestid(3595274,"2640321209699719569")

addappid(3595275,0,"54884b7ba7572661a56b77b8cacdaf1a8d9afafbe86703ec1c5864954e5d5847")

--setManifestid(3595275,"3321574838033002752")

addappid(3595276,0,"a6aec9f4d58bac77dd6c3784f33f700ed14ebd69544025a60191bf4a8045593e")

--setManifestid(3595276,"1770792621228626680")

addappid(3595277,0,"c924be704a46718a204b8b589d4f4077d7c91bc0f254f969ef067a76cef50547")

--setManifestid(3595277,"2510723612240406989")

addappid(3595279,0,"90989e3b394461a5ce8470a4c85435a0e7ccf6666006a93179c5f3d20073a42c")

--setManifestid(3595279,"4060459897973560604")

addappid(3603221,0,"b1acc836f4c2e1c8e4e634332f6bfc433b49fa4b30270bd79b42f5fdfe8eca8a")

--setManifestid(3603221,"5808758743313524152")

addappid(3603222,0,"4d69755e9f878111c1156b44a4e0cec867db4f29c1ea639b8dd2437562eb3226")

--setManifestid(3603222,"7933951097224280613")

addappid(3603223,0,"57adb7266d6a4e0c8af8776627b969e07636f8e860edd5de4c287878a762111c")

--setManifestid(3603223,"4892727090779451021")

addappid(3603224,0,"1fd6118261395673e49591230fa2c0a14520ca727c533730119dc1d95663643a")

--setManifestid(3603224,"2528367951215410258")

addappid(3603225,0,"a267fa386dd448a6549c40fa1ab3f5a5695a9f0969ad705bb95a59f074a11ffe")

--setManifestid(3603225,"4639348059805469892")

addappid(3603226,0,"4809a6a3de3e6180544c5ae0f017d3a95d69535f561a5a6664d0c3fdab180afe")

--setManifestid(3603226,"3795099037207734476")

addappid(3603227,0,"aff8fe35e482b3e3531f5e6736f52a034e51ac2ae7b1fecda2c6cc2d53fcf5e8")

--setManifestid(3603227,"919026984939734690")

addappid(3603229,0,"2ec7842c457de11898a60de77c894c438bd73e8226acb7630978d909f9247dd0")

--setManifestid(3603229,"8478402319748958625")

addappid(3603234,0,"7a30dd7cb27c6823e59d9c8de4bb5fc75f64dabf0e216ba6521bd1afd86a65c2")

--setManifestid(3603234,"4037436283071539951")

addappid(3603235,0,"72a75190903056bae90a391831675118af9d161cb3c75b1fe3bd9f019e5d3183")

--setManifestid(3603235,"1778161117784506181")

addappid(3603236,0,"2527ef2ca04ded65bc35ba646940039a1c4ad3200250d5b877807cefa9015a91")

--setManifestid(3603236,"705815866476503320")

addappid(3603237,0,"b8e7fff461cbfe38576c7dbe50c6867922deb2913ff54d4c107f28ae3e39a7bd")

--setManifestid(3603237,"3733780824875703844")

addappid(3603238,0,"f020e73a72256c3082c6c33801ac0aa270bdab4362ea4dad814f559834ee5960")

--setManifestid(3603238,"4596859813053898092")

addappid(3603241,0,"638cc6dd649350fa52dfed99e868bcd4828fceff01440583baf016f110cff95e")

--setManifestid(3603241,"8589181863794489089")

addappid(3603242,0,"6803b7a85874c7f992acda10c557eb20bb1b51e6293c77b9bd88094a62b65d2e")

--setManifestid(3603242,"1328418601987960704")

addappid(3603243,0,"fcc0583a2b7b3761e835c5c6e73868fc64e3d226c006d410a86152e1641eff47")

--setManifestid(3603243,"5278791094223072147")

addappid(3603244,0,"459d850b551e7ff90a1280acb47a666098be257d37e719404c0998afe89c8dbb")

--setManifestid(3603244,"6336049302793324506")

addappid(3603245,0,"a9e38815f0942c072f25e9e3ae9cd0de2a8b0144583451712d2d0be3925eb820")

--setManifestid(3603245,"4042405204667399567")

addappid(3603246,0,"866aa782e489fa65a531d5f8705b4952296a3f00cc79cac040d839b886536a2f")

--setManifestid(3603246,"4700826504309475517")

addappid(3603247,0,"ffdce0d8abb90981c0b815856c2c8aa2d519401c5cbfbafab536b2a1211c7e5f")

--setManifestid(3603247,"1449642798063902133")

addappid(3603248,0,"7eec7f74589a1b486adb47e418d57d72b2a205d2e5303ff81e3c83a070709299")

--setManifestid(3603248,"8714910702666389722")

addappid(3603251,0,"1fbbf9543f2ae50498215aa68b2f6eaf1c6f1a8d9e5737fb059184741f3cc4b3")

--setManifestid(3603251,"452349824044422082")

addappid(3603275,0,"5ab825dc9a9ce12ed4c80b8c2350c71c045889faac2b0ead2da40b5bd6f3d383")

--setManifestid(3603275,"97812279956230496")

addappid(3603276,0,"8e4afff2de1cf7e10417dcff72dfe50a0e3105c47eff17ffcef027a3deaac61c")

--setManifestid(3603276,"1369588035072732785")

addappid(3603277,0,"0c3755b90ad768ea9d8ac6947724b80867b35f67d07863e9af44e3089a9b5723")

--setManifestid(3603277,"6297716946734525264")

addappid(3603278,0,"42cc510757e9449645e00dd6ae385c6502721e11525b1f603e4708e0e3b95553")

--setManifestid(3603278,"8133311708430158098")

addappid(3603279,0,"5a7187da353db70e9aaba630148b691f7b450b39e355a6765c85c5406a3671f8")

--setManifestid(3603279,"6144240833866283421")

addappid(3603451,0,"1bdfb520bfe32bf9af2011ea78aeedec8ea9a5e0fcbdbaa0973097d11cc0b707")

--setManifestid(3603451,"6180838982390363752")

addappid(3603452,0,"bc4b43ebf45cbea4766fd6a2d932be8e841386e41e0854a721562aafe45e29b0")

--setManifestid(3603452,"7268065244632429599")

addappid(3603454,0,"91e1c77841db361758f60be0af67862ba2535269ad2c3c380d78eac24cd2884c")

--setManifestid(3603454,"7096404458273370471")

addappid(3603455,0,"cfa0b79d857b950afa6219f374699086df42ce4ebc796e43629ef867f3d05562")

--setManifestid(3603455,"1451975185421700799")

addappid(3603456,0,"5dd2c23dfc20fa0c60cd539fe42e818bfd153160334ff4992d779bfcb8da2a01")

--setManifestid(3603456,"1244644096707602098")

addappid(3603457,0,"94848b96b8f49eda8201959040f2726d4501405868b306e6b9ce2269dd3998b2")

--setManifestid(3603457,"6609842957503039205")

addappid(3603458,0,"1656432baf1cddde5db3a6f7cfc9b22a58c73f7cb496e2acf688fbbdaad813b2")

--setManifestid(3603458,"1916426486978008368")

addappid(3603459,0,"8d1de9447a508c9b64b932dced11b498b9fb60f61c378c552eb9f32ac9f759ef")

--setManifestid(3603459,"19980072663409511")

addappid(3603461,0,"3dc0d375a5126bd0e945a045622f37d8ee921055e762b02b3649d06d8b23db7e")

--setManifestid(3603461,"6224774448488382765")

addappid(3603462,0,"5e20fdb9fc04c0a540de571fddd01811962693c4c4046ddb8e62595f7e6a72d8")

--setManifestid(3603462,"4616304644189679996")

addappid(3603464,0,"e737e49205073cc67c92b462a1a247f3a3f1df8514f95b181676fc1f33a28360")

--setManifestid(3603464,"5696464031355307078")
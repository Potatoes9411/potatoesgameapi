-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2863680's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:01:11 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 2
-- Blacklisted Depots: 4
--   Depot 2863641: Blacklisted
--   Depot 2863060: Blacklisted
--   Depot 2863080: Blacklisted
--   Depot 2863180: Blacklisted

addappid(2863680) -- ZERO PARADES: For Dead Spies
addappid(2863681, 1, "6f8570b7626034b90d4244ec942a2e30b85f4a6c139c76622a364117e5e49be4") -- Depot 2863681
--setManifestid(2863681, "1416711104331163916", 10521977303)
addappid(4719150)
addappid(4719150, 1, "9ede90e3a696df35e824df54f8a882256941165d2b283859e3a422c7dccf75bb") -- ZERO PARADES For Dead Spies (Art Booklet) - Depot 4719150
--setManifestid(4719150, "6005577581934271192", 59547847)
-- Made by F1uxin, Discord ID:965053505901588521 | Discord Server (TGP | The Galaxy of Pirates): https://discord.gg/VfCxRsFyFe

-- If you're interested in distributing these files please dm me on discord (UserID:965053505901588521) 
-- (I don't care if you send them to a friend or to help someone, just if you add them in your bot or have them widely available then i would like to know.)

-- Socials: https://guns.lol/f1uxin

-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid", save the file, then add the lua file, (i think you can add the manifests too but I would just add the lua file to ensure it works).

-- If you have any questions feel free to dm on discord (UserID:965053505901588521)


-- Main stuff to actually add the game, DLCs, & depots.
addappid(2863680) -- ZERO PARADES: For Dead Spies
addappid(2863681, 1, "6f8570b7626034b90d4244ec942a2e30b85f4a6c139c76622a364117e5e49be4") -- Depot 2863681
setManifestid(2863681, "1416711104331163916", 10521977303)
addappid(4719150)
addappid(4719150, 1, "9ede90e3a696df35e824df54f8a882256941165d2b283859e3a422c7dccf75bb") -- ZERO PARADES For Dead Spies (Art Booklet) - Depot 4719150
setManifestid(4719150, "6005577581934271192", 59547847)
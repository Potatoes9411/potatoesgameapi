-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3845600's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:48 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(3845600)
addappid(3845601,0,"2d8364f2c5ac538d21eae15a9d72aa05fb83c2441ae893803d6b9f071569d3fc")
--setManifestid(3845601,"4832271126686775499")
addappid(3845603,0,"d86ad6f2608d9e73d3235bafa31f6f32940bab52b0445e4f43835890739f0c84")
--setManifestid(3845603,"619247420104831004")
addappid(3845604,0,"a4a7fde02df89e85d3e99cf4bbb9a9ca65d438fb483fc1fbd15554d6272cac1a")
--setManifestid(3845604,"6420451039250001022")
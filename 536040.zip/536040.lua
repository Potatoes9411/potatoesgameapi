-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 536040's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 07:00:02 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(536040)
addappid(536041,0,"9dc7b0c71a8a9557fd972577682adf9adc5929fa55aa4c634ad039942f4220cb")
--setManifestid(536041,"4552808971983854447")
addappid(536042,0,"138984c3afa77ad33fdf49b904883fb991f0032c11a89378ecf0b8e6fa1d229e")
--setManifestid(536042,"8897422091382040331")
addappid(536043,0,"4e5c701b211cbeeb2d23fab3f453c3f099369d8e777ca36c8736bba8bd11cecf")
--setManifestid(536043,"2869765756390153286")
addappid(536044,0,"f23b157601259ca603a5af06c768354fc53ef8992fc0f14e58ddbe66a35f422e")
--setManifestid(536044,"2864909492431199848")
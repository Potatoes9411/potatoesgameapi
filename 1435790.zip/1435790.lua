-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1435790's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:56:30 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 30
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(1435790)
addappid(1435790,0,"dc4fc1a6086c3fec14fa8c15648fb902bdece70b871d7cca5a69506011b30f0c")
addappid(1942100)
addappid(2000170)
addappid(2175260)
addappid(2419810)
addappid(2644870)
addappid(2644890)
addappid(2843390)
addappid(2879620)
addappid(3193660)
addappid(3972570)
addappid(1435791,0,"4057c2e4d3083f052c881b031171988306f2bde449c77ab6cfd5541947857170")
--setManifestid(1435791,"1395331211382412270")
addappid(1435792,0,"8b3951f256821087d5326a05a2cf23f36379373dec625c63ec7f4c7cdbdb13a0")
--setManifestid(1435792,"6582109039461736254")
addappid(1435793,0,"d04510be8de95b7ea005909ec5ea68132911a2111a19da874f06676b970fe273")
--setManifestid(1435793,"4584824974729317396")
addappid(1942101,0,"94bbdab36b8a43027b43ef0ba68f9f65364dad25e65ae6cef303120421471d52")
--setManifestid(1942101,"1534680646323210663")
addappid(1942102,0,"db33217a845d1ff6a94526b18c5594f0749bc6db1db16d2561cbdaebcb32610d")
--setManifestid(1942102,"7841559841278405606")
addappid(1942103,0,"221a7c112dc519ce94404f8df55a834fdbcae272f816efe386e3bfc4897d31bd")
--setManifestid(1942103,"6040600248402492465")
addappid(2000171,0,"6fd96776a4f0d78d1a785948c00a3370ac28152ddb9dfb900eb12f445edb569d")
--setManifestid(2000171,"544960132068981305")
addappid(2000172,0,"3a6668a7a6dc6d1cb5e4ca343ba7a351ce715eaaaacb3921d512fc459506bc4d")
--setManifestid(2000172,"7822348840246250794")
addappid(2000173,0,"3e99148664ebfc54b2115a527ec7f0a788a617cbdf9be34a06ee494f7e815926")
--setManifestid(2000173,"1479351674591888670")
addappid(2175261,0,"de314519da801ba0df61d5dbeebaa2a4b681c21e55f4f90df3172608579740f2")
--setManifestid(2175261,"4554297078629761298")
addappid(2175262,0,"88ed3d5073016506f4008c64c5a2249622f3c2317cf109a43313af649d2fb7a0")
--setManifestid(2175262,"5553074800641849326")
addappid(2175263,0,"b2067039860ecfbbef633b648fb29a7f5438e94f1a4f7770fa4e272249daf43a")
--setManifestid(2175263,"7234441360137336478")
addappid(2419811,0,"38e760cda6c0e0a518b9d4f01513b48cd3860150d6a850e6b73ebd68dad642bb")
--setManifestid(2419811,"8181146344485940014")
addappid(2419812,0,"2dd31bc062412c20887664b718a748b8a23b96dc56411aff87809afa74045c7d")
--setManifestid(2419812,"247133852256229809")
addappid(2419813,0,"64fc8e30814b1163287fbcb311b54a7579eccb77a3141fb30a90a3437f7f3864")
--setManifestid(2419813,"6696910378805345569")
addappid(2644871,0,"8db0e32271fe81dc31e2181673a06a52dceaa00e7ed671e8bd301c8aae61b597")
--setManifestid(2644871,"6407125016437847843")
addappid(2644872,0,"f032cb22636e7bc7db98c9a88485a179121feef3e093809d1e2233815a9b0f0b")
--setManifestid(2644872,"8835743958767427024")
addappid(2644873,0,"cc56d0e0e0bd69367bd8d6a9dea798b5711718e0684d3a21e1f3a3a324fb72ca")
--setManifestid(2644873,"2025263818566943515")
addappid(2644891,0,"cf3c2c613e9f7a37e6270a585eb2b4adc94756b12b38d63917bf6c317b5c142a")
--setManifestid(2644891,"7243949069247745797")
addappid(2644892,0,"080e0d23f2b479583a982b399098e016729270b1d89c48856da3fabd40f9b814")
--setManifestid(2644892,"1876460747319217344")
addappid(2644893,0,"b6704f28a017405e2e6419d42727d104d8645285f15ca501b6fa184254b333b2")
--setManifestid(2644893,"1922692175112638791")
addappid(2843391,0,"3c4de5a39a2a16aab580fdaf965410fea8c7cfd3ac4abbcb5b0615f4dfe87479")
--setManifestid(2843391,"7258005221969580784")
addappid(2879621,0,"98e8839ac92ed3f458755d7ed994b25b3f152d1b665c72b088468eb2f5ce0d71")
--setManifestid(2879621,"1243717326532108995")
addappid(2879622,0,"b26e18d223fad8dde74ad4e1f996f896b50a813b764d563066f69e79f111987b")
--setManifestid(2879622,"1914535262038615556")
addappid(2879623,0,"c5c28e20f89f33b30448a228ea85aa2533a9c313bfddcb74bdf2777775683c4e")
--setManifestid(2879623,"5717225719696203399")
addappid(3193661,0,"bf40c73a0e77967ddc30859ca94aa4e4d2b7da47f132fe9ef5b403ea6c8f8239")
--setManifestid(3193661,"4760553673854196860")
addappid(3193662,0,"f05e1412e708a34e97be6aa14db6ac2402c42cf9dd838f0545ded77a1581cb5a")
--setManifestid(3193662,"7727191578338045427")
addappid(3193663,0,"455b6c7e6a58f501d72f19cbc64ede33686950062b1afacba974e16056f2894f")
--setManifestid(3193663,"8053838337269895168")
addappid(3972571,0,"bacc08147e046c64e1b55a5f84bca359f194493d9cedfb954ffd8644d6f0a704")
--setManifestid(3972571,"2069522345408067866")
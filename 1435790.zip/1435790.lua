-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1435790's Lua and Manifest Created by Potatoes9411
-- Escape Simulator
-- Created: May 16, 2026 at 04:45:47 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 21
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(1435790, 1, "Unknown")
addappid(1435791, 1, "4057c2e4d3083f052c881b031171988306f2bde449c77ab6cfd5541947857170")
setManifestid(1435791, "1395331211382412270", 0)
addappid(1435792, 1, "Unknown")
setManifestid(1435792, "Unknown", 0)
addappid(1435793, 1, "Unknown")
setManifestid(1435793, "Unknown", 0)
addappid(1435794, 1, "Unknown")
setManifestid(1435794, "Unknown", 0)
addappid(1435795, 1, "Unknown")
setManifestid(1435795, "Unknown", 0)
addappid(1435796, 1, "Unknown")
setManifestid(1435796, "Unknown", 0)
addappid(1435797, 1, "Unknown")
setManifestid(1435797, "Unknown", 0)
addappid(1435798, 1, "Unknown")
setManifestid(1435798, "Unknown", 0)
addappid(1435799, 1, "Unknown")
setManifestid(1435799, "Unknown", 0)
addappid(3972570, 1, "Unknown")
setManifestid(3972570, "Unknown", 0)
addappid(2644890, 1, "Unknown")
setManifestid(2644890, "Unknown", 0)
addappid(2419810, 1, "Unknown")
setManifestid(2419810, "Unknown", 0)
addappid(2175260, 1, "Unknown")
setManifestid(2175260, "Unknown", 0)
addappid(1942100, 1, "Unknown")
setManifestid(1942100, "Unknown", 0)
addappid(3193660, 1, "Unknown")
setManifestid(3193660, "Unknown", 0)
addappid(2000170, 1, "Unknown")
setManifestid(2000170, "Unknown", 0)
addappid(2644870, 1, "Unknown")
setManifestid(2644870, "Unknown", 0)
addappid(2879620, 1, "Unknown")
setManifestid(2879620, "Unknown", 0)
addappid(1779700, 1, "Unknown")
setManifestid(1779700, "Unknown", 0)
addappid(2843390, 1, "Unknown")
setManifestid(2843390, "Unknown", 0)
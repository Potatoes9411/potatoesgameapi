-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 108800's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:55:32 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 11
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(108800)
addappid(108801,0,"7524f88042c40cddc00d3a4d9a3887f14432d907b9e2037a48f7d597f904f385")
--setManifestid(108801,"4435336190133065638")
addappid(108802,0,"69040cdd3ff6a14bc1aecdeb3a06879bd50598a251a38ea5d43bf547647c6102")
--setManifestid(108802,"4881587595324762365")
addappid(108803,0,"33673c96b61267bb9202e0ebe9626d830db3feef3e86f2ba548612f12c4d3d13")
--setManifestid(108803,"4964356744059286797")
addappid(108804,0,"01000a281bf0caac31f0fbd0aebac8a2515e8f987ae29dd05ee5833334ad1e9d")
--setManifestid(108804,"7091676493200822311")
addappid(108805,0,"34c37d55f890fe2a85086fa82f090ec18001558ddbd9623269a5669bc3b837cb")
--setManifestid(108805,"6267119516148811252")
addappid(108806,0,"4fca762cefee410e93f011482ceacdd8b6dbbf38ea1ab22154d32df728e17514")
--setManifestid(108806,"5963919717102499067")
addappid(108807,0,"6088d0f5f9c9b26b0f08a4549ed8823fc82d13b43bcdc6db90523a775fa5f2a5")
--setManifestid(108807,"7516132942479836678")
addappid(108808,0,"c038da063908c97e01fb14b57a7f800294070f64a3bbe75bba4b1ddeeed30ade")
--setManifestid(108808,"1617765526315783219")
addappid(108809,0,"296114ec58bcdb18a6fdb656a9c287ff4f5f05a1334fb1a697eb480d25f6e162")
--setManifestid(108809,"7342531331099624233")
addappid(108810,0,"cb2ea2f9940fb488647eac02d30308671ac6e64f6e601c6479d51d7d7fb32bf0")
--setManifestid(108810,"6341353486687586219")
addappid(108811,0,"a473fef39094e0c65952cf107c9dd2061b79e346929749b00761b17635df5c40")
--setManifestid(108811,"3712559361882134850")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1868140's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:14 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 9
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(1868140)
addappid(2492320,0,"80467121a86d6b38971889737a91b309bb3aa329fee8e93ac63f2748f43fa063")
--setManifestid(2492320,"8303250180391868718")
addappid(2677020,0,"0f12757b1a8cc78265828ba98e12b673ff97e942bbfd3ae07eca6d10f6b8dfcf")
--setManifestid(2677020,"3523098559722946035")
addappid(2677021,0,"794d4476c6913ad8568af8bf1303f216b1f16b3d6041f62834536fe460d661dd")
--setManifestid(2677021,"2579806968208051974")
addappid(2841140,0,"a5e4472216eb53c5abc48c617b42bc740a1fac4adf25659c183015a27f8849fb")
--setManifestid(2841140,"5969075150231517220")
addappid(2841141,0,"a6863e71aca974796ecc6423cb6d8b9820fd11e9df7f06bcbaa7a1926227f77d")
--setManifestid(2841141,"1811376077504623732")
addappid(3543180,0,"5dbf7b425cf6ac47d95a2abe30926e2c845f6b9fbf05903c27837624a56b6b66")
--setManifestid(3543180,"8491586211128714786")
addappid(3543181,0,"fda6ac6e3da3645d6c445ad4c68bffd11640df814da698f3fb85db7ada2a388b")
--setManifestid(3543181,"1623285286579638098")
addappid(1868141,0,"dec1482ee88e2a62d7fddedf0e75c6abdef55d2884440de6508bef83044198d8")
--setManifestid(1868141,"2704810792193494396")
addappid(1868142,0,"f55cec1c353af17ba294e0bc3c1af6766a91b76e97d59d44425873918058d6c5")
--setManifestid(1868142,"3559519271332288570")
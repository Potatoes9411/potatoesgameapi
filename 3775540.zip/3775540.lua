-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3775540's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:46 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(3775540)
addappid(3775541,0,"B953EFA0F900A657E9A6EC52343ABA98022AA9F7C06D44C5D8D6FD041A700BEB")
--setManifestid(3775541,"7785375471511776069")
addappid(3775542,0,"B6A74777C4104D6237764CFA69D7BC1AB2338315575A7BE08964A6492A910082")
--setManifestid(3775542,"2126758935928042576")
addappid(3775543,0,"E994B95DC13D1E3FB9D031A3017687F3AC500ECD7AF553F8DD339ADD967C6C5A")
--setManifestid(3775543,"1754716595677865532")
addappid(3775544,0,"C518AEAF366F333BF1028B6E6F491F6EA146B55277C4D6917279D98D4396068B")
--setManifestid(3775544,"3902621252671417291")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2169200's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:03 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 23
-- Blacklisted Depots: 0

addappid(2169200)
addappid(2561520)
addappid(2729150)
addappid(2800240)
addappid(2800250)
addappid(3003600)
addappid(3003610)
addappid(3003620)
addappid(3003630)
addappid(3258690)
addappid(3618300)
addappid(2169201,0,"f0442f7884739333bfdcc7544a60a639ccf65a344fb7e5312d81b71d53f3483f")
--setManifestid(2169201,"7391481385941074802")
addappid(2169202,0,"01734f2ec3ffff33c42ef6f7337642950f08f3d7251d72eead052011085536f6")
--setManifestid(2169202,"1865254937317479303")
addappid(2169203,0,"e6c06bbeb1a3f7316704546bd26db1ec93406963a3d84d402a9e31956f8b7cc7")
--setManifestid(2169203,"7139550291347173555")
addappid(2169204,0,"d11132ae9b8705ec81f29311b269dda0811ffb55d25dbf766eadaac3660ad7f5")
--setManifestid(2169204,"372530551937361395")
addappid(2169205,0,"cfdf61799a0c9e8ec83eb607ab4fd3482ee99d700d99eb6d6d194f0f41360faa")
--setManifestid(2169205,"4461957118771003967")
addappid(2169206,0,"58856b5fdc9f0115eeef7fa218522ef3f74c223a794906e53b01541c82b9f32e")
--setManifestid(2169206,"1047435328961232841")
addappid(2169207,0,"f2266e1c1d7f21bcf969ad780c66debeaf32eb3d564ed083458f9d64ef89d1c6")
--setManifestid(2169207,"3300678429426280478")
addappid(2169208,0,"7130b3aa6ad5e700afca9674a124616dc9d04c226ebab6453d98cab4d8dfa2d1")
--setManifestid(2169208,"5843923210413641436")
addappid(2169209,0,"d722416d284d1778f0911b4c0577c3e6864b72100d39bdea21056ade0129251b")
--setManifestid(2169209,"3901507899860555469")
addappid(2561511,0,"ed396bd5a04dcb8cbf85bfb20018ce8905c58a3f245459ca2c4f18f036a5d932")
--setManifestid(2561511,"3740802027707569957")
addappid(2561512,0,"edd809a64000a91fb3ac08691ba68bbcb629ea6f693c9811c3c32679ce936be9")
--setManifestid(2561512,"6751910486874420582")
addappid(2561513,0,"fc8eca9e12e0f3bf1fb24524a1703fcc77a1f3f636afe8ac954922d202d3989d")
--setManifestid(2561513,"2873633407686130884")
addappid(2561514,0,"81aa2260b9d0d8a0a4e194dee301d61e683d6aa6aa151e20ad351f579b9ce991")
--setManifestid(2561514,"6889488596835225992")
addappid(2561515,0,"db078358a476eb1b8549563936329da856dcdf7f2dc1b5deeec74eaf78d679c6")
--setManifestid(2561515,"3195328302612406793")
addappid(2561516,0,"1c448e10003fbe6f2be8716ca09189c53b2bd8dbfc36e6abe243d7736679a458")
--setManifestid(2561516,"1189735114395280860")
addappid(2561517,0,"444cee8f5e54fc5971ae18ec553fd532307d6ba3b9d11036cc8a143b36f32f38")
--setManifestid(2561517,"6263522995165149636")
addappid(2561518,0,"6439c73ba8f70236c8e73c167af4b04bbc5f2476ffab4554ccc1340e466a4c2d")
--setManifestid(2561518,"3608856189875224965")
addappid(2561519,0,"6a940a58a5b3e5fe4b41c87e7d1e8fe5339025a1934e46835f0146b2f2a4e0ab")
--setManifestid(2561519,"1191642172033623765")
addappid(2561520,0,"e9782dcff591c25264d47b0a83c5d9738ae22a2456e4d7fd5eba2ce17858d21c")
--setManifestid(2561520,"4740185705261078409")
addappid(2561521,0,"9f465c45d74c657d4af3adf7d4048c896868b411ec45d6dde4cc057d5fb0c7ae")
--setManifestid(2561521,"622305630631083236")
addappid(2729150,0,"9008f4414e442c17ceb0d7b181d9da5a763bb6407bef14f212f915e57c7e921c")
--setManifestid(2729150,"7327088656667926825")
addappid(2800240,0,"28250feeef899032c0de5ae470b5a9b880ec93ddfd6afe2ed52ed6604ae09ea9")
--setManifestid(2800240,"3684063861755512692")
addappid(2800250,0,"27f94daae928259b037667abc464aaa7cac0901503e2fea07fe5e7abc114468d")
--setManifestid(2800250,"1513378400177448501")
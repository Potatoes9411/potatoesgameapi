-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3743220's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:45 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 1
--   Depot 3743791: Blacklisted

addappid(3743220)
addappid(3743222,0,"66d99230b885450aa77e941f79333f71fa34472861fa6df267f87f4894039880")
--setManifestid(3743222,"8078622772073584677")
addappid(3743223,0,"e7cf459d4a688b0f8b2fcc61d2171c5cfcb2fbf598689ccf2485685d9eaaa149")
--setManifestid(3743223,"8755718503293806543")
addappid(3743224,0,"1e41b3ea9a5bf48d7d86ca3c010c94905d8ff3d5a1dc2092724a385e61933831")
--setManifestid(3743224,"4446386664752867196")
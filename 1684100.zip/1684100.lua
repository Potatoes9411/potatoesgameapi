-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1684100's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:50 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 3
--   Depot 1684151: Blacklisted
--   Depot 1684148: Blacklisted
--   Depot 1684161: Blacklisted

addappid(1684100)
addappid(1684101,0,"5f25649f14ebfebeb81cc617218e9ed5418475d0241f6d6cf70664969c648774")
--setManifestid(1684101,"7300993127463195638")
addappid(2653141,0,"149c234e65d978baf98b0f088119541e7d8ba7d1e7a256e1cbfa8ed1f37e776e")
--setManifestid(2653141,"8260885836823937985")
addappid(2937321,0,"07e3f6b774b5ce78db545e594f9091878173f1f5d53ac754e8212ffd2033b264")
--setManifestid(2937321,"441475081072007658")
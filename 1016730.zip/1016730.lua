-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1016730's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:36 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 7
-- Blacklisted Depots: 0

addappid(1016730)
addappid(1066120)
addappid(1066121)
addappid(1066122)
addappid(1155280)
addappid(1337470)
addappid(1337490)
addappid(1684600)
addappid(1016731,0,"2642a4cca1e180519a9b2838383fd35473c1d563dc5657cac08d19b4629803d0")
--setManifestid(1016731,"2672767003703122461")
addappid(1016732,0,"6f38a190b4a3d4b5799f4fe91f4cbff84496b7a6efb03541b98e494a12dd70ec")
--setManifestid(1016732,"3086358498298086895")
addappid(1066120,0,"440b9ffd0f213b364f4b8dabd8dea2cd74ebebf8c799517e7744a2164d68364d")
--setManifestid(1066120,"4645205971323546908")
addappid(1066121,0,"56557a09fc0e1b0fec53fa3e621fab52465ff9c509cccf998f636fdc4a11410f")
--setManifestid(1066121,"5863948573184485952")
addappid(1066122,0,"d6396b279b77c8b412b53c84478faf4ba09dd0f6de5a5a58c427053d12db03f7")
--setManifestid(1066122,"8394522477907312706")
addappid(1337470,0,"19aed3a1f6a20150bdf311516fb5c7f239875420a0ce7dc0db8e0b977da99885")
--setManifestid(1337470,"220152035103203858")
addappid(1337490,0,"997fb1687b0baa0ee8e85bb2a1f930c4e97d1309555d0f74397ed5246a47980c")
--setManifestid(1337490,"1644789737085765564")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3401490's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:28 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 1
--   Depot 3401411: Blacklisted

addappid(3401490)
addappid(3401491,0,"b3318ae1c3e047f333c2fec2cfd1a7a185ffeb91baddf51527a2e025c0a1a744")
--setManifestid(3401491,"873211630557516061")
addappid(3401492,0,"dc9d90c73e408493cd7eab4e4b43e0deea19b19eb638bf253c3577a66bcea01b")
--setManifestid(3401492,"5190422057464815734")
addappid(3401493,0,"e2451bd1cc9819becfa9683190f86337a86c3e55de29fe6b189a4e6a7d3a2105")
--setManifestid(3401493,"4551696053572917218")
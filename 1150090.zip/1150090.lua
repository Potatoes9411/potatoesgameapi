-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1150090's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:55:40 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 5
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(1150090)
addappid(1150090,0,"114295aad80c3a7a9dfef2ce887278ff5d33a6498c2e0342e59280dccf5c5c94")
addappid(1545770)
addappid(1150091,0,"665c97034c7ae21a81c9c82e352ed9ff3c7e70626ed7afe9233db0bbed1cd939")
--setManifestid(1150091,"7190344543645704828")
addappid(1150093,0,"cba65e460e5550e33f89b1becb668701951d6782c4af8ac19d7457030344c294")
--setManifestid(1150093,"7274068230425681312")
addappid(1150094,0,"81dbda729176b415bd1b74f076ab2fab5490bc35377a56abdf34d05fd7a69384")
--setManifestid(1150094,"630835813530253190")
addappid(1545770,0,"b1ca321815b0580c756f28ee5ddf0a4386ad33c6f969d59b33b39a43b30fff83")
--setManifestid(1545770,"8025577116302565116")
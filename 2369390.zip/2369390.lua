-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2369390's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:59:17 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 4
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 2369901: Blacklisted

addappid(2369390)
addappid(2369450)
addappid(2369451)
addappid(2369452)
addappid(2369453)
addappid(2369454)
addappid(2369455)
addappid(2369456)
addappid(2369457)
addappid(2369458)
addappid(2369459)
addappid(2369470)
addappid(2369471)
addappid(2369472)
addappid(2369473)
addappid(2369530)
addappid(2369531)
addappid(2369532)
addappid(2369533)
addappid(2432590)
addappid(1716751,0,"84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
--setManifestid(1716751,"4132506267642462151")
addappid(2369391,0,"c3d84384b92e4ab8aa58ab4d8602f408821c5ce3b7a213d07d79926a6198180b")
--setManifestid(2369391,"5783041166523199015")
addappid(2369392,0,"39cb26249d996a7b6001a56e8ebf11968ce3f346f2342efa3ec20b88e203b405")
--setManifestid(2369392,"8390405336387105870")
addappid(2432590,0,"3b4498e4cb314f981631df47a5a260f6f0ea14bbbb77e50efa0c2810741435d4")
--setManifestid(2432590,"7910386811588276346")
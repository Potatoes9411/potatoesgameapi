-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2980150's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:01:36 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 2
--   Depot 2980272: Blacklisted
--   Depot 2980271: Blacklisted

addappid(2980150)
addappid(2980151,0,"f61acee8eab8eb2b89cdf449abc7c1f08df9ff9641e2939ca6f9958caff9fcbb")
-- setManifestid(2980151,"4067109039117956439")
addappid(2980152,0,"196f53da06ad05782f620df9d2b56802bee6b13b23ce0dc1214d6898828062c7")
-- setManifestid(2980152,"4914704048725186502")
addappid(2980153,0,"f74f050e9d5ebc025624f92f57e7a76ad6f7031f9b7fe81ce4d43c7cd0e2ec2f")
-- setManifestid(2980153,"3065387557767037479")
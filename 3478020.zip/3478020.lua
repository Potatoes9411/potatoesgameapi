-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3478020's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:32 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 5
-- Blacklisted Depots: 0

addappid(3478020)
addappid(3478021,0,"d50a230a39d4320b9c2e5629fc6d802bfc0bfadb498e9ed5797f3425801e9e60")
--setManifestid(3478021,"8315270358221846568")
addappid(3478022,0,"a75ea2f9a0ca2d971b6011f48272f843a2e5aa7e725470c71b93a1de7c7b1768")
--setManifestid(3478022,"8518149839876093110")
addappid(3478023,0,"73d93ee282976fc790061cffd555413125a15c1b40ef29614b9b9826b992e5f7")
--setManifestid(3478023,"6769502226721111542")
addappid(3478024,0,"881bed4824eaa496297c33bc8f25062634fef22b228673e0426426ed8165a21c")
--setManifestid(3478024,"8160522296337886276")
addappid(3478025,0,"90a406fdbbb3a3a013a5574cfc6d88ee82fa5717753d73ca48286f75d95608eb")
--setManifestid(3478025,"2357923969728241443")
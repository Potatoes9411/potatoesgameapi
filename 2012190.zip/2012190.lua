-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2012190's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:38 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 2012511: Blacklisted

addappid(2012190)
addappid(3587380)
addappid(2012191,0,"d563cc1e972880af6c0ef3a7d0074401446803137170f7d69b35db1a59764936")
--setManifestid(2012191,"6139768631577520420")
addappid(3587380,0,"6a475cee5719f87e97601b3387cfef5bc4f300e044aec62737bdde1f22de2a4f")
--setManifestid(3587380,"5204301460403512729")
addappid(3587381,0,"36fce335c938e7a5d6dc60d0da4c77e28dc145b3c7975a05e88390f1c9eede33")
--setManifestid(3587381,"6341949195255574136")
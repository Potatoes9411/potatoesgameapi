-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2282890's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:58:52 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(2282890)
addappid(2282891,0,"7c9c7c8375fb8bd11b85c3299da5ea2fbb018ab5740c2b4dbd5f94063f6e1413")
--setManifestid(2282891,"6551752376579802289")
addappid(2282892,0,"79c266a32e4385c60f6094869d0074d5135c7b4863d15b4c704d1c789ef44fa3")
--setManifestid(2282892,"3835580268048484261")
addappid(2282893,0,"785b1a60b2b10dd7c957ef2d68bafea1e02e0c06d8d55150f4687fc05ce9ee7c")
--setManifestid(2282893,"2639091027772801683")
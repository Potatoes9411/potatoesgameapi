-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2133760's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:58:01 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 4
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 2133831: Blacklisted

addappid(2133760)
addappid(3933690)
addappid(2133762,0,"d52e06a500706a15e7821f6a7c3e30d1a2bce0ea65b784d6a387cdadef756a78")
--setManifestid(2133762,"724256187143795574")
addappid(2133763,0,"788e7476ac625a7a50f7add2445dc120f1524ee6dc56b8f14edec6a2f954474a")
--setManifestid(2133763,"7207604678793379655")
addappid(2133764,0,"1ebff4822d7fe419fe87324ea8a05d3dc5b985322407afcd0ad15c10f340eba7")
--setManifestid(2133764,"5774273785074894040")
addappid(3933690,0,"afe1f7e926f8475241aa36f1c0c4df701ea991827e6844cb852793bf539277ab")
--setManifestid(3933690,"1526406310571522558")
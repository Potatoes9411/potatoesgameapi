-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1408230's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:56:27 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 1
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(1408230)
addappid(1791210)
addappid(1847170)
addappid(1906500)
addappid(2016530)
addappid(2086230)
addappid(2158180)
addappid(2208010)
addappid(2287580)
addappid(2338250)
addappid(2380460)
addappid(2434550)
addappid(2484900)
addappid(2528590)
addappid(2598430)
addappid(2652320)
addappid(2726330)
addappid(2790080)
addappid(2876630)
addappid(3041950)
addappid(3074270)
addappid(3078240)
addappid(3129060)
addappid(3220870)
addappid(3300630)
addappid(3338120)
addappid(3338130)
addappid(3400950)
addappid(3526580)
addappid(3680590)
addappid(3819440)
addappid(3974100)
addappid(4072970)
addappid(4112200)
addappid(4316510)
addappid(1408231,0,"801d8b1cbfc15f01db9306fd2300d43d12ac7cfa46ffde9b86425538d1966813")
--setManifestid(1408231,"7696422396341349269")
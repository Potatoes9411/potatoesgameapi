-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2285150's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:58:52 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 2
-- Total DLCs: 0
-- Blacklisted Depots: 4
--   Depot 228580: Blacklisted
--   Depot 2285944: Blacklisted
--   Depot 2285942: Blacklisted
--   Depot 2285943: Blacklisted

addappid(2285150)
addappid(2285150,0,"c25d9562d9a08deb3661a3d396e2b6d0b6d2796b53e02e4023068781c500f0af")
addappid(4115980)
addappid(4115990)
addappid(4116000)
addappid(4116010)
addappid(4116030)
addappid(4116040)
addappid(4116050)
addappid(4116060)
addappid(4116070)
addappid(4116080)
addappid(4261270)
addappid(4261280)
addappid(2285151,0,"1e7de60c1cc825964d43eb37232a95b15b7638fcd507b51001fa869d0a6fc67f")
--setManifestid(2285151,"5787996515613485417")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 345390's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:31 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 10
-- Blacklisted Depots: 0

addappid(345390)
addappid(360270)
addappid(360280)
addappid(373490)
addappid(373491)
addappid(384620)
addappid(385720)
addappid(385721)
addappid(345391,0,"d4d4504b2125d6ce0354f6eabee56c58083191c70dc6d164de4701b2faef7844")
--setManifestid(345391,"4994429950066138149")
addappid(345392,0,"b6876c56e183ab8f140817dea178ad5a2ecf805eda4721923235c431b346fc55")
--setManifestid(345392,"7537609144334940285")
addappid(345393,0,"7a7d6785df36c4ccd3e2ccee6369dfd9299c8e34be78bac7b84575479659d448")
--setManifestid(345393,"8949539713193871343")
addappid(345394,0,"2970194d74db9e005dcdb60191ec4a89775332a9236879aa7b36c4a15bd4d100")
--setManifestid(345394,"3092915760229310120")
addappid(345395,0,"079f8d390405e86e9cf05e1a2bdc7e938c297d29b1f34e65c2dbca5dfee3322c")
--setManifestid(345395,"6522583905759024897")
addappid(360270,0,"74029533a622ad699e715ab0aa3834d68b5a78b012b85f26f2d388bd2a8c0f77")
--setManifestid(360270,"648574608910822444")
addappid(360280,0,"0b1e68377dcb7eb77ccd2dfaa7387a675622360cee12c986e26cf05f1df6c4a5")
--setManifestid(360280,"3263640479152106158")
addappid(373490,0,"129e45d96f7844eaca21fe20e352050075f51ac03bfa4d0b3e829ea0349ea0c7")
--setManifestid(373490,"1464059817440716607")
addappid(373491,0,"ea68433b81f0d954b55518e66ece13f14f68b576db653d99806229eae82bd882")
--setManifestid(373491,"4195459067883297695")
addappid(384620,0,"0cf1155b7d4e71d4caa42e5e02548685146379ec00934e0536062faab677994b")
--setManifestid(384620,"949264708492472192")
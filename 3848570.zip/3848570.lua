-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3848570's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:48 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(3848570)
addappid(4094870)
addappid(3848571,0,"f10af5b9e5a3a7e539865577a5327b34b3b8c084268c3c9a6b28185c43709122")
--setManifestid(3848571,"4045423896164352546")
addappid(3848572,0,"4fd505c300c597a479bd2492102052c3cfcba9dee2b4fcde0eb915e6f4a68e4b")
--setManifestid(3848572,"358548408881299437")
addappid(3848573,0,"404378a96df50bc3f29eadc283cac7906a5bc04e8fefa914715f1b3dde495fbf")
--setManifestid(3848573,"7387363881918506592")
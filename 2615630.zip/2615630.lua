-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2615630's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:00:19 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 13
-- Total DLCs: 0
-- Blacklisted Depots: 3
--   Depot 261551: Blacklisted
--   Depot 2615541: Blacklisted
--   Depot 261552: Blacklisted

addappid(2615630)
addappid(2615630,0,"0030ea2828ff221d80494d46301ca38de4b71aa4343bf21715258d0fff53de9d")
addappid(2751380)
addappid(2751390)
addappid(2751400)
addappid(2751410)
addappid(2751420)
addappid(2751430)
addappid(2751440)
addappid(2751450)
addappid(2751460)
addappid(2751470)
addappid(2943340)
addappid(2615631,0,"a9100fcaa593ed2b4543e087945f8c37cf6392c3e97df31deea535d4ce6ae9bb")
--setManifestid(2615631,"231089839208976245")
addappid(2751380,0,"c75350a520f4a8a94660898518bd87577e43329fa66fcfd0d32f516c3f981603")
--setManifestid(2751380,"4444080638293249872")
addappid(2751390,0,"c52af38d5ef1913de6fdc62ccf788d79458e654fb6ab9744c852c5db4ba29049")
--setManifestid(2751390,"2267985507946434196")
addappid(2751400,0,"3d50f09e561a70334d36dacd9020ab590772bbbcd78142add680778f5666a617")
--setManifestid(2751400,"7515963819008505588")
addappid(2751410,0,"e453f1341ed34787dca730fcf8282e9cb784ad1a1e6d0ce4e8db8f0d9f187af0")
--setManifestid(2751410,"6052385650891810260")
addappid(2751420,0,"8ccff908949e33aa60d3a41358f65d6d106c5ee38e0ea71700685860ffa78469")
--setManifestid(2751420,"3550018884358459188")
addappid(2751430,0,"04058289919948ed326433cc676689217e6dd14109f2b3f9de7d4a0401c28c43")
--setManifestid(2751430,"6571688654575207382")
addappid(2751440,0,"619add4f4acc4eb0e261b400f3cd1f4976ff1e279ac632a858c9e88b77b187fc")
--setManifestid(2751440,"2383232569964173785")
addappid(2751450,0,"8d75808dfdc1b2c103093433b2b06132e8c8da6cf8f058d817b2d0000d1143c4")
--setManifestid(2751450,"75150872945885164")
addappid(2751460,0,"dc3d929346560539983ffb42699c47509e20f53c67c652b67e70fa8b0b9596a4")
--setManifestid(2751460,"8724777207423088531")
addappid(2751470,0,"2b9df3bed97ebbfdad23f38abb20caf442e285db0da90eb0eeb4854c5841e8f4")
--setManifestid(2751470,"3006100754883428551")
addappid(2943340,0,"38619ea7ce070878d7fff82d2a1a681c7912a53ba4e1e6c8e2b4183ce0b7661f")
--setManifestid(2943340,"4232932357276971922")
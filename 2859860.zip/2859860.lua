-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2859860's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:35 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 5
-- Blacklisted Depots: 0

addappid(2859860)
addappid(3706240)
addappid(3706300)
addappid(3720480)
addappid(3835470)
addappid(2859863,0,"dbdf11de9e490280e6d377345bc39a5f5bfcd69237235e3123708f4d3bebf2f5")
--setManifestid(2859863,"3891919738127748571")
addappid(2859864,0,"ed3ec893d5369aca77606fc8eea694796b8b75c25fe7e8ad6155ff704ec5ee24")
--setManifestid(2859864,"1414419702288029391")
addappid(3706240,0,"03df21931ff9f9b000c43fa7387116bf6183da63d8a0a1f726b6150e19b64dae")
--setManifestid(3706240,"5040843399263009461")
addappid(3706300,0,"29468cccc0b43d38152fd1f5838555f593c79bb1448009b8ce3e7109a86798f5")
--setManifestid(3706300,"3847213057069036907")
addappid(3835470,0,"58b47a2a6f3948706b37056a75a350e31d5fd7264a6ff333ed5f6b6bf5da4f40")
--setManifestid(3835470,"624349640235739554")
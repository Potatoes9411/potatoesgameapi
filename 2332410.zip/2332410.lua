-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2332410's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:13 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(2332410)
addappid(2662320)
addappid(2699720)
addappid(2332411,0,"2d2194993a80d7430f43158ae4c4b5ceb8b426a5d6765e4c905617eff71d0903")
--setManifestid(2332411,"8132839914049527778")
addappid(2662320,0,"25668a9b4a3089da837c220e2539b1a336f5da91137eb1d8464699106143132a")
--setManifestid(2662320,"4445882041219929695")
addappid(2699720,0,"00c7fcbf53a5f8985c3b3687530ec18157efba8a543cb0fc601549c0f4eabef9")
--setManifestid(2699720,"8127620939933060516")
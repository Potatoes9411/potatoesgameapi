-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1145350's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:55:39 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 3
--   Depot 1145364: Blacklisted
--   Depot 1145361: Blacklisted
--   Depot 1145363: Blacklisted

addappid(1145350)
addappid(1145352,0,"ff02298666a5470ddca19f89593983136f6d1727fc82957ca6b847133783b4e7")
--setManifestid(1145352,"8738846457932040901")
addappid(1145354,0,"71f0364cb7bd2b7d7755605c7983bf2b73101a6e2e0ef6b7082d275a4650f7e5")
--setManifestid(1145354,"5128066409806725580")
addappid(1145355,0,"67def0278f458945e71a75914c686e5bf4d3f90c8b4320795c3b78ad999afc56")
--setManifestid(1145355,"6615649503537037104")
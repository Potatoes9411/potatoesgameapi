-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2878450's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:01:14 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 4
-- Total DLCs: 0
-- Blacklisted Depots: 2
--   Depot 2878221: Blacklisted
--   Depot 2878721: Blacklisted

addappid(2878450)
addappid(2878450,0,"3b2ed429ba668eca9c4646e85a886d2a3813d06a3897941e07e9897a22bff1b7")
addappid(4130010)
addappid(4235830)
addappid(2878451,0,"39088c896b7d3fbd00dc4d6ceffc568de759d24c8be29d76139e3349cce53555")
--setManifestid(2878451,"4408308842741607595")
addappid(4130010,0,"f7dc01918e8337c21a145bce691a39fc6a1b50bc7071c055250934cfc62d8538")
--setManifestid(4130010,"4361993302272211209")
addappid(4235830,0,"126830d172ec4df771a54085781dfe608fec4b86a09e4c35bf7c0306ef191a28")
--setManifestid(4235830,"1989286082171167006")
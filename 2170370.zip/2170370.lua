-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2170370's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:58:07 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 1
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(2170370)
addappid(2541230)
addappid(2541240)
addappid(2541250)
addappid(2541260)
addappid(2541270)
addappid(3094060)
addappid(3094070)
addappid(3094080)
addappid(3094090)
addappid(3094100)
addappid(2170371,0,"b8bbfb60f43b86802b10a8c324e9efac6695acac5321c6c86b349f83d87d4e87")
--setManifestid(2170371,"4271236627084597196")
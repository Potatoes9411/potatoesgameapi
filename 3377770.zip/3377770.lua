-- Made by F1uxin, Discord ID:965053505901588521 | Discord Server (TGP | The Galaxy of Pirates): https://discord.gg/VfCxRsFyFe

-- If you're interested in distributing these files please dm me on discord (UserID:965053505901588521) 
-- (I don't care if you send them to a friend or to help someone, just if you add them in your bot or have them widely available then i would like to know.)

-- Socials: https://guns.lol/f1uxin

-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid", save the file, then add the lua file, (i think you can add the manifests too but I would just add the lua file to ensure it works).

-- If you have any questions feel free to dm on discord (UserID:965053505901588521)


-- Main stuff to actually add the game, DLCs, & depots.
addappid(3377770) -- Haunting Havens
addappid(3377771, 1, "66d9fcae2691745f33f9d4c65e97e53e6b10a4923be5ec52b6930ae92f65f758") -- Depot 3377771
setManifestid(3377771, "3022941472106940854", 11354934721)
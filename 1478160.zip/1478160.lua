-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1478160's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:47 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(1478160)
addappid(2495690)
addappid(1478161,0,"0b31a1bb4d834f46c37bd1b54b48127e24153c121da8b990eed3d22bfe55c812")
--setManifestid(1478161,"821091922249474729")
addappid(1478163,0,"a9540f1c2d4cdcbe060c10053578556ee98482b8828c354a711a5b3d60fb0bb7")
--setManifestid(1478163,"4045154009286282484")
addappid(2495690,0,"d37c959d4f78ef15c8647f82355c8f8cd155500049e39df6a36963933d1d558b")
--setManifestid(2495690,"8519005114582078722")
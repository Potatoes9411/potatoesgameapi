-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 4139720's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:54 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(4139720)
addappid(4555000)
addappid(4139721,0,"980a1fa826758e2ca69f2bfaef24bdfb50f08b521e3248994f8d7da43d457f8b")
--setManifestid(4139721,"8910935352535839912")
addappid(4139722,0,"f8e059745627df7bea76de902caefb11d79d1aa8862c856fbdf018a1e222d914")
--setManifestid(4139722,"3255230144051618523")
addappid(4139723,0,"3eefa6d274b7f846f20d7b37463f2803666aa1cb4e11a34b5bc5705ed27fbb3b")
--setManifestid(4139723,"8286069039777430751")
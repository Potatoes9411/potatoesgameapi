-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1121640's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:39 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 5
-- Blacklisted Depots: 0

addappid(1121640)
addappid(2108240)
addappid(4162120)
addappid(1121641,0,"589062032126cb115e44bf22b1f1a7e84ac07202db9d7e297972cc12130c256b")
--setManifestid(1121641,"9190757976551847942")
addappid(1121642,0,"bbb6ebc0721460dbc0155d9b26c55231535405d93f38fb6e50872d0803db0fed")
--setManifestid(1121642,"7163717802903257314")
addappid(1121643,0,"89b00047847f1d8ba2672409d955a16b87f2fba17d5104e7d52f2eb93b0ef7d2")
--setManifestid(1121643,"6844907273858531186")
addappid(1121644,0,"bdd41c80e89da770cf45077f31fabce93992c2a99fde9378afdc725375bdee4e")
--setManifestid(1121644,"9165209617158891256")
addappid(2108240,0,"3bab56d802407d29977f89e57f59dbddd3fbdffb45f22df1832cf0e363bb7a13")
--setManifestid(2108240,"1599426698477333693")
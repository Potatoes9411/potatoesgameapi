-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1043260's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:37 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(1043260)
addappid(3729520)
addappid(1043261,0,"8c865483c01f4bb7399ff967ccfc9a7e110d62a197a7fd9ecf4792f5d9c3fe66")
--setManifestid(1043261,"4484212706260634703")
addappid(1043262,0,"c8f22281632780ee9ecb3c7d19fdc66ff60f7810d61253bfeeb49fd38412aaf8")
--setManifestid(1043262,"926835873374832994")
addappid(1043263,0,"0e8605c7059bd533b9d6fdfa7ca53fbe33c13fd3c09aa5caf609ddce82d74a41")
--setManifestid(1043263,"8368103423483790780")
addappid(3729520,0,"009effc5ecee6e99fe2673f499a3fa7005096d469b82d6e19be8d46259e457e3")
--setManifestid(3729520,"3461928666645399968")
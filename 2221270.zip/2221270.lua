-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2221270's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:58:38 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 1
-- Total DLCs: 0
-- Blacklisted Depots: 13
--   Depot 2221497: Blacklisted
--   Depot 2221924: Blacklisted
--   Depot 2221496: Blacklisted
--   Depot 2221498: Blacklisted
--   Depot 2221499: Blacklisted
--   Depot 2221493: Blacklisted
--   Depot 2221494: Blacklisted
--   Depot 2221921: Blacklisted
--   Depot 2221495: Blacklisted
--   Depot 2221841: Blacklisted
--   Depot 2221925: Blacklisted
--   Depot 2221491: Blacklisted
--   Depot 2221926: Blacklisted

addappid(2221270)
addappid(2221271,0,"b3e657d2704028f2c569b0ee261932fae5cd2978dabb86bb25191e362ccc0616")
--setManifestid(2221271,"5084672748897787282")
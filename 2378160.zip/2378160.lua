-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2378160's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:59:21 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 21
--   Depot 2378623: Blacklisted
--   Depot 2378911: Blacklisted
--   Depot 2378500: Blacklisted
--   Depot 2378505: Blacklisted
--   Depot 2378622: Blacklisted
--   Depot 2378514: Blacklisted
--   Depot 2378517: Blacklisted
--   Depot 2378621: Blacklisted
--   Depot 2378508: Blacklisted
--   Depot 2378518: Blacklisted
--   Depot 2378504: Blacklisted
--   Depot 2378516: Blacklisted
--   Depot 2378512: Blacklisted
--   Depot 2378509: Blacklisted
--   Depot 2378503: Blacklisted
--   Depot 2378511: Blacklisted
--   Depot 2378506: Blacklisted
--   Depot 2378507: Blacklisted
--   Depot 2378501: Blacklisted
--   Depot 2378515: Blacklisted
--   Depot 2378513: Blacklisted

addappid(2378160)
addappid(2378161,0,"d0ad0be4adccf517369a41fbc85482d9ce3330b2d210d926d0884b32b3edcd8a")
--setManifestid(2378161,"3260834307188699090")
addappid(2378162,0,"bd48e5fc6fce44d3865311bc7371854307ccb1b99d56dc09371416932d513b32")
--setManifestid(2378162,"5276337477452626452")
addappid(2378163,0,"d42ee8b74661eb04d8dabde5b6468f5e5440d8e7442bb284fc9746b9724cea23")
--setManifestid(2378163,"8794574675717628955")
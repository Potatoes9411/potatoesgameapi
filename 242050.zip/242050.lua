-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 242050's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:59:32 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 4
-- Total DLCs: 0
-- Blacklisted Depots: 15
--   Depot 2420592: Blacklisted
--   Depot 2420116: Blacklisted
--   Depot 2420112: Blacklisted
--   Depot 2420243: Blacklisted
--   Depot 2420117: Blacklisted
--   Depot 2420244: Blacklisted
--   Depot 2420115: Blacklisted
--   Depot 2420241: Blacklisted
--   Depot 2420591: Blacklisted
--   Depot 2420111: Blacklisted
--   Depot 2420114: Blacklisted
--   Depot 2420242: Blacklisted
--   Depot 2420119: Blacklisted
--   Depot 2420118: Blacklisted
--   Depot 2420593: Blacklisted

addappid(242050)
addappid(260470)
addappid(260471)
addappid(260472)
addappid(260473)
addappid(260474)
addappid(260476)
addappid(260477)
addappid(260478)
addappid(260950)
addappid(264750)
addappid(264800)
addappid(264801)
addappid(264802)
addappid(264803)
addappid(264804)
addappid(264805)
addappid(264810)
addappid(264811)
addappid(264812)
addappid(264813)
addappid(265320)
addappid(1650420)
addappid(242051,0,"6b4004c38a5c8c1a869d90c381726c7d5651f578753c316c2dcd372fa13ef609")
--setManifestid(242051,"30755846185611447")
addappid(260476,0,"c6245eb9d4c77c2f2204ab40754a0d50402bb78f9de10b495e2f9df94d0c051d")
--setManifestid(260476,"3697863006561544635")
addappid(264803,0,"28fe23f7e6ef14d6190c4b1646a87d9d7aa6d22d7a0f89936abfe3ebd293fd80")
--setManifestid(264803,"6005226780702341878")
addappid(1716751,0,"84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
--setManifestid(1716751,"4132506267642462151")
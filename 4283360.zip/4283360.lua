-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 4283360's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:56 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 2
-- Blacklisted Depots: 0

addappid(4283360)
addappid(4283361,0,"01f200be7d1a3ee646f73e5bda964c9a0cd0649be19338738dda86338578ed52")
--setManifestid(4283361,"1020643234266923087")
addappid(4283362,0,"4ec1e6b49bdf03cb59d1f6d4d3c9f1a9f3b2540a7e17777a32fc4b150752ece0")
--setManifestid(4283362,"2904984946074154172")
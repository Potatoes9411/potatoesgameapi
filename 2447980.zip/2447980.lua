-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2447980's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:59:39 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 2447681: Blacklisted

addappid(2447980)
addappid(3795890)
addappid(2447981,0,"0f953f0a434dfe917dd66d01bb6e61b66807d427289649ffba29003ca44092c1")
--setManifestid(2447981,"3620393772610643914")
addappid(2447982,0,"3bd90f54a984cf3b5549bd054886d1ecfa1d50b6ecc397c821b167438a5ac4f7")
--setManifestid(2447982,"4198593613433622709")
addappid(3795890,0,"a5cf72b9230970735ce09f74d72650ca4f408b26dd5c83af6b0fbf723ffbc303")
--setManifestid(3795890,"8594050950906281481")
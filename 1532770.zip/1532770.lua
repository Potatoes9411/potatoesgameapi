-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1532770's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:47 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(1532770)
addappid(1756970,0,"0725e5aa4d9951df6d442b6d7a33f63319ec6a18d331252fe377ec6474cda411")
-- setManifestid(1756970,"5822716055222978060")
addappid(1532771,0,"dbc2cd6327f98c3df57a699fdb5bb5b9c66b9d9926889ee6464391cd04d39ff1")
-- setManifestid(1532771,"6222009358198090217")
addappid(2403200,0,"1463c2501f6d997be27e4dab7e4e91d38ef719c8e3fb9105d10a1da3eb3c72d8")
-- setManifestid(2403200,"7769045731597160631")
addappid(2403190)
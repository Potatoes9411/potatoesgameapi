-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 347660's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:32 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(347660)
addappid(347661,0,"e35efb593fe8201889d3bf8ecd9c44c6d354d1cdcd0f01b0cc97a086869e2c41")
--setManifestid(347661,"278746118628419153")
addappid(347662,0,"3d7c299b9a20ed6ded251a93ed747d100548411a3422eb1429d2ae12e801a77d")
--setManifestid(347662,"3127475466042028676")
addappid(347663,0,"895723492c4a63af647d4abcf841f62ac0c9a82d9126aefec68bea5fa6813f9d")
--setManifestid(347663,"8754065664103382743")
addappid(347664,0,"4fa76d407e4aa3fddc64e5bc8b3d86134c3a161666e7091de1e7d3253e0197ba")
--setManifestid(347664,"4678337985753668542")
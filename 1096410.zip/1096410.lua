-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1096410's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:55:34 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 1
--   Depot 1096551: Blacklisted

addappid(1096410) -- Vampire: The Masquerade - Coteries of New York
-- MAIN APP DEPOTS
addappid(1096411, 1, "4ab6540a3c86f58819c7d643d1fbd362a400be3fcc51e006a4b6d325399250fe") -- Vampire: The Masquerade - Coteries of New York Windows
--setManifestid(1096411, "60988092401406081", 3468538737)
addappid(1096412, 1, "c4e0dc1431e2c09c20cf733e430f7b31d985f172af5ddb0cc09a5d8963bbcc55") -- Vampire: The Masquerade - Coteries of New York Mac
--setManifestid(1096412, "6250251483172086617", 3514844385)
addappid(1096413, 1, "eeefd1f999762edaa693ef73b630b64fabeb8b1a8a683ad315b56447e1ad3704") -- Vampire: The Masquerade - Coteries of New York Linux
--setManifestid(1096413, "6702524452680439920", 3400126061)
-- DLCS WITH DEDICATED DEPOTS
-- Vampire The Masquerade - Coteries of New York Artbook (AppID: 1266750)
addappid(1266750)
addappid(1266750, 1, "7f90f41425c1a23fe582bc6a0e9b6830bc0cbb35a9534d1fae20b24d9af7fb98") -- Vampire The Masquerade - Coteries of New York Artbook - Vampire: The Masquerade - Coteries of New York Artbook Depot
--setManifestid(1266750, "1720435772542163613", 54758182)
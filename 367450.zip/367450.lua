-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 367450's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:42 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(367450)
addappid(367450,0,"db284e990493c81a8718c80e988cb165e376d959f646cc004219cdb4d7244075")
addappid(367451,0,"d665d606792ae4631a504bd59f59310fffb87490652e9b149616eda8ad5962ba")
--setManifestid(367451,"3168549286285070087")
addappid(367452,0,"1d911373e5f75e7fe50cf3e2708aab9380d1565dc3e7fc9bacb9339cc042dec6")
--setManifestid(367452,"5300884783176432417")
addappid(367453,0,"03f1099f465d40ba0296be94392f13b6a696331a12f878d8a4931efb7a88397d")
--setManifestid(367453,"1283089157963056478")
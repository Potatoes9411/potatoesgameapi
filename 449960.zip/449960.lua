-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 449960's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:59 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 7
-- Blacklisted Depots: 0

addappid(449960)
addappid(449970)
addappid(706770)
addappid(968890)
addappid(991890,0,"fc7a30ba9cfe6bdf61023c64b566328f825c606a38c393176e0be98de48342f9")
--setManifestid(991890,"8925794009554676835")
addappid(449961,0,"c85e8ab29a95854075061035a04a70ab9a002a6c0f7a8fed6f331c560d43ee2b")
--setManifestid(449961,"7612820234764631283")
addappid(449962,0,"f66efc8cbd53f29d3b9addf6e26c1f834edd08e31724df98618f78be3121ae60")
--setManifestid(449962,"510365158858247380")
addappid(449963,0,"a904188c477b0ffa7e8ddb295c3fcef656aa62f476b1ec53b7fb50a3e55315a5")
--setManifestid(449963,"232132595985028990")
addappid(449964,0,"832e627a3fa59bb07b46a0d405fb6810f1d10652d4f3192ecfa53922bcd0af8e")
--setManifestid(449964,"8612869221512902806")
addappid(449965,0,"425d7e4876bc1d0442530705a424b81337e5b5af59d985458db405c4ea4dc9c1")
--setManifestid(449965,"1539169703380940064")
addappid(449966,0,"83d1f22339dedc27afd388ca01fa964f9fe4c084566914d5ee8d3c388cf741d6")
--setManifestid(449966,"8867370621665799853")
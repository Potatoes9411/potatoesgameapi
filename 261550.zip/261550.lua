-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 261550's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:25 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(261550)

addappid(261552,1,"b6cfe4c61b9f19a7399a290c50b3dc18052f63b095401ffb3aa8286277597365")

--setManifestid(261552,"4450953435514120557",4739126262)

addappid(261551,1,"16a71c423df683e98af58e40c60a6fc8087dc360f977a73c7d138e8d26b99062")

--setManifestid(261551,"92565971655502058",47549013602)

addappid(2240111,1,"172d8d7fb867c14dfe3251829c334dd13bd3fa452eca4f34a3c583ed9928efea")

--setManifestid(2240111,"6194812840481947105",1210058736)


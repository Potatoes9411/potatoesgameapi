-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1599660's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:56:44 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 1
-- Blacklisted Depots: 1
--   Depot 1599781: Blacklisted

addappid(1599660)

addappid(1599661,1,"d759c1903ae656936c6564d2148c69c553fb408d0234a6604c01916699b2b482")

--setManifestid(1599661,"5076959587775286666",57006801055)

addappid(2131310)

addappid(2193240)

addappid(2193241)

addappid(2206300)

addappid(2206301)

addappid(2206302)

addappid(2216230)

addappid(2228240)

addappid(2228241)

addappid(2232410)

addappid(2232470)

addappid(2232480)

addappid(2232490)

addappid(2232500)

addappid(2232501)

addappid(2232502)

addappid(2232510)

addappid(2232530)

addappid(2232540)

addappid(2232550)

addappid(2232560)

addappid(2232580)


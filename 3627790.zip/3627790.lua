-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3627790's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:39 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(3627790)
addappid(3774080)
addappid(3627792,0,"0788ce3014968b600343007fef05d8da9b9b32e374175d933f0c900866a04c1b")
--setManifestid(3627792,"6161949926552624338")
addappid(3627793,0,"55974ab4cdd99a71daa7121176a6d78dce576c10ec03897bee52c2ddada58c59")
--setManifestid(3627793,"2927501132684571745")
addappid(3774080,0,"4d1c0ba02f11ee44e87127dc966a34868fdfb013e8c09b26c1262c05dc1f6faa")
--setManifestid(3774080,"5576845473352011314")
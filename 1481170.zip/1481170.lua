-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1481170's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:47 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 7
-- Blacklisted Depots: 0

addappid(1481170)
addappid(1481170,0,"0701ce75269f4446b0c7c8df2fd000a608b3a23754b14a909cc5ed8f369dda87")
addappid(3301460)
addappid(3301470)
addappid(3607430)
addappid(4046850)
addappid(1481171,0,"ab7865cbd2a8f2f7849cbd33921b1240846241cb2d269f9aacb275fe03a08147")
--setManifestid(1481171,"6144262366651087284")
addappid(1481172,0,"9a3ffa2d182a63014568fa620607a4f6f2d873b15ed7dea23b6918c5bcea5d69")
--setManifestid(1481172,"695874520463043928")
addappid(1481173,0,"a0a1ce7031ed63051ae73e788c95ef11143c5e5dcc5fc44762bb5329ca99da0d")
--setManifestid(1481173,"1349042453889715270")
addappid(3301470,0,"78e7364c6c382811cee9ac213efb1422278b33d673aa157271f30f2c3679d6c2")
--setManifestid(3301470,"8520414856758569898")
addappid(3607430,0,"c19547136da494638305653481437fe3d585d1c6f9cf3a268a5f2f697b5b00f2")
--setManifestid(3607430,"6135102898699654847")
addappid(4046850,0,"1f7c96db7a496f240a65d49b64f91217d231ccd6e894ecd4b33e16aed674071e")
--setManifestid(4046850,"7642859900305640628")
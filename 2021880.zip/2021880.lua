-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2021880's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:59 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 2
-- Blacklisted Depots: 0

addappid(2021880)
addappid(3143380)
addappid(3143390)
addappid(3143400)
addappid(3143410)
addappid(3143420)
addappid(3143430)
addappid(3144830)
addappid(3158790)
addappid(3495280)
addappid(2021881,0,"2ee32023245e16a98b624134e65f2cb58176b2ec23c8cccf202cc305d57d864e")
--setManifestid(2021881,"2126338807870698220")
addappid(3144830,0,"46ec9fab404dcd3a5e0b2862b1f9c1a0410157b5071f35a086bd4f57f6b79beb")
--setManifestid(3144830,"1036188934286123835")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 268500's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:00:36 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 6
-- Blacklisted Depots: 2
--   Depot 268560: Blacklisted
--   Depot 2685843: Blacklisted

addappid(268500)

addappid(268501,1,"0cdf9d9dad17fb069eb1263e21b41e8030ef4256c0d733b0e864a4a779349071")

--setManifestid(268501,"8736125264145479330",78087509)

addappid(268502,1,"df85fc6f57f1014e2d95a4c56de8d7461795da197117125de8f04bca3f02a532")

--setManifestid(268502,"3964459376964430563",34483373825)

addappid(268514,1,"c8a26176017c43f7aec84302788dcaec6c5dfeccb6a4d64fef810439f0ffabc3")

--setManifestid(268514,"2781230624575294884",43824692)

addappid(268515,1,"3c6771036f5cef19c06d14702b031c6e6830edd334a8ddb87eed413098173b9b")

--setManifestid(268515,"5692944031528902906",3155829)

addappid(424945,1,"1e7fe3a020b7e33558348dde5e781490bf4e00d6bc703a387439c1b4e3067d26")

--setManifestid(424945,"345374647346915517",208552416)

addappid(1523211,1,"6111b2e3d21efa5e5b26a91f75ff32d12aa8c5bb547c4d0215eda184a7f4c49b")

--setManifestid(1523211,"1898676659422131805",134354670)

addappid(426320)

addappid(426321)

addappid(593380)

addappid(785300)


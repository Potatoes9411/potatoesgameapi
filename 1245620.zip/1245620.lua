-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1245620's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:56:04 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 7
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 1245251: Blacklisted

addappid(1245620)
addappid(1799420)
addappid(1896300)
addappid(1896320)
addappid(1922350)
addappid(2778580)
addappid(2778590)
addappid(2855520)
addappid(2855530)
addappid(1245621,0,"5f560fca048a138487e1e634a1e60693a7ad3ae7318c31731d147f16e093f10b")
--setManifestid(1245621,"307900985962711980")
addappid(1245623,0,"b27090a72caa5f3cf2e1f41a81c4bc1c422a6ac277e1cd3a6f1ea68200288d4b")
--setManifestid(1245623,"3547980754086643033")
addappid(1245624,0,"e194ce5e5f83c427743781c1708c4bce6683d5d65521059f6e4ca64a8f36f3cd")
--setManifestid(1245624,"7017181152898342588")
addappid(1896300,0,"946e5c4e2c91a3ed363efc688218994f7fa6e8fdd56aa8b5752456d3b28e0543")
--setManifestid(1896300,"7130086783926325209")
addappid(1896320,0,"de7086b709fdfc7d151bfce5d07509fd80a6c318a21e8fb1e820db5b1cda5860")
--setManifestid(1896320,"5664821938092422533")
addappid(2778580,0,"9f1556645ea8ef43529f920cf02a2682a6da5756b29e630ba376a0cde24e3908")
--setManifestid(2778580,"1674424364022381183")
addappid(2855520,0,"476eca9191866d6743aa7ad82d4d7ce1fcd5e0f0613f2f4b6559635d68f8c0e3")
--setManifestid(2855520,"2785904640065824767")
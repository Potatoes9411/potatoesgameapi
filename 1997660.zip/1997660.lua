-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1997660's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:58 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 2
-- Blacklisted Depots: 4
--   Depot 1997441: Blacklisted
--   Depot 1997741: Blacklisted
--   Depot 1997201: Blacklisted
--   Depot 1997521: Blacklisted

addappid(1997660)
addappid(4066020)
addappid(4066030)
addappid(4235650)
addappid(1997661,0,"e9c32558a9b3073d7a33535e53f219071acd9c48e1180848a5a41324fb1f2707")
--setManifestid(1997661,"695988690991017659")
addappid(4235650,0,"948a3a95adb53c5b777284978f2903764b606ea8e4842ebd6759e5ed6883f97b")
--setManifestid(4235650,"1128419780134133931")
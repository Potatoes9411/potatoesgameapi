-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1909950's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:19 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 9
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(1909950)
addappid(3483930)
addappid(3390820,0,"d22f81e1d50c71064d093e98fd8d79be8fe2443c109def325c1589235ddee9f2")
--setManifestid(3390820,"7112124880795295060")
addappid(3483830,0,"e32b0227a39c74cf84056450d0d93a70f6c229494b783b3a81935018c7ba5f31")
--setManifestid(3483830,"9089033282010469365")
addappid(3483840,0,"c7108fbc58e82ebc3b10935a5048e2da2860b20e89c11f063d9ffe3cd1f6f638")
--setManifestid(3483840,"1145738050661138623")
addappid(3483850,0,"ba95e3ed923a31dee2ca44f450589db4ee2d645691892123d45db80a92358a1e")
--setManifestid(3483850,"4527382040117238039")
addappid(3483860,0,"36d2080cd439b6e5db903a5cc34bc10bbaa4c69167a983ff3522237c56edb427")
--setManifestid(3483860,"2332045968270933307")
addappid(3483870,0,"9cbfb79f2b6e617b33b8011be6be19e88089ae8343b6b83b7087a59cb1507f7d")
--setManifestid(3483870,"9219054550646773475")
addappid(3483900,0,"109130b59df37285a9a1e75cdb50516fb303e6694d4ae1d72e1c41cc7ef31cec")
--setManifestid(3483900,"2408797858890454844")
addappid(3483910,0,"4a871e042cdbc9309625b25d1178c4a4b761e122b26e96f50a31cb4c80031be3")
--setManifestid(3483910,"7610336536250456307")
addappid(1909951,0,"77fcc720c77a9d762fca608c74046980979badaf8ce497d8494b3c2da40d3ddb")
--setManifestid(1909951,"1405394230871288212")
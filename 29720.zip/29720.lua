-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 29720's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:01:35 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 5
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(29720)
addappid(29541,0,"7f93d15c7db86244f86cecadc8137f20f72eddd640ea65297e2f067d0471dde6")
--setManifestid(29541,"2220434158396681779")
addappid(29542,0,"d65c53534c4cf98eefa63b517b1ebd1b983c2c41846e0d55d7837cb1eda51431")
--setManifestid(29542,"5992366029106745127")
addappid(29543,0,"088886029cf89247fa5fc98ed39121aae6b13e7dd9f61eda89bc44569c469798")
--setManifestid(29543,"2449735973173310759")
addappid(29544,0,"32d6a8f3f7e420afc49d460ddc5d840f89281780094a55e9b98691aae327df1d")
--setManifestid(29544,"4759027866653794960")
addappid(29545,0,"294bbd3fe13cf5879b9e8203dd86d2f6e0be165a2c9ccd312f28d4e31ff26ffa")
--setManifestid(29545,"6697105966861456616")
addappid(29540)
addappid(29560)
addappid(29570)
addappid(29580)
addappid(29600)
addappid(29610)
addappid(29620)
addappid(29630)
addappid(29700)
addappid(29710)
addappid(4103440)
addappid(4103450)
addappid(4103460)
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1850570's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:12 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 2
-- Total DLCs: 0
-- Blacklisted Depots: 6
--   Depot 1850161: Blacklisted
--   Depot 1850164: Blacklisted
--   Depot 1850162: Blacklisted
--   Depot 1850051: Blacklisted
--   Depot 1850741: Blacklisted
--   Depot 1850163: Blacklisted

addappid(1850570)
addappid(1850571,0,"f0c67b235585f625ae33882c4547f9ef4404e96c5ad0a1fb4dbf43da61e04e24")
--setManifestid(1850571,"5054031739229969224")
addappid(1946740,0,"e01735660cdb310784cc00ba796a0b48c48605b9b94cf3e4d473b3a5ae97af32")
--setManifestid(1946740,"8878465371266993543")
addappid(1946740)
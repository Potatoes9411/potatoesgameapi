-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3655580's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:40 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(3655580)
addappid(3834680)
addappid(3655581,0,"23c4b597cb7b6ae18c07660d8a21b8b7858b82783c7b29df05d159672521d076")
--setManifestid(3655581,"2306947531826775301")
addappid(3655582,0,"fa8a6fa62a3185aff107dffa48b6418f2c02530f3cd1716bac29ae7efaa3c423")
--setManifestid(3655582,"8537123959946397601")
addappid(3655583,0,"4168178efa63afe15d161bd2cc018b04a5b0f1c316a660adb71e1b2c9c3b71d0")
--setManifestid(3655583,"5096414065632491851")
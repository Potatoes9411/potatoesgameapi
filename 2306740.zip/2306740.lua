-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2306740's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:11 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 10
-- Blacklisted Depots: 0

addappid(2306740)
addappid(2431340)
addappid(2501690)
addappid(2501700)
addappid(2501710)
addappid(2501720)
addappid(2306741,0,"3a6f65c019f1f2bf1a0812a31c5a4f27ba0a40c72689ee3d2db8eb4a49e6467c")
--setManifestid(2306741,"8710198833963689336")
addappid(2431340,0,"bff6faa6e7cb13954ff24a48f90322dbf66a17328f48ba2a580d2ea3ca1ce88a")
--setManifestid(2431340,"5909098657083960944")
addappid(2501690,0,"e328539e64a52ae3b4b018567066de5bff2bd07d7567a92f914bc5945c121705")
--setManifestid(2501690,"644266444276296543")
addappid(2501691,0,"0fc3e146dc315b045f3eb1ff913069ab33f6a1f02ffa99be8bce49ddc89d38e6")
--setManifestid(2501691,"1218096519566542369")
addappid(2501700,0,"06f68e6b51a25e293b9f29547cd2dde060e53dd5a0791c57dcf147f79e1b2c5c")
--setManifestid(2501700,"3173897960963373946")
addappid(2501701,0,"5efa05d026dbb14f02b77eaa22cccde6e5d453f379913acbcf77b20b112b4bc3")
--setManifestid(2501701,"8314562409986485640")
addappid(2501710,0,"fdad5148cc1184cac01c94e3f4a1743eda5420b36df690b7296384c71e14902c")
--setManifestid(2501710,"1789306363310471931")
addappid(2501711,0,"d8cbec0cd3fc359ab3621dfa8ac12ce03c3531599463916b1e3e8be993f12221")
--setManifestid(2501711,"2539501336228918468")
addappid(2501720,0,"04337430b131108074fd0f1c4e3479cf43c48f450e9260477e95f3ff5cf850d9")
--setManifestid(2501720,"5322430849616985020")
addappid(2501721,0,"2d40171666df2397cd92d85cc1757d65a4da5b6843ce8376aaeafc0c022ef7e2")
--setManifestid(2501721,"6154109978025432107")
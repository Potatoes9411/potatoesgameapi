-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2973120's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:01:35 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 4
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(2973120)
addappid(4603110)
addappid(2973121,0,"22c01bbafdfb219a5fd9ba90848c076d2fc0a62366836087c2a8aed2d9c44339")
--setManifestid(2973121,"785007509200111541")
addappid(2973122,0,"d7d1f397f1b5038d3a5cf8597157319b7ca6eeb5933015b27e4ed9b9f722ca6f")
--setManifestid(2973122,"8064324470197357705")
addappid(2973123,0,"dce7b2f5d76759d38587d0330b673efad0c28c0c47ac29e9ab7f6b450d42ab81")
--setManifestid(2973123,"6365062416932578671")
addappid(2973124,0,"8336ffde5b25ce0a901425e42a3b8114d9d11cf87d411c29f5579b390199957e")
--setManifestid(2973124,"1897516404073343174")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 13570's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:56:20 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 8
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(13570)
addappid(13571,0,"f4af994be4acaafddf80fe38ed7af5833ac0b28a4a8a9c313b5746590f87c58c")
--setManifestid(13571,"2604462187318687519")
addappid(13572,0,"c257b00a696f075cd515e41816d5505195d9985c5cdad3a80fc43ebdb97c28d2")
--setManifestid(13572,"2863780006937385850")
addappid(13573,0,"0d8f1d12559fc0ab345ffa9d918a99d664819e384ee106d4125e38fd59a2ae45")
--setManifestid(13573,"3429652351254261449")
addappid(13574,0,"b61e0918d55494ad570b7cfdd4d6582ec74219897c9a2f04a3ff41143e0808f4")
--setManifestid(13574,"9029630630212195878")
addappid(13575,0,"686c2165692c3280c98aa469dd558c78a2ff5804abf583e6926afdb391af1967")
--setManifestid(13575,"6017597725735935521")
addappid(13576,0,"3e89885c80304426b925eece5e33aba75bc33448ceac8ee9e6fad49e9069eeb3")
--setManifestid(13576,"8177966008577298091")
addappid(13577,0,"1cfa73f6577503d20b9c206080638642c04f0dcf2e864881fec3cb88cc16b9b3")
--setManifestid(13577,"3356040755954250153")
addappid(13578,0,"3437c90090bd12f40052c9d65179e7ee1e965b079f39c7c335574db0b7903c43")
--setManifestid(13578,"5072262111294534050")
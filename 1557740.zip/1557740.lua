-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1557740's Lua and Manifest Created by Potatoes9411
-- ROUNDS
-- Created: June 17, 2026 at 06:56:39 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 2
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(1557740)
addappid(1557741,0,"a6cedd0b2c308a406cddc4573cef3b7f00d14682403b44aa8e355d1c2e44ef44")
--setManifestid(1557741,"3274682947036329080")
addappid(1557742,0,"8447b9f98b63911fab9ee2d607107de8fb860f6858c1d77bae0f5379f239f09b")
--setManifestid(1557742,"1060916500951229028")
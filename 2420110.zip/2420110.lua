-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2420110's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:17 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 13
-- Total DLCs: 0
-- Blacklisted Depots: 3
--   Depot 2420592: Blacklisted
--   Depot 2420593: Blacklisted
--   Depot 2420591: Blacklisted

addappid(2420110)
addappid(2420111, 1, "5efc60abd1c102f2ede64fbddb1fcb58fc7b156ef8410eba8ce90a458a09082a")
--setManifestid(2420111, "2239037909320851046", 0)
addappid(2420112, 1, "45ee1a9a56ddd7b41370387bc6a3c6ece37bab529fa3313c7543c1b5ec044b93")
--setManifestid(2420112, "7917507670516987083", 0)
addappid(2420114, 1, "d7abeb87bdc4c80e6c40a78b0681d32db2cbd17261c2ad793c2b8acee674a669")
--setManifestid(2420114, "6680338608508653005", 0)
addappid(2420115, 1, "5908a0f1461073db73b0d36ce13aff474c6243e9aeb57bbf13490f31fcc1a082")
--setManifestid(2420115, "3856210151677793842", 0)
addappid(2420116, 1, "f525051ae30cdf8d4525cd997f307713341a438173122b522a281752db8728a4")
--setManifestid(2420116, "4697055530980282507", 0)
addappid(2420117, 1, "18c0f17fc983e33fe47b8d40449f3d561d3eed66916e0fcb19ee469f5618d32e")
--setManifestid(2420117, "5295276332778237670", 0)
addappid(2420118, 1, "98e66b59c1c5e5ec56e36dbe5d4bb42af86d6c3e3a4f0d7874065667f1a2600d")
--setManifestid(2420118, "8673415990553381851", 0)
addappid(2420119, 1, "661789bfc4fbe123e06843e92004d16fe7b37f293454616f542bb164b565fb5a")
--setManifestid(2420119, "5380212226787194873", 0)
addappid(2452461, 1, "e1a93cdacf0ff6fdc39ea109f0eb689e44d173896b912571537c25e26c959e69")
--setManifestid(2452461, "5708538598987781196", 0)
addappid(2452462, 1, "2febd6f0d43778130ff358538c1bf064e446804f1d403865e464d89dd3499865")
--setManifestid(2452462, "8564962424144066599", 0)
addappid(2452463, 1, "4ddd210beeda422859f5ad26eabcb8798923f613e593bd1182df53f7ddbbb447")
--setManifestid(2452463, "8307697578226900422", 0)
addappid(2452465, 1, "f5a7d177f62ba6108d394056d583a52653d086d6c87eb844331fb714ac57c9eb")
--setManifestid(2452465, "343860007184336722", 0)
addappid(2452466, 1, "202f3496feff614800225f52837d623bcefacd68f7049451f3ec6b2ce62d1e8b")
--setManifestid(2452466, "3510327789903158350", 0)
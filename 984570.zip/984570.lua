-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 984570's Lua and Manifest Created by Potatoes9411
-- Chess Sphere
-- Created: May 16, 2026 at 04:46:34 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 10
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(984570, 1, "Unknown")
addappid(984571, 1, "Unknown")
setManifestid(984571, "1638368046820525761", 0)
addappid(984572, 1, "Unknown")
setManifestid(984572, "Unknown", 0)
addappid(984573, 1, "Unknown")
setManifestid(984573, "Unknown", 0)
addappid(984574, 1, "Unknown")
setManifestid(984574, "Unknown", 0)
addappid(984575, 1, "Unknown")
setManifestid(984575, "Unknown", 0)
addappid(984576, 1, "Unknown")
setManifestid(984576, "Unknown", 0)
addappid(984577, 1, "Unknown")
setManifestid(984577, "Unknown", 0)
addappid(984578, 1, "Unknown")
setManifestid(984578, "Unknown", 0)
addappid(984579, 1, "Unknown")
setManifestid(984579, "Unknown", 0)
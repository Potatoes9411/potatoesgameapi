-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3929740's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:51 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 7
-- Blacklisted Depots: 0

addappid(3929740)
addappid(4103010)
addappid(1716751,0,"84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
--setManifestid(1716751,"8055867430366823504")
addappid(3929741,0,"b2c87c8501ea6789d1e9e8a0f45da5cacdd90b685f0da3d710485e82945d1b57")
--setManifestid(3929741,"3127817338763076110")
addappid(3929742,0,"2892178fb39e7761dc3e49ac7d3bb6f7bc0f8309ca2543aaf578f7de29cfb95e")
--setManifestid(3929742,"6915546572832318699")
addappid(3929743,0,"7b7c06a30aedb97951ba922fa00ee3ad58c6a03a15608b0c058a80fb1d52b778")
--setManifestid(3929743,"8284373307380388717")
addappid(3929744,0,"b8138faa0fbf89fe1ff1d717986d305b462dca6d2e0f69eecbf41cbf4b11e3ed")
--setManifestid(3929744,"1436522670055839786")
addappid(3929745,0,"eff0a6451e562e1e47889ea7a32209e4a2dfc91b959097b3b62ff544af8e49a9")
--setManifestid(3929745,"5230515676687236275")
addappid(3929746,0,"db711b7327d3da24fef76d194f8843f7b01359a552d1378e6fa018b234c8bc05")
--setManifestid(3929746,"521831151215040465")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1809540's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:07 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 4
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(1809540)
addappid(3362590)
addappid(1809541,0,"6c41504f601faddc7ec40aff4688b9ee9e34c37f2ab46b882880cbcc76a8eb40")
--setManifestid(1809541,"4170341253080557508")
addappid(1809542,0,"39cff11ed94d5fb43612916d75ca9d971b35caeca4fa3bda91610e1118927ec3")
--setManifestid(1809542,"6968920301698375133")
addappid(3362590,0,"8393593da990f6cd827af13ecb9d42c653dabc0101e53dd927e7e55ae2fa4aa1")
--setManifestid(3362590,"2032132760684014067")
addappid(3362591,0,"0d84cc89dc3f66b203521c09e53075478305ba8702859948d892ba9c3bf0d9d0")
--setManifestid(3362591,"5837835346821903939")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2581050's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:00:13 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 1
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 2581952: Blacklisted

addappid(2581050)
addappid(3063310)
addappid(3063320)
addappid(3063330)
addappid(3063340)
addappid(3063350)
addappid(3063360)
addappid(3063560)
addappid(3063570)
addappid(3063580)
addappid(3063590)
addappid(3466910)
addappid(3466920)
addappid(3511140)
addappid(3511150)
addappid(3511160)
addappid(3511170)
addappid(3511180)
addappid(3511190)
addappid(3511200)
addappid(3809010)
addappid(3813170)
addappid(3813180)
addappid(2581051,0,"72c4e9e40b3dd0b48fb2712bf570f6390358e03f8bd98d8e8bed1a5f7bec4f2c")
--setManifestid(2581051,"5824467257124826716")
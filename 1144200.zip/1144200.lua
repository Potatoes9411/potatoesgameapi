-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1144200's Lua and Manifest Created by Potatoes9411
-- Ready or Not
-- Created: May 16, 2026 at 04:45:18 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 14
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(1144200, 1, "Unknown")
addappid(1144201, 1, "b9236894ba071d12dd117ce16220fefeb20574d7c6f7d2170e3113346867f3d6")
setManifestid(1144201, "6744259790683578909", 0)
addappid(1144202, 1, "Unknown")
setManifestid(1144202, "Unknown", 0)
addappid(1144203, 1, "Unknown")
setManifestid(1144203, "Unknown", 0)
addappid(1144204, 1, "Unknown")
setManifestid(1144204, "Unknown", 0)
addappid(1144205, 1, "Unknown")
setManifestid(1144205, "Unknown", 0)
addappid(1144206, 1, "Unknown")
setManifestid(1144206, "Unknown", 0)
addappid(1144207, 1, "Unknown")
setManifestid(1144207, "Unknown", 0)
addappid(1144208, 1, "Unknown")
setManifestid(1144208, "Unknown", 0)
addappid(1144209, 1, "Unknown")
setManifestid(1144209, "Unknown", 0)
addappid(4224910, 1, "Unknown")
setManifestid(4224910, "Unknown", 0)
addappid(3174120, 1, "Unknown")
setManifestid(3174120, "Unknown", 0)
addappid(3015760, 1, "Unknown")
setManifestid(3015760, "Unknown", 0)
addappid(3089910, 1, "Unknown")
setManifestid(3089910, "Unknown", 0)
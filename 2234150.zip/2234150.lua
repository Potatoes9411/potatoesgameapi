-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2234150's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:58:43 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 1
-- Total DLCs: 0
-- Blacklisted Depots: 15
--   Depot 223479: Blacklisted
--   Depot 223474: Blacklisted
--   Depot 223478: Blacklisted
--   Depot 223482: Blacklisted
--   Depot 223484: Blacklisted
--   Depot 223473: Blacklisted
--   Depot 223483: Blacklisted
--   Depot 223481: Blacklisted
--   Depot 223471: Blacklisted
--   Depot 223476: Blacklisted
--   Depot 223477: Blacklisted
--   Depot 223475: Blacklisted
--   Depot 223485: Blacklisted
--   Depot 223472: Blacklisted
--   Depot 223480: Blacklisted

addappid(2234150)
addappid(2234151,0,"b7d3cfbe2d7ab09a4e80d1083ae7b7ce90e9e11c3d33c29cf6677ae379ce23ce")
--setManifestid(2234151,"3537954537721895892")
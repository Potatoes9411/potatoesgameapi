-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 590830's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 07:00:03 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(590830)
addappid(590830,0,"d9b26387a4295869ed1ce85b03f90e6fc26c20abfb6662f36abd172536b17c9e")
addappid(590831,0,"5368f87f9235f5cd8144e9eea13824133defa90e4a90c2d478fac61ca5cfcc8a")
--setManifestid(590831,"7866445602777029156")
addappid(590832,0,"5f6814c4b25b087171439e50af8b9e5c75d8a8b2134ce03afc32c7fd5fc8a7a5")
--setManifestid(590832,"7468885803197300112")
addappid(590838,0,"0544a1cb5bde6b828e84023ecfff94eb10ecbbf0bdc20a851d91f0d02a000fc5")
--setManifestid(590838,"6329466737456331656")
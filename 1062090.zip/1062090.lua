-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1062090's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:55:26 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 5
--   Depot 1062163: Blacklisted
--   Depot 1062521: Blacklisted
--   Depot 1062161: Blacklisted
--   Depot 1062162: Blacklisted
--   Depot 1062164: Blacklisted

addappid(1062090)
addappid(1062090,0,"ae26e4878b346db42adc3555b618ae1bc88ccd1cca9758d27b4e7c6e41ea64df")
addappid(1062091,0,"e6291a6d488f1366425014f5742483a513e8771437644a531111ffc9e9674be4")
--setManifestid(1062091,"2974286479314046726")
addappid(1062092,0,"07decf196b134aeb2362a7dcdf1ebce51004f759e44961e838189f59f9943267")
--setManifestid(1062092,"1661847142878378737")
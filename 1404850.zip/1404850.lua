-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1404850's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:45 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(1404850)
addappid(1404850,0,"ae7e224dd533119417de63dba0ab4ede206f1f9615f64827d665a8d6c47553e6")
addappid(1404851,0,"49307113fa498c8ccf0d0c6bd21e61227a4b210377dd39ab2b11082c9a0f9a94")
--setManifestid(1404851,"4508801238880900098")
addappid(1404852,0,"89fe92423db001d554187f01b3a48f7f43a3abcd98516b97de53fe31e65d39cc")
--setManifestid(1404852,"6888388040409228601")
addappid(1404853,0,"eba24d44ed115cfca78c08c1de92a674bc699a0bc43e4054615ad8591a653c43")
--setManifestid(1404853,"6575032920067735833")
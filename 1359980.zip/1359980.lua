-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1359980's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:44 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 1
--   Depot 1359281: Blacklisted

addappid(1359980)
addappid(1359981,0,"4407b8f39b12b4d47ebb635bc862313dc9e3f5afe62b8cbbd0314223eead3856")
--setManifestid(1359981,"907142724616011341")
addappid(1359980,0,"17286d0795724b145c8496a2b2a3d6d756b0749964e7d4190945221c36fe4da0")
addappid(2015160,0,"393d8ee3bef375c514a33f58f6125a93480faa0b5932d4a0d2120ae1b1f0db3d")
--setManifestid(2015160,"3354919700666920471")
addappid(2007440)
addappid(3768390)
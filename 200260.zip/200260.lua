-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 200260's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:36 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 12
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(200260)
addappid(200261,0,"019a5f25f2e8f8f5af0e2abd4a378d118584220629f3696c764feea17a10e7df")
--setManifestid(200261,"957853014295671009")
addappid(200262,0,"5ce8e1ff931612a6ad759d0dc3b9e17792f76ef2f68617a342f8f7ca2878334f")
--setManifestid(200262,"7845728011859274564")
addappid(200263,0,"b4deb67bcf16c9789ca98333b2468a7855c1d0b5666831512931c0ba7fbec342")
--setManifestid(200263,"4940815151499122323")
addappid(200264,0,"efdd039029c3029efa403065598ec995138b93e3397c229fc701b9ec382518cc")
--setManifestid(200264,"387377931563640160")
addappid(200265,0,"9181b86acfee5b9a04dc9cdb91a3b718d7270088f5b8ad38c0546308b6b74bfc")
--setManifestid(200265,"1556860923130685654")
addappid(200266,0,"1d7278a2f37cea578f87ae627b04c1243a1fae53a08c30e61a8480220f2fcb7e")
--setManifestid(200266,"406813562658710105")
addappid(200267,0,"0ffd19248ba97019cfa054a9d313a0c49783c79486cfefa7adb1ae7046a585ad")
--setManifestid(200267,"1530229855874547766")
addappid(200268,0,"218ea6bab509c53b1b4aca532ba76b6333e507c8767eb12ee8941ffc317368c4")
--setManifestid(200268,"425136602149417750")
addappid(200269,0,"5692d822f135fbb0956387d55f8379f18ffc8184a69ed34a5f48f1b6b992ca70")
--setManifestid(200269,"4553205993270337121")
addappid(200270,0,"77e1035ff98a181969f9af3ebe24fe887edc2e508c33a3b77698fd553ce2b94a")
--setManifestid(200270,"827746602157973325")
addappid(200271,0,"650fc34b13a3aed6a2876dc2f60142823f6f87481286bab0632c11add439e722")
--setManifestid(200271,"407262115261230492")
addappid(200272,0,"d9547d1756b041183d7b9ba73e9d32a76915b139426077e696256357c2cb39a5")
--setManifestid(200272,"2232671537466003555")
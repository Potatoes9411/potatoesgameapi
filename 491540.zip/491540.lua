-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 491540's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 07:00:00 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 17
-- Blacklisted Depots: 0

addappid(491540)
addappid(491540,0,"50ede99c2f96404b8a78ea512566035693baad8bf04610df397b9587b56ae155")
addappid(3544250,0,"25a1c05581659f93bcbf9d25a2f6c033ea73eb9fac6eda9727e03454fde92247")
--setManifestid(3544250,"1487328444326737781")
addappid(491541,0,"8d2383b07a93cb99ce9f861e608ebecb5f050f9b03c687a4c34d65810c7a6de2")
--setManifestid(491541,"2649448525336471144")
addappid(491542,0,"17a413c346787a07c3435c510d605b955d08d830625bce61660fea8014c99ee3")
--setManifestid(491542,"3296006866132904316")
addappid(897493,0,"31e71ddf1e4074dd299969b0b2bf3d6752f7d420860a443729aa2b25ac6a15d6")
--setManifestid(897493,"5503265932311683720")
addappid(897494,0,"b3f0af7017d1c49fcf5e67fda2f8f0cf27a8497278ea73223937a1ed9b15df6a")
--setManifestid(897494,"3725264354591688735")
addappid(897495,0,"ee3dfb504287b75635b8f4f65e461b942c19ee2aa79f41ff33bd918c21968341")
--setManifestid(897495,"5501507913094284178")
addappid(897496,0,"775dc74ca6a581d55a7fbb9d866ed88bbb58af2b9db1830bba59605dfb4e4911")
--setManifestid(897496,"7856527596074613875")
addappid(897498,0,"4579ccfebc7d2b7503855a9ca06e5814dd25974c87ba487f9bcb5c57f4126928")
--setManifestid(897498,"2467913106153080820")
addappid(897499,0,"b590c139a5495cb19349ad13183148beebba64cba77fd97fd2203f5c3af3eb0e")
--setManifestid(897499,"3424333586108645378")
addappid(898611,0,"abbdea3d230c0dfec1c0e957b9e7e48d11cee42a4231596bcaf7f7782b0769f2")
--setManifestid(898611,"3784322270561090811")
addappid(898612,0,"7507d616d2d5d33fb200774c4721b24c7b12c9a6e244a7d955292b76d6bf0386")
--setManifestid(898612,"6856078903255251146")
addappid(898621,0,"d6ac0bafa7c3862e611df6645da819c058edc7bff67a77957644795a37d32403")
--setManifestid(898621,"780433789316063419")
addappid(898622,0,"928e91bdd6aff07abd00679a7b57b6cf2afb5e03b0e9552fbfe21559381a2148")
--setManifestid(898622,"1231484820983016185")
addappid(898623,0,"c3946683cfdbc82316bce160e3d183a7910d1dcf95261729d2e831c28f705e0e")
--setManifestid(898623,"2005502871026558840")
addappid(898624,0,"3da00b447931500314e2ec3ef7824e0828a836c20b74edd3f9e46fc04f3a4580")
--setManifestid(898624,"2265013552689358100")
addappid(898626,0,"a0e87b2536cf223daa4572d5c494db6c1da23303a5bf1f00196af604a71915db")
--setManifestid(898626,"8119239068154372879")
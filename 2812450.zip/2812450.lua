-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2812450's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:33 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 6
-- Blacklisted Depots: 0

addappid(2812450)
addappid(3493700)
addappid(3623570)
addappid(3823710)
addappid(2812451,0,"92971f4b75b3fdfcd20b47058bcc1355587bf47f8d0dde109c5d19a73d2fe192")
--setManifestid(2812451,"6771618793689777089")
addappid(2812452,0,"6dd88384ecca8cc7453d0f73ed4a3e3602ad7ce7dbcf99a9c7659656b3c39928")
--setManifestid(2812452,"5371010843305249289")
addappid(2812453,0,"8a4495c12bea8fc1e192cd9a38f6702b3296a236cfa493f71da29f358e721e45")
--setManifestid(2812453,"3866463967639269581")
addappid(3493700,0,"d4139c94384eaa543ba06fdfcffc8406975163ec3186e9606910115bae523541")
--setManifestid(3493700,"286172990771027038")
addappid(3623570,0,"e04a8b7a8e98e1eba64ab21e373895b6bc41f7a214f83fc2de910c2f6efdeab3")
--setManifestid(3623570,"3569204743356337756")
addappid(3823710,0,"03d39c8de6a3f8c4a2f8980e7a8d0b71b24d5e0a27d63c9c8d1c9502042f9986")
--setManifestid(3823710,"5932221360332499302")
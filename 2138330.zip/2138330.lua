-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2138330's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:58:01 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 22
-- Total DLCs: 0
-- Blacklisted Depots: 2
--   Depot 2138711: Blacklisted
--   Depot 2138721: Blacklisted

addappid(2138330)
addappid(2138330,0,"0b2b89913e185ab0ac452b5af584c482d5a8c6f34b7b32ae2dda130deaab64bd")
--setManifestid(2138330,"1003893636455474164")
addappid(2138331,0,"2555f9afe152d9355bbc8153ed96c38750b8bbe66724062fde11810dbf132693")
--setManifestid(2138331,"7557611394831771970")
addappid(2138332,0,"4c64a4a0b1cd40244001e3d86e6fc19208ee6f1367cd117683860fcfe9e08dcb")
--setManifestid(2138332,"7728733908936856189")
addappid(2138333,0,"7991a1134455aead3222a58b1246e836804a0ef11faef0284867c29d77d23945")
--setManifestid(2138333,"2737235465048019797")
addappid(2138334,0,"7cf1934dfe03948c22b65d11c4b0df6fe4bb6f05c0b76fc6c240b730cb62c73d")
--setManifestid(2138334,"2255167949129647656")
addappid(2138335,0,"6388e0552ce0fc948e5c93e23902afa0ba9315d78f9eb491422abdc97b390409")
--setManifestid(2138335,"6491696797696369813")
addappid(2138336,0,"c318bdc3350aad3f756cadb68d2dde3954e60869c003ad15d150e0f5d95bdad9")
--setManifestid(2138336,"8637009798751881938")
addappid(2138337,0,"f9d3075d5d20d353263175bd5a682ff396fc3e2e59836a39e018ac81200c505f")
--setManifestid(2138337,"2512706444417470881")
addappid(2138338,0,"6bf9c69492004a9e232ab7c90dbdafae3ae3364cccdf4104df98f3fd02e4ddb7")
--setManifestid(2138338,"6821671836788372554")
addappid(2138339,0,"0d34fa3f0439c9b355882e4e366c4ff89f4e17d2cc2605a05f7473c48ca93bee")
--setManifestid(2138339,"7556060123277495603")
addappid(2224070,0,"13af5172058a27f8523f2caf0b4378c8dc58adf507ff3b8320ee6292ef2db899")
--setManifestid(2224070,"8906180928185088202")
addappid(2224071,0,"317B5B3562F0A547D859F8203880C860E8D47727942C50486F9810B6BEE43E93")
--setManifestid(2224071,"8308591706303082171")
addappid(2224072,0,"B98C868CA11A3CB0052C5CB5FC6ED67E755C7F5DA8DD080C958C6154EDA17F80")
--setManifestid(2224072,"2650640366998881299")
addappid(2224073,0,"43531DC1BF07842E223AC2591BC263B4CE37090BC89D632B94BAA4EFFDE4DE20")
--setManifestid(2224073,"128847074090854083")
addappid(2224074,0,"8A45B53465567F0E423A2FB234F868FAA70B7B827AA1D4BCA9EB1169B7E63A46")
--setManifestid(2224074,"2438632982641321122")
addappid(2224075,0,"AA69EA92143A543978677D384D5ED2AB574470C137CF691AD2DE2125E9D0EB9E")
--setManifestid(2224075,"4943340702183225440")
addappid(2224076,0,"C793077DE4603ECE9521F298182259790C92EA2933A854E3B8FC2729C15791DF")
--setManifestid(2224076,"5075323111781204317")
addappid(2224077,0,"F788663DC6D2F5C417E51A5B1A22356E2C3C3A60B85D89672F0216517AA92E73")
--setManifestid(2224077,"3364673074736515968")
addappid(2224078,0,"7EE88193E5B45B787242DFEF113C89D6EFAC43C9EF159C362F44485102488194")
--setManifestid(2224078,"1790681978238440284")
addappid(2224079,0,"EA8DF3C3B262A96DD8DD06B0D3AB8393FA170771EDEE5F40A240488E3EDF913B")
--setManifestid(2224079,"8450842337059471618")
addappid(2224080,0,"0CB8AF78EFC733CA46C7B5A0B9D520B2002B5860FD70F052D59B67DC1112E3EA")
--setManifestid(2224080,"1116267346816464113")
addappid(2224089,0,"284E2DB9B686F24646644F365F81F5447D2B26D1363163DF229904C8378A0015")
--setManifestid(2224089,"2868368683526045092")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2570130's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:24 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 1
-- Blacklisted Depots: 4
--   Depot 2570061: Blacklisted
--   Depot 2570071: Blacklisted
--   Depot 2570021: Blacklisted
--   Depot 2570051: Blacklisted

addappid(2570130)
addappid(2570131,0,"c48ebaaee1a11e2e376d2be05838872b051d479a50e76184c3e100ab2f70a3eb")
--setManifestid(2570131,"7576483566595399332")
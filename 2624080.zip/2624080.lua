-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2624080's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:00:23 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 1
-- Total DLCs: 0
-- Blacklisted Depots: 3
--   Depot 2624: Blacklisted
--   Depot 2624671: Blacklisted
--   Depot 2624871: Blacklisted

addappid(2624080)
addappid(2624081,0,"bb75fa0f712706175cd0af75ac246a74367321715a3466abf04d54df27cea61b")
--setManifestid(2624081,"8866584297420315046")
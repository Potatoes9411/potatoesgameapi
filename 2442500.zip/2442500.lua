-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2442500's Lua and Manifest Created by Potatoes9411
-- Coodesker
-- Created: May 16, 2026 at 04:45:25 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 10
-- Total DLCs: 0
-- Blacklisted Depots: 2
--   Depot 2442711: Blacklisted
--   Depot 244211: Blacklisted

addappid(2442500, 1, "Unknown")
addappid(2442501, 1, "Unknown")
setManifestid(2442501, "Unknown", 0)
addappid(2442502, 1, "Unknown")
setManifestid(2442502, "Unknown", 0)
addappid(2442503, 1, "Unknown")
setManifestid(2442503, "Unknown", 0)
addappid(2442504, 1, "Unknown")
setManifestid(2442504, "Unknown", 0)
addappid(2442505, 1, "Unknown")
setManifestid(2442505, "Unknown", 0)
addappid(2442506, 1, "Unknown")
setManifestid(2442506, "Unknown", 0)
addappid(2442507, 1, "Unknown")
setManifestid(2442507, "Unknown", 0)
addappid(2442508, 1, "Unknown")
setManifestid(2442508, "Unknown", 0)
addappid(2442509, 1, "Unknown")
setManifestid(2442509, "Unknown", 0)
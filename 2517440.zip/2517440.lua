-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2517440's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:59:57 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 2517221: Blacklisted

addappid(2517440)
addappid(2517441,0,"0fdbb7cb1b20b55c4f89dddba41583da1ff5c4b126c525bd1bd450a951a52fc9")
--setManifestid(2517441,"5257082168358035575")
addappid(2517442,0,"1299e8a08a3c08075513404d74b84a56e4701369fd1ac537b85054125623c968")
--setManifestid(2517442,"1276340025236826064")
addappid(2517443,0,"9fcc12ff133b5b434cc7b34e20c5f895284dd16f005d03c967101e9e56116183")
--setManifestid(2517443,"5591449114862486921")
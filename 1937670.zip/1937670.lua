-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1937670's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:56 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 2
-- Blacklisted Depots: 0

addappid(1937670)
addappid(3223540)
addappid(1937671,0,"f50f1eca68496223d4ad7bd27bca0d19011139b8f829464c4eb28b088576f3d1")
--setManifestid(1937671,"446635681537227218")
addappid(3223540,0,"701e0eba235c09a5a7f4415d708e62dc51d1f817e2242c980631e8ff4c4f2a06")
--setManifestid(3223540,"1641110266021754547")
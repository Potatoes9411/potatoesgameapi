-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2084000's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:48 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(2084000)
addappid(2084001,0,"e467a1dc28688a4ba159328e3419a2ddbbc265d7677b0eff56c56d25954271a9")
--setManifestid(2084001,"4923084417728162651")
addappid(2084002,0,"c1e765cd79523f2e2e0b9b808de03b6a05d66412826feef443a6dfb427f5e80b")
--setManifestid(2084002,"5092188064288801929")
addappid(2084003,0,"7cb9a4ecc6751d163d9efe97d790a2b4f66bcab785782e1dd0791ecb91592bae")
--setManifestid(2084003,"1684918381538092626")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1895880's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:17 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 1
--   Depot 1895901: Blacklisted

addappid(1895880)

addappid(1895881,1,"47591f17983db571ad7f593c74995675394decc869f130ef55fba97e44b9061e")

--setManifestid(1895881,"4954954142368047141",40481303462)

addappid(1895882,1,"fa1c024080888563fe4764132e611d0df20a3981299e4cf4302a70d998f5f0e2")

--setManifestid(1895882,"8698807142064276173",343307398)

addappid(1895883,1,"d5fc48ab7d1d44287e5810d1b12e2db1990512823e7d7b30eb1c3fa755a12a5a")

--setManifestid(1895883,"8245563844195405867",645558272)

addappid(2366780)


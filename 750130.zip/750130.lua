-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 750130's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 07:00:05 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(750130)
addappid(228983)
--setManifestid(228983,"8124929965194586177")
addappid(228985)
--setManifestid(228985,"3966345552745568756")
addappid(750133,0,"da21083938e32867b6b9190a5f7ae54c1b716b6d74df27516a589f9f0cb9d4f5")
--setManifestid(750133,"6058490855972658563")
addappid(750131,0,"47a72920d4c72af7e8407a617881be6fa81aaaf4f4334c27bc6ce0844890add5")
--setManifestid(750131,"7624002377498776081")
addappid(750132,0,"33dc940870d31a3fff549c22816fa9a2170b5a3c87d60ea2d4d66565fa1520b7")
--setManifestid(750132,"3304446528767190259")
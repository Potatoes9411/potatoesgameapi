-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1839430's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:54 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(1839430)
addappid(4112710)
addappid(4123330)
addappid(4123340)
addappid(1839431,0,"f909216fd63f07d4cc6cad35d3482673e78c92b1b28db3b493113c7f7145c40a")
--setManifestid(1839431,"8262668079174366622")
addappid(1839432,0,"7a4af8a39e4d674b4af25ac5edbf78f3330b80a25891cdc78a58809863bd41b9")
--setManifestid(1839432,"812423775816496509")
addappid(3309801,0,"eb33a62af8d26bd13463a39431cadbc4db3aa54244a0bc91d01bb94feee60f49")
--setManifestid(3309801,"6080085152075284512")
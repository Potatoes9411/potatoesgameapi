-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2984570's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:40 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(2984570)
addappid(2984571,0,"5cecb3accdab658171b3ef98bf8bd0e584f106fdf8316b6f2c1a85c8fee39660")
-- setManifestid(2984571,"4354842722169215443")
addappid(2984572,0,"2faa276cb728cafda94323d80f52391e1a54e2ccb5f5a043412ac2c3f5d0f650")
-- setManifestid(2984572,"3573847695762766688")
addappid(2984573,0,"764cf5b440daa8e52a687fb2bac3dff1aee7ba0bc812d58ae2a8329e74725d03")
-- setManifestid(2984573,"43238630841536815")
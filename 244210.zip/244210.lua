-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 244210's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:59:38 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 14
-- Total DLCs: 0
-- Blacklisted Depots: 2
--   Depot 2442711: Blacklisted
--   Depot 2442462: Blacklisted

addappid(244210)
addappid(244210,0,"f23245bf2e189422f4977c167c5b7f0d5ecccbc7a595e398f8936329d080ff12")
addappid(347990)
addappid(404430)
addappid(423630)
addappid(467980)
addappid(493190)
addappid(509350)
addappid(526060)
addappid(540710)
addappid(540711)
addappid(619680)
addappid(675590)
addappid(1387540)
addappid(244211,0,"7cbd509f5c33d07d80375e94bb55d9951e1bea4861f99c10421e1e37d9c6e6a7")
--setManifestid(244211,"4950336537810395690")
addappid(347990,0,"789cc0104f4b59d55b96c7a310101e6c4766036645244af72bbda39ae7ad03aa")
--setManifestid(347990,"6791848099595238056")
addappid(404430,0,"23de34042efaf92152ae28c16315c8ca57ec21f59069a50ed08ee7c161a07ccb")
--setManifestid(404430,"3305068408340865881")
addappid(423630,0,"e103fe276e451f80152f996b0609a23fa4b816cfba6ce09afd352ba595d58a87")
--setManifestid(423630,"143182663462094843")
addappid(467980,0,"8e4d401e0d78fceea18c3a6e3da94f91cfc1ea9620b93bfe1e7cd93fa83bcae7")
--setManifestid(467980,"1919441460742340991")
addappid(493190,0,"7fce09bb241009bdbfd30240ca2d73d3f8d50c85236266e8a64dac9b187a981c")
--setManifestid(493190,"6702276192559020176")
addappid(509350,0,"304503a53fcb2b4a404d501ab0f4b44e83590876df21979e5308c07935da2761")
--setManifestid(509350,"5232019972713022175")
addappid(526060,0,"5cdea49412168d3835761d2454bf97a87d7261c6f6058e0095edab66d9a41461")
--setManifestid(526060,"1609580688491246185")
addappid(540710,0,"9c7da758ba906a41a39245cd6dcc6f69547231a9d6fb1973b39313afe5354fd4")
--setManifestid(540710,"7212972613834439529")
addappid(540711,0,"6f2fac093cc2cf5e1d1ab99c1c1a766422f97502d689a93cf51076c8aa8d0cf2")
--setManifestid(540711,"5205419179365407728")
addappid(619680,0,"78bda0cdc6e6a57c2a9e2b081db27d0ce9f34bd02196d2b996d17593f77bd124")
--setManifestid(619680,"5396831645102266732")
addappid(675590,0,"962fcf3fd904ee05f71944f3b51692c67799b42d94a81ea6cfc368ea60889f12")
--setManifestid(675590,"4281175229020665840")
addappid(1387540,0,"e9c1b30b9c55940e7a331ec99a84c63c1594420060295bdee11f86c5bd15eb85")
--setManifestid(1387540,"9131952850290736705")
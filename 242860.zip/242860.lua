-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 242860's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:17 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 6
-- Blacklisted Depots: 0

addappid(242860)
addappid(242865,0,"2433b5b1705fea4c3b2ae8da1a58d02e96ee4c1139a99ade8abaa208548919a4")
--setManifestid(242865,"1025927188659212271")
addappid(242864,0,"79aaf5a49662def1bd78635305a019574a88a36b73848bf24a1006660af3d11b")
--setManifestid(242864,"5611449861189975879")
addappid(242862,0,"32493f099e4630cef4e58c575e9302d1b4a7244b95daaf6071c2374e90f1252d")
--setManifestid(242862,"783920121999251094")
addappid(242863,0,"6d09b107eff398052d8fa3d8eab0a49589f76b365235bc8d1dddb13e1824176a")
--setManifestid(242863,"2764337762327928586")
addappid(987070,0,"6a0fbf9ab1b574a31dc0ce5fa29c80486a7fefbf931545a375d550a0a3729e7c")
--setManifestid(987070,"7307236088776550583")
addappid(242869,0,"1a65b012a3ca4c6942ef5002edd237efba12dc92e94c92d6156065388bd34274")
--setManifestid(242869,"6758720324821461309")
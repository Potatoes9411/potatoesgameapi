-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2481790's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:59:49 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 4
--   Depot 248172: Blacklisted
--   Depot 248173: Blacklisted
--   Depot 248174: Blacklisted
--   Depot 248171: Blacklisted

addappid(2481790)
addappid(2481791,0,"7331c7d8fee18c9b3a0c4e1cf87d183ee3a1686d5644a3f51237daac2d6bbd55")
-- setManifestid(2481791,"4182466061550562200")
addappid(2481792,0,"e320a77e9d31b0ab49dd1b1d7d32205b0a9e5764576b94529746ff2e7d6120c9")
-- setManifestid(2481792,"9178667550759510419")
addappid(2481793,0,"228ae5690d270706a30fba91fc729ea47fb31a33d38cc8bac875d7d0795f6747")
-- setManifestid(2481793,"6733737611953892302")
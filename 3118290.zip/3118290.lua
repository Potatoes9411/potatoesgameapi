-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3118290's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:17 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(3118290)
addappid(3118291,0,"1a2470a58ae4b7b12bee0090b3cf97a1c7d831b21327b3bc82c7d0c190600bdd")
--setManifestid(3118291,"7017639504482686436")
addappid(3118292,0,"6e2ac5f95fe73b025d5cf8b68ec936e2bcaaa8e1c59e1c04cd60a2fe16911f9b")
--setManifestid(3118292,"2812390349613512841")
addappid(3118293,0,"20337ade0ebb27fe10c65ae33da4c412bfa7547419644138627f76fe4c9309d7")
--setManifestid(3118293,"8407094222491133078")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2300840's Lua and Manifest Created by Potatoes9411
-- Subliminal
-- Created: May 16, 2026 at 04:45:55 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 10
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(2300840, 1, "Unknown")
addappid(2300841, 1, "4c8307a27765753d31cce03154f0d13df969d0339cf42d2df75852fe03211baa")
setManifestid(2300841, "4778353610403332619", 0)
addappid(2300842, 1, "Unknown")
setManifestid(2300842, "Unknown", 0)
addappid(2300843, 1, "Unknown")
setManifestid(2300843, "Unknown", 0)
addappid(2300844, 1, "Unknown")
setManifestid(2300844, "Unknown", 0)
addappid(2300845, 1, "Unknown")
setManifestid(2300845, "Unknown", 0)
addappid(2300846, 1, "Unknown")
setManifestid(2300846, "Unknown", 0)
addappid(2300847, 1, "Unknown")
setManifestid(2300847, "Unknown", 0)
addappid(2300848, 1, "Unknown")
setManifestid(2300848, "Unknown", 0)
addappid(2300849, 1, "Unknown")
setManifestid(2300849, "Unknown", 0)
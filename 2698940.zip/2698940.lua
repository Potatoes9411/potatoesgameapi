-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2698940's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:29 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 2
-- Blacklisted Depots: 0

addappid(2698940)
addappid(2716050)
addappid(2805000)
addappid(2805010)
addappid(2849030)
addappid(2849040)
addappid(2865990)
addappid(2898630)
addappid(2898640)
addappid(2934260)
addappid(3251420)
addappid(3251430)
addappid(3251440)
addappid(3251450)
addappid(3917350)
addappid(3917380)
addappid(3917390)
addappid(3917400)
addappid(3917420)
addappid(3917430)
addappid(3917440)
addappid(3917450)
addappid(3917460)
addappid(3917470)
addappid(3917490)
addappid(3917500)
addappid(3917510)
addappid(3917520)
addappid(3917530)
addappid(4160650)
addappid(4160660)
addappid(4160670)
addappid(4160680)
addappid(4160690)
addappid(4160700)
addappid(1716751,0,"84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
--setManifestid(1716751,"434820204365296156")
addappid(2698941,0,"d883429e0c229f4e0634265ea029ccf4200bf0a6d171047809fab73ae807ba8c")
--setManifestid(2698941,"471940520532909391")
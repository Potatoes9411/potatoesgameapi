-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 222480's Lua and Manifest Created by Potatoes9411
-- Resident Evil Revelations
-- Created: June 17, 2026 at 06:58:40 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 10
-- Total DLCs: 0
-- Blacklisted Depots: 13
--   Depot 2224080: Blacklisted
--   Depot 2224073: Blacklisted
--   Depot 2224089: Blacklisted
--   Depot 2224078: Blacklisted
--   Depot 2224070: Blacklisted
--   Depot 2224079: Blacklisted
--   Depot 2224071: Blacklisted
--   Depot 2224076: Blacklisted
--   Depot 2224077: Blacklisted
--   Depot 2224072: Blacklisted
--   Depot 2224075: Blacklisted
--   Depot 2224611: Blacklisted
--   Depot 2224074: Blacklisted

addappid(222480)
addappid(229621,0,"cd908e40d47ae228e942070e0e6e9dd87d874f16434488b0b6d70091915ec999")
--setManifestid(229621,"1729720183785589076")
addappid(229622,0,"ae8ea828b9a2c97510d5968ce55a9dae3a04346865801ac4757d7cd7ff106d9d")
--setManifestid(229622,"5762540738354433494")
addappid(229626,0,"1badd29cc032ee6227834ed10f78d0f4e785be725ae708391b1d6083e9d0fd67")
--setManifestid(229626,"1462684019205755272")
addappid(229627,0,"05fe47e8229993a4957c546b6b11f34f46e75c4344ec653a896e52fcfb8d4343")
--setManifestid(229627,"6146425481277420255")
addappid(229628,0,"deda58ec7e09d693118e91f904d7e25e08198a746dfe30f5a988ade2caf96dbb")
--setManifestid(229628,"1091544035272724112")
addappid(229629,0,"c9a80ed80166abc5061fe93f2ca57b2a013075300639e2a7963909215b3cdc57")
--setManifestid(229629,"7610772433233583544")
addappid(229630,0,"c338077d7ee7ef5a03646b62ae08290d05705e25da98b945e75cc86b5c3da7a3")
--setManifestid(229630,"8821996626474824228")
addappid(229631,0,"1d5f2f41d6041f72b150c752b7ecf1ddd7d9db77a0c983831b6803105ebd962c")
--setManifestid(229631,"2800660586458870138")
addappid(229632,0,"31b56ec2f11495352b66ad07ea9df0f95cadec7a23235f6779c25899d192d306")
--setManifestid(229632,"5610201632971379408")
addappid(222481,0,"65e75d906613ce658af73b8db0772cf9f6fa3905427161dd1c0482572da72c0d")
--setManifestid(222481,"2624313053854726936")
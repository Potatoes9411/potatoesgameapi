-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 222480's Lua and Manifest Created by Potatoes9411
-- Resident Evil Revelations
-- Created: May 16, 2026 at 04:45:54 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 17
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(222480, 1, "Unknown")
addappid(222481, 1, "Unknown")
setManifestid(222481, "2624313053854726936", 0)
addappid(222482, 1, "Unknown")
setManifestid(222482, "Unknown", 0)
addappid(222483, 1, "Unknown")
setManifestid(222483, "Unknown", 0)
addappid(222484, 1, "Unknown")
setManifestid(222484, "Unknown", 0)
addappid(222485, 1, "Unknown")
setManifestid(222485, "Unknown", 0)
addappid(222486, 1, "Unknown")
setManifestid(222486, "Unknown", 0)
addappid(222487, 1, "Unknown")
setManifestid(222487, "Unknown", 0)
addappid(222488, 1, "Unknown")
setManifestid(222488, "Unknown", 0)
addappid(222489, 1, "Unknown")
setManifestid(222489, "Unknown", 0)
addappid(229628, 1, "Unknown")
setManifestid(229628, "1091544035272724112", 0)
addappid(229629, 1, "Unknown")
setManifestid(229629, "7610772433233583544", 0)
addappid(229630, 1, "Unknown")
setManifestid(229630, "8821996626474824228", 0)
addappid(229627, 1, "Unknown")
setManifestid(229627, "6146425481277420255", 0)
addappid(229626, 1, "Unknown")
setManifestid(229626, "1462684019205755272", 0)
addappid(229621, 1, "Unknown")
setManifestid(229621, "1729720183785589076", 0)
addappid(229622, 1, "Unknown")
setManifestid(229622, "5762540738354433494", 0)
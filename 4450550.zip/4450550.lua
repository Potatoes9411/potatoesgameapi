-- Made by F1uxin, Discord ID:965053505901588521 | Discord Server (TGP | The Galaxy of Pirates): https://discord.gg/VfCxRsFyFe

-- If you're interested in distributing these files please dm me on discord (UserID:965053505901588521) 
-- (I don't care if you send them to a friend or to help someone, just if you add them in your bot or have them widely available then i would like to know.)

-- Socials: https://guns.lol/f1uxin

-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid", save the file, then add the lua file, (i think you can add the manifests too but I would just add the lua file to ensure it works).

-- If you have any questions feel free to dm on discord (UserID:965053505901588521)


-- Main stuff to actually add the game, DLCs, & depots.
addappid(4450550) -- Femboy Next Door 🔞🚪
addappid(4450551, 1, "de60cdd9d70fb1ff1656de0967a08902acb5a0c905b494f4235d44fe1ff62124") -- Depot 4450551
setManifestid(4450551, "2914560209923537797", 3721105583)
addappid(4734660)
addappid(4734660, 1, "ea92c72a16891b68884b51ad5fd7ef23063318c2fe8c8a0d9238902d363e3e1f") -- Femboy Next Door  - Wallpapers 18 - Depot 4734660
setManifestid(4734660, "6042184828095310531", 230840595)
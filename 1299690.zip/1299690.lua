-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1299690's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:56:14 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 10
-- Total DLCs: 0
-- Blacklisted Depots: 3
--   Depot 1299061: Blacklisted
--   Depot 1299171: Blacklisted
--   Depot 1299530: Blacklisted

addappid(1299690)
addappid(2658940)
addappid(3035200)
addappid(3035210)
addappid(3035220)
addappid(3035230)
addappid(3035240)
addappid(3035260)
addappid(3075820)
addappid(3142680)
addappid(3142690)
addappid(3142700)
addappid(3145920)
addappid(3228010)
addappid(1299691,0,"e98ac5c23950700f14844776585c217a0931a6f1c7b9a60f2b931129107d80ff")
--setManifestid(1299691,"3038959275478678369")
addappid(2658940,0,"efa59322699ac2d52478aae83bc70716e8f0f21387e12fe168899c1d7c256793")
--setManifestid(2658940,"2095183773854632480")
addappid(3035200,0,"484d0739d9ad890e1380ea5efcd32fe49a3339f4844f61baac1cd53f05069253")
--setManifestid(3035200,"3713146454318724576")
addappid(3035210,0,"ebba4c441b880d0ef27d7bdb186aa4544ab1e4d385627cb7ba77a4bb74b19ac5")
--setManifestid(3035210,"2979750113353045176")
addappid(3035260,0,"e5f1f497ca718762593ec5092ac3a3dcc8ac122642c12d9a10dd7c0809f1b553")
--setManifestid(3035260,"4027523710433681809")
addappid(3075820,0,"927cd6251652aa9f7395bd840a721e9f0917be36e0c5ed8cc043302b2a8e3d42")
--setManifestid(3075820,"7655894981325796752")
addappid(3142680,0,"0a4892a3878f4739a94ba50b5b8ee21f651e268749e1e5fb35805568e6d3d758")
--setManifestid(3142680,"4472104082446306389")
addappid(3142690,0,"40829f616c87361c73c44ed4b3d0592f923dfc1d27da535cfd0bb6c789fabc87")
--setManifestid(3142690,"5534220771734770280")
addappid(3142700,0,"9db4fb134de0c6e53994e696e7329ff4b86d143e12e7aa115afb946d96bf275e")
--setManifestid(3142700,"280723302214068352")
addappid(3145920,0,"c9552e22cea4037b0c3cd320c4ee4ba40e895523fd6983ef8c6d4456f9279fb0")
--setManifestid(3145920,"2529152685774886946")
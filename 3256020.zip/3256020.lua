-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3256020's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:23 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(3256020)
addappid(3639410)
addappid(3639411,0,"ba9c27a6f7986f88b0f1caf0a167f35c7fea8f338a4cd54b7b443b0e687dd6d5")
--setManifestid(3639411,"7672113798175441605")
addappid(3256021,0,"ce6fd8f56262e17a4fc4a2441e49de4599c45a29d5f1022d0fe764686dba3184")
--setManifestid(3256021,"3455925112209613885")
addappid(3882821,0,"1bd4e850d1c0459516aa278a303f0515b081f4bba8678222021bce393400e9cc")
--setManifestid(3882821,"4200388923546204385")
addappid(3882831,0,"bd86d7081d0f3c40db78499239807db2a169ef394f22226dab7f8317d910aea1")
--setManifestid(3882831,"7637190870235527762")
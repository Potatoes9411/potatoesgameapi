-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 248170's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:59:49 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 6
-- Total DLCs: 0
-- Blacklisted Depots: 3
--   Depot 2481793: Blacklisted
--   Depot 2481791: Blacklisted
--   Depot 2481792: Blacklisted

addappid(248170)
addappid(248171,0,"160eaeceeeb3e7a29932ff1c1e6953c53d75bd693ddc46274bf93eb11dfc654f")
--setManifestid(248171,"5979420574992650831")
addappid(248172,0,"0efda0c9d0807135964f0efbb83b8c1b577067a26042a7ed3c3900ce76160916")
--setManifestid(248172,"2808615189290196749")
addappid(248173,0,"104f372d486a9c909c3187d0323aaabe7c9331c233889dafe9e4ec601f8ea79a")
--setManifestid(248173,"7390804288553202310")
addappid(248174,0,"c99607630f744e98545a9dad2b478218605e2cf1cc4091c720937974f32f96c1")
--setManifestid(248174,"6703658417066786042")
addappid(267652,0,"d3a897396a2197b5e91043999067882126bf899959381f80826210870894cfc3")
--setManifestid(267652,"966052398975222512")
addappid(1056780,0,"2ba04f3befe99cdc52d6eedf6a1f9b51397bba2396f2ac972ab8b3e5871046dc")
--setManifestid(1056780,"6493421524160028853")
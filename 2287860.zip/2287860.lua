-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2287860's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:11 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 6
-- Blacklisted Depots: 0

addappid(2287860)
addappid(2287860,0,"b9ee8944cf1e72785a79fc18e8f6decd7f80c429eb027425278c01a9ec44b917")
--setManifestid(2287860,"4298569155490177422")
addappid(2287861,0,"2d921fdc2b25720ee78a5d057f91280d7e8ee9c7301421765de5a22348edef62")
--setManifestid(2287861,"476913435246676622")
addappid(2287862,0,"6892dae3181c49256d1ee2ab48d93c12281d1ebaf965b22ae99102d8080df03a")
--setManifestid(2287862,"3672600042821281602")
addappid(2287863,0,"554ff2f4b5f0b1d99e37832ef906f415d0c43ac494e74e16e777d69aa930f9cf")
--setManifestid(2287863,"1221380312118442086")
addappid(2287864,0,"e1cdd92959542cca4347bf97a9750d70501f70a0e5aab6d065d6f4e421430752")
--setManifestid(2287864,"471481962200431169")
addappid(2287865,0,"7f04b82b9bff9ae2e8d14e87a0e74331006ebdfda27a7d5bf278864dab1ec8c6")
--setManifestid(2287865,"2729598219016079316")
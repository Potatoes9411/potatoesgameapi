-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 667970's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 07:00:04 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 6
-- Blacklisted Depots: 0

addappid(667970)
addappid(667970,0,"6d5bb740323cbaf5e450db87b8c2595e1ded9a3e2b96f87dab6a32c635bbd512")
addappid(1770480)
addappid(2141700)
addappid(2531290)
addappid(1770480,0,"2274ce0ff2c9672e0c95404ea4df5f9ed22c295f00f6b9f017d3699c445e9425")
--setManifestid(1770480,"2836902461265788005")
addappid(1770481,0,"da89b7918a466dc116fa3dc2ec780134e8829781ae3a8282aa0532994d34a068")
--setManifestid(1770481,"4625979481897414804")
addappid(667971,0,"34da89de74099b39413bba485bc7fff7a4bebaad40a894b31bcbee4b3f207a0e")
--setManifestid(667971,"809774009354886606")
addappid(2141700,0,"28e77d66a65877ef4ce95d5d4354ee2239f9a397af6eebb32eccc5046eebce54")
--setManifestid(2141700,"1013815941531505868")
addappid(2531290,0,"d5fd310d63d0468ce9b645c74008874bedc3c31bc1e6d1d774b896306c6d10e8")
--setManifestid(2531290,"1746642230860805602")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2246340's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:58:45 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 2
-- Total DLCs: 0
-- Blacklisted Depots: 6
--   Depot 2246688: Blacklisted
--   Depot 2246685: Blacklisted
--   Depot 2246689: Blacklisted
--   Depot 2246686: Blacklisted
--   Depot 2246684: Blacklisted
--   Depot 2246687: Blacklisted

addappid(2246340)
addappid(228988)
--setManifestid(228988,"6645201662696499616")
addappid(228989)
addappid(2246341,0,"15f418b98b8ade3be07b095f07a9ffc62ab918cf659a2fd7465fcb41c462f0af")
--setManifestid(2246341,"8594435241282658287")
addappid(3308900,0,"86e9ff2249c193631e8e04855d9c6154071b06491dced87279c1c72b1662556d")
--setManifestid(3308900,"1655099395066258695")
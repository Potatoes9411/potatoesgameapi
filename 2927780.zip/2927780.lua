-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2927780's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:01:28 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 1
-- Total DLCs: 0
-- Blacklisted Depots: 19
--   Depot 292735: Blacklisted
--   Depot 292743: Blacklisted
--   Depot 292732: Blacklisted
--   Depot 292731: Blacklisted
--   Depot 292744: Blacklisted
--   Depot 292736: Blacklisted
--   Depot 292748: Blacklisted
--   Depot 292733: Blacklisted
--   Depot 292737: Blacklisted
--   Depot 292734: Blacklisted
--   Depot 292742: Blacklisted
--   Depot 292745: Blacklisted
--   Depot 292740: Blacklisted
--   Depot 292739: Blacklisted
--   Depot 292749: Blacklisted
--   Depot 292746: Blacklisted
--   Depot 292738: Blacklisted
--   Depot 292747: Blacklisted
--   Depot 292741: Blacklisted

addappid(2927780)
addappid(2927781,0,"2f80066bc2ec65724f707d1bac4cfa8c63355e03a969f77b06891f789c8bc55a")
--setManifestid(2927781,"3380210494936121131")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1295660's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:43 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 6
-- Blacklisted Depots: 0

addappid(1295660)
addappid(1295660,0,"f23c385f4f13e1385d24f0f6033c70e9dd9fbbbbc955227df88693a31db9411b")
addappid(2778060)
addappid(3004650)
addappid(3004660)
addappid(3087220)
addappid(3087240)
addappid(3087250)
addappid(3087260)
addappid(3087270)
addappid(3087280)
addappid(3087290)
addappid(3087300)
addappid(3087310)
addappid(3087320)
addappid(3087330)
addappid(3087350)
addappid(3087370)
addappid(3087380)
addappid(3087390)
addappid(3087400)
addappid(3087410)
addappid(3087420)
addappid(3087430)
addappid(3087440)
addappid(3087460)
addappid(3369860)
addappid(3490290)
addappid(3502600)
addappid(3958320)
addappid(3958330)
addappid(3958340)
addappid(3958350)
addappid(3958360)
addappid(3958370)
addappid(3958380)
addappid(1295661,0,"59cf929fe0be7af1bba7498247138b359bcc8141d6921f65f06f5d3c4e604430")
--setManifestid(1295661,"8906953515245277050")
addappid(1295662,0,"2d91bb0ac40f79f21d133921c8092cee1bbc5622c1e429d5d5e65a5543a440eb")
--setManifestid(1295662,"7642248969512117524")
addappid(1295663,0,"129446ed0c86a3cecf211aca2aca7c0ef0b14248fe2e7229afb79e90f2b07531")
--setManifestid(1295663,"7294707238988734171")
addappid(1295665,0,"ad00cf603a7538a190b6f7e523a9f9b1ff48759aacb39f2b35a70c5302fcef37")
--setManifestid(1295665,"6640527968926078330")
addappid(1295666,0,"68e1686bc8f5a23173a86f6a5c3fb61ae2714081bf956976f7f837a1f03a9779")
--setManifestid(1295666,"7303807405015271066")
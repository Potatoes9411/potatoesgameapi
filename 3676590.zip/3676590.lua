-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3676590's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:42 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(3676590)
addappid(3676591,0,"7d16ff1444c7eb74340a2d25cb717cff0a7e445f45efc9ca849eac0e534bfdb5")
-- setManifestid(3676591,"5729688750324395964")
addappid(3878660,0,"eab200925ee14b5cd166ac980f0a6dbdd3ca398b22cc0efb48f666b88355f36a")
-- setManifestid(3878660,"7431617725908416976")
addappid(3878670,0,"cb8d35560b1bfc5d70aa2458deacdc7c38c2551a3b1af91154b6042c228b23c4")
-- setManifestid(3878670,"2010903198205964383")
addappid(3878680,0,"f1d43edf27541d3180dfb58d32550a5f64f75b68f1beb47d7995c9ac375814d0")
-- setManifestid(3878680,"7725812291313090971")
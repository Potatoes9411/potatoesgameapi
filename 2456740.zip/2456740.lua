-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2456740's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:19 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(2456740)
addappid(3887680)
addappid(2456741,0,"e91cba2d1d471bdfb115bee76ac997858f84e6ab0a82af5f17d0054f8a3c9686")
--setManifestid(2456741,"5882439350554180132")
addappid(2456742,0,"7c9a756f88682f7ae0913792f29b1c2ad7c702cb41859ecb9965e8c8760aff0d")
--setManifestid(2456742,"3640606761970167668")
addappid(3887680,0,"25ed1bd4d03ac4fd1a739171c82248fe6db511beea87dccfe33721091039e9c8")
--setManifestid(3887680,"5649700698807492759")
addappid(3887681,0,"443b555d0c838bd99b995ed172ed1d49f028e6347a1f27e3d74e648cd5718bc2")
--setManifestid(3887681,"4516423758677951634")
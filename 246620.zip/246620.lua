-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 246620's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:59:46 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 7
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 2466902: Blacklisted

addappid(246620)
addappid(246620,0,"540f338bcb2eb1e9d469f9302ea6b60481008cef56be0e01e378a92f72041732")
addappid(1472780)
addappid(4508320)
addappid(246621,0,"19ad23e511f566d12808b52a4cfabb6457d8acc91815acbaddc6fdfe76dacfbe")
--setManifestid(246621,"2388251910619442033")
addappid(246622,0,"dd2e9f4b104c4ce27c22dadf3dd13210e54a51c0fa09f14addd72d8c05121f89")
--setManifestid(246622,"3971804755455255724")
addappid(246623,0,"516e04bc485cebe525f9d28a727a2fbc29aad932656bcb36238448797d52a337")
--setManifestid(246623,"3376522824965617773")
addappid(246624,0,"b7170469891310d1335cb12516164cff304a536657ad2c35fad0950719133123")
--setManifestid(246624,"712597846969897429")
addappid(246625,0,"3c1666a26d525bf81d9b9c90bbd47b0fd637db2d2056950f5a9c8c72f76109bb")
--setManifestid(246625,"8060770308095908779")
addappid(246626,0,"8d0fb3394cd06ae93b744373a1024f9a4c4b5c4a1e30ed95fadbb05718d02ff2")
--setManifestid(246626,"1898025581291238622")
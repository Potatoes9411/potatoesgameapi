-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2428980's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:59:34 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 6
--   Depot 242862: Blacklisted
--   Depot 242869: Blacklisted
--   Depot 242864: Blacklisted
--   Depot 242863: Blacklisted
--   Depot 2428801: Blacklisted
--   Depot 242865: Blacklisted

addappid(2428980)
addappid(3902770)
addappid(2428983,0,"4459aa4e531d8007450e4a278ffab68b61d229d38bc1801993ed63bd4275d455")
--setManifestid(2428983,"2879090634081494659")
addappid(3902770,0,"2b223e01ee05e0705677387631030ad574ba96ce2f3736fc222d6405ee4870ad")
--setManifestid(3902770,"1365297379121112229")
addappid(3902771,0,"3497a41434ccc15e61f388247dc9f1afad1c50d64a96463a0969ee7d185c5d1a")
--setManifestid(3902771,"1114887159564530060")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 391720's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:50 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(391720)
addappid(550210,0,"fd1f73f5566a7b8eae9978c7891e5ee3857c685c32e1b5992f8a3d5a8c4debc5")
--setManifestid(550210,"5946813455617328314")
addappid(391721,0,"1162ab36159039f4781377536e3876faa9f479d44d97241be0270ce8da7a7698")
--setManifestid(391721,"2319949262459381934")
addappid(391722,0,"6d9db8f3d6215b58516336c2ad0b05b9825abfbbf08e83ae59af125eede9a701")
--setManifestid(391722,"2962438352194839955")
addappid(391723,0,"d3fdc865309b0966094284e3502d89bd0e136ddf666944cff9c6ed6defde0cad")
--setManifestid(391723,"3911521086648383521")
addappid(493530)
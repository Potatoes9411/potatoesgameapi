-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 204100's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:41 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 17
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(204100)
addappid(204106)
addappid(204107)
addappid(204108)
addappid(204109)
addappid(204110)
addappid(204111)
addappid(204112)
addappid(211520)
addappid(211521)
addappid(211522)
addappid(211523)
addappid(213370)
addappid(204112,0,"2ee4d3650aeaff9375a1ce0583920546f347c6bcddebc179729e816e22a52746")
--setManifestid(204112,"4680365301983588413")
addappid(211520,0,"d88e20d7fcab099ebf4ac07d88fd1462cb71178c1e4eea3a4bd622dea7f06fdc")
--setManifestid(211520,"2775848059097881311")
addappid(211521,0,"a13d9d6dd44ff1182e0c74e446cd9882a59e6f45456f1c632d12dd15d1c303ab")
--setManifestid(211521,"2115168271737722500")
addappid(211522,0,"d294ae04bfb512e055f6b0b1e12b27dec4575896be9aafddaf07f23d32cadce8")
--setManifestid(211522,"5033146606938445985")
addappid(211523,0,"a543a8027ca32b69db40c3608b5142391f0d9dcf98388cb260e0ccaa8994a554")
--setManifestid(211523,"5411554521103652584")
addappid(1899671,0,"b7921da5e50d00b2238d0fe870a354cb572bc5d397955fef02a439103f62827b")
--setManifestid(1899671,"6894431991641066272")
addappid(204102,0,"167f0b123df8cba56896db84579bafbbad31ba8dfefdb40dc4ab47734aeb7e48")
--setManifestid(204102,"3355664247437611729")
addappid(204104,0,"dce5aa99fab4fdb1bfb2ddd967d6d4ecd69b36ead35c7c44b5bbb0cf6be6af35")
--setManifestid(204104,"2018645313186401509")
addappid(204105,0,"c05905041da5986ede4ce2fd3f66027e5e88b443d0316dda2efd19cdd7a72a62")
--setManifestid(204105,"4567261895926818834")
addappid(204114,0,"259509faa392b6a3cde24feca3b2e6e3dffa1e455e61f671f65247bf948a2193")
--setManifestid(204114,"3750780175254170444")
addappid(204115,0,"793f0c2aa16ed5fd0e1c3c2721fafe0eca5d683fadb9961eec550c9729f671aa")
--setManifestid(204115,"6904567155150232022")
addappid(211524,0,"aefe926f7cdfe8b40dbe21f70dc7bc52cbe0d86f0d728d7c5416e9331e9d62a1")
--setManifestid(211524,"6377511973916138874")
addappid(211525,0,"ab72819e97335eedb1293f42e382e53605fd3e6d22775c03fbdb8fc313c861f3")
--setManifestid(211525,"2222537199617026930")
addappid(211526,0,"b140a43f717d375697db1ba4c82b2b29ae99dd71cec14b08e6694aabf9cdc747")
--setManifestid(211526,"5413856105312404894")
addappid(211527,0,"c53538f1c58553e3a25f55809cab51920f8191c06e350837b4f8020c622f96be")
--setManifestid(211527,"8919153356669044544")
addappid(211528,0,"f15a3cfc93f0d2f9d6f4307585d30003bd2d05c290913643f283c1bbdb334123")
--setManifestid(211528,"799267678352422137")
addappid(211529,0,"9797ce84ff78d7c701f4204018e45c7703e20e7f97a14c29817ad8ec5f984bb4")
--setManifestid(211529,"5043794854051410684")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 774181's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 07:00:06 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 5
-- Blacklisted Depots: 0

addappid(774181)
addappid(774181,0,"54c730f0832db85585d3feedbc7af7061f7ad1c6fe0b1123dce46ec60e011a64")
addappid(774182,0,"76d37d204d148b56554e8f8de5fba461e96eb4206c11c67aaf4fce8327ddd0a9")
--setManifestid(774182,"3850487481284136597")
addappid(774183,0,"51118da8096080b0800e51f785e7b8812e81e340ad4f3e6caed07a39ff96ecab")
--setManifestid(774183,"8786754313772251086")
addappid(774184,0,"3ae0a202ba2e80ef7386acf3a1f9014a1bf2bec36d70f66349afb9495e030006")
--setManifestid(774184,"1788007697861073647")
addappid(774185,0,"106fec9539cb2a9532e537df1fda91b4297a1482dfc2799a4b79aa8df59a55d5")
--setManifestid(774185,"3034747914455388980")
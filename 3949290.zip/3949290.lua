-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3949290's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:51 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 11
-- Blacklisted Depots: 0

addappid(3949290)
addappid(4360500)
addappid(4360510)
addappid(4360520)
addappid(4360530)
addappid(4360540)
addappid(4360550)
addappid(4360560)
addappid(4360570)
addappid(4360580)
addappid(4360590)
addappid(3949291,0,"d0d80228ab18573e394fbad3b4b594ed136caaea01a0018c11f5c6d5dd7f1921")
--setManifestid(3949291,"5703632458595102503")
addappid(4360500,0,"5cc8ae3c422f352bf863f9f5d5375e08e13f04aa958aa931b9c75224f3fd8e65")
--setManifestid(4360500,"6942946786323120547")
addappid(4360510,0,"b79b40ea64804753f8889f141e890777506b935a5581ebeb9b9a9c349b9a5912")
--setManifestid(4360510,"4554454394152832934")
addappid(4360520,0,"2901901b11ec3ca86ecc8686e471b11b40c79be8865d71a12fcc2ce18540466d")
--setManifestid(4360520,"8070916009776487170")
addappid(4360530,0,"67eb82744f89f1fb0ee46a6c67eaa400f2f6cbee4c947e00eb14f3d63ee9b299")
--setManifestid(4360530,"5071719528936885914")
addappid(4360540,0,"4f6c9b71446facb92e40e481543837a0f6a1da71327bd97e3fd1376075b23585")
--setManifestid(4360540,"7028733845523510377")
addappid(4360550,0,"9739c03fd27ae0577014559c4a87df540c13ccd33ac2a10838173f8575b6601a")
--setManifestid(4360550,"5654394984709247232")
addappid(4360560,0,"1167bc6a2f8e9be20c220a42e5c8f6ad00da9648a0f169ec8a6a9c1dfdbc1ce9")
--setManifestid(4360560,"4987141314910204989")
addappid(4360570,0,"fc3355fa7b0b39008d938ab20d806dfaee14731cf4a6d097fbe70e37868fa7e7")
--setManifestid(4360570,"8179494025301155894")
addappid(4360580,0,"471ec4cb6990e5e2916e814f392d41fe9dac7874b93087361804af9456750485")
--setManifestid(4360580,"631926832490011298")
addappid(4360590,0,"d2b87b93536c6e06806a109c0320b362af7757bf6f1f2b0a8a92a2f5e9350af9")
--setManifestid(4360590,"1680953349918251382")
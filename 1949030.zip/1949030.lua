-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1949030's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:25 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(1949030)
addappid(2208700)
addappid(2208701)
addappid(2330100,0,"21dd9d672e685c3529683b7c95ec6e28aaae408ef532769282a39c17f9f0d43c")
--setManifestid(2330100,"3767737197284181840")
addappid(1949031,0,"9d24669555d74ce46354104ac51cabb0d56b98f2be48de9c9eef2ff5b2a392cc")
--setManifestid(1949031,"1556170711472305898")
addappid(1949032,0,"f5ed67a9eed700ec2032583ddac5767254f593873bcc340b7b30141eac7d1dc7")
--setManifestid(1949032,"9049401390664358768")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2154940's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:58:04 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 2
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 2154071: Blacklisted

addappid(2154940)
addappid(2154941,0,"27d9d5edbfa05494a0c35a48bfa106dd69298ff95ea6cb960e450d770ba20e2a")
--setManifestid(2154941,"5374094612203032110")
addappid(2154942,0,"2b13529b81902c135801154d148b5637d42d9b0de61354e4464cef15eb95730e")
--setManifestid(2154942,"4047166814500035283")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 784150's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 07:00:06 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 6
-- Blacklisted Depots: 0

addappid(784150)
addappid(784150,0,"c09fda78c22d893fbed2ed6733c5b1d153a9d3a991b3b6ebfcb276e87ff7bb68")
addappid(1948180)
addappid(2499360)
addappid(3333420)
addappid(3334790)
addappid(784151,0,"3cbf0aae21e6bfca8d67af48b8f449d1ab056ef999590f4f3eb4c487badc6a19")
--setManifestid(784151,"6023959781350857449")
addappid(1948180,0,"b696c3e1ec422855ee25cedaa1728344b4700f94fb0857da3e3e19f470f91550")
--setManifestid(1948180,"4247618679340706319")
addappid(2499360,0,"c7307729a15331dec7fc6d57ca362afae67d7a014999b980c5d88ef198e26331")
--setManifestid(2499360,"6454835771496263943")
addappid(3333420,0,"4b5e8038aff5bb90f428d2a559cc99e36a0d1f0be5e5180df163807db5c0a37c")
--setManifestid(3333420,"5551990786996895510")
addappid(3334790,0,"40c9ff3a431a75ba2a4056613920f62e835a5c1fc3d25cfce748848f0d91995f")
--setManifestid(3334790,"4574163444664747917")
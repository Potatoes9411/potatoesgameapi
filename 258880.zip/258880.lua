-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 258880's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:00:14 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 2588611: Blacklisted

addappid(258880)
addappid(264830,0,"da09955ec485265efb131c9b7e0b5a06d3d9f490c0501c9e2e6fe2f74ea0960e")
--setManifestid(264830,"6317521241998284805")
addappid(288850,0,"7077714ae2f0e41bdf1d5919cfecd881d237bda4bfec8f7f5f35a015e6ff9b36")
--setManifestid(288850,"734397544844504180")
addappid(258881,0,"3dc88de5dae71ccf9cb8dd720178a8962a9d5afb4db5edafbbcbd3d6108d67b0")
--setManifestid(258881,"776622816120668070")
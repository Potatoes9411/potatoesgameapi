-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2536960's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:00:03 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 2
--   Depot 2536521: Blacklisted
--   Depot 2536522: Blacklisted

addappid(2536960)
addappid(3555070)
addappid(3555080)
addappid(2536961,0,"3df080decc628928621080b03652e6b736eb4d35e609da5e4d94a2c8877c5457")
--setManifestid(2536961,"8777360277796888985")
addappid(3555070,0,"17d516b829c95ccfb54a8690e24c515e629bb475b04a081ac04ccc774bd7a61b")
--setManifestid(3555070,"502834350719243049")
addappid(3555080,0,"56ba79018bfed9302183ec1fec3e9893a85faaeb61f02895d9037650586155e3")
--setManifestid(3555080,"4114331096832174785")
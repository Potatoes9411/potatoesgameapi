-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2675390's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:00:33 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 2
-- Total DLCs: 0
-- Blacklisted Depots: 8
--   Depot 267557: Blacklisted
--   Depot 267558: Blacklisted
--   Depot 267554: Blacklisted
--   Depot 267555: Blacklisted
--   Depot 267552: Blacklisted
--   Depot 267551: Blacklisted
--   Depot 267556: Blacklisted
--   Depot 267553: Blacklisted

addappid(2675390)
addappid(2675391,0,"4c623740e0995eb526f0b857baa7f1d32de6baef1c0875d559a81affe00ac68c")
--setManifestid(2675391,"4731330916688311411")
addappid(2675392,0,"ebb94fdcf80b1831412e1e8fccb6cbcbfa5eb1b49d1e593ea1b1c883f03c0fc8")
--setManifestid(2675392,"2165025953905332471")
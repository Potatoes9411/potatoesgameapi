-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 814000's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 07:00:06 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 2
-- Blacklisted Depots: 0

addappid(814000)
addappid(1888180,0,"9b6b1e02076f2b3b11efddeddcf5f205f632842421696481a24be1cbfbd6a46a")
--setManifestid(1888180,"1333443026720192680")
addappid(814001,0,"42d84d2e42b1e4103fb7597c5044385c294167829b1e033d894530ec3e3c4456")
--setManifestid(814001,"3541244075542598126")
addappid(2004606)
addappid(2004602)
addappid(2004607)
addappid(2004601)
addappid(2114010)
addappid(2114030)
addappid(2281181)
addappid(2004604)
addappid(2281180)
addappid(2004603)
addappid(1888180)
addappid(2004600)
addappid(2004605)
addappid(2282610)
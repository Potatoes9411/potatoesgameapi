-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 378540's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:46 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 16
-- Blacklisted Depots: 0

addappid(378540)
addappid(555300)
addappid(702980)
addappid(702990)
addappid(797280)
addappid(841250)
addappid(378541,0,"9f27bb61d0684760bb2d5c92e3e31241fb68ded5f9e9059467d4331b282c4639")
--setManifestid(378541,"2393638906793861124")
addappid(378542,0,"170b89ba060208f3867566c30947663fd4a2fcdbd06b248d8bba73e94c095c63")
--setManifestid(378542,"8435101459164407190")
addappid(378543,0,"a7a87584eef603d0fcdc33b6b3e66fff0e12b420d6b8b5b1e0dfcf0d08e80838")
--setManifestid(378543,"7049078200079114849")
addappid(378544,0,"32a0b34e6097f52b8715fa4ed498894cdae956afa4ef11eb68ca7d0603762341")
--setManifestid(378544,"2926963022114575524")
addappid(378545,0,"d124bcac7fed00ff386221c43e637c73d2c8a99bae2fc3a421c9fa01f67f0bfb")
--setManifestid(378545,"2118262339171869373")
addappid(378546,0,"986f1818bb8492c0d81b0f593a27c93c7c01fa1df1c1fb6b9da28ec03b975b6c")
--setManifestid(378546,"3908778727197922083")
addappid(378547,0,"ec49d2e969e20df1f309bdaaa8117adba769b57d5f4e35179ac142b591d5465e")
--setManifestid(378547,"5225885042331320776")
addappid(378548,0,"8e4adee51388d18c7344dc4d6e5ea8977d92e26f068ff7ed99458c2b380599a9")
--setManifestid(378548,"5348792405736011752")
addappid(378549,0,"bef04b4cfee7e086d53ace4dd832be4e728b75552312d319a49218eb81142963")
--setManifestid(378549,"6303600817736633682")
addappid(555301,0,"edeb0ba710b432518ea7450c267d919bc8a825cd2725c0cad2d817a675788ef6")
--setManifestid(555301,"6208728517099123017")
addappid(555302,0,"297b001c344a4c0b045d9e982b2b95022a32907ae97aa518de542d1948c6c1f7")
--setManifestid(555302,"6097622905281312182")
addappid(555303,0,"032bb59e2998f8239f9f594d14e90df823f00845f96cdde61dc563d53073f4e4")
--setManifestid(555303,"6168923113685161678")
addappid(555304,0,"7dcb71204199c91cc9fb75af39568e80dcc7ce2101d000fcdf7ffa4da4b41ed5")
--setManifestid(555304,"8556397363028756885")
addappid(555305,0,"80ef43f4a3248cc8db4e47a8c55faa229a5384ff5229a1ccc12ae7c972a76418")
--setManifestid(555305,"4640087290934532338")
addappid(555306,0,"399ed95a187471f88df984c91f380da52fcef9aecc14d9eb37b634bf745a0188")
--setManifestid(555306,"3560863954792490432")
addappid(555307,0,"b3b65017871ee347a3b957417b8205dac3ddb7b3a2cb8dedb8f0eaa4a60b7790")
--setManifestid(555307,"8279439492384809410")
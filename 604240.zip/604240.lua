-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 604240's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 07:00:04 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(604240)
addappid(991920)
addappid(604241,0,"898d033401487dae243aaf9df921db57952cf4488dcd59f419bbeea782bd7038")
--setManifestid(604241,"1067807849580504785")
addappid(604242,0,"5b837aced07ca8e39cc0618486416727d7bf3422e1b916252415b9752be1d2c7")
--setManifestid(604242,"1381077213320234109")
addappid(604243,0,"3a132a9b5c23766b655e88f4fbc34c3942bb9f16e14c118df03ed1d035d0d6da")
--setManifestid(604243,"512422918958722745")
addappid(604244,0,"3daa3a70b724d2b6904b3c18f2386b31a204bd6d8fe73005683411ec3291d3fa")
--setManifestid(604244,"147156944792297357")
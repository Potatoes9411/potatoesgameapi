-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2528800's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:22 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(2528800)
addappid(3966840)
addappid(2528802,0,"93FD73F8E84C6BBEC78CBADC1CA81E1AC754D8C5FE20167829704944FAE17156")
--setManifestid(2528802,"1236267771441634497")
addappid(2528803,0,"894C887F3613EBDF33F26546D2996CFEA37D26E773C33C79F8CA3C0D290C8B77")
--setManifestid(2528803,"6061974750089000227")
addappid(2528804,0,"9A5D2FDD096D2DD988EE6B59FBBE673C01103AFC4899225CBA40C1D7B74567D3")
--setManifestid(2528804,"4019297870781315971")
addappid(3966840,0,"58a394d4065d6015d1386701b058034c001cd53ba8965bf1cf98c4841dd636d0")
--setManifestid(3966840,"4912281212008687221")
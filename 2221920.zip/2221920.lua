-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2221920's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:58:40 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 5
-- Total DLCs: 0
-- Blacklisted Depots: 9
--   Depot 2221497: Blacklisted
--   Depot 2221496: Blacklisted
--   Depot 2221498: Blacklisted
--   Depot 2221499: Blacklisted
--   Depot 2221493: Blacklisted
--   Depot 2221494: Blacklisted
--   Depot 2221495: Blacklisted
--   Depot 2221841: Blacklisted
--   Depot 2221491: Blacklisted

addappid(2221920)
addappid(2222840)
addappid(2222841)
addappid(2222842)
addappid(2222843)
addappid(2222844)
addappid(2222845)
addappid(2222880)
addappid(2224320)
addappid(2224321)
addappid(2236200)
addappid(1716751,0,"84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
--setManifestid(1716751,"2169126266364568976")
addappid(2221921,0,"8275786a67804e966e135b16f69f1645268119c16cfd77f21c6067bcb56a83e8")
--setManifestid(2221921,"3031123413831949673")
addappid(2221924,0,"591f2020ca54e1092d56368756b4f1451320964f23ed1be6097c2a7024cd7280")
--setManifestid(2221924,"4175715142077790583")
addappid(2221925,0,"9a0bb2ad4553ba8307ba1d495e1e90c970ae1168c1dd796537fe4f4b19f7519f")
--setManifestid(2221925,"4971002940988183118")
addappid(2221926,0,"4ae02ea71b8eeec15234a8ac672df21243ce0439b0f08a7f434e339d300e6795")
--setManifestid(2221926,"1914799300096293395")
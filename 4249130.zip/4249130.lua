-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 4249130's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:55 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(4249130)
addappid(4249131,0,"8a848b7691d0a3d0bf697cfc04bb44221a778b027d21c7330459a0a8fbfbbb3a")
--setManifestid(4249131,"7160042762315048429")
addappid(4249132,0,"e0da4eae252a1a7e9ad8f1dcd3c6bec1f5399f5ada44585dc8b193615d4c6543")
--setManifestid(4249132,"5434870342583988935")
addappid(4249133,0,"6f92df7d6327d7ed27320219fdd39495d2e1319925a587517f99467fc7a221f6")
--setManifestid(4249133,"2089596546887604834")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3364070's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:27 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 5
-- Blacklisted Depots: 0

addappid(3364070)
addappid(2828508,0,"86a8e078c58ea7fbf57bdf1b2611116fe069f5e590cfa11058ca6610e0961700")
--setManifestid(2828508,"5145691608909662874")
addappid(3364071,0,"ad2481161bdbad60f49ea1f0ae3125891cbef62f7d5f2ace16e54c446e0229c8")
--setManifestid(3364071,"8527287556509194466")
addappid(3364072,0,"38346a0266c20efdb2a5d2b50c159ea4435769b04cfae96e4f0cc3c558b4cdb7")
--setManifestid(3364072,"3314895098517906756")
addappid(3364073,0,"7568b1bbc1409ab2c3dbed275d2dab04d7db4095d786b525dd00c9c20bc28f87")
--setManifestid(3364073,"5774495096749686011")
addappid(3364074,0,"c058856186c86e8188ad3cca08c68ffe12386625daf1ef6d117741da6ea5e1a1")
--setManifestid(3364074,"5638748487765333378")
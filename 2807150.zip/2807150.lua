-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2807150's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:00:58 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 10
--   Depot 2807967: Blacklisted
--   Depot 2807962: Blacklisted
--   Depot 2807968: Blacklisted
--   Depot 2807966: Blacklisted
--   Depot 2807963: Blacklisted
--   Depot 2807971: Blacklisted
--   Depot 2807965: Blacklisted
--   Depot 2807964: Blacklisted
--   Depot 2807969: Blacklisted
--   Depot 2807961: Blacklisted

addappid(2807150)
addappid(3964220)
addappid(2807151,0,"1969ccb9a84fc59a5a2e4c3ea8f3ef0d00ce746e5fe05f2dec27cc4583a45de3")
--setManifestid(2807151,"776063559962953609")
addappid(3912591,0,"4629dc7d387a903958a204ee7adc286a09491d32cec9a2d953672ca7748aeed3")
--setManifestid(3912591,"8969526720109211949")
addappid(3964220,0,"acecd028a0536aa248d94522b14928da55e7fc75961f456b121c21f0d828470a")
--setManifestid(3964220,"6791124115384923238")
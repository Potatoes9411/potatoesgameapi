-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1989070's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:58 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(1989070)
addappid(2975170)
addappid(1989071,0,"acc053225619f523280f867bc4314633c93cae4e3852acc9ff63dfb12bc5104a")
--setManifestid(1989071,"7684088551347295249")
addappid(1989072,0,"cb38de04d4eaa1887862c4ccafec65aa47cc5fb5483caf9708060cb4bdd620fd")
--setManifestid(1989072,"4287281956176326305")
addappid(2975170,0,"cf405148c78a3ff4b03dae2559706245cc2c3d0d10e6b91b5bd0292f49c71c53")
--setManifestid(2975170,"5851144457067261337")
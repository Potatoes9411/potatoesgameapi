-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3081320's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:44 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(3081320)
addappid(3425730)
addappid(3425740)
addappid(3425750)
addappid(3425760)
addappid(3425770)
addappid(3081321,0,"735a7c6b3f8d915e0c21319a079d89d673617cb135b626725ab4ea1740296891")
--setManifestid(3081321,"3805631244306435009")
addappid(3173601,0,"b0deff0d3c2afe06ff2792382f0ec1199a3dc6e0be5c25225651494e6f02b442")
--setManifestid(3173601,"3189771191662573237")
addappid(3952761,0,"07f5708641c3e31b9f6015248e1547c8b4f1386962022a6376878726ed002dfa")
--setManifestid(3952761,"3352020898973177355")
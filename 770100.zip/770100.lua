-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 770100's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 07:00:06 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 9
-- Blacklisted Depots: 0

addappid(770100)
addappid(860980)
addappid(860981)
addappid(870620)
addappid(870621)
addappid(889380)
addappid(894970)
addappid(1418480)
addappid(770101,0,"93bdad3a8acbb69bd83225c7e01d1680872bd62af386f00956edbf1e475864e7")
--setManifestid(770101,"7218509553485921395")
addappid(770102,0,"518784016a7ad6313ac2b7ccf077939659451a28b971c83bd78a443a0ec6e271")
--setManifestid(770102,"1606090596288312694")
addappid(770103,0,"2763dd597df6bdac95fcdf91334e77871d885cd7180ccd7ef0506c3c18401c49")
--setManifestid(770103,"7433911922351604254")
addappid(860980,0,"ee768817afb3c265577f3f7472fb596c40b634f5c759eb8a4952f15f593b7b0d")
--setManifestid(860980,"8756056082604186776")
addappid(860981,0,"f22c5239b039ee5700b3bbb508ba51dafc1545db8c68c806bcec8aa7dfb0312c")
--setManifestid(860981,"4838077999054553022")
addappid(870620,0,"384c4c60be8bf86e19104e416cf8758eae528c7a9f7a3a3b5ef813469d1bf676")
--setManifestid(870620,"7143390211383298765")
addappid(870621,0,"2f5a2deae1131e8d4d4ce2182cb78d7438ded39938e0acd8b49236feb96ba3a8")
--setManifestid(870621,"5966014977923567965")
addappid(889380,0,"07046cab34ff4f4d6761d5019f301173d1cb25840f598283ad4a8560b93d53e1")
--setManifestid(889380,"8113921267579368941")
addappid(894970,0,"65faf5b025da109806816241ec158e5c22077dd31dacc00a2e3b501319b63e98")
--setManifestid(894970,"6978717669983680845")
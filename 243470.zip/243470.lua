-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 243470's Lua and Manifest Created by Potatoes9411
-- Watch_Dogs
-- Created: May 16, 2026 at 04:45:24 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 14
-- Total DLCs: 0
-- Blacklisted Depots: 2
--   Depot 243437: Blacklisted
--   Depot 243489: Blacklisted

addappid(243470, 1, "Unknown")
addappid(243471, 1, "77184dab3ba78bfc47c7a4de0a466dcecc808954c08be694e6772e5efdca2d21")
setManifestid(243471, "5582561119037069284", 0)
addappid(243472, 1, "Unknown")
setManifestid(243472, "Unknown", 0)
addappid(243473, 1, "Unknown")
setManifestid(243473, "Unknown", 0)
addappid(243474, 1, "Unknown")
setManifestid(243474, "Unknown", 0)
addappid(243475, 1, "Unknown")
setManifestid(243475, "Unknown", 0)
addappid(243476, 1, "Unknown")
setManifestid(243476, "Unknown", 0)
addappid(243477, 1, "Unknown")
setManifestid(243477, "Unknown", 0)
addappid(243478, 1, "Unknown")
setManifestid(243478, "Unknown", 0)
addappid(243479, 1, "Unknown")
setManifestid(243479, "Unknown", 0)
addappid(293054, 1, "Unknown")
setManifestid(293054, "Unknown", 0)
addappid(293057, 1, "Unknown")
setManifestid(293057, "Unknown", 0)
addappid(293059, 1, "Unknown")
setManifestid(293059, "Unknown", 0)
addappid(293061, 1, "Unknown")
setManifestid(293061, "Unknown", 0)
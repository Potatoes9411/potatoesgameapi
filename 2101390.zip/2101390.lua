-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2101390's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:54 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 1
-- Total DLCs: 0
-- Blacklisted Depots: 22
--   Depot 2101962: Blacklisted
--   Depot 2101921: Blacklisted
--   Depot 2101922: Blacklisted
--   Depot 2101904: Blacklisted
--   Depot 2101920: Blacklisted
--   Depot 2101961: Blacklisted
--   Depot 2101928: Blacklisted
--   Depot 2101924: Blacklisted
--   Depot 2101902: Blacklisted
--   Depot 2101901: Blacklisted
--   Depot 2101926: Blacklisted
--   Depot 2101907: Blacklisted
--   Depot 2101925: Blacklisted
--   Depot 2101909: Blacklisted
--   Depot 2101906: Blacklisted
--   Depot 2101905: Blacklisted
--   Depot 2101908: Blacklisted
--   Depot 2101923: Blacklisted
--   Depot 2101903: Blacklisted
--   Depot 2101929: Blacklisted
--   Depot 2101900: Blacklisted
--   Depot 2101927: Blacklisted

addappid(2101390)
addappid(2101391,0,"e9e93c0152536a02e1821999b67494d7106bf822697b9d5e16ef0a3f88a46dca")
--setManifestid(2101391,"122214967238802966")
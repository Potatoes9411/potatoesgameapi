-- Made by F1uxin (UserID:965053505901588521), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/NmmpgnAgen)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:965053505901588521)
-- And if you have any questions feel free to dm on discord (UserID:965053505901588521)

-- Socials: https://guns.lol/f1uxin

-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid", save the file, then add the lua file (i think you can add the manifests too but I would just add the lua file to ensure it works).

-- Main stuff to add your game.
addappid(3438850, 1, "30e1f7e188e92cc3ddfe88f8da2ddd9201e70d77603ac4bc798e055b2fdb91f1") -- Sledding Game
addappid(3438851, 1, "4f2a0854d927f1098bcc4ef65ce87280d5779230d0ce4a79549a990e7a04f2a7") -- Depot 3438851
setManifestid(3438851, "7311454735255286733", 977776032)
addappid(4527730) -- Sledding Game - Supporter Pack
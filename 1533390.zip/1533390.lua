-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1533390's Lua and Manifest Created by Potatoes9411
-- Gorilla Tag
-- Created: May 16, 2026 at 04:46:14 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 10
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(1533390, 1, "Unknown")
addappid(1533391, 1, "Unknown")
setManifestid(1533391, "Unknown", 0)
addappid(1533392, 1, "Unknown")
setManifestid(1533392, "Unknown", 0)
addappid(1533393, 1, "Unknown")
setManifestid(1533393, "Unknown", 0)
addappid(1533394, 1, "Unknown")
setManifestid(1533394, "Unknown", 0)
addappid(1533395, 1, "Unknown")
setManifestid(1533395, "Unknown", 0)
addappid(1533396, 1, "Unknown")
setManifestid(1533396, "Unknown", 0)
addappid(1533397, 1, "Unknown")
setManifestid(1533397, "Unknown", 0)
addappid(1533398, 1, "Unknown")
setManifestid(1533398, "Unknown", 0)
addappid(1533399, 1, "Unknown")
setManifestid(1533399, "Unknown", 0)
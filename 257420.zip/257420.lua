-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 257420's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:00:11 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(257420)

addappid(257421,1,"8096f8677bd37048df6dc882760cfe3acf7e8fd4bb525f250f604d2b93eac97f")

--setManifestid(257421,"4590363821351997440",75913264)

addappid(257426,1,"4a353c662b034310254d9c7d00885e076d46c5990eb7d7f46e68197e50a9db1b")

--setManifestid(257426,"5285547987528508936",46765739300)

addappid(257427,1,"e50c354bca42cdade83dbb7b8857d9a0118284edbd368e34b7c4e98f5024e9a6")

--setManifestid(257427,"3824505940309722734",78491099)

addappid(1330600)


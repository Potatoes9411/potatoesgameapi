-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2239550's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:09 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 15
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(2239550)

addappid(2239551, 1, "62572c9c866092b5d5c24f9d76b0d30e122ec188a384cf332863c2354a16e499")
--setManifestid(2239551, "5409223134227379956", 0)
addappid(2239553, 1, "aedafe5b1f90390eead5c8b1284c9135978cb376a92d63f3cc50f72cfc25c1b9")
--setManifestid(2239553, "861626495949591325", 0)
addappid(2239554, 1, "7c56b1185c417eb03429ae8d45ac5f601ad32ea1b165aeb4e865d8be81b38057")
--setManifestid(2239554, "150776765054703772", 0)
addappid(2239555, 1, "5264cd8b1760303e1252fddcd7c22b8737ee4072a06c949c17a70567c46f91d0")
--setManifestid(2239555, "1126084741540836795", 0)
addappid(2239556, 1, "cf5f6a46e9a1570e6233eb2635494823fbb6500438ff91f9d9bf5e15dd7f1015")
--setManifestid(2239556, "1246586549978281605", 0)
addappid(2239557, 1, "7ef880457a787df11e53915796a5683e5b4cecbdf13e652cf6b241258670fc46")
--setManifestid(2239557, "1708196626566240967", 0)
addappid(2239558, 1, "96a2343878739aa83ae1594e8308477aae7103b27c47275413b29faf2467962e")
--setManifestid(2239558, "5263627914238077400", 0)
addappid(2239559, 1, "6e573031c1f7df976ba2afd51dc5d9ad29867474e9c89336c319a28746479ba6")
--setManifestid(2239559, "1849129399140238585", 0)
addappid(2239578, 1, "ab14e233729a7f7aa201e66ca2561e17606d2b5ef892d3c3d5576393ad51a296")
--setManifestid(2239578, "1722712900383029919", 0)
addappid(2239579, 1, "c9a01759f720b3981960152bf9935ad070d46a90896d63866b2f5628c2cfda75")
--setManifestid(2239579, "4016126354565287573", 0)
addappid(2239581, 1, "8780ca840c8994c0aea640128c1627f27ed861e147aebcbe0b965a1645a1eb4e")
--setManifestid(2239581, "2185846408303563524", 0)

addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068")
--setManifestid(228984, "2547553897526095397", 0)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358")
--setManifestid(228988, "6645201662696499616", 0)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")
--setManifestid(228990, "1829726630299308803", 0)
addappid(1716751, 1, "84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
--setManifestid(1716751, "7692967814764193714", 0)

addappid(2239570)
addappid(2239571)
addappid(2239573)
addappid(2239574)
addappid(2239575)
addappid(2239576)
addappid(2239577)
addappid(2239580)

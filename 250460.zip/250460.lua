-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 250460's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:59:55 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(250460)
addappid(250461,0,"eae01a0da0e8de3887148806b9e685174060e8941d3326a519675ebe15ff1803")
--setManifestid(250461,"3099152109662277537")
addappid(250462,0,"3127bf9e9a5db9cff2f37eb66c028dd50fb41b00e9f83024d79951bf09b93173")
--setManifestid(250462,"1173558715887083542")
addappid(250463,0,"22ec1b406b902a4e568710bc4d79832b10f0fb8ed9fb044f198c43049008a38f")
--setManifestid(250463,"4761085321376882390")
addappid(463810)
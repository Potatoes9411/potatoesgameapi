-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2531310's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:22 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 4
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 2531531: Blacklisted

addappid(2531310) -- The Last of Us™ Part II Remastered

-- MAIN APP DEPOTS
addappid(2531311, 1, "f7506952e736e71547c2d3c2c82959438e836c66d5b8b8f3208ccc082f60df23") -- Depot 2531311
--setManifestid(2531311, "4566212634007989287", 0)
addappid(2531313, 1, "a88758211f172f53efb57ad5c819b9d5f34b0796b44bd876639a09029e6a8089") -- Depot 2531313
--setManifestid(2531313, "4994458262959665537", 0)
addappid(2531314, 1, "3dc1a7d997476f1b4eb3a78f11af1be0d750a14719dc5d5eaeb940bcd44b74e5") -- Depot 2531314
--setManifestid(2531314, "6262322802969244361", 0)

-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
--setManifestid(228989, "3514306556860204959", 0)

-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3420050) -- The Last of Us Part II Remastered - Pre-purchase Entitlements

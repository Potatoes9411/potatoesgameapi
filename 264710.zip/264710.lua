-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 264710's Lua and Manifest Created by Potatoes9411
-- Subnautica
-- Created: May 16, 2026 at 04:45:56 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 11
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(264710, 1, "Unknown")
addappid(264711, 1, "Unknown")
setManifestid(264711, "Unknown", 0)
addappid(264712, 1, "d764b2a41e9bdbf338f04948309614ea6f8d462073a610940aaf10cbfc35aa85")
setManifestid(264712, "4495119477327785570", 0)
addappid(264713, 1, "Unknown")
setManifestid(264713, "Unknown", 0)
addappid(264714, 1, "Unknown")
setManifestid(264714, "Unknown", 0)
addappid(264715, 1, "Unknown")
setManifestid(264715, "Unknown", 0)
addappid(264716, 1, "Unknown")
setManifestid(264716, "Unknown", 0)
addappid(264717, 1, "Unknown")
setManifestid(264717, "Unknown", 0)
addappid(264718, 1, "Unknown")
setManifestid(264718, "Unknown", 0)
addappid(264719, 1, "Unknown")
setManifestid(264719, "Unknown", 0)
addappid(1619300, 1, "Unknown")
setManifestid(1619300, "Unknown", 0)
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1076200's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:55:27 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 4
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 1076380: Blacklisted

addappid(1076200)
addappid(1518150)
addappid(1518151)
addappid(1518152)
addappid(1518153)
addappid(1704470)
addappid(1076201,0,"50ee1eeed9965f82ead8a6be6c534afef4ac5991a57be019e7c2f479e1442d14")
--setManifestid(1076201,"2995946032821263265")
addappid(1076202,0,"37a9c8bdb3dc21a8955368d58448ee07ec2c23e089ed50893aadef75fd40a7dd")
--setManifestid(1076202,"4503896454055639366")
addappid(1076203,0,"1a13c15ae96dec51ce59c1881ad86035c73e1e83452499a1c74b7e765860a70a")
--setManifestid(1076203,"5320882812528019288")
addappid(1518153,0,"e0201f4c7f897b67ae6e591bc1a50ccd0b583b8dbe427900d97381bb0b47ea08")
--setManifestid(1518153,"4545673233408779824")
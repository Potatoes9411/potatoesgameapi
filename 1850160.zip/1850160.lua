-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1850160's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:12 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 5
-- Total DLCs: 0
-- Blacklisted Depots: 3
--   Depot 1850051: Blacklisted
--   Depot 1850741: Blacklisted
--   Depot 1850571: Blacklisted

addappid(1850160)
addappid(1850160,0,"60d9b9b2b4153da7a2a021e2c48157f64286c98c13c8be08bb945664dc04d918")
addappid(1850161,0,"f14a199914983b46136c120280723eb68f50d6c5469ca10f7b0dee6685a0da4a")
--setManifestid(1850161,"7754941722888358343")
addappid(1850162,0,"b2a9b3ddf9d15ab4e95a9a75ade810663329a66e9102fd0ff0555bb51d939029")
--setManifestid(1850162,"1697171793545420688")
addappid(1850163,0,"ec5d14eee4e26845fe971a0f575561829b316485bbfee07234e6b79456131534")
--setManifestid(1850163,"2056663278567264835")
addappid(1850164,0,"4df14bab9c49b0f491d1df8155ad4ef79e03119e83f9de42857272be9fb91d57")
--setManifestid(1850164,"529244433927282171")
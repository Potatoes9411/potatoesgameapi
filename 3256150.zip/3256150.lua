-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3256150's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:23 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 8
-- Blacklisted Depots: 0

addappid(3256150)
addappid(4331970,0,"881f17b8528d375433958f5b0ef835fd8c531b95a7902c95b74401a6d042fb08")
--setManifestid(4331970,"5090349023517406104")
addappid(4331980,0,"0ca49997c33c1f9bb18e3391624bef275731356fc5ff5bd823844e7b6f597989")
--setManifestid(4331980,"6249520768726745988")
addappid(4331990,0,"03bfdf8cdb77bffd6ca72e97bc51ab66b3c430cb1658e670e2e577225f959a3f")
--setManifestid(4331990,"5112103889037684524")
addappid(4384190,0,"1701f708ecf1149e2fb438c140753887318c3caab5bf84762fb8436eea53776f")
--setManifestid(4384190,"3919185941925370294")
addappid(4384200,0,"65b3e88c3d45f5fa51dc974212381e5a8ff7b619ef377314eb67aa1fb665724c")
--setManifestid(4384200,"8863653252650919736")
addappid(3256151,0,"2e154b1c0d5b3c72ab4d2610e491a5f262967fc96cb148666c2cf2f2b2d05c0b")
--setManifestid(3256151,"8490949412962437988")
addappid(3256153,0,"c6eb1699098152f6a41c6b7307e4fb245d68bff238b14bcca7ba11df3d6e24fc")
--setManifestid(3256153,"1282413307145046996")
addappid(3256154,0,"b6d0822618b4f941bf273d57d1a07e3eac89781704132297db7ba6eef85909bb")
--setManifestid(3256154,"7461702279879374650")
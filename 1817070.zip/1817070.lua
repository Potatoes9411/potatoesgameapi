-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1817070's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:08 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 14
-- Total DLCs: 0
-- Blacklisted Depots: 4
--   Depot 1817232: Blacklisted
--   Depot 1817231: Blacklisted
--   Depot 1817801: Blacklisted
--   Depot 1817491: Blacklisted

addappid(1817070)
addappid(2083110)
addappid(1817071,0,"490a357029d1621deff9708e5d42f19324ccc758124ae1b455e091551df2a041")
--setManifestid(1817071,"7101193785692308687")
addappid(1817072,0,"ae2589c0e9de7a18dea92ceac08a6537cf7b83c1983e9f4738a188a49fd137f9")
--setManifestid(1817072,"670672075597558132")
addappid(1817074,0,"d1d379b15dba708a435fa177bacfc7f625c53c84b45b299ded3cbeeca084e330")
--setManifestid(1817074,"2767115330843299188")
addappid(1817075,0,"ecb149a90bf5eda310dd5f18e7715c255b022db3e327037cc6daa4f69ff22107")
--setManifestid(1817075,"3039496220919935469")
addappid(1817076,0,"6cb4d05622fdd2cd0d10703a36cf47140a2d952a49e31325a3b65af53db59974")
--setManifestid(1817076,"7023492310614800670")
addappid(1817077,0,"3e7903be905c0a12045d1f7d303e596ca9889e64b0b2f4a5e52680e7839b20fb")
--setManifestid(1817077,"1086775484848552274")
addappid(1817078,0,"9815d29285202efd418b703002a67cf17ccde07230fe3f2b171e1581d17ba0e4")
--setManifestid(1817078,"2990142445242902328")
addappid(1817079,0,"e357c3433e694ca3c616af966efc889f3d6af51c4d45e34fbf3d6537715c9bf0")
--setManifestid(1817079,"2023143758263501793")
addappid(1829890,0,"fc8ce2606acf5525e88dffc6cdc9cd4cf50e092efa04536528ee66fda012fe79")
--setManifestid(1829890,"3912377727024202284")
addappid(1829891,0,"69db276eece234ce4caf8b55262d17c74686450104a1d1db09cfdc425555b707")
--setManifestid(1829891,"2632761098204669985")
addappid(1829892,0,"cd4dd166b577600a9fe435ad640a58caa41fb8311111ab403c24a7b1d5a29ed9")
--setManifestid(1829892,"1540729933509716096")
addappid(1829893,0,"48c0acb19e2fc2d02db4b9dcf88fabf25c8eb7eb1e218b7f26c54a53073bb934")
--setManifestid(1829893,"5021811276708038952")
addappid(1829894,0,"1406f2b316ca60231c614560afc407a0b3eca5c0cce4e46f5493e73f269808ef")
--setManifestid(1829894,"2167297873910007583")
addappid(1829895,0,"4773012855296205ad41eeb15231c6d5db4ee4264feb5b217e8b09b752c4526c")
--setManifestid(1829895,"4268839994794210418")
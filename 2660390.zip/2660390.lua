-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2660390's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:00:30 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 2
--   Depot 2660461: Blacklisted
--   Depot 2660: Blacklisted

addappid(2660390)
addappid(2660391,0,"6a4bf9a9a47ee306f471a62816ccb8f1fca918b1d17e16c48871d40143f0e3bb")
-- setManifestid(2660391,"7509757963367711422")
addappid(2660392,0,"f24bd4b65229e54715f6272f88f2922d0eab08ca481b8ce23a1dfe86bf6c1afd")
-- setManifestid(2660392,"4243708886758177220")
addappid(2660393,0,"f6a248925f23507188ff9550d7da5434cf8f1959db755fec3e4c569e0b2f9585")
-- setManifestid(2660393,"8632498404432494532")
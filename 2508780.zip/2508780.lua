-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2508780's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:59:55 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 5
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(2508780)
addappid(3051830)
addappid(3248040)
addappid(3482230)
addappid(3847810)
addappid(3847820)
addappid(3847830)
addappid(2508781,0,"d3d2cecbf425b32af43928d0b54fb991edc1a74dfac4d72d31a47b22d078ec14")
--setManifestid(2508781,"3482600068670466972")
addappid(3051830,0,"11061a1ed5036b24ad17351d518ca68411d4fe283cf6156176f5d161b9044ebc")
--setManifestid(3051830,"7047648226728925275")
addappid(3248040,0,"d671f9d0718c441e13b212891d9003f5260e69433455f44bcf2c768e61173336")
--setManifestid(3248040,"2588098502636584215")
addappid(3482230,0,"0789e54527d096025f42b5c9e7196eed567c1e7b5a83a8466121fe86a3b6a8bb")
--setManifestid(3482230,"498202292068430120")
addappid(3847830,0,"418b5c8fd01c80869d13b37d6ddff62844ed8fa89b0c9c3803a9846c36a96c3f")
--setManifestid(3847830,"726245139049856328")
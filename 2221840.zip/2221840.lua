-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2221840's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:08 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(2221840)
addappid(2221841,0,"9c64d8d4a97700162de3d91372d607c0b32e26b07eacac186762aaa29e0ef4ae")
-- setManifestid(2221841,"8467549423023912903")
addappid(2900390,0,"a50332276e1a9600bd604be4c9fab3ae8197d96cf928ede8088b0e01ceb30213")
-- setManifestid(2900390,"6543008594258223691")
addappid(2900400,0,"86a31dc32f27c42f1d68b0f6018136c2b8d7be96fafe313a544cdb398e6fc260")
-- setManifestid(2900400,"2339738814922771453")
addappid(2900380)
addappid(3985260)
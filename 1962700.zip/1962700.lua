-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1962700's Lua and Manifest Created by Potatoes9411
-- Subnautica 2
-- Created: May 16, 2026 at 04:45:22 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 11
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(1962700, 1, "Unknown")
addappid(1962701, 1, "96feb03fc707b975cf8271da4659fdb16c14c4b1a5c5bf8f94bd66e39edd4d96")
setManifestid(1962701, "4222263125962173451", 0)
addappid(1962702, 1, "Unknown")
setManifestid(1962702, "Unknown", 0)
addappid(1962703, 1, "Unknown")
setManifestid(1962703, "Unknown", 0)
addappid(1962704, 1, "Unknown")
setManifestid(1962704, "Unknown", 0)
addappid(1962705, 1, "Unknown")
setManifestid(1962705, "Unknown", 0)
addappid(1962706, 1, "Unknown")
setManifestid(1962706, "Unknown", 0)
addappid(1962707, 1, "Unknown")
setManifestid(1962707, "Unknown", 0)
addappid(1962708, 1, "Unknown")
setManifestid(1962708, "Unknown", 0)
addappid(1962709, 1, "Unknown")
setManifestid(1962709, "Unknown", 0)
addappid(3803320, 1, "Unknown")
setManifestid(3803320, "Unknown", 0)
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 212580's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:58 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 7
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(212580)
addappid(212601)
addappid(212602)
addappid(212603)
addappid(212604)
addappid(212581,0,"d23382087c0da68ca6f567ff779bc203c7162321584f6d864c2d0cbc1be0840b")
--setManifestid(212581,"1702234277720319664")
addappid(212582,0,"8aeec6cf149da2b143e196082875675996d9524a8ea559fc79826c22965ab786")
--setManifestid(212582,"5825619185047011556")
addappid(212583,0,"377cb2e704c6d52a796135ea56753e35b542772a2c269af09d932f0bf3e8de1b")
--setManifestid(212583,"3874623814017625460")
addappid(212601,0,"8c910c76a24ac85a021ee21933ea27402d6fb56767f1334aefed793aaf9a0b26")
--setManifestid(212601,"2897447588684645591")
addappid(212602,0,"2713a16923cb10651be1998dad32f2f700fd31bd30611e299cf41860f6e4c0ee")
--setManifestid(212602,"4369698113859439931")
addappid(212603,0,"bb8aab42a14bb797f3763d50364c41d2fb0432a09ed66ed021a819249c2ee51a")
--setManifestid(212603,"6247646008149235506")
addappid(212604,0,"e2567ac1f5bc0b81c66b29af122070047cffe037c5e61ad432e8dcc37967b130")
--setManifestid(212604,"2284257357487342745")
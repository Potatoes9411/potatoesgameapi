-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2098150's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:54 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 1
-- Total DLCs: 0
-- Blacklisted Depots: 12
--   Depot 209823: Blacklisted
--   Depot 209818: Blacklisted
--   Depot 209825: Blacklisted
--   Depot 209827: Blacklisted
--   Depot 209811: Blacklisted
--   Depot 209828: Blacklisted
--   Depot 209824: Blacklisted
--   Depot 209826: Blacklisted
--   Depot 209820: Blacklisted
--   Depot 209822: Blacklisted
--   Depot 209821: Blacklisted
--   Depot 209819: Blacklisted

addappid(2098150)
addappid(2098151,0,"fe1cce66505eb500c8df4d03b590f7f20fced983221af5abef8f5f482a0191bd")
--setManifestid(2098151,"7860184188140705281")
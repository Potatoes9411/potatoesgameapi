-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1247290's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:56:04 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 13
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(1247290)

addappid(1418110)

addappid(1928630)

addappid(1962060)

addappid(2096770)

addappid(2190600)

addappid(2209640)

addappid(2209641)

addappid(2236140)

addappid(2274640)

addappid(2298680)

addappid(2309710)

addappid(2339070)

addappid(2339071)

addappid(2339072)

addappid(2378170)

addappid(2389980)

addappid(2398710)

addappid(2410450)

addappid(2447250)

addappid(2447280)

addappid(2447390)

addappid(2488710)

addappid(2540150)

addappid(2566410)

addappid(2605740)

addappid(2626790)

addappid(2626800)

addappid(2676360)

addappid(2676370)

addappid(2679540)

addappid(2679550)

addappid(2679560)

addappid(2679570)

addappid(2679580)

addappid(2682830)

addappid(2682840)

addappid(2691260)

addappid(2710440)

addappid(2728960)

addappid(2728970)

addappid(2740070)

addappid(2778470)

addappid(2831970)

addappid(2831980)

addappid(2832350)

addappid(2873340)

addappid(2873350)

addappid(2873360)

addappid(2873390)

addappid(2873400)

addappid(2877510)

addappid(2910660)

addappid(2911300)

addappid(2933010)

addappid(2933020)

addappid(2933030)

addappid(2933040)

addappid(2933050)

addappid(2996440)

addappid(2996450)

addappid(3052750)

addappid(3054640)

addappid(3156140)

addappid(3196920)

addappid(1247291,0,"787d185cc8f67981a6502daa02fb6bf4060355a92caf92c4bf0b7e5ca653e9cf")

--setManifestid(1247291,"8186616930812901801")

addappid(1247292,0,"7b8601b136e12d8ec741828d9f79b6111bc58eee8dc673a40592608f342cbaeb")

--setManifestid(1247292,"7920714840961973560")

addappid(2236140,0,"d3d8a4b9cc857e894d0e2451566b2e6fc22f7364a1286bc8d46e825869bcfe2c")

--setManifestid(2236140,"8707272267973928989")

addappid(2298680,0,"69d7a1ab493d0e618162fe19bb97d2572fec56f25360f101c78f18c6d3f9832e")

--setManifestid(2298680,"3900196261455126972")

addappid(2566410,0,"e4b4d1a70a75ab6e038ce35c299c8be26bcd22c01d7636abf12859d2f2e9bc7d")

--setManifestid(2566410,"4985046195170754350")

addappid(2626790,0,"33e31186c0fe3db00db140bb8061a7e775c378fa9a1a280d1e5adc718d0f65b4")

--setManifestid(2626790,"619965996597556375")

addappid(1247293,0,"fc98a799e604f3378a8e8d40750ee3568c69684140547b59cfe1dce30c6a546e")

--setManifestid(1247293,"2555273873339066169")

addappid(2710440,0,"e799fa740a442adaebb739055496cdb9458bc73d2e4ecb52f0e79df966aabee3")

--setManifestid(2710440,"6519528693739900564")

addappid(3156140,0,"7a7c38a25c9f9d1fade2eeb9db2f5352b212d193f236fe8af461015a0145c2d5")

--setManifestid(3156140,"8153840298466508189")

addappid(2873360,0,"f4bae2e9c9042a6992338d00a7d3e5429ba46affd0a50b57d585cd7d7ef95c4c")

--setManifestid(2873360,"2941044412784448028")

addappid(2873390,0,"55707d61fb2f85a1546ee065629a6181210b7abf0c2f1c0962e26fbe43d462c7")

--setManifestid(2873390,"8598160318629025042")

addappid(3409400,0,"e4e710ca5c74f7a1f6a2644656a33013cdd685a4ee6c999653644f3f73b4bb6d")

--setManifestid(3409400,"5677428491779656299")

addappid(3358180,0,"4374b7f5a8152f259b7336fdd0ef32461b94f23685ec99a24cfca46e53d1e515")

--setManifestid(3358180,"9133119145309775544")
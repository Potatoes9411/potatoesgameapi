-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 241260's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:59:28 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 16
-- Total DLCs: 0
-- Blacklisted Depots: 3
--   Depot 241282: Blacklisted
--   Depot 241280: Blacklisted
--   Depot 241281: Blacklisted

addappid(241260)
addappid(1168710,0,"c9eee05f8a7f2b6c20253529b20c9b605c68a69cabf76a9566b51a4edc5eb52b")
--setManifestid(1168710,"5911716632117581489")
addappid(241261,0,"6d8d5c20c176f16011f5b1630c517815d086165a0603114f5cbcb638f0a812c7")
--setManifestid(241261,"5312736027243409766")
addappid(241262,0,"4685bf73e66d1bc7ec15dce44f1ef8aeaa99d622f08d185f7ccb6f71a8367713")
--setManifestid(241262,"93543048248588550")
addappid(241263,0,"3673c7fb7cc89718b4b77aa3cbbed44a34154da0d2a76685e1ffb6f48a80f25d")
--setManifestid(241263,"495960297327580215")
addappid(241264,0,"e17d11894b588dc7c63da37876896ff2100c171fc9f9fb3fdb591ca6f2a41212")
--setManifestid(241264,"1728619411129026457")
addappid(241265,0,"ffc63b95a6f2d50815f1a395a4e623d7826bc3f3a6105dc6c146b58f2309013c")
--setManifestid(241265,"670241112431313879")
addappid(241266,0,"c4d8eadfbc7c1bc575390a7201fb3f4c36a7b967b4bf0dbc1a11248aebddae9e")
--setManifestid(241266,"8595807162967397399")
addappid(241267,0,"94015be77d4d4ccb0b51f2252dc6c1fa137351e66690e017f70d197933de7166")
--setManifestid(241267,"5530190149658416935")
addappid(241268,0,"f18f50a47be2aed5c11e556b3e8ecaf4d14c6420a30b9b679fb784d5ce9196ac")
--setManifestid(241268,"1005165040270426010")
addappid(241269,0,"c6fc7ef569408284a8a91cb22c3e226d69637e81c39745663d3da8e8b67165ce")
--setManifestid(241269,"1012134030912396928")
addappid(241270,0,"0b9ab6eca33873e2949b23ecae4ed47631b57f79c2cb26134e6bd68482d90d3d")
--setManifestid(241270,"3051067043672590142")
addappid(241271,0,"671af4db042e2f998df0db1287e1169462ba3992bc399d99112d0befc8db2c15")
--setManifestid(241271,"6468095642510072643")
addappid(241272,0,"12dafeb858af3e6b52191e4627016c974ee0da1a37346e9f0a9f3371dd2e257b")
--setManifestid(241272,"7496764169964406607")
addappid(241273,0,"541acb392d116beaa4270b2525e91ba166b56d50849a92cb9727403b8f78147e")
--setManifestid(241273,"6111949570481399047")
addappid(241274,0,"52c03b849f4c63023a4dc025dbbab0ac4e8bb71bce9eb7c20f1544a8d54172ec")
--setManifestid(241274,"525513743204208908")
addappid(241275,0,"0b4de2d6bb79c22b74592a663d238ce9c09e2a654bf41225bfd7e572076f444b")
--setManifestid(241275,"8509618962112101288")
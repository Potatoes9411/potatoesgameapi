-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 282070's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:34 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 11
-- Blacklisted Depots: 1
--   Depot 2820751: Blacklisted

addappid(282070)
addappid(282070,0,"fe6e6a89b726d9c05a497190f0fc3246543f146d4ca7d5e0835461754229642b")
addappid(1125630)
addappid(3323700)
addappid(348040)
addappid(481090)
addappid(750030)
addappid(750031)
addappid(974610)
addappid(282071,0,"e0dab4469d4abc2b32a850279e71e6863af67f2cf9284a914523f2e11f0a6417")
--setManifestid(282071,"6552058215746440591")
addappid(282075,0,"0c275e68876ad6ce2edda3ee1beb82edc13332a8a7b514aee527d6676f295258")
--setManifestid(282075,"8880811861723404629")
addappid(282076,0,"d1305ccca6bc352a52f4a8d1a4df9819d5b75ffb9f02f488747903a7a6fd989d")
--setManifestid(282076,"4018066801537559079")
addappid(282077,0,"277d097a46d043c46959fcae68803d7c1bcaa3c21f3a12fe5c822236b5d7cd04")
--setManifestid(282077,"452741546977371630")
addappid(282078,0,"7fee77c87195927d57c924b7148fc09b34012e6aad771e88739f425fa8754842")
--setManifestid(282078,"4447666893151889109")
addappid(282079,0,"4439900a2a4255f39264f070a6c15c2bb621f4b6f6d630d23b4b333d3dd18862")
--setManifestid(282079,"6223985759980493607")
addappid(282080,0,"febf661a527ee326c1ac1405686f841217fa2c6bbf9d9494b5e34d474bbb8ddb")
--setManifestid(282080,"8992250823172660735")
addappid(282081,0,"83c07c51b5b1c0c22ebfae13b5d73fae0bd981fa5d2e87df392a3c2c5f0b9bc8")
--setManifestid(282081,"3050329373520057479")
addappid(282082,0,"17ca28917674ea02ee60d015d22780a67fba03c320bff92a1ffb11b76bba89a4")
--setManifestid(282082,"5097219911030405993")
addappid(282083,0,"203f1220197ba5c43de5e54a00b19f626db14a29856a49f1aad5b30f122ad3ef")
--setManifestid(282083,"8930109651456891263")
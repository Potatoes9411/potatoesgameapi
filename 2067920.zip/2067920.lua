-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2067920's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:45 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 2067791: Blacklisted

addappid(2067920)
addappid(2067920,0,"a47b3e09649f7bf93dc067e588b9e81b3f13e1f771b7dbf9836e267a0d38f565")
addappid(2388080)
addappid(2388081)
addappid(2067921,0,"694c6e03c612ee141cf99d179407a9016054d522927e3a6643df1317e545f4c9")
--setManifestid(2067921,"228200599860138903")
addappid(2067922,0,"30d15d97387ea8a35c73b655ea8101a694c293d83fc181da021eec8ab76d5666")
--setManifestid(2067922,"3197378208033658590")
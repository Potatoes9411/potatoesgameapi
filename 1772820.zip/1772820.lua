-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1772820's Lua and Manifest Created by Potatoes9411
-- Mushy
-- Created: May 16, 2026 at 04:46:16 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 10
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(1772820, 1, "Unknown")
addappid(1772821, 1, "Unknown")
setManifestid(1772821, "Unknown", 0)
addappid(1772822, 1, "Unknown")
setManifestid(1772822, "Unknown", 0)
addappid(1772823, 1, "Unknown")
setManifestid(1772823, "Unknown", 0)
addappid(1772824, 1, "Unknown")
setManifestid(1772824, "Unknown", 0)
addappid(1772825, 1, "Unknown")
setManifestid(1772825, "Unknown", 0)
addappid(1772826, 1, "Unknown")
setManifestid(1772826, "Unknown", 0)
addappid(1772827, 1, "Unknown")
setManifestid(1772827, "Unknown", 0)
addappid(1772828, 1, "Unknown")
setManifestid(1772828, "Unknown", 0)
addappid(1772829, 1, "Unknown")
setManifestid(1772829, "Unknown", 0)
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 221910's Lua and Manifest Created by Potatoes9411
-- The Stanley Parable
-- Created: May 16, 2026 at 04:45:53 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 10
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(221910, 1, "Unknown")
addappid(221911, 1, "Unknown")
setManifestid(221911, "4574887516115604592", 0)
addappid(221912, 1, "Unknown")
setManifestid(221912, "4004439736290655106", 0)
addappid(221913, 1, "Unknown")
setManifestid(221913, "Unknown", 0)
addappid(221914, 1, "Unknown")
setManifestid(221914, "Unknown", 0)
addappid(221915, 1, "Unknown")
setManifestid(221915, "Unknown", 0)
addappid(221916, 1, "Unknown")
setManifestid(221916, "Unknown", 0)
addappid(221917, 1, "Unknown")
setManifestid(221917, "Unknown", 0)
addappid(221918, 1, "Unknown")
setManifestid(221918, "Unknown", 0)
addappid(221919, 1, "Unknown")
setManifestid(221919, "Unknown", 0)
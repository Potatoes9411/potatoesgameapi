-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 221910's Lua and Manifest Created by Potatoes9411
-- The Stanley Parable
-- Created: June 17, 2026 at 06:58:38 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 4
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(221910)
addappid(221911,0,"63a52ac3857a0c6a6a85bfe4af6d84395e79ddf0cc5e38eb1bf45b6932e30999")
--setManifestid(221911,"4574887516115604592")
addappid(221912,0,"239566732a9a1d0e47deba270c2d39cdf30f5e1916164c046f4069f9751353e8")
--setManifestid(221912,"4004439736290655106")
addappid(221913,0,"e1551dfc6816c3dab69e361f7d3d8a3a5a7364c11c17932e91e41b129d012f9f")
--setManifestid(221913,"565664059840023103")
addappid(221914,0,"c5c453c2733e1fd0ba816e8772d28d2078d6ec93f2315063d2f1926eb9b1a903")
--setManifestid(221914,"4819957267483375851")
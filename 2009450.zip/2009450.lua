-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2009450's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:59 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(2009450)
addappid(2552980)
addappid(2617860)
addappid(2009451,0,"ca1c7feb6bf278dda6fcd952032f4bdbdcc79757b9399868e1c34f56c920c5c4")
--setManifestid(2009451,"8948063246115874810")
addappid(2552980,0,"abaffadb56619843e298e71ea39422bd20466d3adea446637f9d9e47bfe73d72")
--setManifestid(2552980,"4088856112652316135")
addappid(2617860,0,"7f6d81f1bf2cceaf5f306321a687d99421552082b36b19b3057b6538c1b6f8df")
--setManifestid(2617860,"2591779905579190782")
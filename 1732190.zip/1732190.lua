-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1732190's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:56:59 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 1
--   Depot 1732431: Blacklisted

addappid(1732190)

addappid(1751203,1,"4adafabbc0acd89e419fa3d001b3e5145f9c1610b20ea41c589f71c86630359f")

--setManifestid(1751203,"109097717630190306",4346397270)

addappid(1751204,1,"07ff8fbe297d5350d7cf72088d7c4363bc7f39f8039601e30a222ab5548c8129")

--setManifestid(1751204,"547659163536929531",242338064)

addappid(1732191,1,"41fbca52fbea25bd47005f1c64a88877acf4621890040a4dd2f54ee07b05e8dd")

--setManifestid(1732191,"5426184032901443170",19729695446)

addappid(1751201,1,"b89827dae7308c51c72ff8c69f724f1db76dfefae10b759f846106bb90446bb7")

--setManifestid(1751201,"747587657479076756",46219200)

addappid(1751202)


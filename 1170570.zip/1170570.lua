-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1170570's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:55:43 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 1170611: Blacklisted

addappid(1170570)
addappid(1170571,0,"ff0011f75c7eb759bc12f76299fcac9b69bb93985272bef530616f987c70ec8f")
--setManifestid(1170571,"6275663928688031875")
addappid(1170572,0,"7d81728c32fd7968ca3485dbed5cb4be71b1409691e3f8b15ecd88f1c6021551")
--setManifestid(1170572,"1014278723441305330")
addappid(1170573,0,"33cd587b83a1d217fe5fdec1ff8f0b41e45d065bbd303cfd1bbbb80f7432acc8")
--setManifestid(1170573,"2100966012467387883")
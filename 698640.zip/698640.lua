-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 698640's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 07:00:05 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 10
-- Blacklisted Depots: 0

addappid(698640)
addappid(1076630)
addappid(1189700)
addappid(698641,0,"4424bef307f10780448a5871e9f820c61fa0414c45811682453045bcc5eae1f5")
--setManifestid(698641,"3723473929815078880")
addappid(698642,0,"5902e55ea6cd266c85dfd176b443286aa7c9450dc262c03db32a47530d5870d1")
--setManifestid(698642,"6902577589337547800")
addappid(698643,0,"dd96bd78aa84d754ae4c49ec89ffdc9c4b7bfc35fc1658c9f4d3312faa1e653e")
--setManifestid(698643,"350911014941476390")
addappid(698644,0,"337281a6a3fef91c11f8c467acbd0d4ee5decfa25e5c4068b62ddf51d3714691")
--setManifestid(698644,"8182344922145492456")
addappid(1076630,0,"1d1c6fdadf36a0dc422c3b5a2896c91168129326289438fa5961e901d8076c4f")
--setManifestid(1076630,"5054214072472989796")
addappid(1076631,0,"f0892273c9cf7b0784b3ddc102f05d8d8201e97ebc0eaeaddc324b1f499ec140")
--setManifestid(1076631,"8325263623075380066")
addappid(1076632,0,"e50f4621562777a8f2ac3abec9a6af1547bd23c241fddaef2425bbbf53f39eec")
--setManifestid(1076632,"4061444630453359401")
addappid(1189700,0,"ded38d6bb54d657af46d6aaea9f714f65f0f221678e2f741c074ca3504ec9103")
--setManifestid(1189700,"5967145975119754018")
addappid(1189701,0,"081eb68b1fdae8142b0763f8a30bcb8ef3bcbb88f6e6fdbb3cd86644a56a878f")
--setManifestid(1189701,"7356493167865206792")
addappid(1189702,0,"468ce7d11facff6a159f769a6568fb6a117d7ddbb28aa7be6491c41bbbf6e0b8")
--setManifestid(1189702,"2901347428097405288")
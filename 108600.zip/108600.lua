-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 108600's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:55:28 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 4
-- Total DLCs: 0
-- Blacklisted Depots: 10
--   Depot 1086942: Blacklisted
--   Depot 1086943: Blacklisted
--   Depot 1086946: Blacklisted
--   Depot 1086948: Blacklisted
--   Depot 1086949: Blacklisted
--   Depot 1086945: Blacklisted
--   Depot 1086944: Blacklisted
--   Depot 1086621: Blacklisted
--   Depot 1086947: Blacklisted
--   Depot 1086941: Blacklisted

addappid(108600)
addappid(108600,0,"fc06c9893d7792ec35292dfc1b216f92d0f9e173df982804f4ab00293e9ab25b")
addappid(108602,0,"2c6834d3d5c0e48329883a18abe5614aa868c3e7911fc582c613cec21b3a5d1c")
--setManifestid(108602,"8852133329654085073")
addappid(108603,0,"0b2a31059fa239993389b69ca9a0bebd9e3cbc8ccb446335c2becbe85060b0c4")
--setManifestid(108603,"4769387464264218860")
addappid(108604,0,"3f8e8c70818c5469711aeaefe50b4f280028b72dfd7f7a4c83b6bd747e4a382a")
--setManifestid(108604,"5842262968114218862")
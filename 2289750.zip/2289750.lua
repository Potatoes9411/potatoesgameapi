-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2289750's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:58:54 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 2
-- Total DLCs: 0
-- Blacklisted Depots: 8
--   Depot 228983: Blacklisted
--   Depot 2289820: Blacklisted
--   Depot 228988: Blacklisted
--   Depot 228989: Blacklisted
--   Depot 228984: Blacklisted
--   Depot 228990: Blacklisted
--   Depot 228981: Blacklisted
--   Depot 228985: Blacklisted

addappid(2289750)
addappid(2289750,0,"d9f24360174522fcb3d9f1d042634358f1ef823565062eb565add4fad25f166d")
addappid(2289751,0,"7c55ae6c9ad8d57caf5c869d0646221c0175dd371a933d2c9edabd34ab38c835")
--setManifestid(2289751,"8881582775017854093")
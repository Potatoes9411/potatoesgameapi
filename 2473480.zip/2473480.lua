-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2473480's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:59:47 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 6
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 2473641: Blacklisted

addappid(2473480)
addappid(3058540)
addappid(3119400)
addappid(2473481,0,"363154dca3195676d8f0f48c60b10690f47e439967d27162e4d18a5e6cbbcb83")
--setManifestid(2473481,"5401488014085579130")
addappid(2473482,0,"1e8929a53406c9c3c38ab507f124e2492d1f9d1a0ecfa993352f09466fd546a1")
--setManifestid(2473482,"3832686212079158057")
addappid(2473483,0,"43ad883ffa605f7c85a9fdc773be82ff190f8979de0f191a5503b3cac94564e9")
--setManifestid(2473483,"5577620011052035423")
addappid(3349181,0,"413a06c88c381839d07d241916f10a2681ed3cdef593f6a5d304bcb9c610e987")
--setManifestid(3349181,"7855392380586790061")
addappid(3349182,0,"009ea79dfba6cef415f71a52745273f03ebfde6a79d84f4b30c51b497c69d7ad")
--setManifestid(3349182,"4723780383063735356")
addappid(3349183,0,"f43c197d84c2aec17e0067ec0966c9871c3b5e5a030d02d47c287165a15fbc3e")
--setManifestid(3349183,"2393591933885771349")
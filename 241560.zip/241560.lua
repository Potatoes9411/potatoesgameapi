-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 241560's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:59:29 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(241560)
addappid(313670)
addappid(314080)
addappid(314090)
addappid(314091)
addappid(314092)
addappid(314093)
addappid(314100)
addappid(314101)
addappid(314110)
addappid(315380)
addappid(315381)
addappid(315382)
addappid(315383)
addappid(315384)
addappid(315385)
addappid(315386)
addappid(315387)
addappid(315388)
addappid(315389)
addappid(315392)
addappid(315393)
addappid(315394)
addappid(315395)
addappid(315396)
addappid(315397)
addappid(418990)
addappid(420200)
addappid(512350)
addappid(241561,0,"1be1e7dac5110de350ec4e8bef5adeb9f3462a7b97b0816158c163a30a634e8b")
--setManifestid(241561,"8497448424664183398")
addappid(241562,0,"8aadd8a2edf897c35e27b15ad03ef8b4eab7b060324519e59988e290391dcafc")
--setManifestid(241562,"8522332589588748716")
addappid(1716751,0,"84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
--setManifestid(1716751,"4132506267642462151")
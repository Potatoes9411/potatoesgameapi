-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1153410's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:55:41 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 2
-- Total DLCs: 0
-- Blacklisted Depots: 10
--   Depot 115323: Blacklisted
--   Depot 115322: Blacklisted
--   Depot 115327: Blacklisted
--   Depot 115326: Blacklisted
--   Depot 115329: Blacklisted
--   Depot 115324: Blacklisted
--   Depot 115321: Blacklisted
--   Depot 115330: Blacklisted
--   Depot 115328: Blacklisted
--   Depot 115325: Blacklisted

addappid(1153410)
addappid(3749550)
addappid(4054180)
addappid(4449300)
addappid(3749551,0,"ebe86f26c512a72840dfc92fcfd523c57ede0185d0150f30ea1f0e04a11a219d")
--setManifestid(3749551,"3311103993817349003")
addappid(1153411,0,"aae6e034473725f27603fc003f2520e4df8111c1433317b84a92e8bb8fb64913")
--setManifestid(1153411,"5246107015794696966")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2628570's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:00:24 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 2628: Blacklisted

addappid(2628570)
addappid(2628571,0,"3d8f02ab298debf84b3210ecc847f8439a407d8de7c7ec0c40cc66ef8fa81aac")
--setManifestid(2628571,"5789341579985645452")
addappid(2628572,0,"b88d7a78dfe127bd0964901f250dc5ecd00a06a81c4b96ee3068197625076d06")
--setManifestid(2628572,"1736151728310603144")
addappid(2628573,0,"13d84019b3ef433647851bf73205b2c86e07ac2a16685ae0f974a8067ce0b14c")
--setManifestid(2628573,"3590063118355978936")
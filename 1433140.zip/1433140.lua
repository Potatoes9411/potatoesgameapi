-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1433140's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:45 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 1
-- Blacklisted Depots: 0

addappid(1433140)
addappid(2394720)
addappid(2512180)
addappid(2521700)
addappid(2627220)
addappid(2628320)
addappid(2628330)
addappid(2628340)
addappid(2628350)
addappid(2628360)
addappid(2665270)
addappid(2665280)
addappid(2665290)
addappid(2665340)
addappid(2843740)
addappid(2894080)
addappid(2902450)
addappid(2946830)
addappid(2975770)
addappid(2975780)
addappid(2995360)
addappid(2995370)
addappid(3026790)
addappid(3026800)
addappid(3026810)
addappid(3053640)
addappid(3056080)
addappid(3087840)
addappid(3124350)
addappid(3130770)
addappid(3131330)
addappid(3197420)
addappid(3197430)
addappid(3197440)
addappid(3212770)
addappid(3266360)
addappid(3266370)
addappid(3266380)
addappid(3266390)
addappid(3266400)
addappid(3326200)
addappid(3326210)
addappid(3328030)
addappid(3375020)
addappid(3375030)
addappid(3375040)
addappid(3375050)
addappid(3455240)
addappid(3455250)
addappid(3455260)
addappid(3512930)
addappid(3512940)
addappid(3556440)
addappid(1433141,0,"333f806b286218fd908b89ab09f76d78ca28410ed7e235b95fbce1eddb1afa33")
--setManifestid(1433141,"2117981515629396747")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 209100's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:00 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 10
-- Blacklisted Depots: 3
--   Depot 2091333: Blacklisted
--   Depot 2091331: Blacklisted
--   Depot 2091332: Blacklisted

addappid(209100)
addappid(210019,0,"be0a09b9ce70a9f38db057df6085b3d644d941a9c31595ca64bebd86ac0a1671")
--setManifestid(210019,"1626462342786322075")
addappid(210018,0,"38daf59157cd92a5da021ac4bdfead8f1e6221cdd7d8626589ff842a05e74b9a")
--setManifestid(210018,"8775897540560642606")
addappid(210017,0,"7cc5209e5fa52feca4047b105ad0a3d9762e8a104ef91f64469c6ab8cdd2233c")
--setManifestid(210017,"5881169774455065208")
addappid(210016,0,"f26ba9e157c543c4b85a9fc7752522028eb99b1ab154f8c7cd573a10d420a8eb")
--setManifestid(210016,"8165546360368386361")
addappid(210015,0,"5d91d23e61ddb257ac0fd2902243f3c45d2d52104361cb9492487ceb235ea014")
--setManifestid(210015,"3095055180986312337")
addappid(210014,0,"ae16d95c7e1b1cb592a2256129cb9c3ab82d9c1c0e6b490cf6c1c5b9a741b9c0")
--setManifestid(210014,"6929097708000127585")
addappid(210013,0,"11a1d2d64ee443e4ac618d9c0d424ee6d68bb830034f70c6b33e455d5c7b4d28")
--setManifestid(210013,"8905134226746428943")
addappid(210012,0,"b66f99c08b15b07edaab9c45a6bddcecbda138e31c6136c9d9543278ff7cab7a")
--setManifestid(210012,"5768689185529545089")
addappid(210011,0,"1dbe894edc1b1c111f6f7156c42b1ff91a94ef953210399bbc345a9b76d287cf")
--setManifestid(210011,"8733898632540622121")
addappid(209101,0,"0cb75133d130a7f7e5291ee1f5324f3eb890004c910cec3777467cbeb4d95840")
--setManifestid(209101,"419826520612959058")
addappid(210010)
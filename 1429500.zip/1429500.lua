-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1429500's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:45 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(1429500)
addappid(2177410)
addappid(2177411)
addappid(2177420)
addappid(2383090)
addappid(2559460)
addappid(2993520)
addappid(3179040)
addappid(1429501,0,"4af31007a32b3a62aa74845448e0de78f69c44172d68b5292dc330e9b0be7ad8")
--setManifestid(1429501,"776729820351271622")
addappid(1429502,0,"7a5cc48e0d18d23604a2b14deebc04c3d406551f22a4a43da1192b8845c1091d")
--setManifestid(1429502,"292594823423242408")
addappid(2177411,0,"050a349e666466b9c5bc23b673aeadc4c84fa528b6cdae05c39f5129e4e67e3c")
--setManifestid(2177411,"155144051738553663")
addappid(2177420,0,"8cb9bde0a297f48e38063f9cebb17b4239349a7f0f97ff36590605d86df3f0bc")
--setManifestid(2177420,"1574774707044956456")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 105600's Lua and Manifest Created by Potatoes9411
-- Terraria
-- Created: May 16, 2026 at 04:45:15 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 12
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(105600, 1, "Unknown")
addappid(105601, 1, "Unknown")
setManifestid(105601, "5751495116255795831", 0)
addappid(105602, 1, "Unknown")
setManifestid(105602, "Unknown", 0)
addappid(105603, 1, "Unknown")
setManifestid(105603, "Unknown", 0)
addappid(105604, 1, "Unknown")
setManifestid(105604, "Unknown", 0)
addappid(105605, 1, "Unknown")
setManifestid(105605, "Unknown", 0)
addappid(105606, 1, "Unknown")
setManifestid(105606, "Unknown", 0)
addappid(105607, 1, "Unknown")
setManifestid(105607, "Unknown", 0)
addappid(105608, 1, "Unknown")
setManifestid(105608, "Unknown", 0)
addappid(105609, 1, "Unknown")
setManifestid(105609, "Unknown", 0)
addappid(409210, 1, "Unknown")
setManifestid(409210, "Unknown", 0)
addappid(1323320, 1, "Unknown")
setManifestid(1323320, "Unknown", 0)
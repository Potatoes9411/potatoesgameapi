-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2131640's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:02 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 5
-- Blacklisted Depots: 0

addappid(2131640)
addappid(2314260)
addappid(2314261)
addappid(2131641,0,"9e0f2cb55b09888aff90e9aade07595c51381b2dd13720057b88e569fc795868")
--setManifestid(2131641,"4626135309493798288")
addappid(2131642,0,"a454a9a487006c18009feb3a699f51d070728520c70ad6d82b3946268926e00e")
--setManifestid(2131642,"6534155900624658606")
addappid(2131644,0,"ed0021ded7e9812a517fa945eb64e5816b7385e8d895fc389c2db15daa466770")
--setManifestid(2131644,"4370148963514409199")
addappid(2314260,0,"9eea628721d13db63c23c3818238e17b8ce84693d659577fcb951ec4fb35110f")
--setManifestid(2314260,"7562505140636859611")
addappid(2314261,0,"39588cf7f429a47c8ebafcd19084333ca255a9e983122f3b329bb57e00661727")
--setManifestid(2314261,"1038044913448868335")
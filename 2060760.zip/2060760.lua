-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2060760's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:44 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 2
-- Total DLCs: 0
-- Blacklisted Depots: 7
--   Depot 2060311: Blacklisted
--   Depot 2060162: Blacklisted
--   Depot 2060313: Blacklisted
--   Depot 2060312: Blacklisted
--   Depot 2060314: Blacklisted
--   Depot 2060163: Blacklisted
--   Depot 2060310: Blacklisted

addappid(2060760)
addappid(2060761,0,"b3c538482d82e6037a05c543920b28b3e756744d89e62074a88673f3824cae8a")
-- setManifestid(2060761,"3793904101147834122")
addappid(2090850,0,"158cd791cfc5ea748f1e375f8a540efd5c2af849e38b399c37013553e3117423")
-- setManifestid(2090850,"5459864160355604383")
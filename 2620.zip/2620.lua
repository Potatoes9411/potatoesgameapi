-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2620's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:26 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 14
-- Blacklisted Depots: 0

addappid(2620)
addappid(2621,0,"5491a58960839f2a84d89ab4f60ba804a9223e294e009e546b5a583326628691")
addappid(2622,0,"189b1f2a30e52793693e95574fccb93c18e062579f28d98459bd1f2dc8718e29")
addappid(2623,0,"7fbbb4b1c2c3a4bbc4905f15cda7c19f23eed88ed466931879ed901b6c5cd8cb")
addappid(2624,0,"b52bceba80afc8164e492beb475d34e3bfd62d31426433c924b78356eda349e5")
addappid(2626,0,"46b3759cb79f4a80538c47a12c495f14ecf036933c261dc5122edd45b53e4f09")
addappid(2627,0,"831c20b8f3d1d86d6a6bb7019295f47664b6f79dbb2164c110ee3faa5c942ffc")
addappid(2628,0,"d9ba0ba8d2956dbda9f626116e6fc1fad6cc0ce2b8f5f20ee8ccd745ae822de4")
addappid(2629,0,"0b29fd16c4dfb4c896579be5de8f6b04bcf4b4bab47fbeeac61e131c8368aeb2")
addappid(2650,0,"4d266d6b85b7f9f6d32ec83f1334801a00b59a3e877a3cb47c36fd04eceb3d89")
addappid(2651,0,"287b83eff2e9237054ed0cfbb19cb0b67a0576c866e503012c212fcfe250216b")
addappid(2652,0,"05413275d287a69029d0d3d82e088673b808110c633a50588745034a2729cc1c")
addappid(2653,0,"2becd55f0072497dc6cc208e2a7a1eaaa6aacbca589766656d11dd3483a8d130")
addappid(2654,0,"fd6273f47de1b1fdb0957c1e7ac3c19342793cc56cd39f94bbf4bba8bf3e5f14")
addappid(2655,0,"97c1dc9780e76afdc28a8457fbca98846dddbf1c4508406887da2a1537a5b324")

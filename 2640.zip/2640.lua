-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2640's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:00:26 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 4
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 2640951: Blacklisted

addappid(2640)
addappid(2641,0,"36f1541ab1d713a20a676d2a797a0827e02e423ab89565e65791608bc2222da4")
--setManifestid(2641,"3417320556416905624")
addappid(2621)
--setManifestid(2621,"235916370645017959")
addappid(2642,0,"04bf9fd8c34331f7f1e3270ce1f5e39aeae22532f11b1d606d316d8380f26472")
--setManifestid(2642,"5930555561332439777")
addappid(2643,0,"b09d9e478376212e6d088091efeb0247b6333bec6ffa2704639607c1444773f4")
--setManifestid(2643,"251240555274784949")
addappid(2644,0,"61f34a50c83de39dba6b02810d0d3a8a562758d56c45fdee47e50db543dfbb3c")
--setManifestid(2644,"2093258244524288041")
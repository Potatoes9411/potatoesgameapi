-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2020710's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:39 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(2020710)
addappid(4156780)
addappid(2020711,0,"93bce109acdd17cf295a57e249841decc07e5a373ae984d23781b2ef3ef3505f")
--setManifestid(2020711,"8952272837561132279")
addappid(2020712,0,"4d148624a81eee8d397c9103e183f5839e303ef4ec7856fb46407791c65e7432")
--setManifestid(2020712,"6691357485840758269")
addappid(2020713,0,"6c349d7950be7d4323683c009f1c319577e117e6fe076b927dd7d1c955f1ab16")
--setManifestid(2020713,"8831500198337538297")
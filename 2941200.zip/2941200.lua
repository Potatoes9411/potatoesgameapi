-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2941200's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:01:31 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 1
-- Total DLCs: 0
-- Blacklisted Depots: 17
--   Depot 294107: Blacklisted
--   Depot 294113: Blacklisted
--   Depot 294101: Blacklisted
--   Depot 294103: Blacklisted
--   Depot 294112: Blacklisted
--   Depot 294115: Blacklisted
--   Depot 294116: Blacklisted
--   Depot 294105: Blacklisted
--   Depot 294114: Blacklisted
--   Depot 294106: Blacklisted
--   Depot 294111: Blacklisted
--   Depot 294110: Blacklisted
--   Depot 294108: Blacklisted
--   Depot 2941711: Blacklisted
--   Depot 294109: Blacklisted
--   Depot 294104: Blacklisted
--   Depot 294102: Blacklisted

addappid(2941200)
addappid(2941201,0,"28fba5dadad2225742fa42564c4b14baf559c0d3cc441274784a6389f2acca0c")
--setManifestid(2941201,"8154772410875293311")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 401680's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:52 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 6
-- Blacklisted Depots: 0

addappid(401680)
addappid(401681,0,"252c45db846d30301af4ffbe669aa2aa5e7023ee11d930f8018917553bbb2d27")
--setManifestid(401681,"3914599598838946193")
addappid(401682,0,"0bee7626e249e556df5bd0ead0f93611ab4d6d1b7e13e1251feb27a7e2c6246e")
--setManifestid(401682,"6222116235039793827")
addappid(401683,0,"3c4e6372aef78a9ddb5836f5a14f238dcc4ccf544163ae1e92b9826871fdb955")
--setManifestid(401683,"2504145601774977058")
addappid(401684,0,"1e4a42b570df48c1bc4a44aa9115f391e19f49eb43337d73ad35cde3f5937df9")
--setManifestid(401684,"9202629513538553961")
addappid(401685,0,"f3366b6a06377566d2547b6dea0104d2304d66e083ef9f586d56d25bc84d32b1")
--setManifestid(401685,"2846684166415870920")
addappid(401686,0,"68154512b9c9e325b13a55e368f5c91635966e98c2713e0d1856c69b4c23fc9a")
--setManifestid(401686,"7598919311012993660")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3916540's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:50 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(3916540)
addappid(4008760)
addappid(3916541,0,"b60ec3d8b3e39542a8769e6b15584cc4e3819bd49c54982cab4ff81f495a49d2")
--setManifestid(3916541,"4503334120030934532")
addappid(3916542,0,"2940c54f75508a874babc02055f5119b8c3c23c0111fc513242c61a3d0a6951f")
--setManifestid(3916542,"4185456833360199126")
addappid(4008760,0,"bbbd082b5d64dc77a7b00405e21a4405dbf9856c3fa483faf4932b7a4197f2b4")
--setManifestid(4008760,"6631293348273895279")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 218760's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:58:12 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 6
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(218760)
addappid(228983,0,"77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b")
--setManifestid(228983,"8124929965194586177")
addappid(228990,0,"44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")
addappid(229002,0,"f95e8545cfe871c330a483b25520ba7ed3750d21b9a51791ff0f0ed0dae33738")
--setManifestid(229002,"7260605429366465749")
addappid(218761,0,"d88caff8cc6c40c810db2ca62f71721c50e821c3f04018a712ce8cfe7a406779")
--setManifestid(218761,"5005856277633400399")
addappid(218762,0,"beb284109c2f46edbf2f183185de947f9181f5f2789aab15f501249f47f80a46")
--setManifestid(218762,"2322168789692605827")
addappid(218763,0,"b8341ce5214e81674f78c62f77d7d370dfe45223affa9b6a1508162a4700f963")
--setManifestid(218763,"395104994287955324")
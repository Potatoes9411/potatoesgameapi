-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 644830's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 07:00:04 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 10
-- Blacklisted Depots: 0

addappid(644830)
addappid(1068260)
addappid(1135970)
addappid(1135971)
addappid(1135972)
addappid(1137640)
addappid(1137641)
addappid(1162230)
addappid(644831,0,"5273086060e6534a2869d0aa041197d1800ee255416bc62d8054f8cfb34ce6cc")
--setManifestid(644831,"3191620500871439918")
addappid(644832,0,"264b2b4974f18466c6fc793568ee06180368326452a3b67cafa9d41e0f8ca0a7")
--setManifestid(644832,"4451458172733501493")
addappid(644833,0,"c4528347167bcbc478ea4676f78c1bc4d65211250d443d84269196fb5f233e7a")
--setManifestid(644833,"8163400162859938542")
addappid(644834,0,"45f4adb20300ea55959279bf0b9bc1b8618bd2b3d6ffb2b91628e3f5fe877b9b")
--setManifestid(644834,"4332506889156647888")
addappid(644835,0,"782f58e874be3f73dd144917d6ba9c497bda342787d297e74780e45bb3475fcf")
--setManifestid(644835,"2041984520297196038")
addappid(644836,0,"7b2266bd09aa555d1e75ae40445c2cc678b470f96c570d54dac264506ee10449")
--setManifestid(644836,"4084818526915859018")
addappid(644837,0,"c6f4f22308baf57e31bf82a38aa604f412bdcc8add016073253dfcee46c27fab")
--setManifestid(644837,"6300986339426965562")
addappid(644838,0,"bbb343d1f71ac58b573ba9a44ab20a5872fd5452ac67e65737455cc342a38eaf")
--setManifestid(644838,"1041803459927629548")
addappid(1102334,0,"0547a3098567ccdff45ca84909f835af85911cb22db4eeeb36ee2ddc014b3247")
--setManifestid(1102334,"7116448327281246369")
addappid(1102335,0,"35eff09e4d09506b683bcadea614fb2b066a37a657f96da02dc6aa6c8d914d5e")
--setManifestid(1102335,"9197997188770382412")
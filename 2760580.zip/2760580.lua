-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2760580's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:31 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(2760580)
addappid(3888510)
addappid(3959660)
addappid(3959670)
addappid(2760581,0,"db681438192b6f3d7ea13050140a1056a1dcf7f9b9883ea46536f94420f9d474")
--setManifestid(2760581,"6375435570114615019")
addappid(3888510,0,"f55cd0d1086e93a9d7fe4d79acb255f0701501ae6fea8a3270ec8e5ba60750b3")
--setManifestid(3888510,"8926686536884428842")
addappid(3959660,0,"e17dc46c919a9677a1a44866a00369a2a2711bb011f840f057397eabe11846db")
--setManifestid(3959660,"4026315217561317299")
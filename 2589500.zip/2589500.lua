-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2589500's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:00:14 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 2589740: Blacklisted

addappid(2589500)
addappid(2589500,0,"5163fe41419ecfe3e90105d7df21b63bea613635c470bc40684a61343139d02a")
addappid(2589501,0,"6f51226f61dd888511279cdc32b68f2eafddb79f8d92998ffcac30e6dae73021")
--setManifestid(2589501,"7855083263507322701")
addappid(2589502,0,"4b0d0eb017d111efc9280dba6335288de7d0c691d506d8ab30559a254745f0c2")
--setManifestid(2589502,"7764607977219522818")
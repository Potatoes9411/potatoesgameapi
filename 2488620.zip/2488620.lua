-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2488620's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:20 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 6
-- Blacklisted Depots: 0

addappid(2488620)
addappid(2488620,0,"703777a80cf4d7e480beff412e25cdbdb698d1ec6fa6bc3ef1920437e590d6ce")
addappid(2751140)
addappid(2751150)
addappid(2751160)
addappid(2751170)
addappid(2751180)
addappid(2751190)
addappid(2791190)
addappid(2807940)
addappid(2994700)
addappid(3075400)
addappid(3335270)
addappid(2488621,0,"631754f71ffa45dd53c6375d1e093a58315b5c7468e7dae0b1c1f168b1e3b062")
--setManifestid(2488621,"5937082381037127537")
addappid(2488622,0,"3bb5b95c44afb22626dfe7f4717d1a8c829e93cf3bfad336352103c304cb4378")
--setManifestid(2488622,"5100092380679030330")
addappid(2488623,0,"e2f55053a31b74536dc064d80009d8fb3905a66be6c1c4809a522f27166f609c")
--setManifestid(2488623,"3598762856071715621")
addappid(2488624,0,"13515b2f09f7b81529a2c82c13692f6148e80f4aea11fde68100e35560e67a60")
--setManifestid(2488624,"367140462649007330")
addappid(3893181,0,"7f675c2fe8e758d16f3cf8d3b493956afaee78e96d78cdb668a5edb8ac1580f6")
--setManifestid(3893181,"5841062713806441202")
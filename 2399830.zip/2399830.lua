-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2399830's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:16 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 9
-- Blacklisted Depots: 0

addappid(2399830)
addappid(2881150)
addappid(2972680)
addappid(3282470)
addappid(3571730)
addappid(3720100)
addappid(3720200)
addappid(3982300)
addappid(2827030,0,"ca47571a30440cd0d827bee6a57a945cf56d25fd4dbc19435d608994b021302a")
--setManifestid(2827030,"8740940789069011475")
addappid(2849450,0,"06a4aa068a1a3940e0c7eff34508ad6474806f4b46520ef9ea12b4b7f77a3d0e")
--setManifestid(2849450,"3444753660636381887")
addappid(3583650,0,"e7d5b3c53aabefd8ec1f24038e55c6e614c31d7e5c6237c443e83c4eb1fc5a83")
--setManifestid(3583650,"4486757358974352376")
addappid(3059650,0,"84b1a413568c28ea0226bbd983fbf08741ead907cc7cd9cdd447056405850bd2")
--setManifestid(3059650,"1113400709024649774")
addappid(3349320,0,"e0cbc7f932b6b5ffa7e36b9fe8ccf5b2317d5073f520b8a357a7bb8e32d7a181")
--setManifestid(3349320,"4309558368216093467")
addappid(3483400,0,"8f2706fe64f86426091cbb9a23dedbc3ec0c53a78877abb9b549edded5f436ea")
--setManifestid(3483400,"7204157948119996991")
addappid(3675020,0,"5028ee914f2c74aba43cc91d7f2f49fd5ad0ec96dcb76372ed26deec22b0e88c")
--setManifestid(3675020,"1601575005126806817")
addappid(3982310,0,"184547e9bf5059e77f7971af6c7a064a5a7eb7a76a3b210fbeed6ebb00df991c")
--setManifestid(3982310,"5410702574832216930")
addappid(2399831,0,"320e0bcc46f1e7d88e18488c73990878eedbc06c3284015e1d0af97abe143e23")
--setManifestid(2399831,"4694934180093727512")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2103510's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:55 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 1
-- Total DLCs: 0
-- Blacklisted Depots: 54
--   Depot 2103783: Blacklisted
--   Depot 2103734: Blacklisted
--   Depot 2103740: Blacklisted
--   Depot 2103731: Blacklisted
--   Depot 2103471: Blacklisted
--   Depot 2103741: Blacklisted
--   Depot 2103781: Blacklisted
--   Depot 2103766: Blacklisted
--   Depot 2103739: Blacklisted
--   Depot 2103759: Blacklisted
--   Depot 2103750: Blacklisted
--   Depot 2103733: Blacklisted
--   Depot 2103735: Blacklisted
--   Depot 2103749: Blacklisted
--   Depot 2103761: Blacklisted
--   Depot 2103757: Blacklisted
--   Depot 2103737: Blacklisted
--   Depot 2103747: Blacklisted
--   Depot 2103788: Blacklisted
--   Depot 2103760: Blacklisted
--   Depot 2103744: Blacklisted
--   Depot 2103769: Blacklisted
--   Depot 2103770: Blacklisted
--   Depot 2103754: Blacklisted
--   Depot 2103753: Blacklisted
--   Depot 2103743: Blacklisted
--   Depot 2103784: Blacklisted
--   Depot 2103793: Blacklisted
--   Depot 2103746: Blacklisted
--   Depot 2103794: Blacklisted
--   Depot 2103765: Blacklisted
--   Depot 2103756: Blacklisted
--   Depot 2103786: Blacklisted
--   Depot 2103763: Blacklisted
--   Depot 2103738: Blacklisted
--   Depot 2103745: Blacklisted
--   Depot 2103751: Blacklisted
--   Depot 2103091: Blacklisted
--   Depot 2103771: Blacklisted
--   Depot 2103742: Blacklisted
--   Depot 2103764: Blacklisted
--   Depot 2103755: Blacklisted
--   Depot 2103796: Blacklisted
--   Depot 2103752: Blacklisted
--   Depot 2103758: Blacklisted
--   Depot 2103730: Blacklisted
--   Depot 2103748: Blacklisted
--   Depot 2103736: Blacklisted
--   Depot 2103768: Blacklisted
--   Depot 2103795: Blacklisted
--   Depot 2103778: Blacklisted
--   Depot 2103762: Blacklisted
--   Depot 2103767: Blacklisted
--   Depot 2103732: Blacklisted

addappid(2103510)
addappid(3286970)
addappid(2103511,0,"a8335fae431b595479800b85ef52a9a758f66ad49ec5b4724823b5adbfa64c5f")
--setManifestid(2103511,"5125783047560548710")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1062160's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:38 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(1062160)
addappid(1062161,0,"dbdee5dc6bbc788137c7e79c69cb426c6a29e384afd8d7bddc510b9fbdd0e2e8")
--setManifestid(1062161,"7891077659831470565")
addappid(1062162,0,"c11113d3df439909cf97ddfdfbe93cda9ef1131270627970ff27aefce06a5f07")
--setManifestid(1062162,"1268252425519729745")
addappid(1062163,0,"c15494d2cf3ac61e4c3cb47288ef2e57f7f2581ff5e197d7dcd3e4ba90b70d77")
--setManifestid(1062163,"1655132407324165096")
addappid(1062164,0,"18a955c1d539cc2e3187d0b9cc9dda2488f3cbbb7c8dda72a62b3e2ca6fabe5d")
--setManifestid(1062164,"5790352083275615295")
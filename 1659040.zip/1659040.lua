-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1659040's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:56:51 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 2
-- Total DLCs: 0
-- Blacklisted Depots: 2
--   Depot 1659422: Blacklisted
--   Depot 1659421: Blacklisted

addappid(1659040)
addappid(1829580)
addappid(1829581)
addappid(1829582)
addappid(1829583)
addappid(1829584)
addappid(1829585)
addappid(1829586)
addappid(1829587)
addappid(1829590)
addappid(1829591)
addappid(1829592)
addappid(1829593)
addappid(1829594)
addappid(1829595)
addappid(1829596)
addappid(1829600)
addappid(1829601)
addappid(1829602)
addappid(1829603)
addappid(1829604)
addappid(1829605)
addappid(1843460)
addappid(2184790)
addappid(2184791)
addappid(2475260)
addappid(2828470)
addappid(2973650)
addappid(3110360)
addappid(3254350)
addappid(3711140)
addappid(3957470)
addappid(4097630)
addappid(4328240)
addappid(4542910)
addappid(4621250)
addappid(1659041,0,"891bd9670c03fa74065659fe448680b55b5279707dfe40493d5f00372e02b42f")
--setManifestid(1659041,"5604189710016205281")
addappid(1659042,0,"a4a03eaeb99e5848f2074a8902ce896268489ec313300285a521885c807e263c")
--setManifestid(1659042,"8022087307091797250")
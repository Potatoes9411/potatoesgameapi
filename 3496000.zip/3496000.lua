-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3496000's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:33 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(3496000)
addappid(3496001,0,"ab5f7aa3985fbccdb6589b71db8c36547133ecf078cf8935abd0f2964f35f10a")
--setManifestid(3496001,"3519434759820507781")
addappid(3496002,0,"77b869aca5e686b9829a458c3570f5995bcb7f3338ad5ff03c885c08798bcbc9")
--setManifestid(3496002,"1451990103381963056")
addappid(3496003,0,"79d8e58bf474d19192c3e85f00303ed311f2870726d7caea4b2b2ee66abdf2c9")
--setManifestid(3496003,"8884482275144595948")
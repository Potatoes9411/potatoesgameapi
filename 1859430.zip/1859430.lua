-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1859430's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:14 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(1859430)
addappid(3349710)
addappid(3349720)
addappid(1859431,0,"4d2164d4378d37ecd0d12bfdf51f791e0bda0b885caaf1bc649f8782d039c7c6")
--setManifestid(1859431,"944176290333349810")
addappid(3349710,0,"7da5a6c00b768ae8d7316817e8f473b6c9aa267597c56f170e39bb08fed2d278")
--setManifestid(3349710,"3648696743718052628")
addappid(3349720,0,"4d36c89f489cdbc426e6020f4eda05eb8827a63a9688cb668819bb38cb6addbf")
--setManifestid(3349720,"5919957891950198464")
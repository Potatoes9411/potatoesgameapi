-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 252490's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:59:59 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 4
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(252490)
addappid(252490,0,"070d35c4cac50d6b14881a6fd630bf1c58a061bec585e899a48c813972638108")
addappid(494560)
addappid(1174370)
addappid(1353060)
addappid(1374000)
addappid(1670430)
addappid(3891560)
addappid(252492,0,"96b750328197855f4311ba6ad6d86e9051866cc6b9a6c851de55cc41b8ad9a24")
--setManifestid(252492,"2208299763163969643")
addappid(252494,0,"5d5f72c0460cb7598666696c1b2f612f22efb43fb87cf4322e596bfec8a231ec")
--setManifestid(252494,"403111719879211028")
addappid(252495,0,"728fcdc1c6af4454f3c86e5bc62a75875af5ba790cc8a2623620e216086e034d")
--setManifestid(252495,"7548202537082450228")
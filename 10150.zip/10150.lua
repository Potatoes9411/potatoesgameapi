-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 10150's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:36 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(10150)
addappid(10151,0,"6a8031835dc05293f181f82838888b8125309337318239b1ddbdb09f0a4caa77")
--setManifestid(10151,"2961055382649058691")
addappid(10152,0,"fe92b92ecf2f65762c8fa0946ed504a468250e5d5bba72d8c22d82dbf4837fd9")
--setManifestid(10152,"1688785474723655723")
addappid(10153,0,"2d78a62123ebaeaa32c518637004173360e4c771d95d477c473cc15ce4c5d40d")
--setManifestid(10153,"1808095436463938303")
addappid(10154,0,"18966e09d0c0543581c6fdc1623d6e5666a410dd1a8005eea750d7414e54204a")
--setManifestid(10154,"3364852067550674408")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3480's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:32 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 6
-- Blacklisted Depots: 0

addappid(3480)
addappid(3489,0,"5adea0126a71cdc11390b4e1f09a54ffc3a0de686dde2373bcbf1078a7317b4e")
addappid(3481,0,"84b8fc8f5aef44c756634061a97dd52f355a38068705741b18ad87c2baf54e40")
addappid(3485,0,"e48fd850584ba591e32ee481d98d9c19ca173be73fff6c8f49b345ac40208bbc")
addappid(3486,0,"1bf4d2a04a39089e92982dfef6c353f9d9b1d227e5d07c18b22ea782fdc88dd9")
addappid(3487,0,"533d6fef2855107b6fafea77130c85db757ad18250ea763ff351547280afa05e")
addappid(3488,0,"31e5b0deba3c07124c21878f816a9e6815da5ea8a140a85e24ab9de563b5fbbd")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1184820's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:55:44 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(1184820)
addappid(1184820,0,"5ea55bc26df932d00e34c22dfa5b7a2ec8d7b6d1dcdb21aec2997158982dca53")
addappid(1184821,0,"d99750b50ab3c92db290d86b11a2488433c9cc1f47b9c55c51aacc6387916b66")
--setManifestid(1184821,"5516134484504520010")
addappid(1184822,0,"da013567571fd3407663770209cc732a37c8fd37d2453820f8e9c7254960f0e2")
--setManifestid(1184822,"4392792565099128614")
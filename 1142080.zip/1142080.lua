-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1142080's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:55:39 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(1142080)
addappid(1938870)
addappid(1142082,0,"de620277c4a1ada7872cec710760e51e282d53e8181422142b7858f278a482ab")
--setManifestid(1142082,"590784518725178393")
addappid(1142083,0,"836e08bcc888ed4f7758f1a7ff3a4a1e8f6dcf15dbb911d1a92d02bc460a7994")
--setManifestid(1142083,"3920224311256263081")
addappid(1142084,0,"fb18eed20dfbb38990ca58586833e070bd5db3627161f9fee7d50a410af8a787")
--setManifestid(1142084,"678088482385963261")
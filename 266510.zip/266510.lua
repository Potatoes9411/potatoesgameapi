-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 266510's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:27 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(266510)
addappid(350460)
addappid(266511,0,"d96fddad3a96581f9565048fffa4c9c736808b3ff3eaf138442010656716fa71")
--setManifestid(266511,"8462080091421849596")
addappid(266512,0,"f069d71777e1c3d4e1e405029c8c59abd278ee8fcd1a11892ea2677d85b2ee73")
--setManifestid(266512,"2280619790639060045")
addappid(266513,0,"5b0d5965087479fd1bd6e1a56a6edfd2631b9df5c20bf33385f43a8d8638f385")
--setManifestid(266513,"1351952917202550539")
addappid(351430,0,"14c5d50c4d139bc65a7314115ca98e7f5bdf8367dbf01632519c36e662e58d51")
--setManifestid(351430,"618821319119946243")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1085660's Lua and Manifest Created by Potatoes9411
-- Destiny 2
-- Created: June 17, 2026 at 06:53:41 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 22
-- Blacklisted Depots: 1
--   Depot 1085221: Blacklisted

addappid(1085660, 1, "Unknown")
addappid(1085661, 1, "c659b5e3411b08b00254acdd060490edf00b7803c96e6c45c875bf427882b23b")
setManifestid(1085661, "5920321711042808597", 0)
addappid(1085662, 1, "ff16e660aa96ae3ecc53e25fd85e91273d87d9c1b78eb6ff7ece94c49c71bb5b")
setManifestid(1085662, "2064388945826876851", 0)
addappid(1085663, 1, "Unknown")
setManifestid(1085663, "Unknown", 0)
addappid(1085664, 1, "Unknown")
setManifestid(1085664, "Unknown", 0)
addappid(1085665, 1, "Unknown")
setManifestid(1085665, "Unknown", 0)
addappid(1085666, 1, "Unknown")
setManifestid(1085666, "Unknown", 0)
addappid(1085667, 1, "Unknown")
setManifestid(1085667, "Unknown", 0)
addappid(1085668, 1, "Unknown")
setManifestid(1085668, "Unknown", 0)
addappid(1085669, 1, "Unknown")
setManifestid(1085669, "Unknown", 0)
addappid(3186540, 1, "Unknown")
setManifestid(3186540, "Unknown", 0)
addappid(3186490, 1, "Unknown")
setManifestid(3186490, "Unknown", 0)
addappid(2336880, 1, "Unknown")
setManifestid(2336880, "Unknown", 0)
addappid(1945340, 1, "Unknown")
setManifestid(1945340, "Unknown", 0)
addappid(1656330, 1, "Unknown")
setManifestid(1656330, "Unknown", 0)
addappid(1656370, 1, "Unknown")
setManifestid(1656370, "Unknown", 0)
addappid(1314563, 1, "Unknown")
setManifestid(1314563, "Unknown", 0)
addappid(1090200, 1, "Unknown")
setManifestid(1090200, "Unknown", 0)
addappid(1090150, 1, "Unknown")
setManifestid(1090150, "Unknown", 0)
addappid(1745440, 1, "Unknown")
setManifestid(1745440, "Unknown", 0)
addappid(1569630, 1, "Unknown")
setManifestid(1569630, "Unknown", 0)
addappid(4562000, 1, "Unknown")
setManifestid(4562000, "Unknown", 0)
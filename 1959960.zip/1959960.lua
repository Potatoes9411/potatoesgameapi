-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1959960's Lua and Manifest Created by Potatoes9411
-- Burg
-- Created: June 17, 2026 at 06:54:11 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 10
-- Blacklisted Depots: 0

addappid(1959960, 1, "Unknown")
addappid(1959961, 1, "Unknown")
setManifestid(1959961, "Unknown", 0)
addappid(1959962, 1, "Unknown")
setManifestid(1959962, "Unknown", 0)
addappid(1959963, 1, "Unknown")
setManifestid(1959963, "Unknown", 0)
addappid(1959964, 1, "Unknown")
setManifestid(1959964, "Unknown", 0)
addappid(1959965, 1, "Unknown")
setManifestid(1959965, "Unknown", 0)
addappid(1959966, 1, "Unknown")
setManifestid(1959966, "Unknown", 0)
addappid(1959967, 1, "Unknown")
setManifestid(1959967, "Unknown", 0)
addappid(1959968, 1, "Unknown")
setManifestid(1959968, "Unknown", 0)
addappid(1959969, 1, "Unknown")
setManifestid(1959969, "Unknown", 0)
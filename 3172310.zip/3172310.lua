-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3172310's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:19 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 4
--   Depot 3172191: Blacklisted
--   Depot 3172061: Blacklisted
--   Depot 3172281: Blacklisted
--   Depot 3172671: Blacklisted

addappid(3172310)
addappid(3172311,0,"e00d93bf5a25fff5de35f341dae52e61922bbde6debb7529c93bfcbe7eeda48c")
-- setManifestid(3172311,"5217988976623184986")
addappid(3172312,0,"cb1ed7ab9912b2732523610fbabff5a934271d73fdc92e054ac9c4f42339710d")
-- setManifestid(3172312,"7010801445481611487")
addappid(3172313,0,"1e85ba06e7e069e87b7412abfdbfe2c4b53ac9ac0ca2ad9bae6f8b1fe852178f")
-- setManifestid(3172313,"6407207977289258753")
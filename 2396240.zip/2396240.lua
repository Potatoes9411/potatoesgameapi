-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2396240's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:59:24 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 1
-- Total DLCs: 0
-- Blacklisted Depots: 13
--   Depot 239619: Blacklisted
--   Depot 239621: Blacklisted
--   Depot 239617: Blacklisted
--   Depot 239623: Blacklisted
--   Depot 239613: Blacklisted
--   Depot 239624: Blacklisted
--   Depot 239620: Blacklisted
--   Depot 239622: Blacklisted
--   Depot 239616: Blacklisted
--   Depot 239614: Blacklisted
--   Depot 239618: Blacklisted
--   Depot 239615: Blacklisted
--   Depot 239611: Blacklisted

addappid(2396240)
addappid(2396241,0,"a33fb80f640826dd29e8a225baf9156fc106564d7de50b8c786bb01ba5e3effb")
--setManifestid(2396241,"3227884472846331420")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2879290's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:01:14 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 1
-- Total DLCs: 0
-- Blacklisted Depots: 13
--   Depot 2879621: Blacklisted
--   Depot 2879848: Blacklisted
--   Depot 2879571: Blacklisted
--   Depot 2879623: Blacklisted
--   Depot 2879846: Blacklisted
--   Depot 2879847: Blacklisted
--   Depot 2879841: Blacklisted
--   Depot 2879845: Blacklisted
--   Depot 2879622: Blacklisted
--   Depot 2879844: Blacklisted
--   Depot 2879842: Blacklisted
--   Depot 2879849: Blacklisted
--   Depot 2879843: Blacklisted

addappid(2879290)
addappid(2879291,0,"675521f33808432dcc54346b0c971450cf051ff807ad93cb2438a06b647d4cdc")
--setManifestid(2879291,"6516720829067023382")
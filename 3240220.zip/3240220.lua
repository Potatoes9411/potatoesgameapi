-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3240220's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:22 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 6
-- Blacklisted Depots: 0

addappid(3240220)
addappid(1899671,0,"b7921da5e50d00b2238d0fe870a354cb572bc5d397955fef02a439103f62827b")
--setManifestid(1899671,"2821759503143114834")
addappid(3240221,0,"61fc2e176574df29022e435d489e10efa92e38b3297e1f0c641e63b11df58a8a")
--setManifestid(3240221,"7738940149188702855")
addappid(3240222,0,"a90ba98205062c9ae855344794a6a3e0e9e59d825595f0508d7276e4d26da852")
--setManifestid(3240222,"8737726049140786475")
addappid(3240223,0,"46bece69b70a0f45bc94213cabf17a5a8e0546fe5b42c9d71f357f9fd7eaa605")
--setManifestid(3240223,"6109028520665039655")
addappid(3240224,0,"3ff530fbca5308cf7d55f33334770b536834d48139880615673f26e3569b99d9")
--setManifestid(3240224,"3207789125684884376")
addappid(3240225,0,"8951f7eb7724cc2b407c9170e8bf5ce6792f8d6a7ad6a42c460a74abacac719a")
--setManifestid(3240225,"7524661139560880719")
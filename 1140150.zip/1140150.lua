-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1140150's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:55:39 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 4
-- Total DLCs: 0
-- Blacklisted Depots: 2
--   Depot 1140001: Blacklisted
--   Depot 1140000: Blacklisted

addappid(1140150)
addappid(1140150,0,"3352c7971eb9675d4e36f56709a8be8d71a6d3e6883b4a96b1ef51cfe632bf30")
addappid(1140151,0,"50615b31d57243ccab3116b85ab46fe01d860584a3a8ede2bde1362d2d581cc1")
--setManifestid(1140151,"2262922701688309341")
addappid(1140152,0,"c946bb7206279356b9b1a03620110ce4f354d253b4664f59f1f00da7e61b79ee")
--setManifestid(1140152,"9087029170994327570")
addappid(1140159,0,"0f4b3ec0d7d598640d4ad325db0ce63f9f7eabf89590f146a981a7d76df828a5")
--setManifestid(1140159,"9040816952781435953")
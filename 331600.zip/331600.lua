-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 331600's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:24 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 14
-- Blacklisted Depots: 0

addappid(331600)
addappid(378500,0,"cd743e5a9515d23420d0a1867896f173453c871e83e438d5acb9201111095e6a")
--setManifestid(378500,"4644783731658738856")
addappid(378501,0,"4fff391948763d0561c0fbd04ca0d3fe5a2dd9d42fe6bdd26f2330294148e22a")
--setManifestid(378501,"3106342256878354993")
addappid(378502,0,"3c173deccea6f6acfde664264cbc40e116d285771dc8912e636ff20de28549ed")
--setManifestid(378502,"1187508003630435865")
addappid(378503,0,"dc2285746cd4e634a1ac21bfdf4247fa95cb8ed1b0c1a0b55ce912e0fb156f35")
--setManifestid(378503,"1360882669800474027")
addappid(378504,0,"9b015b1bf5d31e776ce9ded2014c79306598b387a8127f1d00a0738893312e21")
--setManifestid(378504,"783450909398244918")
addappid(378505,0,"a65303537a5f193898e2d4f784852d77c6b0dea235983672fe79f5ce06569e5c")
--setManifestid(378505,"8826423171708072748")
addappid(331601,0,"a4e8977b01d0724041633b7a8e5b366e42667f7061b9c174b11a6c2f410da593")
--setManifestid(331601,"2999088748357607913")
addappid(331602,0,"0e44ba49f0bca8ac2cc0b49464e484a267062e35e88154c3dc80641db36c70c9")
--setManifestid(331602,"420010684058355530")
addappid(331603,0,"172c21850f8cd7a9e321c4b17eacf2b0525b793c40d9793172f00c77af436299")
--setManifestid(331603,"7301338650225706767")
addappid(331604,0,"2582bb68fa0ca8dec81ba7dbba5124bb37e1f796ea06928502d09c406c8a5348")
--setManifestid(331604,"3770011428541504259")
addappid(331605,0,"e89ccd6dbfa911b5f0a34cae3456de67841390d85d35151031f11c9419b63b65")
--setManifestid(331605,"4803800176798335417")
addappid(331606,0,"5f42b52aebe4e6dc59dfb6963464e88d19efea127051cd97ce82f2a2f3f92d71")
--setManifestid(331606,"7875471842702689716")
addappid(331607,0,"73602a983211b1d17cf2cec8805ec8590e5258683b65491203ecdd1eab0d8ffe")
--setManifestid(331607,"3168331287934858695")
addappid(331608,0,"5dc48b567fb61cc7bc35920ac789461012b98f803e80027f926d1cc60370a242")
--setManifestid(331608,"7841786857034604379")
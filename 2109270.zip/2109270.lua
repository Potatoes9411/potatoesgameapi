-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2109270's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:55 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 2
-- Total DLCs: 0
-- Blacklisted Depots: 19
--   Depot 2109309: Blacklisted
--   Depot 2109307: Blacklisted
--   Depot 2109304: Blacklisted
--   Depot 2109317: Blacklisted
--   Depot 2109314: Blacklisted
--   Depot 2109305: Blacklisted
--   Depot 2109313: Blacklisted
--   Depot 2109310: Blacklisted
--   Depot 2109312: Blacklisted
--   Depot 210935: Blacklisted
--   Depot 2109308: Blacklisted
--   Depot 2109306: Blacklisted
--   Depot 2109316: Blacklisted
--   Depot 2109311: Blacklisted
--   Depot 2109341: Blacklisted
--   Depot 2109315: Blacklisted
--   Depot 2109300: Blacklisted
--   Depot 2109301: Blacklisted
--   Depot 2109303: Blacklisted

addappid(2109270)
addappid(3114870)
addappid(3621280)
addappid(2109271,0,"159b87c9592c3fcd889e37b4bb9ad67aa87361e8e6f1dc80f56e7013ce994bc0")
--setManifestid(2109271,"1595931300507678956")
addappid(3114870,0,"784cbcfb5e2c251e30f6ec0a195863de46a66bae7a1ffd86766d8dff261adeca")
--setManifestid(3114870,"5117146261738859761")
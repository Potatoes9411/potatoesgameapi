-- Made by F1uxin (UserID:965053505901588521), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/NmmpgnAgen)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:965053505901588521)
-- And if you have any questions feel free to dm on discord (UserID:965053505901588521)

-- Socials: https://guns.lol/f1uxin

-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid", save the file, then add the lua file (i think you can add the manifests too but I would just add the lua file to ensure it works).

-- Main stuff to add your game.
addappid(3892270) -- Gamble With Your Friends
addappid(3892271, 1, "90695be6010d5ec2e8890f1d742357316f4d5f74a8a9d22b2ae076b184797167") -- Depot 3892271
setManifestid(3892271, "7320099300644156449", 2259235243)
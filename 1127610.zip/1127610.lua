-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1127610's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:55:37 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 4
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(1127610)
addappid(1254340)
addappid(1127611,0,"cf327b43d6b9d3c6d298a239e16463d41ee789e93192b8197dc36d59d4eb394a")
--setManifestid(1127611,"397316618741933440")
addappid(1127612,0,"aa1154bb4ed92409fd07e60275d6df30a6242e1a73823954e098e1b9611f2994")
--setManifestid(1127612,"48207306337739225")
addappid(1127613,0,"98679a34c61297a71aef07ade22925a65361cd9bd52b16c8c67cdd5fdf990196")
--setManifestid(1127613,"3910661606613730701")
addappid(1254340,0,"8f4bf6b05e02854f2e5b8f62a5cf91cd87e8a9f80d65244f51b8a8165e244dfd")
--setManifestid(1254340,"6227712231918947700")
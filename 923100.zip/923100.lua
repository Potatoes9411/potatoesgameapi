-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 923100's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 07:00:08 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(923100)
addappid(3708270)
addappid(923101,0,"4d633cb83924597c91bc78f7b2cfe2a3eecbf102272c166e720255f0c3144fc0")
--setManifestid(923101,"8943456212532972100")
addappid(923102,0,"d201a0f36915ce46d95a08ccdf1bf1147f37f66d840b0e672cc40d1de088ac09")
--setManifestid(923102,"3568623930295210323")
addappid(923105,0,"0df7be2261b6610ef43845a56219d487dc11827e7fab4cd76ae1dcdb2f888523")
--setManifestid(923105,"3391520716300528073")
addappid(3708270,0,"b81c919b6be907c86f6045d9b1c83582c71111a4d0f702f0e5edfc696324ef99")
--setManifestid(3708270,"1539446857837869129")
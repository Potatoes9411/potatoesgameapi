-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 271590's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:00:43 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 6
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 2715871: Blacklisted

addappid(271590)
addappid(362000)
addappid(362001)
addappid(362002)
addappid(362003)
addappid(413180)
addappid(771300)
addappid(271591,0,"baebeedec48b33c68a322fea0cbaa8d023d1dab4d2870aa909b82c33caa53941")
--setManifestid(271591,"6768057890420400504")
addappid(271592,0,"e34313f0ec133a608e636cf04fd879d3ac1e8e10af38542436940be1b6834bee")
--setManifestid(271592,"8238436718767500927")
addappid(271593,0,"71b57be5c50e5fbc819068a5bf31db42b653f1c75d88307da682ff0d5cae9457")
--setManifestid(271593,"2967789647252082634")
addappid(271594,0,"ae7ed6931a136d41d3aae146563368eb3b3e4e60963344f3f426c0abc74bbdab")
--setManifestid(271594,"8854874882423166314")
addappid(271595,0,"6dc0d2ce6b9dc96469ff792f6a607f759f0abd851d496cac73d71cd145c70b4d")
--setManifestid(271595,"1376135673068470825")
addappid(1899671,0,"b7921da5e50d00b2238d0fe870a354cb572bc5d397955fef02a439103f62827b")
--setManifestid(1899671,"2821759503143114834")
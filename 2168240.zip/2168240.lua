-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2168240's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:58:05 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 4
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 2168261: Blacklisted

addappid(2168240)
addappid(2346600)
addappid(2379840)
addappid(2426680)
addappid(2168241,0,"0b5b008cb201babba949bc2fc102380bf65c566c75f45f787bd79e29ddc71881")
--setManifestid(2168241,"6398103334800398603")
addappid(2346600,0,"453a54e331ae1606491f826b6449ea421ce19dd7a96328801d8de1780609794e")
--setManifestid(2346600,"1465629805742244881")
addappid(2379840,0,"101cee81588b7b80c56f0dd0240f6c8d693d8174740b91480cd99aae175517f0")
--setManifestid(2379840,"423172349271376133")
addappid(2426680,0,"58252cdaaf621f8557cd426dc0a53569012b4f88e5bdd10e3829f24a6dca309c")
--setManifestid(2426680,"6856094543262044113")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2670630's Lua and Manifest Created by Potatoes9411
-- Supermarket Simulator
-- Created: May 16, 2026 at 04:45:59 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 16
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(2670630, 1, "Unknown")
addappid(2670631, 1, "Unknown")
setManifestid(2670631, "6058445394227756543", 0)
addappid(2670632, 1, "Unknown")
setManifestid(2670632, "Unknown", 0)
addappid(2670633, 1, "Unknown")
setManifestid(2670633, "Unknown", 0)
addappid(2670634, 1, "Unknown")
setManifestid(2670634, "Unknown", 0)
addappid(2670635, 1, "Unknown")
setManifestid(2670635, "Unknown", 0)
addappid(2670636, 1, "Unknown")
setManifestid(2670636, "Unknown", 0)
addappid(2670637, 1, "Unknown")
setManifestid(2670637, "Unknown", 0)
addappid(2670638, 1, "Unknown")
setManifestid(2670638, "Unknown", 0)
addappid(2670639, 1, "Unknown")
setManifestid(2670639, "Unknown", 0)
addappid(4078560, 1, "Unknown")
setManifestid(4078560, "Unknown", 0)
addappid(4078570, 1, "Unknown")
setManifestid(4078570, "Unknown", 0)
addappid(4196060, 1, "Unknown")
setManifestid(4196060, "Unknown", 0)
addappid(4196070, 1, "Unknown")
setManifestid(4196070, "Unknown", 0)
addappid(4196080, 1, "Unknown")
setManifestid(4196080, "Unknown", 0)
addappid(4199610, 1, "Unknown")
setManifestid(4199610, "Unknown", 0)
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1687990's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:51 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(1687990)
addappid(1811830)
addappid(1687991,0,"3df2f7d2b4ef4305cd612cb2fb78a77477704e2ecac5d53a57d0e4d1eaeb1a82")
--setManifestid(1687991,"557916910394169077")
addappid(1687992,0,"c4ba53b88a16a4317b22aeab86db68307f6346261df6f39ae8561da68ed1fc48")
--setManifestid(1687992,"75144761534925339")
addappid(1811830,0,"c3b3f1bcc0ea3d44d016791ed8e878afec5d5549b5c7808e5c60341749a0fdc2")
--setManifestid(1811830,"3335688101434800504")
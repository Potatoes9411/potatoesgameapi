-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2830690's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:01:05 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 1
-- Total DLCs: 0
-- Blacklisted Depots: 11
--   Depot 2830506: Blacklisted
--   Depot 2830500: Blacklisted
--   Depot 2830508: Blacklisted
--   Depot 2830505: Blacklisted
--   Depot 2830507: Blacklisted
--   Depot 2830504: Blacklisted
--   Depot 2830503: Blacklisted
--   Depot 2830509: Blacklisted
--   Depot 2830502: Blacklisted
--   Depot 2830501: Blacklisted
--   Depot 2830031: Blacklisted

addappid(2830690)
addappid(2830691,0,"d0363971c0c569c7a2539638b3bb6fbc33c32ccc5f5298a4b60c53f67ea25b6a")
--setManifestid(2830691,"370019793075925980")
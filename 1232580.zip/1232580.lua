-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1232580's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:56:02 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 1232222: Blacklisted

addappid(1232580)
addappid(1608610)
addappid(2891150)
addappid(1232581,0,"32718d93ad2804ff032dfb35bdbcd1b786c02ed19a8e40fec6ead1248c34f692")
--setManifestid(1232581,"2096682189921063884")
addappid(1232583,0,"d745e38afb2ee29d553671803bcd54ec499f0e8d9d479d5d4377b38841c64c5a")
--setManifestid(1232583,"4544847764483553814")
addappid(1608610,0,"8cea821d5f219ab4ecf1cfaf02e7098d5c390ba6f1cba8c93350792cc19d5366")
--setManifestid(1608610,"3492343555234506526")
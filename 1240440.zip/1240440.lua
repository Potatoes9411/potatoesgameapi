-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1240440's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:56:03 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 26
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(1240440)
addappid(1708090)
addappid(1708091)
addappid(1708092)
addappid(1240441,0,"c9057fb7f913b73308cadca3c570080625c8fae45f6c74566a09dfa53c32955d")
--setManifestid(1240441,"2509191712656092244")
addappid(1240442,0,"243d9c5e3471cd043ee1b68cd8f90e554d9ab609db437f8d924308b9138ecf31")
--setManifestid(1240442,"3310217600695701879")
addappid(1240443,0,"13d292be5865d7885f18cb099d5bcb1b04686cda1506527b8d7981037f66aef3")
--setManifestid(1240443,"1961174997092173120")
addappid(1240444,0,"7c766c3a686dd5d78c495422079cc8b1182264ab5d20d17aa9f80078345a3cdb")
--setManifestid(1240444,"3787581302182680603")
addappid(1240445,0,"52c69d4eb4dc7c3449a0b8cfe338e139bef9bf1b43d4a0e6b5b0d2f9bdef9d28")
--setManifestid(1240445,"6212087839736214815")
addappid(1240446,0,"601def2df97fb3bbb9e042cb35cbe7f4ecacd0b72e874dfec0f6b8e4bbda18e2")
--setManifestid(1240446,"5961114131542256223")
addappid(1240447,0,"4e26fcbe95d2092ed6d62ee9f8d44ffd4b670867da475668eff83eed204d2ca1")
--setManifestid(1240447,"8536732866283005504")
addappid(1240448,0,"4085c3f1d38cddd7dfdc14271a323647e278fa0d148bb1ec76a1c20c9c80f36f")
--setManifestid(1240448,"7099774409191523370")
addappid(1240449,0,"a2ca5a0bc11e8e1e762847fbee7d7e42ef23a53eaebc37511e3b6ad82428287f")
--setManifestid(1240449,"363057356585956965")
addappid(1521610,0,"c992a878945cb00883e5aa4eafd2763236a07d40a16756b94d1991cfd0fbbf5c")
--setManifestid(1521610,"6475830760600214425")
addappid(1521611,0,"78b25a92d0f659f2f9fb9d74dd56720378bb542cba178c25028d3bcfe1ca48b2")
--setManifestid(1521611,"7393915373152469083")
addappid(1521612,0,"da8b25c75240b663d38dc78c908985d8610cae32268119e9b59900a42e593479")
--setManifestid(1521612,"6226236412227213094")
addappid(1521613,0,"1338a735e86e43fa8af54c6e46e15f29708c08d91f0b7565f084259e295decef")
--setManifestid(1521613,"2932603352733819859")
addappid(1521614,0,"b0ec0322409360c0929e2c42d477414e64ec6a20224621d842931a8563187e7b")
--setManifestid(1521614,"1484258721365003910")
addappid(1521615,0,"9a90eb853d305270c37d7955d146ff5fa366259a5fe900e223c6f7580da4c048")
--setManifestid(1521615,"5651415488847273110")
addappid(1521616,0,"82f6b18ca6681acb7a2427f2c0e1fe5d9232127d28f3da4e1deae2e1cc3a4bdf")
--setManifestid(1521616,"5104787929641177582")
addappid(1521617,0,"4ffc4e0da16998a077b985b44194ff28ae074bf075623f08e22193f490d080fe")
--setManifestid(1521617,"443174564544235007")
addappid(1521618,0,"0c24f8c80c757e2410b8bb471bc601c1eca6a905c7745b47bb8fe7c3716c0dc5")
--setManifestid(1521618,"7907859300157572659")
addappid(1521619,0,"dfe1c1a4d023d38b94b5395e8cc03c45ae48302cf7b7ba0d2299118a85cfb94c")
--setManifestid(1521619,"5318554684921636580")
addappid(1521620,0,"8e7ee867468c54daccf33444f7837397cd0b961563c68216e79053f7f944678a")
--setManifestid(1521620,"2496236242817095130")
addappid(1521621,0,"2c764216a68d7cdea6768ab9806971a7ea2cfe039a5ffb50cdd33a5dd96fdde5")
--setManifestid(1521621,"4425839573476823251")
addappid(1521622,0,"669c414852ee54ea00569920f9501d9dafe4afc48255999073212a05c93b141c")
--setManifestid(1521622,"3939133919175594196")
addappid(1521623,0,"e09b653715eefa5e0f1790855b54b047c294e4c0ce93e4c274709fa5503f7ebd")
--setManifestid(1521623,"3647146900337896843")
addappid(1708090,0,"36a49d974f8aae5465b880bbdc0fe5e221d314d88c1984ef9d24013be2acf178")
--setManifestid(1708090,"2946141885574616836")
addappid(1708091,0,"13689863bcd84ee19b33fe68d8b8f14ec4755230f04d108d19b9dc8d990a92ca")
--setManifestid(1708091,"6543739757680044463")
addappid(1708092,0,"e880614c9c86a278ef067573337c332da19d68c54babf0cf908dab55864cf3d4")
--setManifestid(1708092,"8153737427099341847")
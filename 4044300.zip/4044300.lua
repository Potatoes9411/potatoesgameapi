-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 4044300's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:53 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(4044300)
addappid(4044301,0,"de507173d66f44da1953712bfcb56360031ac3e7d157efa3dc25c5bb82958a11")
--setManifestid(4044301,"9171940051293122396")
addappid(4044302,0,"7CAFF29F6A545FE1ABC6FD160F6734760AE79A5E4B2A93BFC61652E50BCB64F9")
--setManifestid(4044302,"5788933138338369983")
addappid(4044303,0,"2F6B00752B86D647DA8211D7E57224F807BAE6023B6677B1E13B06135B0F5853")
--setManifestid(4044303,"3704278257735266502")
addappid(4044304,0,"AAB49B68585D13EB8DEBF0132264176F08973A93D88C1795ACDB1B75F791AF99")
--setManifestid(4044304,"1416362958557083366")
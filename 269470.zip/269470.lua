-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 269470's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:29 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 6
-- Blacklisted Depots: 0

addappid(269470)
addappid(229002)
--setManifestid(229002,"7260605429366465749")
addappid(229006)
--setManifestid(229006,"1784011429307107530")
addappid(269471,0,"1bd6287e8f509a1dfb81c9d954fdf93b4be11c6d7ff527097d2e2f5c2c859077")
--setManifestid(269471,"6493104805051685563")
addappid(269472,0,"e273c43f06e23e6129f64d055e40766dd172b5a069f222247ac69bc75cd960c5")
--setManifestid(269472,"5566710258777829395")
addappid(269473,0,"0ad72bc977d64723618b2619958713f70b561b63f85a20466bed2a20077ebc14")
--setManifestid(269473,"8029691312841847416")
addappid(269474,0,"be9758849e3bb1fd7a0b353bc0f814d1ede1a498940194798eb80fe195c51d54")
--setManifestid(269474,"7372805276800016656")
addappid(269481,0,"868b822e459debe7bb794eeb4d0d073ebbd89719a1dc084f3706466d8c9623db")
--setManifestid(269481,"3630275616349540958")
addappid(269483,0,"48fe990fba685dc0bb2eeaa2252143c971bb89536fce3ba9b8f3ac577992a498")
--setManifestid(269483,"3904909006949599344")
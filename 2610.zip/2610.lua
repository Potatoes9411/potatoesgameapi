-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2610's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:25 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(2610)
addappid(2611,0,"cd52840677ca6fc0ca0ff0dbb725803dd29bc5e0b8f9ecaed259ec7396f2d30e")
--setManifestid(2611,"1258713482754051281")
addappid(2612,0,"7ac3d19acb0ddb59b5656a76c304abf4acc876db74d1f08fb72a1f87e72da3c1")
--setManifestid(2612,"7428136853115268160")
addappid(2613,0,"0dad7435ea7de4a3083bf3a8d7f45e4da8f9665e97b6318a00a62b77e301db4e")
--setManifestid(2613,"6209332003847279713")
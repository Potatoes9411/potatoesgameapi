-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2507950's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:59:55 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 12
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 2507821: Blacklisted

addappid(2507950)
addappid(2918370)
addappid(2507951,0,"91450364d55cea454aaa08b61911d1029ff00e9490f0a9f59b155148a474d290")
--setManifestid(2507951,"6347859754265143376")
addappid(2507952,0,"0AB8D62B3BA4AFEED746ADE47A8095F550D7C6C82B1277AEB3953B5009E84F97")
--setManifestid(2507952,"1664752877451854218")
addappid(2918371,0,"DC8953D9A2BA66FDB7E5622A8C219C972A7B00979E2F5B07C1A8FCC4D36B7317")
--setManifestid(2918371,"507925464518717815")
addappid(2918372,0,"3fedb72202be223251d2273e7dd1f4a98bd1feb84bcd0043de3fd6a95bbc0e11")
--setManifestid(2918372,"3791310320994759843")
addappid(4107271,0,"f8b66f7ea012a90048427492a47c07439d7146996982014474ee74cbb7080851")
--setManifestid(4107271,"7496617677688265599")
addappid(4107291,0,"ef25135d1f89f6cc364506b01bfa2a67c44b6b7222ecf53492dda526644d1f4c")
--setManifestid(4107291,"7784650747102673975")
addappid(4107301,0,"7c98703fc72e0faafd9ea8f8929327b61314f803679c5f643e1e572de2fe9098")
--setManifestid(4107301,"463804847349342980")
addappid(4107341,0,"12572acd2c0f5626498ed0027943ea386542b7d4ca17c4910b02ba218a69d38c")
--setManifestid(4107341,"7608747186670164786")
addappid(4107351,0,"b44ab2ee1179f58822b38f3a204642760a94d3b7b57ee9242f91d05401057072")
--setManifestid(4107351,"151320725798773451")
addappid(4107361,0,"cba773d307445aed70979c0f85b6fba00df176adc152742d3e2b0b2af846628d")
--setManifestid(4107361,"2968846909786131853")
addappid(4107401,0,"1fba4d9ae37413e8b1ae09be81abeeb3d5181c5595c481e25fcb0ce3d89ced84")
--setManifestid(4107401,"1275435673109813087")
addappid(4215791,0,"2a961b80336f302077b89104a6e63884f47d3daa76eaa0f5e3637e12ba09bd0b")
--setManifestid(4215791,"8595741134958822398")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 545540's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 07:00:02 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(545540)
addappid(545542,0,"89ca12cff9e5d626e1e689f0fc02b9778a8b37e178fba6ca4b9166c9dc3b1f84")
--setManifestid(545542,"5168715164016610004")
addappid(545544,0,"48d4bc653255776cd900b79468bb09017950db95dbdc970a0c798d1866a2d214")
--setManifestid(545544,"8360475015627000341")
addappid(545545,0,"6c2cda9b75629504978f5bab332bb8e18c93c6f8b15e25da85ab6d3ae0fb31b7")
--setManifestid(545545,"2885655597010787462")
addappid(545548,0,"9468f096b1b960345b30f32c9117345fb0257d7a9f8aeca2ee4bc3ebae14a2d5")
--setManifestid(545548,"3205659368235698128")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2300320's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:58:55 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 34
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 2300841: Blacklisted

addappid(2300320)
addappid(2981100)
addappid(3453810)
addappid(2981090,0,"0651e56ae954c27ffee937a46ec72d5a6d9838157153e18713a5f5367b6655dd")
--setManifestid(2981090,"7847067090206129125")
addappid(2981110,0,"c8311e383c31827910b45fd0ab017594f10b8c6395251b28c6c4fa0d57a8e7be")
--setManifestid(2981110,"2426592928577282527")
addappid(3450870,0,"9a83c658cb248afaef38c4df9015a9c6e0bf9b2397e9dfff8dca12aa6e4d3a81")
--setManifestid(3450870,"8018742123442168696")
addappid(3453950,0,"467c83ead3c8b40f90c044575fc18c1cd49f0acdd23423219f7ab35f19e30b02")
--setManifestid(3453950,"6124778635013292")
addappid(3453960,0,"2316b4442225a84b1c071368fbca8259d035c27a00d6bd261001f6434429b8cc")
--setManifestid(3453960,"5556110324443214206")
addappid(3453970,0,"bda31b60d517b56988250720f32f8e205ae01b8e0137f6e0c65150a0d7ff4a02")
--setManifestid(3453970,"9107997170241092572")
addappid(3816190,0,"c4bb89ebe43f8f1e8d233156a2b7ded8c2696eb186afbdfdbe7a58b9c53e9f97")
--setManifestid(3816190,"1491330788882535021")
addappid(4054370,0,"c184b40eca33e8c19bd297e07790abb95aaf1420d694646707ca7bedbd8cd6a7")
--setManifestid(4054370,"2097302948663994711")
addappid(4348790,0,"057b03766cf1beaefd052d018f8e29d180a83a7ba2db94f80b1b327c8e87f36a")
--setManifestid(4348790,"7621124791274507943")
addappid(2300321,0,"e5e857b4939e3993f78ae1bfa1857aa4dca14c90680aec0e63f48565c885c2ae")
--setManifestid(2300321,"8486032555252581185")
addappid(2300322,0,"e60dffe1f9b3a6f6fb4475045e0d66ec6a40410ffb036ce2dd37fd88c3acd6a5")
--setManifestid(2300322,"7779113186443415832")
addappid(2300323,0,"3de49a7eee583d841ab3194df793f8db9fe186930c8623d2a864a81ff5586afd")
--setManifestid(2300323,"1550107122794757569")
addappid(2300324,0,"f8938589cbd4ca4f7c8031839fe15759ac1c8c79ef2eaef69e6a00241703a2c5")
--setManifestid(2300324,"7082434029875972807")
addappid(2300325,0,"f946e8f4ea8420aed7edd1f5918e81d77ce171e78ea11c54b7adeae8a4669a4d")
--setManifestid(2300325,"2519322278117707135")
addappid(2300326,0,"cca076ed972ab800d4c8c6efafe281be83d39290660fe3a2b27603c21151da6c")
--setManifestid(2300326,"2699845844463245190")
addappid(2300327,0,"639dd3cbaa8cbc16ccedb39098b2b8a039da4a992920ff2e368bc2c041b28cba")
--setManifestid(2300327,"8747416787258114339")
addappid(2300328,0,"c121e9f50b5801a92cc456d3211620c4d920f3a0e75686f6184cb10bb562d904")
--setManifestid(2300328,"4898221753086484171")
addappid(2300329,0,"f80f185138acffeef2e34fa3571b351e5551c4d705483aaabd9b5d15e74e75fb")
--setManifestid(2300329,"5932979496095422232")
addappid(2981091,0,"968fe6780cc09c4baeda840f0411a94b5f1bab38dfca0f36c89fbe2331c294a8")
--setManifestid(2981091,"5292817651936743538")
addappid(2981092,0,"e0288911696b43f3458119ec84de121e35abfe2d2322504ce777e37a018b4a33")
--setManifestid(2981092,"3986813650063916220")
addappid(2981093,0,"29d185a1ecc003c97c77f0e8b70151d2f4ce3499db9e54ca2e85cbe1b2ff9070")
--setManifestid(2981093,"934605271199172290")
addappid(2981094,0,"ea0932e50bea6317bc6a512361e03c2e454e9733c0a9a65a5290879eee89bf6b")
--setManifestid(2981094,"4467306760700940625")
addappid(2981095,0,"ade1eac77aba845dd5816f2573f47b7ac39f5599834dc69c3b71af8f59bee8ec")
--setManifestid(2981095,"8694346490421832324")
addappid(2981096,0,"863228b07a13e8d3eba1639ebaab3cc538e34672e7b3672c40197ffb6c896ba2")
--setManifestid(2981096,"8727505838908121317")
addappid(2981097,0,"1ced5c6691d6aa866ca70e4708a6617186dc447bc154699a8ec16682c9cf165f")
--setManifestid(2981097,"6937195163401650241")
addappid(2981098,0,"d1f521d8b6ae2b013a7e2a9f4c44766e025a4e0a6112ee90016c6f2968da9e24")
--setManifestid(2981098,"8829242856986735896")
addappid(2981099,0,"655b7d0f6e8e38251a8eeec6f60e4ed47d5ddc3a50b3cacb2faca871417c9dc0")
--setManifestid(2981099,"3980285498065046994")
addappid(2981101,0,"9f00d6bfe26a671b716b22bcfacf0ffa17e67b9960a7627a9c6d6a5448f93fd8")
--setManifestid(2981101,"6096155025109753201")
addappid(2981102,0,"9eb91152a6aa2d434131b3551ccd34e79cdcd87baa77972f930e2e49f2727c16")
--setManifestid(2981102,"6773764835871137388")
addappid(2981103,0,"9a3b1f5733c28c3ac4529ab6f6ae7c3c35639bd8adc5518066c1e9db0ac6a9d8")
--setManifestid(2981103,"2996502837207591963")
addappid(2981104,0,"ae85b8e8c5a5ed430feea1df6a23f3bccca41ee70b4b77592b6f6551c956be81")
--setManifestid(2981104,"8290737112462894023")
addappid(2981105,0,"41b3097f70f8b302773f6d473d438df683eba85bc6fedfca26e4b55f00388cec")
--setManifestid(2981105,"6806530335208221837")
addappid(2981106,0,"8f6f1b07d0ff2a282fbaa971eb841ec96e4cea021abb7fdbb8b788a0c2bdd556")
--setManifestid(2981106,"2141179524058091071")
addappid(2981107,0,"402e70f1a56080cfdac842c33ef75226c38fd20e3e390c6e67dcae0b01e28a95")
--setManifestid(2981107,"782481009953151439")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3125750's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:17 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 6
-- Blacklisted Depots: 0

addappid(3125750)
addappid(3273490)
addappid(3345380)
addappid(3345400)
addappid(3345410)
addappid(3345420)
addappid(3125751,0,"8e98d35380e0ac080fbc6342eca2d99a14165fb1f54e883ecf81a691c99c1ecf")
--setManifestid(3125751,"4526864796636492866")
addappid(3273490,0,"bd2ee0c4b65cfa695db6f47c24a2c7c2a508e1a1df69be2478180e3b138cb2af")
--setManifestid(3273490,"7279457516532429743")
addappid(3345380,0,"9a9b24b0fcbd745e892372f653dfe0b38e60db478743edb5bc9bf137727da8c2")
--setManifestid(3345380,"6956964429016939257")
addappid(3345400,0,"f5e90e13a7c91cfe19599118d404e9387ddfcfa8973453879a081cfb893887bb")
--setManifestid(3345400,"5846874651050349388")
addappid(3345410,0,"e74ecedeeefda54b1cd44c68e17598c1f7a182acfab6e56c6443d902c600a44b")
--setManifestid(3345410,"9211927886095506478")
addappid(3345420,0,"2200753bbc8b717820588bd1c244b34fb2b89d699f3645a2192b0ee7d71f6a0e")
--setManifestid(3345420,"248382308376934963")
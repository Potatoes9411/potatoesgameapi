-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2283860's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:58:52 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(2283860)
addappid(2283861,0,"1939ed123fcfef0123cad2c185c357130ba449d1962b1a3cac6786881b3176a3")
-- setManifestid(2283861,"7637008217430865563")
addappid(2283862,0,"76c4803dd40760a6b47ef30c10f46701714b76916a9d7fa8a5c2d27f769335fb")
-- setManifestid(2283862,"7084515268458789044")
addappid(2283863,0,"01d69dab83cfe5ca83624b2620f6a8c8e6502b288ca37d64223d81b2af60d6c5")
-- setManifestid(2283863,"8165514145115930039")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1709900's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:51 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(1709900)
addappid(2328120)
addappid(2986180)
addappid(1709901,0,"f1bdadbf552e261bf283a3d1caf24cdf293cea88deb9dc61d4f9a7ab13823306")
--setManifestid(1709901,"621921859370661859")
addappid(2328120,0,"490ef7ed04441f799c706e147115ef8e12ea9f06fba8ca129bbe175915c77875")
--setManifestid(2328120,"5894027965750074598")
addappid(2986180,0,"4c829b5761cb2c06f9b0b160cb1d29ba9fe73cfa1dc895ec5772bbb6e21d1ed7")
--setManifestid(2986180,"2143691415241522771")
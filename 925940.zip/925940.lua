-- Made by F1uxin, Discord ID:965053505901588521 | Discord Server (TGP | The Galaxy of Pirates): https://discord.gg/VfCxRsFyFe

-- If you're interested in distributing these files please dm me on discord (UserID:965053505901588521) 
-- (I don't care if you send them to a friend or to help someone, just if you add them in your bot or have them widely available then i would like to know.)

-- Socials: https://guns.lol/f1uxin

-- If you have any questions feel free to dm on discord (UserID:965053505901588521)


-- Main stuff to actually add the game, DLCs, & depots.
addappid(925940) -- Myst IV: Revelation
addappid(925941, 1, "963780b175bfcf863b98e849cb329b3446259736718957a950adacb50ea68bb7") -- Myst IV: Revelation Content Windows
setManifestid(925941, "8561123361488423937", 6984257668)
addappid(925942, 1, "0e07060ee85b093230618da9fe8a728208c5745b224013f9d8ba3ed2c34daf90") -- Myst IV: Revelation Content Mac
setManifestid(925942, "7262766438232236524", 8855376260)
addappid(925943, 1, "50cf5cd612e6018b8e5113aad84aea0a91b1ec2b943c5d723573a059e57396a4") -- Myst IV: Revelation Depot English
setManifestid(925943, "1739766542280417644", 527253723)
addappid(925944, 1, "50e842f54115fb91a9d63de6ff05181d48e9660bf7e7d7077c010393e533d0cb") -- Myst IV: Revelation Depot French
setManifestid(925944, "1055563181124081720", 524108068)
addappid(925945, 1, "91e0c585e8d27e9d1e29749872785ae0d038bd57cad284ac2cebfb89fa05cba8") -- Myst IV: Revelation Depot German
setManifestid(925945, "1049972908394119120", 528588383)
addappid(925946, 1, "683df55fea80f58af443d6f009e4d0d531fffc779909b21a1afeeaf6864659d2") -- Myst IV: Revelation Depot Italian
setManifestid(925946, "4802053662548668077", 530056888)
addappid(925947, 1, "d3b0ea553b52e17329a9bcfaab2496f44d7b8469e109db9f1b39a198cee8d149") -- Myst IV: Revelation Depot Spanish
setManifestid(925947, "5917204741293175361", 527483926)
addappid(925948, 1, "fd0a3ace2bbc13f04458a972ba5c372f3da72c6b74928ea4f6ca9db19ff6e5c9") -- Myst IV: Revelation Depot Dutch
setManifestid(925948, "5866908893095743513", 529031529)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
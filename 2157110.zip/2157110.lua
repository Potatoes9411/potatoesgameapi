-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2157110's Lua and Manifest Created by Potatoes9411
-- FUCK HITLER
-- Created: June 17, 2026 at 06:54:12 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 10
-- Blacklisted Depots: 2
--   Depot 2157831: Blacklisted
--   Depot 2157711: Blacklisted

addappid(2157110, 1, "Unknown")
addappid(2157111, 1, "22e0f43f0752cc32700a72fd164e119a1dd89455de526334172661ad38cb89f6")
setManifestid(2157111, "5218677512514470110", 0)
addappid(2157112, 1, "Unknown")
setManifestid(2157112, "Unknown", 0)
addappid(2157113, 1, "Unknown")
setManifestid(2157113, "Unknown", 0)
addappid(2157114, 1, "Unknown")
setManifestid(2157114, "Unknown", 0)
addappid(2157115, 1, "Unknown")
setManifestid(2157115, "Unknown", 0)
addappid(2157116, 1, "Unknown")
setManifestid(2157116, "Unknown", 0)
addappid(2157117, 1, "Unknown")
setManifestid(2157117, "Unknown", 0)
addappid(2157118, 1, "Unknown")
setManifestid(2157118, "Unknown", 0)
addappid(2157119, 1, "Unknown")
setManifestid(2157119, "Unknown", 0)
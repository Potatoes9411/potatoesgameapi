-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1279630's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:56:09 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(1279630) -- Vampire: The Masquerade - Shadows of New York
-- MAIN APP DEPOTS
addappid(1279631, 1, "647aeaae509b7b2774fe9aadb85a0f949e8a0782bb99d1b175f23d0aa4538d8d") -- Vampire: The Masquerade - Shadows of New York Windows
--setManifestid(1279631, "8160589885853593075", 3476779767)
addappid(1279632, 1, "200d866edf070bc1ba83649b142ff582955c2033f93527a38fb9aa4ee769fbba") -- Vampire: The Masquerade - Shadows of New York Mac
--setManifestid(1279632, "8424518390913282305", 3534481986)
addappid(1279633, 1, "b18b3305b9c2f0dffde161419bb823533e09ff345fbb6ed8a44274d638e0198a") -- Vampire: The Masquerade - Shadows of New York Linux
--setManifestid(1279633, "682664415050000019", 3397432559)
-- DLCS WITH DEDICATED DEPOTS
-- Vampire The Masquerade - Shadows of New York Artbook (AppID: 1405990)
addappid(1405990)
addappid(1405990, 1, "126fbb76bb1ecd80253e7ab18a9af9978595c9bb7dfc1b06b52a63838a82ee86") -- Vampire The Masquerade - Shadows of New York Artbook - Vampire: The Masquerade - Shadows of New York Artbook
--setManifestid(1405990, "8172490253821243778", 76931431)
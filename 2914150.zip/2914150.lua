-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2914150's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:01:23 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 2914120: Blacklisted

addappid(2914150)
addappid(4535490)
addappid(4535510)
addappid(4535520)
addappid(4535530)
addappid(4535540)
addappid(4593360)
addappid(4535570,0,"42c1266aeecdd79fa0701b6661f0dbb4271cc21cf24bdbcd8dce2a0308edacc7")
--setManifestid(4535570,"7019849430230487716")
addappid(2914151,0,"b1591193815ae73a16edda181a76e82de4c309d8390cd9845dc4d3234828cd4f")
--setManifestid(2914151,"1444907180442376902")
addappid(2914152,0,"895ab86b71bd36d16aa55f77398958dfd8d65887bb77a013ebb5510e959683db")
--setManifestid(2914152,"1760257574849926377")
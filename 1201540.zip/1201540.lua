-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1201540's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:55:46 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 5
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 1201701: Blacklisted

addappid(1201540)
addappid(1201540,0,"d83b48611442aa124ce266ec70c390cfb6455160ce0ac1a4632f3fab2522a52c")
addappid(2289820)
addappid(2308840)
addappid(2308841)
addappid(3039290)
addappid(3066170)
addappid(1201541,0,"05f46e5015acc33d5ddb5ed1e26f714626c81381f1b1a99ac114a6c9ca56af37")
--setManifestid(1201541,"5334745702896540112")
addappid(1201542,0,"77c151416b5ecca6177f179e0cbff1877cc0fed194017a4e29d9de807fbfa0fc")
--setManifestid(1201542,"917430348655459603")
addappid(2289820,0,"60d6725d2ba3a078ec0d750fe14de4f6fd763d6259e6ae16a5fd60a535d0c979")
--setManifestid(2289820,"626864412202302781")
addappid(3039290,0,"03c15506769c4c00a727f8b8cfb8b809f0f144c464a2afb81c24d3049fe026a0")
--setManifestid(3039290,"727208747133270857")
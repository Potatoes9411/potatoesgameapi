-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2776450's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:32 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 5
-- Blacklisted Depots: 0

addappid(2776450)
addappid(3396410)
addappid(3899280)
addappid(4241290)
addappid(2776451,0,"d344b9a8eb3356663a0ad386889d0a675acdf4e1b2e41aa43d220e0ef38e65a8")
--setManifestid(2776451,"3319818166423715322")
addappid(2776452,0,"5dfd6d9811882cd6da7723ad0578e41691fde46e771cf807bc1c88eb807aa733")
--setManifestid(2776452,"2237389136274809297")
addappid(3396410,0,"e9e432ec213897831b3a129e0921ca743bc67ae7432200c574ee4c88c5c0241b")
--setManifestid(3396410,"1827197711922415816")
addappid(3899280,0,"6bbe09eb7c5ab83c2c9712aacfa41a3256b1003f4b7f4ddf0e49b116726f188f")
--setManifestid(3899280,"3887469285390096070")
addappid(4241290,0,"022339d9fe8516374b77d940c224ee8b6f06a3d034ae3b0127b90c31c1a6b1bf")
--setManifestid(4241290,"4546803236679401623")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1201700's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:40 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(1201700)
addappid(3856440)
addappid(3856450)
addappid(4529310)
addappid(1201701,0,"84e0e2885f079a294d4a105b0731bf345a9a48091c564dacb6dd1abd28534ba7")
--setManifestid(1201701,"8529676689557253267")
addappid(3856440,0,"9d841dfc96a2b7b5faa9625767acb0907b87217d87f5ab10f1d5c5a9d2caa845")
--setManifestid(3856440,"4572045634603010603")
addappid(3856450,0,"b4bae956fa297f13f5c05b1bb6e64deeef2edbeec9e7244ebb1893a3e9f91b43")
--setManifestid(3856450,"3436142105388291070")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 920680's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 07:00:08 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(920680)
addappid(920680,0,"8c26e40d88c27b5a826b86b29dfcd4a6d7a4d52ee18bf63aefd0e29b9598d697")
addappid(920681,0,"c163ad7768dd12840f1ec6ec28f295db8c3da81e77ea14729ab1d5ffd3552be5")
--setManifestid(920681,"4848940236798564172")
addappid(920682,0,"abca3dcd364ae85063a10067dd0b2c1a09ac93229631df346d8a902ec9d30677")
--setManifestid(920682,"9063074076845614943")
addappid(920683,0,"4ae66f438a8924600a5a31f477eef728798830d6429092a5f18d7ecba0afd2fd")
--setManifestid(920683,"6103845711892771381")
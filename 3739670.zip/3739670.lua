-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3739670's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:45 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 5
-- Blacklisted Depots: 0

addappid(3739670)
addappid(3739670,0,"d89e11a47be2e599f3cd286f31e4cf6a1086f7fd2ae935a18dc4c4d9616f08e8")
addappid(3739671,0,"39e7e2d3e7df7d07f0f0d0e1acc8da86c92779a2147bba495ec9a97c46d027c2")
--setManifestid(3739671,"3992239048505019665")
addappid(3739673,0,"ac0c51d0d5542c3aa99c03c7baf5a8553f325130f46ebfeb76c83733d478e7af")
--setManifestid(3739673,"1126006755875710527")
addappid(3739674,0,"0d6148919a980e4ef0b5036cffa4ec27fa19ef56d3fbc07e1a8cc3754d3f1106")
--setManifestid(3739674,"5251484723507825762")
addappid(3739675,0,"a684725a20f87687627e18cc07d8a5adc1614a602ecbc73f6db629e8d24932c8")
--setManifestid(3739675,"5536416199040269134")
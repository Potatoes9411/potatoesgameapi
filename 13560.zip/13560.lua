-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 13560's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:56:20 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(13560)
addappid(13561,0,"c4917ce247a7821b6dd96bdb62827c3a557ce2d609cdc1acc32cb06154607203")
--setManifestid(13561,"5783583149290546482")
addappid(13562,0,"fee00fb2e12dbf0cb990c38ed2c0e3d4b352eb32d3bb6ceee571aa5d71c2a48d")
--setManifestid(13562,"734512394030004926")
addappid(13563,0,"5d340e6ebd2f46c1daa023a459b64f463b36322a698e222755aa5891f8d01cf9")
--setManifestid(13563,"893893204198510066")
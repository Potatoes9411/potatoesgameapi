-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2600's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:00:16 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 6
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(2600)
addappid(2601,0,"9d9a44e23934058d06dd944ade19bcb15c26d94c19606d9780c300b7590b3eea")
--setManifestid(2601,"7559191905314037026")
addappid(2602,0,"b927197ffca00e23bf86b5bff4a74aecafb78b6b60e661eb1b4461f4bdff6b20")
--setManifestid(2602,"5942701187426550593")
addappid(2603,0,"b6b13add8afbdac9895ceae218f9d35243e840fb8a89fd9ff5c11a6ab33e3036")
--setManifestid(2603,"1507670812436564491")
addappid(2604,0,"bd949f3356db457ac868d03ed76922436bf32e542357418b5e40c0cc73d3bbd5")
--setManifestid(2604,"215762182350885820")
addappid(2605,0,"d7952ec7dac0218ed27476b8c6fbfd6c5dba91b98a4dacd67b7dc0aa366218e0")
--setManifestid(2605,"4881312952147864264")
addappid(2606,0,"add69f117e5de56b103ac07247888237ececa8586b91d22a2aeae5ff25062827")
--setManifestid(2606,"7124292092481898282")
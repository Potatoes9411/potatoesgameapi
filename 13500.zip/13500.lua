-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 13500's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:56:19 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 6
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(13500)
addappid(13501,0,"1927562a78578b21ac7eb2a7ff202060c71870d222e56e4ff4a64eb19c153c85")
--setManifestid(13501,"5941015487132604059")
addappid(13502,0,"7426889bbf0b87c1c3c474ebb8f385eefdc881a1674c88eece8e00fbb7061411")
--setManifestid(13502,"8157882244001950031")
addappid(13503,0,"0fb111f81f635102b0391af2c60de348a5937b49dd08c5f2a95a87df40859d10")
--setManifestid(13503,"7860987930863725762")
addappid(13504,0,"bc2d9c3220d89b05dd7b7b02c242e4d2052beaa4222fd764010728a6dc748f12")
--setManifestid(13504,"5998576978956074664")
addappid(13505,0,"d27bd3aaf7ac1b585adc89df17f6c758eec4bebc2e9dd28ac2f829138cc0a1f0")
--setManifestid(13505,"4654705708861862723")
addappid(13506,0,"41cd6f351ef5ff9d7ce832cae75d0bb6d502f6f0101fcfe1c160b325e399baed")
--setManifestid(13506,"8925745147734781774")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 305620's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:43 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 10
-- Blacklisted Depots: 0

addappid(305620)
addappid(305620,0,"4b7d17191dfd796a730b8812292b2f9fd3d94f929e22af7b4a423c49b9315e6d")
addappid(2091330)
addappid(2095000)
addappid(305621,0,"2a658a052de2d030f6031e4aa4835b7b12b6646cb7142fde7f0216b06b9b3d85")
--setManifestid(305621,"134510413447246021")
addappid(305622,0,"973dd3d0c6c26bcaaabe742bd507c7d2711d69bbc1f1f5c21650629e93121eca")
--setManifestid(305622,"6712309255533235896")
addappid(305623,0,"9960f03341efd0f41aa06b12b9df8c42a592b5d1385f29a87531bec7c84709d0")
--setManifestid(305623,"8298338497795703841")
addappid(2091331,0,"ef5d6edc9a2c7de7d0c7e187558780cc5724114441d0e5cfab386460042b0975")
--setManifestid(2091331,"6765003824253611249")
addappid(2091332,0,"71e3e4cc7b1539fd8cf9f21f16c4c191d9927f04656a51ab06a8e03051a4b612")
--setManifestid(2091332,"3362128598970287538")
addappid(2091333,0,"9cdb1d532c9c2a2315abf67c51cc52d39725194ee239616f8cb38ad89e8a697a")
--setManifestid(2091333,"3436324744187098494")
addappid(2095001,0,"c38c5ee851fd90ea714284f31e69e3adde2d17018bef93398aba3cc91cb7548b")
--setManifestid(2095001,"194739429533185353")
addappid(2095002,0,"1eddf8e27184634ad945b1491c042d71f3a157e0df86f36dbe724ceb3333f8b6")
--setManifestid(2095002,"4498742367804787764")
addappid(2095003,0,"a223ad812dca8bccde9bc8fd91c2baa033dc7b67befff5ea497641a6c24b351f")
--setManifestid(2095003,"6967308045435750616")
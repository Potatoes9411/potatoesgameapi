-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 108710's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:55:31 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 18
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(108710)
addappid(108726)
addappid(108727)
addappid(268560)
addappid(108726,0,"9ebe0fd1145cd3cf70f5c9d95392770d67885c7cb51fd5902a658601b3107d39")
--setManifestid(108726,"1713738522381113009")
addappid(108727,0,"9064e7a115fcba0603259c3a8e068ae0cc09239e99a5b3ee8c2342c08a2e9d9a")
--setManifestid(108727,"2106058700918439926")
addappid(268560,0,"bcc6783bed2b3227d8faba2ead3f192aa0de1481bd1d538ac5297174517f4b86")
--setManifestid(268560,"6556411015070000727")
addappid(108711,0,"593019a366642176828b47ad2404c961328ad6d50cc1e105624421a5e55f51d7")
--setManifestid(108711,"3695390701422947803")
addappid(108712,0,"76ae76c8e8329d7e8fd7e54145770aefac0d18b853f25fb0ad76139305dc8b43")
--setManifestid(108712,"901025420359456534")
addappid(108714,0,"58a4933a1cb9cbfc1bfcf97f0e916c407d3ed63d8782afad70bd680451dc7eb4")
--setManifestid(108714,"7153105019757630594")
addappid(108715,0,"45ff646c49b2d4adde1631e0444cbc213214883c3357351c7256d3f8a3e732bc")
--setManifestid(108715,"8640327155719467447")
addappid(108716,0,"e3bd3cff0ce0749b5c6f782ebd84722d762b0a2fd31504b4e286c47eca1fc68d")
--setManifestid(108716,"9153511591353296967")
addappid(108717,0,"01fa7167dedeaebdd29cdf423312c0e49d95bfdd0a5b2cd42434f69f3627c505")
--setManifestid(108717,"7363828501531477407")
addappid(108718,0,"5cde1de1c5b9bb5accad062487b0fc79c912754fae85cde9bf05926166a50453")
--setManifestid(108718,"4467213347088643931")
addappid(108719,0,"9f0af0dd9b121c271670fbe72725d8b67a2bac55bed1ed6bc1e594a0e0271c3f")
--setManifestid(108719,"4247239336910949318")
addappid(108720,0,"3207988014785543a77a0bc7c4a8a9ae9dbbbdd8e2d08249628bce804a19205e")
--setManifestid(108720,"1973162837400191961")
addappid(108721,0,"ef3742e56ca3cccca4ed1d71d659ed801869915a36b5860dc4ae00d41fe5f1aa")
--setManifestid(108721,"1797539877300237257")
addappid(108722,0,"b2aa53bb1464a54d8498862bc2e5f59696b27f45b77708968dce407e4ddb7bf7")
--setManifestid(108722,"2433517643315622897")
addappid(108723,0,"63201370bc616dec6faa824600dabc95a39474dfe1a21040e6b258c415e7ca5a")
--setManifestid(108723,"5060317705156608793")
addappid(108724,0,"4fda34d7cdc50d35a4bd100a30a4eb23d47eeab4d13dea76441d57452a574b53")
--setManifestid(108724,"8702697917673304354")
addappid(108725,0,"29b03c21ab8aa192c9887499075d79cae9f5e441213f810e74040f13f7eb6650")
--setManifestid(108725,"1993621679641115397")
addappid(108728,0,"8e002cdf751131259924e7a28965bd025e71690c6328f9f8e57a08f869657239")
--setManifestid(108728,"8247444636893821162")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1117090's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:55:36 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 1117140: Blacklisted

addappid(1117090)
addappid(1117091,0,"3190f262974ed84e2a6b9699c7312cc61bd6ed67f3f6b18d650a6a5d3c661932")
--setManifestid(1117091,"3816518439972338028")
addappid(1117092,0,"506db883c795315b48f3ea36ab5de60ae74ea8baaa3d9d5ab79bcf238ae772e9")
--setManifestid(1117092,"4007599312739032979")
addappid(1117093,0,"737e0240fa9182cf2e33bd4cafb9f83121d90f2bccdf16b9e4db9b32686b1ca9")
--setManifestid(1117093,"7325201813144791451")
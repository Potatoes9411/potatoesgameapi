-- Made by F1uxin (UserID:965053505901588521), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/NmmpgnAgen)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:965053505901588521)
-- And if you have any questions feel free to dm on discord (UserID:965053505901588521)

-- Socials: https://guns.lol/f1uxin

-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)

-- Main stuff to add your game.
addappid(4364570) 
addappid(4364572, 1, "d6ea87db4a93279b94a0a8634c0d5ca9effc3b01879ec31788687aad29301288") 
setManifestid(4364572, "6905405700917460042", 166613704)
addappid(4364573, 1, "97c495a8c930be18f17c7c260b5edb7f5e262e536a5b37c6c5366a3a40a38b66") 
setManifestid(4364573, "7130495616942230615", 133058292)
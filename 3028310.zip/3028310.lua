-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3028310's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:42 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(3028310)
addappid(3453990)
addappid(3028311,0,"553fc1b6d6075185f02a8eba5821d274d56536e35f297a4733b779552e9b07e7")
--setManifestid(3028311,"2621667522736861196")
addappid(3028312,0,"2407db94a13666878dc806ac384b2af3741cce1a7499122097f3b1cd57b670e2")
--setManifestid(3028312,"925675605577395760")
addappid(3028313,0,"e86a6f9d2c72b0fb239862435f6b8c4c431acc28a8734d846ed3032fc6b5f4fe")
--setManifestid(3028313,"4757693445840776990")
addappid(3453990,0,"6b5ee20b58e6268ecbdc302b151f75c70818bac9adeac5b600680781c73afed6")
--setManifestid(3453990,"3511222665114790489")
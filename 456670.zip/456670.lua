-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 456670's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 07:00:00 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 5
-- Blacklisted Depots: 0

addappid(456670)
addappid(456670,0,"86a624cbd30489319ee7bd4a496c1474575e4d04e192f93d355db015c009ac5b")
addappid(862450)
addappid(945450)
addappid(969730)
addappid(456671,0,"bb27c3e9325bdfccdc1a9ef3e69b3c8db5089585fdc5d9de6d9015ee35f194da")
--setManifestid(456671,"8561667146405872946")
addappid(456672,0,"53b29a41370902161c587ed9a515eab2743e966669fee913fa9a7d8b3962fa5d")
--setManifestid(456672,"630757303952783695")
addappid(456673,0,"6ebcbc1fd1e26d56c45a808b1679152f45bc0d75097118730f5837b117b059c4")
--setManifestid(456673,"205607834967817334")
addappid(748680,0,"3892f039b194c55244529fdbb9c706866c73730d863a05c0f8f33123ba586266")
--setManifestid(748680,"2448048581490451121")
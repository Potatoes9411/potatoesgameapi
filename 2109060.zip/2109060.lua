-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2109060's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:55 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 1
-- Total DLCs: 0
-- Blacklisted Depots: 20
--   Depot 2109309: Blacklisted
--   Depot 2109307: Blacklisted
--   Depot 2109304: Blacklisted
--   Depot 2109317: Blacklisted
--   Depot 2109314: Blacklisted
--   Depot 2109305: Blacklisted
--   Depot 2109313: Blacklisted
--   Depot 2109310: Blacklisted
--   Depot 2109312: Blacklisted
--   Depot 210935: Blacklisted
--   Depot 2109308: Blacklisted
--   Depot 2109306: Blacklisted
--   Depot 2109316: Blacklisted
--   Depot 2109311: Blacklisted
--   Depot 2109341: Blacklisted
--   Depot 2109315: Blacklisted
--   Depot 2109300: Blacklisted
--   Depot 2109301: Blacklisted
--   Depot 2109303: Blacklisted
--   Depot 2109271: Blacklisted

addappid(2109060)
addappid(2109061,0,"17fcaa86b0ec780c27db8f8c036f000a5d5f1177c063e6fb0dd6d81d9795a0a8")
--setManifestid(2109061,"4852832528689717413")
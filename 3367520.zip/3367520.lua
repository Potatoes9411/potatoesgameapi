-- Made by F1uxin, Discord ID:965053505901588521 | Discord Server (TGP | The Galaxy of Pirates): https://discord.gg/VfCxRsFyFe

-- If you're interested in distributing these files please dm me on discord (UserID:965053505901588521) 
-- (I don't care if you send them to a friend or to help someone, just if you add them in your bot or have them widely available then i would like to know.)

-- Socials: https://guns.lol/f1uxin

-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid", save the file, then add the lua file, (i think you can add the manifests too but I would just add the lua file to ensure it works).

-- If you have any questions feel free to dm on discord (UserID:965053505901588521)


-- Main stuff to actually add the game, DLCs, & depots.
addappid(3367520, 1, "c12f6c21d8511a6cdeaae391265c1b9c74b57d7cd2ddb218e4bcb0ad4a82d52b") -- Wrath and Retribution
addappid(3367522, 1, "00cbd5580c90ba4bee812f5b4de9f697f3d96d9cda5a7b01504e8747b07aaae1") -- Depot 3367522
setManifestid(3367522, "6226718056540850905", 5992756430)
addappid(3367523, 1, "242d379d9c076dfe341783a238ad94342717ece92b1daf1eb111f5dc801eea33") -- Depot 3367523
setManifestid(3367523, "9097911551403191967", 6091736635)
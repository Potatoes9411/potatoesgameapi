-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3472040's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:31 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 1
--   Depot 3472101: Blacklisted

addappid(3472040)
addappid(3657560)
addappid(3657590)
addappid(3657600)
addappid(3657610)
addappid(3657620)
addappid(3657640)
addappid(3657650)
addappid(3657660)
addappid(3657670)
addappid(3657680)
addappid(3657690)
addappid(3657700)
addappid(3657710)
addappid(3657750)
addappid(3657760)
addappid(3657770)
addappid(3657780)
addappid(3657790)
addappid(3657800)
addappid(3657810)
addappid(3657820)
addappid(3657840)
addappid(3657850)
addappid(3657860)
addappid(3657870)
addappid(3657880)
addappid(3657890)
addappid(3657900)
addappid(3657910)
addappid(3825290)
addappid(3472041,0,"98720ddedf5fb5a37faf70ca90602a9949e727a7f7b6b9171ecc2764ee2d3b21")
--setManifestid(3472041,"1925123203326264577")
addappid(3472042,0,"34db1ecbd759eab0b3e63e7304bc8fe901b1ca351a3d453affb865d97c5e62be")
--setManifestid(3472042,"5079480980657798487")
addappid(3472043,0,"54228c22842f9dce94c4087041d2cf97e9f00130877da328bf5c4ebb351c7fe0")
--setManifestid(3472043,"2777645125693417938")
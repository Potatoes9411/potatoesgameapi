-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 252330's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:21 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 3
--   Depot 2523632: Blacklisted
--   Depot 2523633: Blacklisted
--   Depot 2523631: Blacklisted

addappid(252330)
addappid(324720)
addappid(324720,0,"68b676b8e2acb3037d54da8df98b19b42f1d199f7c4f77533b69685f2b194968")
--setManifestid(324720,"643807341307717112")
addappid(252331,0,"e5560ed6dd390ae0d9f6871ca9c1876e16ad21133a7b86d6a7122b0fefa85ffd")
--setManifestid(252331,"866185040561999353")
addappid(252333,0,"72f4636af73f4fe564875b914f96d4e9901a8af683c3288c7499bbd7f9de61b6")
--setManifestid(252333,"3269406983956120028")
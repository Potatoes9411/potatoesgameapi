-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2950120's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:01:32 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 1
-- Total DLCs: 0
-- Blacklisted Depots: 45
--   Depot 295020: Blacklisted
--   Depot 295071: Blacklisted
--   Depot 295075: Blacklisted
--   Depot 295090: Blacklisted
--   Depot 295004: Blacklisted
--   Depot 295054: Blacklisted
--   Depot 295024: Blacklisted
--   Depot 295061: Blacklisted
--   Depot 295052: Blacklisted
--   Depot 295035: Blacklisted
--   Depot 295003: Blacklisted
--   Depot 295078: Blacklisted
--   Depot 295092: Blacklisted
--   Depot 295057: Blacklisted
--   Depot 295002: Blacklisted
--   Depot 295059: Blacklisted
--   Depot 295088: Blacklisted
--   Depot 295084: Blacklisted
--   Depot 295001: Blacklisted
--   Depot 295036: Blacklisted
--   Depot 295037: Blacklisted
--   Depot 295070: Blacklisted
--   Depot 295058: Blacklisted
--   Depot 295028: Blacklisted
--   Depot 295051: Blacklisted
--   Depot 295080: Blacklisted
--   Depot 295053: Blacklisted
--   Depot 295087: Blacklisted
--   Depot 295079: Blacklisted
--   Depot 295091: Blacklisted
--   Depot 295060: Blacklisted
--   Depot 295065: Blacklisted
--   Depot 295039: Blacklisted
--   Depot 295066: Blacklisted
--   Depot 295072: Blacklisted
--   Depot 295074: Blacklisted
--   Depot 295083: Blacklisted
--   Depot 295000: Blacklisted
--   Depot 295055: Blacklisted
--   Depot 295038: Blacklisted
--   Depot 295089: Blacklisted
--   Depot 295067: Blacklisted
--   Depot 295082: Blacklisted
--   Depot 295076: Blacklisted
--   Depot 295063: Blacklisted

addappid(2950120)
addappid(2950121,0,"1d3e2aaba5c7c3ea0b4a2d986a15a83146264fedf57e114bb7aebe232ba4ae6b")
-- setManifestid(2950121,"6728294959634295530")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1639080's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:56:49 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 1639431: Blacklisted

addappid(1639080)
addappid(1639081,0,"bcd3da063c1d570ea26c3100e5cfb754972c13e4b2a5a9f5b1c5b44b2b7d4b71")
--setManifestid(1639081,"597870700091888376")
addappid(1639083,0,"6e337aaad4d09643b639a7a475462aa5af07237cc303b89ba035f00a82c90b72")
--setManifestid(1639083,"8507457326953071193")
addappid(1639084,0,"717bcd1860e2cbbeb0ceba1839843d88100addfe1f61ddd52ab76fcae2bc4857")
--setManifestid(1639084,"5979334443274680492")
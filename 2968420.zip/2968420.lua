-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2968420's Lua and Manifest Created by Potatoes9411
-- PowerWash Simulator 2
-- Created: May 16, 2026 at 04:46:00 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 12
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(2968420, 1, "Unknown")
addappid(2968421, 1, "Unknown")
setManifestid(2968421, "Unknown", 0)
addappid(2968422, 1, "Unknown")
setManifestid(2968422, "5909065605077659426", 0)
addappid(2968423, 1, "Unknown")
setManifestid(2968423, "Unknown", 0)
addappid(2968424, 1, "Unknown")
setManifestid(2968424, "Unknown", 0)
addappid(2968425, 1, "Unknown")
setManifestid(2968425, "Unknown", 0)
addappid(2968426, 1, "Unknown")
setManifestid(2968426, "Unknown", 0)
addappid(2968427, 1, "Unknown")
setManifestid(2968427, "Unknown", 0)
addappid(2968428, 1, "Unknown")
setManifestid(2968428, "Unknown", 0)
addappid(2968429, 1, "Unknown")
setManifestid(2968429, "Unknown", 0)
addappid(4173830, 1, "Unknown")
setManifestid(4173830, "6742564778197930674", 0)
addappid(4229450, 1, "Unknown")
setManifestid(4229450, "Unknown", 0)
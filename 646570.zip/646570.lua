-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 646570's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 07:00:04 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 6
-- Blacklisted Depots: 0

addappid(646570)
addappid(646570,0,"4794cf193a25b70a28f151dc8f05e4e92fa57074d42afc4749b59dd40ae56508")
addappid(646571,0,"af36e1914da16f3e4556bedf7e46a76646b670c91bb6e1d3cca380e16ceb2df6")
--setManifestid(646571,"9072802409324604124")
addappid(646572,0,"d46524b47e7a9384e6b575394a6e96940634c8db3f58e829182eb486ca60e425")
--setManifestid(646572,"2910015420030023273")
addappid(646573,0,"7b0997618ad03031136f9caa6811f5d2c08ee7e0ac4b9c745675f12fd0354ee4")
--setManifestid(646573,"5221386008033040636")
addappid(646574,0,"85867004baa33349870d65ae84baac02f1a0e0280462a7b6f41912a30e008955")
--setManifestid(646574,"6089130681980710352")
addappid(877621,0,"9aebfbce314584af6e967104be1d5060284feca4baef886010adc9c4a983b4fc")
--setManifestid(877621,"1616206291221819177")
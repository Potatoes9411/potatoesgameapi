-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 312670's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:17 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 21
-- Blacklisted Depots: 0

addappid(312670)
addappid(826080)
addappid(826081)
addappid(826082)
addappid(826083)
addappid(826084)
addappid(826085)
addappid(826086)
addappid(826087)
addappid(826088)
addappid(910560)
addappid(920960)
addappid(826083,0,"5836965c2ddaf41372fa8c5926504699065bce94e97b2cd00768039afd3f6d67")
--setManifestid(826083,"4034826216629893668")
addappid(826085,0,"129537aeb0c7ee6b6201b45ce5f34c8d2bd7087a5df110a44085d1021aff523a")
--setManifestid(826085,"5909233017413341135")
addappid(826087,0,"d9d3bbd47af28c2e5504c28252b5fde9c67840a09f75c0b06116bd08e92ddffe")
--setManifestid(826087,"1276871526972175210")
addappid(312671,0,"79ce5b96915f30620a091e67fbb954d264d588c45c87d3ce12c3fad073a243dd")
--setManifestid(312671,"6384116069032795441")
addappid(312672,0,"669f39b8231f10c99840f08d84e9d0876bc05739e9ee16f96bc98eaa6f0f3ba6")
--setManifestid(312672,"5179276132694182298")
addappid(312673,0,"cd058df2b6efda2074416afc9ebd675ecb73361012745d4f6a295e4a0d6caa19")
--setManifestid(312673,"5175632726159802832")
addappid(312674,0,"03eb40e5db023c2b18dc0dc2f185b853e8b0162e1240b6a4cc6a761873f284a8")
--setManifestid(312674,"1045730485590701379")
addappid(312675,0,"71aa4ed1b66fc04aa63cb8ee1f541b96332b46e665cc77e676d828f269f7d2e3")
--setManifestid(312675,"6434654279715062752")
addappid(312676,0,"0e5d5a2d0e9807b8edcb1a00b93fbec99f2ac58a6954d739c6326cdfa4893ab0")
--setManifestid(312676,"8664982138400399131")
addappid(312677,0,"3566e0d099d0d952df8809fcf1768dc233db84f9aedc5173672cb4b96f0e5009")
--setManifestid(312677,"2511699933593818932")
addappid(312678,0,"b330415a245eba5edd1552d870a33768276da6b60ac393fa094425f46e3b7e14")
--setManifestid(312678,"7239270272355280159")
addappid(312679,0,"474f491b58a41fbe5f8002d7dc9dba22f37d83d9950aa36566d3d9e7b1ed1b3f")
--setManifestid(312679,"4498634764385291286")
addappid(826089,0,"11d19974140ba77daee1c02019beeb4b1060c76c22b588edcd8cbdcf6ff14039")
--setManifestid(826089,"458616485806171809")
addappid(903890,0,"a936bd8e28cd0b60a5a53df7b16fe44cb71a58fc7ccc183abcae2291c2dbff1b")
--setManifestid(903890,"4192292735721304608")
addappid(903891,0,"9e0e738cbdd560c69b27bba3db34a57eaa8329d7246f0dfe25c122a7aa49dccc")
--setManifestid(903891,"4817289828532266177")
addappid(903892,0,"590b9a1cef77beaf6ffaebeda9385db81df0cc66322ace890cd06e376b2e737d")
--setManifestid(903892,"6594183272760221033")
addappid(903893,0,"0e4010b0e9de100cb093c5bfd7ac186487dadb2dbff5ad88fb306f15e1acde3d")
--setManifestid(903893,"3330333222147203167")
addappid(903894,0,"1b394a60948aec046ca2c08673162fa496069d86ad1138c488997cd9c8eb1855")
--setManifestid(903894,"4006597583536618838")
addappid(903895,0,"93d49d0a1f3cbb21509d23b7fc58387f500477603b338d31cd85a358bf667cbf")
--setManifestid(903895,"7771789655402343549")
addappid(903896,0,"4722fb00994d49a083e11a7d275146943c725e6a3ce98aef11dba5ffce73fdf6")
--setManifestid(903896,"5779103003841739764")
addappid(903897,0,"442d7bf552d98a10f61ed9f4b9e57fe1ce862a1683d897db669ef63ca2f3ce88")
--setManifestid(903897,"5900821032968014150")
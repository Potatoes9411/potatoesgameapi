-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3760160's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:45 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(3760160)
addappid(3760162,0,"a9acbc794e477b782c065f10cc41b9e2a6ce5c95d738092c49d9694b1218a318")
--setManifestid(3760162,"3961063197394146657")
addappid(3760163,0,"e01ea3436b00ffd205aa470f3e22ed9ef3f440f5ab96a9aeb26d3894b4a1e4b5")
--setManifestid(3760163,"8320322453560550091")
addappid(3760164,0,"4f4fb745dd9ec7653f0002973957a14e62243f5553f597f13724ba1dd0a06afd")
--setManifestid(3760164,"6003790031119234525")
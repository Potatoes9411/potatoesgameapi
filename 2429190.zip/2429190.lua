-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2429190's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:59:34 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 2
-- Total DLCs: 0
-- Blacklisted Depots: 5
--   Depot 2429861: Blacklisted
--   Depot 2429241: Blacklisted
--   Depot 2429862: Blacklisted
--   Depot 2429863: Blacklisted
--   Depot 2429051: Blacklisted

addappid(2429190)
addappid(3544420)
addappid(2429191,0,"795c6e2f938e195ef9d62a34c064f1df89b670d9d7c101d9680d270950684e80")
--setManifestid(2429191,"4724013166920089438")
addappid(3544420,0,"3065376e6093078763c1f0d8844e0466a9fa1a1cf4d876dd2ec96657c88e9107")
--setManifestid(3544420,"5134086322696834747")
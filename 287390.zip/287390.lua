-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 287390's Lua and Manifest Created by Potatoes9411
-- Metro: Last Light Redux
-- Created: June 17, 2026 at 06:53:50 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 10
-- Blacklisted Depots: 10
--   Depot 287379: Blacklisted
--   Depot 287375: Blacklisted
--   Depot 287378: Blacklisted
--   Depot 2873661: Blacklisted
--   Depot 287376: Blacklisted
--   Depot 287374: Blacklisted
--   Depot 287373: Blacklisted
--   Depot 287377: Blacklisted
--   Depot 2873662: Blacklisted
--   Depot 287372: Blacklisted

addappid(287390, 1, "Unknown")
addappid(287391, 1, "b83248490dbb4df7788d5976584e6829597922e10fb4a9ab537e4da04c52b61b")
setManifestid(287391, "5751786806703515364", 0)
addappid(287392, 1, "b31b8b47d359f387ffb0f435de1b127ab2a3dfcfd16304b1d18efff394f3c7f5")
setManifestid(287392, "2801661353323416159", 0)
addappid(287393, 1, "Unknown")
setManifestid(287393, "Unknown", 0)
addappid(287394, 1, "Unknown")
setManifestid(287394, "Unknown", 0)
addappid(287395, 1, "Unknown")
setManifestid(287395, "Unknown", 0)
addappid(287396, 1, "Unknown")
setManifestid(287396, "Unknown", 0)
addappid(287397, 1, "Unknown")
setManifestid(287397, "Unknown", 0)
addappid(287398, 1, "Unknown")
setManifestid(287398, "Unknown", 0)
addappid(287399, 1, "Unknown")
setManifestid(287399, "Unknown", 0)
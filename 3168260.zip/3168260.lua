-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3168260's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:19 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 2
-- Blacklisted Depots: 0

addappid(3168260)
addappid(3282660)
addappid(3363660)
addappid(3557410)
addappid(3168261,0,"749bf7e07a235e19744c49d9e52c28077f3b903fa05cd3ca4f42f5dd1f949448")
--setManifestid(3168261,"6643920076439977773")
addappid(3363660,0,"55b793da8c0f3c1924b44589a6ba46aa73793e0de3a39afce32ea5fac4de9c4d")
--setManifestid(3363660,"9113216547409956970")
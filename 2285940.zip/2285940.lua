-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2285940's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:58:53 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 2
--   Depot 228580: Blacklisted
--   Depot 2285151: Blacklisted

addappid(2285940)
addappid(2285942,0,"ac0883ea64c687445fb1b7de9b83d174ed78d2542886907bd59362adba8c033a")
--setManifestid(2285942,"78434514733552952")
addappid(2285943,0,"abb61194789a3e4ababbc8a6cdeb91987b70e78555966c55c4eaf53668be6a80")
--setManifestid(2285943,"9159941876223055260")
addappid(2285944,0,"2b7c08b7caddb183a05442c3ffc9fb316cd1d942013c02327b5b7126842c7172")
--setManifestid(2285944,"2638925295339712160")
-- Made by F1uxin (UserID:965053505901588521), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/NmmpgnAgen)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:965053505901588521)
-- And if you have any questions feel free to dm on discord (UserID:965053505901588521)

-- Socials: https://guns.lol/f1uxin

-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid", save the file, then add the lua file (i think you can add the manifests too but I would just add the lua file to ensure it works).

-- Main stuff to add your game.
addappid(3949040, 1, "4af18553dbd752cd4d8084f32b7cdb37d59b1cc4d946360519d03546911b7e9c") -- RV There Yet?
addappid(3949041, 1, "98435e5f712a11c88e455130e718254b2745a33f7443b2034d634f54af0da031") -- Depot 3949041
setManifestid(3949041, "6388475935469519170", 2222971680)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
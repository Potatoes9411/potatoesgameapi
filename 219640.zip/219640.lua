-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 219640's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:04 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 19
-- Blacklisted Depots: 0

addappid(219640)
addappid(219970)
addappid(222360)
addappid(241280,0,"c5d85aec8e3ae2284c28c7e38023f971799f93a971e5e0de89be7dac548c1f98")
--setManifestid(241280,"880170471970950644")
addappid(332240,0,"55a7ac77bd6858d232bf772eb8405d2a2c7e2c8733516ac9a5996978173fb9d5")
--setManifestid(332240,"6691372111344943121")
addappid(219641,0,"5e4199fb27641aac8d432350147632f91727cedcedfab11742d974c76bf126cf")
--setManifestid(219641,"5420751348196476206")
addappid(219642,0,"00886fd9433cfb0ca1941a46a99e71811cf3bae7900d1fdc9f247de4949aefee")
--setManifestid(219642,"5498109063579544861")
addappid(219643,0,"128e024b1372f224b5bbef6d43baef829ffce2bf73fe9e896b728be3e48d1864")
--setManifestid(219643,"3415605889317653749")
addappid(219644,0,"4e7d2025681b5438e76d63ac4435f3e82119c83c0f31f34a62f9e43a134bab37")
--setManifestid(219644,"1587238564289828773")
addappid(219645,0,"70f8a2cf8ec0d99d1b13e1323e62f9e3cdb5a02aa5ad2a0d8c83382bd941d64d")
--setManifestid(219645,"8356898321895091700")
addappid(219646,0,"53be80f02f5acf929a9c9b2ccc9081f3a84478158c7877c98c28da70274e79b0")
--setManifestid(219646,"2027569603224592954")
addappid(219647,0,"659b1acc6aba9aaee051d654680c084c42c4abaf25344253c8b156da19c1788a")
--setManifestid(219647,"821628290314199241")
addappid(219648,0,"f7b995e91850a5b94bcdeaca070fdb400f2966e0d86ba6489095c6ce39219eed")
--setManifestid(219648,"6495673810377795438")
addappid(219649,0,"205492797b8a4f4f470385bd8c5567ea5ff59463b2d4d919d54cbbab60e16339")
--setManifestid(219649,"363373769149503502")
addappid(219650,0,"bbe5626d40b2f866e26160d36ca3832c316f985eb7fa3861649710d7a72b7afa")
--setManifestid(219650,"5352351775221351856")
addappid(219651,0,"0fde2b80a76fe33a5fba3df963fbfd2c68498a8a17b5416542863fc60693f86d")
--setManifestid(219651,"1890196345633816391")
addappid(219652,0,"88a70c12778f6a7c4a8978a98187c2e3d4532c754a520dfe83c4ca24f55fab1e")
--setManifestid(219652,"7618325354729702671")
addappid(219653,0,"539cea91c24887e861094986de79a771969c335075676f6edd1c685a33424e97")
--setManifestid(219653,"2719510494229397316")
addappid(219654,0,"7f7f4fa4682e804873376ac9056369890586618b70498323e02e3b13bb3a2a03")
--setManifestid(219654,"2896157429406130252")
addappid(219655,0,"94774369dd72f96f17e636a25608714e4517debf9ee5d5cefd7bef4cdbbae96b")
--setManifestid(219655,"569965421698297382")
addappid(241281,0,"52995c3ec6e4a246f21fe4595c02ed89f27a0cddec7ddf4b610500aefbd7fe3c")
--setManifestid(241281,"9010872612406699644")
addappid(241282,0,"f96b4f2053ca50f2fce995357eeb0806a30c02b8669a86054e5e1bbb24a034a2")
--setManifestid(241282,"7683327107744007225")
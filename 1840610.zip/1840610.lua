-- Made by F1uxin, Discord ID:965053505901588521 | Discord Server (TGP | The Galaxy of Pirates): https://discord.gg/VfCxRsFyFe

-- If you're interested in distributing these files please dm me on discord (UserID:965053505901588521) 
-- (I don't care if you send them to a friend or to help someone, just if you add them in your bot or have them widely available then i would like to know.)

-- Socials: https://guns.lol/f1uxin

-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid", save the file, then add the lua file, (i think you can add the manifests too but I would just add the lua file to ensure it works).

-- If you have any questions feel free to dm on discord (UserID:965053505901588521)


-- Main stuff to actually add the game, DLCs, & depots.
addappid(1840610) -- Apocalyptic Vibes
addappid(1840611, 1, "33101ad41def159019c7fe11f3ef701889ca17731ab751b3eb03801c6ed68e2f") -- Depot 1840611
setManifestid(1840611, "9113331197143659824", 488303490)
addappid(1840612, 1, "0d89b87a696618ec71169d8f138865263bad5e0184af04a4520459384b18db36") -- Depot 1840612
setManifestid(1840612, "8582496449363050134", 488307107)
addappid(1840613, 1, "c446c1e54ccb3dbfc0ac49d5551851b7e7481bd145aca6e1df96ccfbc9abc09a") -- Depot 1840613
setManifestid(1840613, "2459093514286297872", 497552600)
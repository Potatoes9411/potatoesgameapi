-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2852190's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:35 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 22
-- Blacklisted Depots: 1
--   Depot 2852771: Blacklisted

addappid(2852190)
addappid(3581270,0,"ef13f858536aa4b5c54307a638e5efb7764ab9763ce513f0893d9d752cf458ea")
--setManifestid(3581270,"8458212944527962292")
addappid(3581280,0,"585336c8945a87126b16997b0323567b357fbbb3cf529cd362fa6ec10f93329d")
--setManifestid(3581280,"7569748194585989011")
addappid(3581290,0,"94d76ae0d0ff4533fc1db50e587a91c84454342672882ed4849f773615336cd6")
--setManifestid(3581290,"2093297960475433885")
addappid(3581300,0,"0928f3f1790516b082ca620d36abae082684c31f0073341bca492de242831a09")
--setManifestid(3581300,"8952166521260427532")
addappid(3581310,0,"678544f31185ca208900fc3b509c2b0f0db2f9383ffb3a408cc5b01ff33828e3")
--setManifestid(3581310,"6376214278045416999")
addappid(3581320,0,"72b08e75337e0436b49187778e9d57c98b43b6944a1b6731d50fcf54018851e0")
--setManifestid(3581320,"3127807661445653310")
addappid(3581330,0,"5133aff38832e81fbb44ddbcf1be7bed1a60f2bc3512e81cd3cf9d6809be42fc")
--setManifestid(3581330,"240227128175926447")
addappid(3581340,0,"28d189a8b1dcf05fe55df9c24f2026603b5b7ce3a851764f9654cd3f9048cb68")
--setManifestid(3581340,"4135893026995074115")
addappid(3581380,0,"2de77f7d0978c2524258337ea4eb8837adc735aef087362b12425e26fc06956f")
--setManifestid(3581380,"4887326740324044471")
addappid(3581390,0,"52ca7186e556b209f821b8df5252d70e4e3f54813b6e68841688e269d9f24255")
--setManifestid(3581390,"2728666657550847926")
addappid(3581400,0,"0656897589842d8b5f43294dbc6cf1b3322f474f0cd0f44bd15b3b2d8764f8cf")
--setManifestid(3581400,"1463607991440957207")
addappid(3581410,0,"ddff775d6666c34298b5adb830451180d8c76c47805551cac13d84d1e0de82b1")
--setManifestid(3581410,"2909396534256144995")
addappid(3581420,0,"7f3529d148dea90208308cc087a305b65934fff1e9c8f904d351a9402a353aff")
--setManifestid(3581420,"5379677702933453096")
addappid(3581430,0,"15a47d2f5a349aa24e600074429047313e185e288e5399157223d27bb3f97b1b")
--setManifestid(3581430,"1977062647901345030")
addappid(3581440,0,"f03ec354e423bfaece6ea9f22263abcc5c1afb97fa317f3794989b3f82d6443b")
--setManifestid(3581440,"451376771089979740")
addappid(3581450,0,"d45246faa11048ff03056a420f73ff4f80b9ca1dd61a4a77d36b4cd7f53cc51d")
--setManifestid(3581450,"1506988313793986765")
addappid(3581460,0,"955f11da865a79a14ed09d05caac901334031a7f994cc98bff1bb3b09cb64198")
--setManifestid(3581460,"8124295821573494354")
addappid(3581470,0,"36d4431ea0b56006c4cef362163e584d212331c31721591efefb66458a208d16")
--setManifestid(3581470,"2640357821360084225")
addappid(3581480,0,"b42ab35e827d7a2936b4412ad36b56964a8aa00f845590800d722d2c9d6bf9e8")
--setManifestid(3581480,"7764411618427858643")
addappid(3879380,0,"9cc00e11fdaab23c845e9ccfee48a996421bd2fab4647a5fd9acc6fe7335a5c5")
--setManifestid(3879380,"3600498023744702612")
addappid(3879400,0,"ae5e5e1120dc2085e8f9b68942bc777dbc99b200133bf9b5e673dbafd251d02a")
--setManifestid(3879400,"6273590793040211798")
addappid(2852191,0,"d9ab76ecfa885be755b04a902f6949a0ee65ed60942bda0caeea1cb8832f65cf")
--setManifestid(2852191,"8886833791827245141")
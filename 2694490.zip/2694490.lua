-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2694490's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:00:38 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 6
--   Depot 269471: Blacklisted
--   Depot 269473: Blacklisted
--   Depot 269481: Blacklisted
--   Depot 269472: Blacklisted
--   Depot 269483: Blacklisted
--   Depot 269474: Blacklisted

addappid(2694490)
addappid(3349410)
addappid(3349420)
addappid(3349430)
addappid(3906470)
addappid(3906480)
addappid(3906490)
addappid(3906500)
addappid(3906510)
addappid(3906520)
addappid(4200610)
addappid(4200620)
addappid(4200630)
addappid(4200640)
addappid(4200650)
addappid(4200660)
addappid(2694491,0,"e30d071e5cd89c91b6675ce95a63377021dd70852367d073a9fc76ec88fff843")
--setManifestid(2694491,"8501502106898155489")
addappid(2694492,0,"605258f87a1f07cfe2baaf34fedebb1b064859274a3191cdb43fcd5876336221")
--setManifestid(2694492,"5569379660150104250")
addappid(2694493,0,"75fd52272326822de2282884751247dae91c9eb7937338a58e25d214a307a756")
--setManifestid(2694493,"4202169727166933799")
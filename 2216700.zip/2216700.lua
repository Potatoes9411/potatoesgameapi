-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2216700's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:58:21 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 1
-- Total DLCs: 0
-- Blacklisted Depots: 9
--   Depot 2216831: Blacklisted
--   Depot 2216833: Blacklisted
--   Depot 2216832: Blacklisted
--   Depot 221681: Blacklisted
--   Depot 2216834: Blacklisted
--   Depot 2216771: Blacklisted
--   Depot 221682: Blacklisted
--   Depot 221683: Blacklisted
--   Depot 2216241: Blacklisted

addappid(2216700)
addappid(2216701,0,"53b66f4e80cee01d010bb4a32ff78c1cdced48757452600e2bb6f6a297562056")
--setManifestid(2216701,"3705946128553043972")
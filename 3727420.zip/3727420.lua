-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3727420's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:44 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(3727420)
addappid(4323310)
addappid(3727421,0,"1B2FAC8D35696F04A299917B26E56703F2D2AD6CA1D13032E8FE82F51E3AEB8C")
--setManifestid(3727421,"933590943284599116")
addappid(3727422,0,"F95DAC27C9985D567D411741D02A15299FF04C0245E195E56EFE31A9CE1BAF03")
--setManifestid(3727422,"1378679560376129108")
addappid(3727423,0,"086791A63DEFD0E9498D436B4BE5BDC81AC7EBB0CFCBD0EF9516FBBB17356296")
--setManifestid(3727423,"2088014629262415645")
addappid(4323310,0,"B225B739AA65321985E959644C337CBE9441677F2A0253E50722E63BAF391E9B")
--setManifestid(4323310,"1678518943669183509")
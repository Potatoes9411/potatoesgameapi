-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 633230's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 07:00:04 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 1
-- Blacklisted Depots: 0

addappid(633230)
addappid(633231,0,"94df9bad960ed6e04e89edf50a1b7a953c09cd7be9027ee380e41ba0a22e142b")
--setManifestid(633231,"4065135017352345847")
addappid(1090130)
addappid(2321099)
addappid(1090164)
addappid(888851)
addappid(1983243)
addappid(1087424)
addappid(2185750)
addappid(1983240)
addappid(1090180)
addappid(1090161)
addappid(888853)
addappid(1087420)
addappid(1087451)
addappid(2321093)
addappid(1087425)
addappid(888850)
addappid(1090181)
addappid(1087423)
addappid(1983244)
addappid(2321100)
addappid(915390)
addappid(888859)
addappid(888854)
addappid(1087422)
addappid(1090160)
addappid(1090167)
addappid(1087421)
addappid(1090241)
addappid(1090184)
addappid(1090163)
addappid(1087450)
addappid(1090140)
addappid(1090162)
addappid(888872)
addappid(1090166)
addappid(1983242)
addappid(1983245)
addappid(1090141)
addappid(2321091)
addappid(1087427)
addappid(888852)
addappid(1087428)
addappid(888857)
addappid(1087426)
addappid(2321090)
addappid(2321094)
addappid(1087429)
addappid(1983246)
addappid(1983247)
addappid(2321098)
addappid(2321097)
addappid(1090165)
addappid(887640)
addappid(1090182)
addappid(888856)
addappid(888858)
addappid(888870)
addappid(1983241)
addappid(888871)
addappid(2321095)
addappid(888855)
addappid(2321096)
addappid(1090183)
addappid(2321092)
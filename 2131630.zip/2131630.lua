-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2131630's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:02 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 6
-- Blacklisted Depots: 0

addappid(2131630)
addappid(2314210)
addappid(2314211)
addappid(2314212)
addappid(2131631,0,"5611f7eca8917daa3b4503c93aecc8ca3970b442be9d89b2b6e90ef16de6264b")
--setManifestid(2131631,"7339216024084706552")
addappid(2131632,0,"06990dbaa532ef23fc9c5b67dd9f0183e01ad29486b0ed6b7000b5d7e529786e")
--setManifestid(2131632,"7713525600005167712")
addappid(2131633,0,"b5534a1dc315beefb2031cfeda2b76f2602e42fcf1556dcd08b36ff166823513")
--setManifestid(2131633,"6062097622870190229")
addappid(2314210,0,"e068c94228149aa99007649f734b768c4ab7a51d4513556df1cf33ee1c2a0126")
--setManifestid(2314210,"9135189822400605037")
addappid(2314211,0,"db3ba13aeb08c580831ddae67b40c2e92853f73a5e8f88b8a196d1a9d0703959")
--setManifestid(2314211,"6106653665695138588")
addappid(2314212,0,"c2905c5640fde8855cb314b8a55650eb6625c631a1047fca98dff7a43125b691")
--setManifestid(2314212,"3092029632321159821")
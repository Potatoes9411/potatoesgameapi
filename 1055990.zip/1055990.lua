-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1055990's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:37 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 6
-- Blacklisted Depots: 0

addappid(1055990)
addappid(1055990,0,"2bb060b5d00951bf9e466a894767add5182a2027d6f8dd9da84c12fc18181945")
addappid(1208660)
addappid(1239130)
addappid(1301870)
addappid(1473810)
addappid(1055991,0,"f23ef1533fc65649098b0a73403db098fe57ab941040c10d93dde6fd99935b5e")
--setManifestid(1055991,"4059763836576519421")
addappid(1208660,0,"be3b3abd7f49c836f1bf64736b408e6b32f3600dcbe3ac1acc5a06e084448ffb")
--setManifestid(1208660,"336793455762730045")
addappid(1239130,0,"ec2e474b9de34daeadf1367502e890708492ae2a4a9fff5e50e5aa530222ac32")
--setManifestid(1239130,"3477773781010927444")
addappid(1301870,0,"034f340cef65dda5caed85131717dc326f2891521444559cc1adbef0a84e3d3b")
--setManifestid(1301870,"5771583426965358160")
addappid(1473810,0,"fd831a8ab408f80d74f76ee9384d6872bf0fef3eb5fb3a3c136b76e83c474590")
--setManifestid(1473810,"4088553061941926159")
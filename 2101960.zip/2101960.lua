-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2101960's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:01 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(2101960)
addappid(3748530)
addappid(3748540)
addappid(3748550)
addappid(3748551,0,"a00d5fc8b73f7250ff62ca6a67441ad191eb2a2415db2d0db193285a7bb92780")
--setManifestid(3748551,"2053467992832422812")
addappid(2101961,0,"7f2c42a3171b51a0ea7463a8acbf143d1341f27c8e7babad3fa9eeef66f133eb")
--setManifestid(2101961,"5536483172283921175")
addappid(2101962,0,"d3f3ea72d940025825a5859f4747ec70d37c6b3df38f8ec038c1c70911d4e0ac")
--setManifestid(2101962,"991181794389347370")
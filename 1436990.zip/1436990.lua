-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1436990's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:56:31 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 5
-- Total DLCs: 0
-- Blacklisted Depots: 2
--   Depot 1436952: Blacklisted
--   Depot 1436951: Blacklisted

addappid(1436990)
addappid(3606320)
addappid(3666380)
addappid(1436991,0,"6565aea4417dd0ea5c0ef0e7cfedae34723da97dfbb9656f34f27cfb73fe2af8")
--setManifestid(1436991,"399410714482656905")
addappid(1436992,0,"c046e9e4bf5e86095f1f6d88924da4870357b892cc0711428eb31d57850afd23")
--setManifestid(1436992,"7832528367334165195")
addappid(1436993,0,"3680620184ee4df7dc49e48da6a0010221342c24be3a074d06e92c51151398bf")
--setManifestid(1436993,"8284418863986248666")
addappid(1436995,0,"c45e76af7498de2a0b485e3552502e511b203d66255fa1cdbff1d0542a0b2c0a")
--setManifestid(1436995,"1221672304803955490")
addappid(3606320,0,"390826f306966ed2b9155a50c7dc5cd9c33fc32234ca00216a853fa4fd89b12f")
--setManifestid(3606320,"3374204548946768648")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 919370's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 07:00:08 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(919370)
addappid(987110)
addappid(1194470)
addappid(919371,0,"6d3f4c2df57c4f9c4d275afd49347da2c06b4439af51fa06455916839fb5c133")
--setManifestid(919371,"5027899425965208274")
addappid(919372,0,"5b1ea148c337f17a297acbe881497fdf4a45b6a61c5b80a443ab6536cad119ad")
--setManifestid(919372,"5049247022153931868")
addappid(919373,0,"1461e662cba1d5abfbe726cbac867c84e6326312e1d7ce5086cc698e929bc78c")
--setManifestid(919373,"6284553120834788676")
addappid(987110,0,"e6218b5f3aa1289e5c7ee3a4335c8b3498d9aa10b0565c9809c5793cbb090d85")
--setManifestid(987110,"7184409368402996017")
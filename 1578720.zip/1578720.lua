-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1578720's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:48 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 1
--   Depot 1578241: Blacklisted

addappid(1578720)
addappid(1578722,0,"8b2c5ac0218c826ebc6b3e3648b776544ca7a76631df758b6df1dd12bbd2a421")
--setManifestid(1578722,"3797979248379802515")
addappid(1578723,0,"7bf0303a920b404cd22dbfc75b6537aceb2d38ff8a85da4dcb2969f74fe231f6")
--setManifestid(1578723,"339109482620221330")
addappid(1578724,0,"b40ef63e345c573b53d310720e9c0df090bf1e8806000079487e37d99c3a05ea")
--setManifestid(1578724,"9160436394081656651")
addappid(1578725,0,"9fda943a38477b1e0565e0ced847aa546327bd06984ac73f777c5de8731f25ec")
--setManifestid(1578725,"4753800683859980844")
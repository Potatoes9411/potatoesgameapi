-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2001070's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:58 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(2001070)
addappid(2001071,0,"1a1bb30e75dac9319e59c05cd2cf671bd58d69622641a320a63a2bd9665ce7a4")
--setManifestid(2001071,"7595312668967207001")
addappid(2001072,0,"d99c074ccbebc30d9fd3c7e65ee1025c781f28985577c017a291b232cd65f927")
--setManifestid(2001072,"8539367056249246440")
addappid(2001073,0,"dfdd7b00971120c31672747d712438f1195956496423bc46bf525178e8924d34")
--setManifestid(2001073,"4667989864604957354")
addappid(2001074,0,"2db2619ffb8909de8d65a6ec36840288680f7d199371e175fa7c6e4b4a582070")
--setManifestid(2001074,"4368129817465468590")
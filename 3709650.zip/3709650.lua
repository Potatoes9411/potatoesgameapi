-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3709650's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:44 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(3709650)
addappid(3709651,0,"c594788bd01ce7c13f459d4db3667ec01117680e02406483dd4ded311db09945")
--setManifestid(3709651,"3796789744172812324")
addappid(3709652,0,"b11678f8c0396a4f942844f98dbb9a37f62abf00c29c7c0266daba90bf0d96c7")
--setManifestid(3709652,"4039774429676556522")
addappid(3709653,0,"86a7803b7522f7e399f72aae6d14b3f8204781f4b7f92fd22b1c17242a7f1fd0")
--setManifestid(3709653,"1642298918525638070")
addappid(3709654,0,"50f0799aa01ea05a0a74895138e230b94f48b1bd55de7ed97f1e8e52c2c5cbb1")
--setManifestid(3709654,"9088670821564417152")
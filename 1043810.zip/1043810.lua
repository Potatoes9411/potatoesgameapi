-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1043810's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:55:24 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 3
--   Depot 1043262: Blacklisted
--   Depot 1043261: Blacklisted
--   Depot 1043263: Blacklisted

addappid(1043810)
addappid(1043810,0,"6bf239b75e3456b9ef0df05899aacffe946ef0b184090885419d5e9a7a053855")
addappid(3065010)
addappid(3139350)
addappid(1043811,0,"e49b8531e1cc3d1b3405a44cee14b159a511a1029ac6196e292b1b28248e70be")
--setManifestid(1043811,"1147383277017085137")
addappid(3065010,0,"dc826393ba0e3e8e0f85b6d81a54497c2a2e0f25315c25fae7853ce69b7459df")
--setManifestid(3065010,"1180374840999261033")
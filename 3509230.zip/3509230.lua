-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3509230's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:33 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(3509230)
addappid(3509231,0,"2b25d268f4553699e2683e63aa8fd16e8ca8f3b2cd709ddf9534264c92337525")
--setManifestid(3509231,"1759586370925666215")
addappid(3509232,0,"e1fb07d77144d880fbbe761bb34573dcd8977dc3fc137d62e97dba2f45dfa306")
--setManifestid(3509232,"6999413251159337750")
addappid(3509233,0,"6f18c74d120d5739d8f8bad5a6ca465392922f26da0014062cdb4fa4e2a08ee6")
--setManifestid(3509233,"307616918309499605")
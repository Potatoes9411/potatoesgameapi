-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1721470's Lua and Manifest Created by Potatoes9411
-- Poppy Playtime
-- Created: June 17, 2026 at 06:56:59 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 6
-- Total DLCs: 0
-- Blacklisted Depots: 2
--   Depot 1721111: Blacklisted
--   Depot 1721061: Blacklisted

addappid(1721470)
addappid(1817490)
addappid(2555190)
addappid(1817491,0,"e8a0b69343b9b3297a7db08e084898fd14130435cf9b95a9e77b794a430e66a0")
-- setManifestid(1817491,"2957411760343078601")
addappid(2555198,0,"9b728f6de496b74d3e277f9e8dd3c852dd0b70b4ab461fc5c2d5db73a5ffeec2")
-- setManifestid(2555198,"7976244025258826224")
addappid(3008670,0,"05af48230917e5f7df38d99935306907947f276d13191bc0853a0338fc295fa7")
-- setManifestid(3008670,"4811752737085405084")
addappid(4100940,0,"527fa72d80412026553480eaf2d04230eee3d58c07d133d290b72be6d664fe75")
-- setManifestid(4100940,"6752305149208661743")
addappid(1721471,0,"d8ffbaae7dda98a1608af24916982826d6ec61a8a1338fda6f793da5d3239152")
-- setManifestid(1721471,"6958304966447160997")
addappid(1721472,0,"9ff882ee821997013c8a26b12ee0e04fe781434ec5e6d41881ec53c759bacdd0")
-- setManifestid(1721472,"8897478021450885176")
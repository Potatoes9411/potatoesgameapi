-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1721470's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:52 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 11
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(1721470, 1, "93b2ee0b53ef3ced9770d2c9ffd33aa464f18c60307a1267655d297e56759f8e") 
addappid(1721471, 1, "d8ffbaae7dda98a1608af24916982826d6ec61a8a1338fda6f793da5d3239152") 
-- setManifestid(1721471, "6958304966447160997", 5612538888)
addappid(1721472, 1, "9ff882ee821997013c8a26b12ee0e04fe781434ec5e6d41881ec53c759bacdd0") 
-- setManifestid(1721472, "8897478021450885176", 286984144)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") 
-- setManifestid(228988, "6645201662696499616", 29212173)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") 
-- setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") 
-- setManifestid(228990, "1829726630299308803", 102931551)
addappid(229007, 1, "eba9fa9ff4f811929c119074450f49f739113bcae9317ded9bea262aa21ec58d") 
-- setManifestid(229007, "4477590687906973371", 117381405)
addappid(1817490)
addappid(1817491, 1, "e8a0b69343b9b3297a7db08e084898fd14130435cf9b95a9e77b794a430e66a0") 
-- setManifestid(1817491, "2957411760343078601", 8913357573)
addappid(2555190)
addappid(2555198, 1, "9b728f6de496b74d3e277f9e8dd3c852dd0b70b4ab461fc5c2d5db73a5ffeec2") 
-- setManifestid(2555198, "7976244025258826224", 38840530233)
addappid(3008670)
addappid(3008670, 1, "05af48230917e5f7df38d99935306907947f276d13191bc0853a0338fc295fa7") 
-- setManifestid(3008670, "4811752737085405084", 7499725982)
addappid(4100940)
addappid(4100940, 1, "527fa72d80412026553480eaf2d04230eee3d58c07d133d290b72be6d664fe75") 
-- setManifestid(4100940, "7625226749850580980", 11956737333)
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1703340's Lua and Manifest Created by Potatoes9411
-- The Stanley Parable: Ultra Deluxe
-- Created: June 17, 2026 at 06:56:57 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(1703340)
addappid(1703341,0,"4ad33a8eebc89ec9c5958991c29f4e6107081b775da63780ea7a65863e8720b1")
--setManifestid(1703341,"666286276060684573")
addappid(1703342,0,"966eb6d445b023674763f835aa0f2785afa11b860655b1a61602f12208dbf796")
--setManifestid(1703342,"4431616934395467188")
addappid(1703343,0,"fc29c1a04e7652e4b7f63ee3f942884a38bfb77e3ffef99a95e6c289cc7d2923")
--setManifestid(1703343,"6417175135100130100")
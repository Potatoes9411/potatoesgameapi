-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 365590's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:40 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 6
-- Blacklisted Depots: 0

addappid(365590)
addappid(437700)
addappid(437701)
addappid(437702)
addappid(4381160)
addappid(451530)
addappid(451531)
addappid(451532)
addappid(451533)
addappid(451534)
addappid(451535)
addappid(451536)
addappid(451537)
addappid(451538)
addappid(451539)
addappid(451550)
addappid(456280)
addappid(456281)
addappid(459500)
addappid(459501)
addappid(468460)
addappid(494630)
addappid(556470)
addappid(568990)
addappid(569000)
addappid(571030)
addappid(571031)
addappid(596190)
addappid(599980)
addappid(1716751,0,"84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
--setManifestid(1716751,"8055867430366823504")
addappid(365591,0,"cfc1408fd9eb22a20e55a7cc94c75065779da06a34d6826f63a48dcd380701ae")
--setManifestid(365591,"7456652011661806476")
addappid(365592,0,"4ec2ab170d6a036fb1f870729fbdceecc329b5d4008b84451370f72a0d0d1c1c")
--setManifestid(365592,"1819117757562302837")
addappid(365593,0,"a8fc437e850c2360cad81e0ae5d7c0c3b276079a449ea031aebf0280b405b1f8")
--setManifestid(365593,"992674267804407918")
addappid(365594,0,"e1b087915fdacc02b7beab6883a2122a84eed401a39feb11ba5179eeb9bf5433")
--setManifestid(365594,"4330104248805325811")
addappid(365595,0,"77decf95d069e54fd9c4e7f7be84626a5d71dd95abec5d06e82dac73bb466c6e")
--setManifestid(365595,"2718287761614813845")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 17330's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:00 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 12
-- Total DLCs: 0
-- Blacklisted Depots: 2
--   Depot 1733111: Blacklisted
--   Depot 1733112: Blacklisted

addappid(17330)
addappid(17331,0,"4cd77e69a0ad729128570fdc361adaedfec4d4791e2d9588c1ca8ea013ac7484")
--setManifestid(17331,"923661878828750741")
addappid(17334,0,"bcd09f91daf8b80015e8afe634d474f21f45edc969d02d39ffbf5d2cc2310015")
--setManifestid(17334,"4937478814353793569")
addappid(17335,0,"327b465a0be4a4e5053f63dd8beb043d69eaf6159760682280a4f7fe3ff3fd00")
--setManifestid(17335,"1108159091546718434")
addappid(17336,0,"fa7294955c3f364db9dbc557501b9de30d23db0398ccd0729bc7e59aa32a9126")
--setManifestid(17336,"6881707760445572206")
addappid(17337,0,"d91c451e3af500eb3a54ecc7a59ff195b7f2756ac156894ac5a02d18c1588989")
--setManifestid(17337,"8936014016216197136")
addappid(17338,0,"2d574179a9828efe0fb16c0d5dec4b4a64a7c8dd21021731923832d78283e36c")
--setManifestid(17338,"8956337184360264693")
addappid(17339,0,"6a9cc8e59f444613adc1ea036bce0d0e6494c0258471c87e0156e823f3943b37")
--setManifestid(17339,"3586109764689151747")
addappid(17361,0,"9a8db091d6cd7370d6f9a659129ec8f15ae303d8190745562975cc97d9e8e457")
--setManifestid(17361,"4396425827150853793")
addappid(17362,0,"b1987666c6944220af9213c049a016e2ba534016139f83c3fb79b3e878e9be1e")
--setManifestid(17362,"8834722339458821583")
addappid(17363,0,"eb9e1599652fc2327a1796441092f461776f924f4bd7c0f20346ed3080578763")
--setManifestid(17363,"1993183445942795532")
addappid(17364,0,"2eeb83f5c2db86280f65c5d047e8a0c400bd4aad3b8d9b6e53db5bb8f54e576e")
--setManifestid(17364,"8615419751850579511")
addappid(17365,0,"41ddb8897f64c8ef53a1026a813048a19a683a1ce65c8d8ae04870861f100f81")
--setManifestid(17365,"4487510727198704137")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1674780's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:56:54 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 5
--   Depot 1674201: Blacklisted
--   Depot 1674531: Blacklisted
--   Depot 1674901: Blacklisted
--   Depot 1674831: Blacklisted
--   Depot 1674902: Blacklisted

addappid(1674780)
addappid(1674781,0,"bd7f83ebcedce1e0c989d4b0c5f5336fb5f7e7d0fa76810799427d8e0c07d7f6")
--setManifestid(1674781,"459339879476692113")
addappid(1674782,0,"d019afa21fa89277ecd670d3ab25556f5ae90cb2ff03ab65a081aa8ed149d1c6")
--setManifestid(1674782,"6078900051896279086")
addappid(1674784,0,"e77dc07575a80e76cb0bbf00af551de79c28263c64acd5e73d134f33d866d078")
--setManifestid(1674784,"248713648623061357")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2776780's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:00:53 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 2
-- Total DLCs: 0
-- Blacklisted Depots: 4
--   Depot 2776452: Blacklisted
--   Depot 2776941: Blacklisted
--   Depot 2776091: Blacklisted
--   Depot 2776451: Blacklisted

addappid(2776780)
addappid(3372940)
addappid(2776781,0,"afa10f600fdbcfa388448072896e37c7d362a5efbbf2f49e6e85493d0e90aabe")
--setManifestid(2776781,"3370887563752703821")
addappid(2776782,0,"e018e66dc491c66e51db146b43901006c0de6494db6cb7be71c2c8aa0098b19f")
--setManifestid(2776782,"7969229050545172562")
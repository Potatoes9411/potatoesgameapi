-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2202010's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:58:16 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 1
-- Total DLCs: 0
-- Blacklisted Depots: 36
--   Depot 220211: Blacklisted
--   Depot 2202577: Blacklisted
--   Depot 220245: Blacklisted
--   Depot 220205: Blacklisted
--   Depot 220208: Blacklisted
--   Depot 220201: Blacklisted
--   Depot 220244: Blacklisted
--   Depot 220255: Blacklisted
--   Depot 220217: Blacklisted
--   Depot 220216: Blacklisted
--   Depot 220212: Blacklisted
--   Depot 220207: Blacklisted
--   Depot 220253: Blacklisted
--   Depot 220249: Blacklisted
--   Depot 220243: Blacklisted
--   Depot 2202578: Blacklisted
--   Depot 220206: Blacklisted
--   Depot 220256: Blacklisted
--   Depot 220214: Blacklisted
--   Depot 220251: Blacklisted
--   Depot 220242: Blacklisted
--   Depot 220252: Blacklisted
--   Depot 220241: Blacklisted
--   Depot 220202: Blacklisted
--   Depot 220203: Blacklisted
--   Depot 220248: Blacklisted
--   Depot 220246: Blacklisted
--   Depot 220215: Blacklisted
--   Depot 2202579: Blacklisted
--   Depot 220247: Blacklisted
--   Depot 220250: Blacklisted
--   Depot 220204: Blacklisted
--   Depot 220210: Blacklisted
--   Depot 220209: Blacklisted
--   Depot 220254: Blacklisted
--   Depot 220213: Blacklisted

addappid(2202010)
addappid(2202011,0,"f4f4b2b7a7bdabc73e9cee7d04ba520204385638c86d2a89753f6eea6640eb08")
--setManifestid(2202011,"8789919833605549663")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2365090's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:59:16 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 2
--   Depot 2365641: Blacklisted
--   Depot 236590: Blacklisted

addappid(2365090)
addappid(2365091,0,"4895f8f614e4f04757dc86567eabe7946c2313459c2849e9969ae18ec5be354c")
-- setManifestid(2365091,"8314372997976902836")
addappid(2365092,0,"fe2dd7e69afcb2d457e571f90eefc7b9cafdc51a4fca70f075f2f6dfeb87f799")
-- setManifestid(2365092,"5045889676812886137")
addappid(2365093,0,"d14f41f7ddc209aec8889087bf0b8b84b5d32713f6bf11fb90b344a538c7d826")
-- setManifestid(2365093,"2323342509869347614")
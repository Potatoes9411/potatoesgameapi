-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2356780's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:13 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(2356780)
addappid(3299430)
addappid(2356782,0,"7b6a14efc42db13c57345a4d149afca6f1a16389dc609a5a3c3ad4a85cc61c73")
--setManifestid(2356782,"6005589065969855449")
addappid(2356783,0,"81ce7bfff474863adeb76261d7e151cdd6eb5fd86ce53d6f4e76520bf447cbdb")
--setManifestid(2356783,"7295813560181936332")
addappid(2356784,0,"553e16a517cbe8a877d676827b2eae7dc49471ceb7af1c14894c104126615bbc")
--setManifestid(2356784,"6199188363037569396")
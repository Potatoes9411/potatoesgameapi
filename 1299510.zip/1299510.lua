-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1299510's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:43 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 4
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(1299510) -- Vampire: The Masquerade - Swansong
-- MAIN APP DEPOTS
addappid(1299511, 1, "10e6d9c752130de53e4644e5493a6001a70aba427bd5878a59b396b95940ed61") -- Depot 1299511
--setManifestid(1299511, "5209156498979665496", 24679337300)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
--setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
--setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Vampire The Masquerade - Swansong - Artbook (AppID: 2407740)
addappid(2407740)
addappid(2407740, 1, "3ad7f9a316a140f2f61c7102d8bd07a83290f1ee4ccb85708e51563e96f451c7") -- Vampire The Masquerade - Swansong - Artbook - Depot 2407740
--setManifestid(2407740, "8989587942344330123", 176479814)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1801880) -- Vampire The Masquerade - Swansong Alternate Outfits Pack
addappid(1801881) -- Vampire The Masquerade - Swansong Victoria Ash
addappid(1801882) -- Vampire The Masquerade - Swansong Artifacts Pack
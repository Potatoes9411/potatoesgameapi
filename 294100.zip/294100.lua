-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 294100's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:01:30 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 25
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 2941711: Blacklisted

addappid(294100)
addappid(294100,0,"44498055cce67eea5d84c5b6bc1bd5ca9e8c988963aea857574277fc217cbad0")
addappid(367680)
addappid(367681)
addappid(367682)
addappid(1149640)
addappid(1392840)
addappid(1826140)
addappid(2380740)
addappid(3022790)
addappid(294101,0,"a5f3f4466343e7297b20a43dde9d6b6ed9d0d4230b74689caf5746d11de0367d")
--setManifestid(294101,"7953786152513421342")
addappid(294102,0,"dfa49a9452d912eb031ecd2111c1a9b1331bfe58000b9d68b8d5b646acbd1054")
--setManifestid(294102,"2497899177261850067")
addappid(294103,0,"a8218a15388519f5ded274def07d1dd1c535e1bfe646eb17463775bf47f63e39")
--setManifestid(294103,"3134934206210576837")
addappid(294104,0,"db7d2330e8748efe01ff1674580919b72e40879517e378b568533acc2863ec26")
--setManifestid(294104,"2772688105937893244")
addappid(294105,0,"be81976289e837bb2cb5c9858b07b9f72612a69414697f44c5b138fb3041a250")
--setManifestid(294105,"3885486926018788663")
addappid(294106,0,"d1a9518d7b68f46dc53981fe05514f6daa66a3aa125637c13c1535e8cdb8e4b6")
--setManifestid(294106,"1227145614562470487")
addappid(294107,0,"132106f7d7fd90e2cef97d5a01632ca943c2147afcd166c202d51865cf0786e6")
--setManifestid(294107,"5359145108392473956")
addappid(294108,0,"80efa15b6a1330572a30a52fc0147fd7fecf36ea2e3acfa8d7db1d78f28c2144")
--setManifestid(294108,"569687740856239076")
addappid(294109,0,"d670f6ba851c27bd62423853e8dd18d5e32b75393b65bf18914103a0b0db63e9")
--setManifestid(294109,"7818336393444714786")
addappid(294110,0,"96eea289fb25789e7d7791bcf77e2af4d62eacaa1c05866991b72e75b805069c")
--setManifestid(294110,"868105332660730820")
addappid(294111,0,"62487ea6d7f63684007a6713749fd8fb14c7955e885aa14cda8c5daa5d930f78")
--setManifestid(294111,"8082717694556047429")
addappid(294112,0,"69dc90bdbb7c2c47b168606c5b8bde5ab1c6ec88404fa31bfb1faaf2d5c452c3")
--setManifestid(294112,"724110462483695149")
addappid(294113,0,"3a667846a7e65282aae8275c6848ede3e0e48b3959c6045ebc0ceff98db49e0a")
--setManifestid(294113,"6306290553655225872")
addappid(294114,0,"76f5a14f8283fd55fe1b8e0eca01a5408e01b23611e70c2cb92a7e303e835646")
--setManifestid(294114,"6581907861000077546")
addappid(294115,0,"40c853711dd9329158bf8acf348ff5b209664fb273949bee5276501836c32943")
--setManifestid(294115,"5979071730349817278")
addappid(294116,0,"17b44d4ac86a4bd0f697320c0b34672092058aba22133b9b9028e11cff1c498d")
--setManifestid(294116,"6423111671391618215")
addappid(367683,0,"eae351654f6795aae5320150c2801aa853cc2e46412b72bccca2fbf3f50af32a")
--setManifestid(367683,"883708408590570304")
addappid(367684,0,"699e092d84e16c90a62ebfcd68d1c568c4947ae94d538e999fe56e7cc6043942")
--setManifestid(367684,"5027583327039997575")
addappid(367685,0,"8a4f6b777fb54e2730c7ace0e4f85ddf4fc58ea3607ad94eb9cf01acb2571446")
--setManifestid(367685,"1751266350468796361")
addappid(367686,0,"ddec61094ce592f6db40f3867b99e458ea4ce2af56cb8f62474631b33a96c734")
--setManifestid(367686,"1776297058088144151")
addappid(1149641,0,"298db7a9d64ecbc820422e53907ab224611829745e8e4b20a4387efba317bee1")
--setManifestid(1149641,"2347721629532249182")
addappid(1149642,0,"14ba0c9d972b57cf45870968dfd396baa35f94d87f117e91e64ba03d25d5d5ad")
--setManifestid(1149642,"1765958875109776452")
addappid(1149643,0,"a2065b38cf6723c9cc336f68388389a7b437e4404a9856982d2594a928b49b23")
--setManifestid(1149643,"1527472528506197989")
addappid(1149644,0,"fafd64b303cda2e9b938ce60e7af4653a574b035d59cccd31be1ff5c2dc8c0ee")
--setManifestid(1149644,"1883707662054891831")
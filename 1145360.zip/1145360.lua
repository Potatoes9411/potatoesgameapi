-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1145360's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:55:40 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 3
--   Depot 1145352: Blacklisted
--   Depot 1145355: Blacklisted
--   Depot 1145354: Blacklisted

addappid(1145360)
addappid(229006)
--setManifestid(229006,"1784011429307107530")
addappid(1145361,0,"e7db1a4f43363b9d751ed9e888334353425704ea0db26c8434015e516a482f4d")
--setManifestid(1145361,"5173085471687919135")
addappid(1145363,0,"b88219eb2aee190d115e532ef9feea08c69bbc53bb1f959a2c48f3739f871b31")
--setManifestid(1145363,"2572656066874346283")
addappid(1145364,0,"c70c6707a01507e124d35ac0e1644ee6210f383a1ae759aa252478cbd1ca7e0e")
--setManifestid(1145364,"6896671991921324741")
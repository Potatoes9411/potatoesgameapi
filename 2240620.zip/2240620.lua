-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2240620's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:58:45 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 2
-- Total DLCs: 0
-- Blacklisted Depots: 10
--   Depot 224064: Blacklisted
--   Depot 2240081: Blacklisted
--   Depot 224061: Blacklisted
--   Depot 224062: Blacklisted
--   Depot 224067: Blacklisted
--   Depot 2240082: Blacklisted
--   Depot 224066: Blacklisted
--   Depot 224065: Blacklisted
--   Depot 224068: Blacklisted
--   Depot 224063: Blacklisted

addappid(2240620)
addappid(3951650)
addappid(2240621,0,"80b19fbd6c9057548e637a2e743cb48d753af68fa08227be8200dc8e3cc33753")
--setManifestid(2240621,"4010139835286936078")
addappid(3951650,0,"706689526031d649f39c7ce4ed4c578bfffbc570afae867b5c7464e12b7259ed")
--setManifestid(3951650,"5872580140548776251")
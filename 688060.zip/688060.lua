-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 688060's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 07:00:05 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(688060)
addappid(688060,0,"5ef496c500e7e21c08879b8ad76a93e2675e340f5651013aee7244c3e6015786")
addappid(688061,0,"17113a3ff27562d68ceec2376e075ef106ff7e1227eb87560f6156b9fa493aaa")
--setManifestid(688061,"889407794165941766")
addappid(688062,0,"4fb128a2f8dda0165f5dd07f00a93ba7fe83f60a127032e633874c8f768d0921")
--setManifestid(688062,"670108761142164788")
addappid(688063,0,"920ee68dbc20f81e011b153f1eb554642d7b399c1dffeddce20dabe0ba29d456")
--setManifestid(688063,"6936611257955281965")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2440510's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:59:37 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 1
-- Total DLCs: 0
-- Blacklisted Depots: 3
--   Depot 2440273: Blacklisted
--   Depot 2440272: Blacklisted
--   Depot 2440271: Blacklisted

addappid(2440510)
addappid(2557390)
addappid(2557400)
addappid(2557410)
addappid(2557420)
addappid(2573690)
addappid(2573700)
addappid(2573710)
addappid(2573720)
addappid(2573730)
addappid(2573740)
addappid(2612060)
addappid(2612070)
addappid(2612080)
addappid(2612090)
addappid(2612100)
addappid(2612110)
addappid(2612120)
addappid(2612130)
addappid(2612140)
addappid(2612150)
addappid(2613770)
addappid(2662850)
addappid(2662860)
addappid(2662880)
addappid(2662890)
addappid(2662900)
addappid(2662910)
addappid(2662930)
addappid(2662940)
addappid(2662950)
addappid(2673230)
addappid(2728110)
addappid(2731660)
addappid(2833110)
addappid(2833220)
addappid(2833230)
addappid(2862340)
addappid(2921330)
addappid(3026540)
addappid(3118460)
addappid(3472460)
addappid(2440511,0,"c7f1787c2ad76d9b13d4db530c1ee953f08e63cb69b9a59c619dcca4736f10c0")
--setManifestid(2440511,"1248740277997037180")
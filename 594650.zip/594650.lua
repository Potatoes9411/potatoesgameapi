-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 594650's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 07:00:03 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 4
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(594650)

addappid(594654,1,"8b77c5e77de5ce174135da1a533aa4314f18efb1fd5c358665192adddd8b3f92")

--setManifestid(594654,"1106102421821451145",0)

addappid(594651,1,"2b731d9a42ee11b0f9a51d4aea2c779a2c1943f0ca0027bf38529240e3fd70e4")

--setManifestid(594651,"8545816923384182972",614390833)

addappid(594652,1,"a8a0c9b88ad0802d43ca2c0d3b8dd40d95a480ddec25ddbc6d154f1b268da0b2")

--setManifestid(594652,"2604284512958939920",55559106615)

addappid(594653,1,"3ff39c9a082647ddfb27213a069c8fb08fd4161798aba12e5dd30cf535b99bb1")

--setManifestid(594653,"3961338879304480979",180469855)

addappid(1143840)

addappid(1166470)

addappid(1166471)

addappid(1166472)

addappid(1180490)

addappid(1180491)

addappid(1191490)

addappid(1225140)

addappid(1228530)

addappid(1255000)

addappid(1255001)

addappid(1304600)

addappid(1304601)

addappid(1374340)

addappid(1397380)

addappid(1397381)

addappid(1530430)

addappid(1576410)

addappid(1586080)

addappid(1610550)

addappid(1643020)

addappid(1674570)

addappid(1674580)

addappid(1720670)

addappid(1761570)

addappid(1784870)

addappid(1784880)

addappid(1852470)

addappid(1852480)

addappid(1887100)

addappid(1906330)

addappid(1966460)

addappid(2014790)

addappid(2081520)

addappid(2100450)

addappid(2133640)

addappid(2160020)

addappid(2160330)

addappid(2200640)

addappid(2272500)

addappid(2272530)

addappid(2304380)

addappid(2304500)

addappid(2407940)

addappid(2407941)

addappid(2531020)

addappid(2581740)

addappid(2585200)

addappid(2643040)


-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 15160's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:56:36 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 4
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 1516051: Blacklisted

addappid(15160)
addappid(15161,0,"d32c4c5b73800bc162a3d19440c8b78817b274f0ad8ddb8788aaf9e6df0b4382")
--setManifestid(15161,"3367859733614380481")
addappid(15162,0,"d22ac806602e7290cb667ac7d402d3a0a65c1fedbd4087960d23da712b47c473")
--setManifestid(15162,"6148356972750949472")
addappid(15163,0,"4d113b80f4535725865003acabf78995f447bea9bb98c08439eafd4af08dcf44")
--setManifestid(15163,"1925464892691589820")
addappid(15164,0,"f8ff9cc5a28a7ef045f43fb79be33f30f6827d084f3612b2bf99d932ee39bd56")
--setManifestid(15164,"3391362419238893200")
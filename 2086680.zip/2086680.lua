-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2086680's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:50 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 1
-- Total DLCs: 0
-- Blacklisted Depots: 10
--   Depot 208652: Blacklisted
--   Depot 208659: Blacklisted
--   Depot 208654: Blacklisted
--   Depot 208653: Blacklisted
--   Depot 208658: Blacklisted
--   Depot 208660: Blacklisted
--   Depot 208651: Blacklisted
--   Depot 208656: Blacklisted
--   Depot 208657: Blacklisted
--   Depot 208655: Blacklisted

addappid(2086680)
addappid(2086681,0,"d26f1082b54bbbc389fc56aedfc2cb3f47a9a5d8257f27f6fab2dcfcbf25bae0")
--setManifestid(2086681,"6053324742163516490")
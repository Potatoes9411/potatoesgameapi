-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3017860's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:41 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 9
-- Blacklisted Depots: 0

addappid(3017860)
addappid(3017862,0,"b537907a613fd29911d2e311eb41fd2f0b309324601b0ef164c8520562eac290")
--setManifestid(3017862,"2294956030765668938")
addappid(3017863,0,"0c010bdf1623542793fb5765875c715494c4a6c78856f75c124aa7d31f3021cd")
--setManifestid(3017863,"399781073792192298")
addappid(3017864,0,"35f0d11b6d2b729dd8e5f50a21e7b0300e8d6b79fc6ba487f4198ca6d3402c0d")
--setManifestid(3017864,"5126423772771951062")
addappid(3017865,0,"558521d6ef4cac7a1318bb55268dc878b72482482691e7791ea81bff06c73694")
--setManifestid(3017865,"9108580810918908470")
addappid(3017866,0,"cc9112a06785fd0d7f6e24a50702f1f71e655e35caf8fb3ea09f6036680c0fe4")
--setManifestid(3017866,"9217731964535062300")
addappid(3017867,0,"8ffa78f10846725bed8d48d1a182cf4088f770691c44561b2d167f84fdc60789")
--setManifestid(3017867,"873442200902637512")
addappid(3017868,0,"fb3bda82e733857d05419dce15179a1aa642b840af21ef69520346fe8a00e20e")
--setManifestid(3017868,"1775352278196208271")
addappid(228989,0,"ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853")
--setManifestid(228989,"550968249685141759")
addappid(228990,0,"44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")
--setManifestid(228990,"1829726630299308803")
addappid(3363930)
addappid(3363940)
addappid(3698350)
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1926680's Lua and Manifest Created by Potatoes9411
-- FUCK PUTIN
-- Created: May 16, 2026 at 04:46:18 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 10
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(1926680, 1, "Unknown")
addappid(1926681, 1, "Unknown")
setManifestid(1926681, "Unknown", 0)
addappid(1926682, 1, "Unknown")
setManifestid(1926682, "Unknown", 0)
addappid(1926683, 1, "Unknown")
setManifestid(1926683, "Unknown", 0)
addappid(1926684, 1, "Unknown")
setManifestid(1926684, "Unknown", 0)
addappid(1926685, 1, "Unknown")
setManifestid(1926685, "Unknown", 0)
addappid(1926686, 1, "Unknown")
setManifestid(1926686, "Unknown", 0)
addappid(1926687, 1, "Unknown")
setManifestid(1926687, "Unknown", 0)
addappid(1926688, 1, "Unknown")
setManifestid(1926688, "Unknown", 0)
addappid(1926689, 1, "Unknown")
setManifestid(1926689, "Unknown", 0)
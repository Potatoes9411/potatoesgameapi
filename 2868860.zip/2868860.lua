-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2868860's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:01:11 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 2
-- Total DLCs: 0
-- Blacklisted Depots: 5
--   Depot 2868842: Blacklisted
--   Depot 2868841: Blacklisted
--   Depot 2868843: Blacklisted
--   Depot 2868390: Blacklisted
--   Depot 2868431: Blacklisted

addappid(2868860)
addappid(2868861,0,"184987f74fbd9ce7b4460cf727ca7d3eec737adec7aab9dc0e7e438a0a01841b")
--setManifestid(2868861,"7527947550084716289")
addappid(2868862,0,"80b6ab971d1f90ec323fbf5aedafd84333e63fb6bdb112de35b23df597fc2309")
--setManifestid(2868862,"935428779441252188")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2513280's Lua and Manifest Created by Potatoes9411
-- SONIC X SHADOW GENERATIONS
-- Created: June 17, 2026 at 06:53:48 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 14
-- Blacklisted Depots: 1
--   Depot 2513030: Blacklisted

addappid(2513280, 1, "Unknown")
addappid(2513281, 1, "e5b9cddfe91ed04af8c6d17537301797ab16a5041a7edca1d45ae281208a740f")
setManifestid(2513281, "1703635842257284304", 0)
addappid(2513282, 1, "Unknown")
setManifestid(2513282, "Unknown", 0)
addappid(2513283, 1, "Unknown")
setManifestid(2513283, "Unknown", 0)
addappid(2513284, 1, "Unknown")
setManifestid(2513284, "Unknown", 0)
addappid(2513285, 1, "Unknown")
setManifestid(2513285, "Unknown", 0)
addappid(2513286, 1, "Unknown")
setManifestid(2513286, "Unknown", 0)
addappid(2513287, 1, "Unknown")
setManifestid(2513287, "Unknown", 0)
addappid(2513288, 1, "Unknown")
setManifestid(2513288, "Unknown", 0)
addappid(2513289, 1, "Unknown")
setManifestid(2513289, "Unknown", 0)
addappid(2983600, 1, "Unknown")
setManifestid(2983600, "Unknown", 0)
addappid(2909790, 1, "bf6e60e47f8307ecf6fa9f9d935d223475b099b56d9da116e8e52377b5b971b4")
setManifestid(2909790, "811552346142850245", 0)
addappid(2999160, 1, "Unknown")
setManifestid(2999160, "Unknown", 0)
addappid(2909770, 1, "Unknown")
setManifestid(2909770, "Unknown", 0)
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2984520's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:40 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 3
--   Depot 2984571: Blacklisted
--   Depot 2984573: Blacklisted
--   Depot 2984572: Blacklisted

addappid(2984520)
addappid(2984521,0,"ca87779475badf891924f8de1336ee4407cfa077e32c95d5c909bb7127a1aaef")
--setManifestid(2984521,"2113784587878176096")
addappid(2984522,0,"9c1ea63d6b1d16caacd864c686a6ffe1e175ae5219bca781224c1e90292ec1c2")
--setManifestid(2984522,"2459107099915111528")
addappid(2984523,0,"65c1e86f69bbdbc8df58c7257789328e6df6042de57f1bc477830bb68bcdee71")
--setManifestid(2984523,"4392163342269677699")
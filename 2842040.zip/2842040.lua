-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2842040's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:34 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 9
-- Blacklisted Depots: 0

addappid(2842040)
addappid(3112310)
addappid(3261290)
addappid(3261340)
addappid(3271130)
addappid(3271140)
addappid(3271150)
addappid(3271160)
addappid(3271170)
addappid(3271180)
addappid(3271190)
addappid(3271200)
addappid(3271210)
addappid(3271230)
addappid(3271240)
addappid(3271460)
addappid(3394020)
addappid(3515960)
addappid(3541390)
addappid(3541410)
addappid(3702240)
addappid(3702250)
addappid(3702260)
addappid(3702270)
addappid(1716751,0,"84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
--setManifestid(1716751,"4132506267642462151")
addappid(2842041,0,"bed1b2aedb9b823e084bde3a15663caf8f50feaadd104bba0c7e474540a11f43")
--setManifestid(2842041,"5039899775321241999")
addappid(2842042,0,"110e9180cab6db688b21cc6f16820d8197b333d0c1d88b66da81d43753a9c786")
--setManifestid(2842042,"8023630815732376815")
addappid(2842043,0,"2d98d4345bb461b3ee9574d5e4f00cf62e968042031e7d7361b3d15d09282788")
--setManifestid(2842043,"4839953097128885780")
addappid(2842044,0,"dbaf8d54cceac51941390dffb5257608db23f202ec6d06d61fae96fed743e9d9")
--setManifestid(2842044,"7424665147348076845")
addappid(2842045,0,"845fbe248a74375c3dda44984552af44018332d3b7f355dce4d1c833727e0a42")
--setManifestid(2842045,"6353372299728446551")
addappid(2842046,0,"58faa2a3ab11d95ab7d448ae380c4211c92726b9fcf619835d2b3900356506ac")
--setManifestid(2842046,"7478173584789464744")
addappid(3271130,0,"cd4259d93979d9d480227cf581dbb3855b238747fa76988d8c94da591300669e")
--setManifestid(3271130,"3969923851033101926")
addappid(3541390,0,"a2c323e9b71ce1d184500fedc2ddaf67f9f96af0f57324757cb7f9949f71944a")
--setManifestid(3541390,"6063451016620732592")
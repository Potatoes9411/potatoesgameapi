-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1708150's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:56:57 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 5
-- Total DLCs: 0
-- Blacklisted Depots: 6
--   Depot 1708771: Blacklisted
--   Depot 1708091: Blacklisted
--   Depot 1708620: Blacklisted
--   Depot 1708090: Blacklisted
--   Depot 1708772: Blacklisted
--   Depot 1708092: Blacklisted

addappid(1708150)
addappid(2608730)
addappid(1708151,0,"350e0a3bacd9f9a558fb952336912411ebc1dd3ea4e13cbc54ffd50c3805e7dd")
--setManifestid(1708151,"3504071933938304842")
addappid(1708152,0,"a416649c4590909ce21411bbcd5f73de11da733340669e152b74afe1d29c3c34")
--setManifestid(1708152,"5913646606469454825")
addappid(1708153,0,"4dcaaabed510cd6e63b04067324896dc8713d7da881cf453e3c99c4a43952f9d")
--setManifestid(1708153,"52030157512258358")
addappid(1708154,0,"995798dc31b8d22a5405ecef2a8ccb4ad415514fc8b869d9a438e1f1e9acd54c")
--setManifestid(1708154,"2518386505822434500")
addappid(2608730,0,"81059967d4d512535581edd47d545aaf05ea7990ab3b2a09a931ff0a9f36f250")
--setManifestid(2608730,"5784488609533887109")
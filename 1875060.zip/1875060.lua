-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1875060's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:15 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 3
--   Depot 1875582: Blacklisted
--   Depot 1875581: Blacklisted
--   Depot 1875831: Blacklisted

addappid(1875060)
addappid(3010540)
addappid(3333960)
addappid(3564800)
addappid(4131780)
addappid(1875061,0,"a33eb91dbaf0ab42248dfe4e4d11a817ad3f8e033b56465281a752da06245e7d")
--setManifestid(1875061,"3557025574315942788")
addappid(1875062,0,"80791d99567e5d3181ef98a4e8b9138fbf99a33d0d67d1d23d44f46cf315d2b2")
--setManifestid(1875062,"1749096932264659250")
addappid(3010540,0,"9cf3cbf9469a572366e3c3977b7a7c802708b3fcad132ac73745639df8e05b6f")
--setManifestid(3010540,"3896516526556556967")
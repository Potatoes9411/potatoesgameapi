-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2386310's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:59:23 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 2386480: Blacklisted

addappid(2386310)
addappid(2649730)
addappid(2386311,0,"af749a581922a0c97f5cd9d034f04d877796b39acf48e7a430aae7f3dd52a852")
--setManifestid(2386311,"3582887505871889030")
addappid(2386312,0,"d9c4cf37af7bd810f59dd4ab10b58036676003464de7951a02f4362a9ba6031f")
--setManifestid(2386312,"3520414471288568020")
addappid(2649730,0,"f30ea3d32d7bed49f7fb1180aa43a34f94cb972fdaf4e804172aabe70fefa3df")
--setManifestid(2649730,"442444320526257897")
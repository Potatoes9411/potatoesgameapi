-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1879680's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:16 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(1879680)
addappid(2435580)
addappid(1879681,0,"9cb6a9082de4bdfdfe9e6872827ef9e5bccf28fee8038a03f841b7bc0f9f5fcd")
--setManifestid(1879681,"4042621404312990929")
addappid(2435580,0,"fa9e62937c504a797aef6cdf4918be7edec59fc6497a3074bee9b9f064beceaa")
--setManifestid(2435580,"2764432428690608312")
addappid(2435581,0,"038ee57c627668f29db0193ed3d0feb50dfed3ae15e96ff506b188358005fd02")
--setManifestid(2435581,"3822894329981012107")
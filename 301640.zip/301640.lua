-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 301640's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:41 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 19
-- Blacklisted Depots: 0

addappid(301640)
addappid(301641,0,"550204c5e1c64a694d1452d5290bdc5aa4fd6f553204efbfc2daa43063b1927e")
--setManifestid(301641,"2645768744049394218")
addappid(301642,0,"fc92c06a03000c5b9e43cabcd680f0bb7d31cc47b53c5bcace13ed471bdfc349")
--setManifestid(301642,"7218416939251580222")
addappid(301643,0,"9121a06f2dbb3e4ba8acb556357cc26ac8361526a4430f8f8f8c410cd0816c4e")
--setManifestid(301643,"8446901549704368218")
addappid(301644,0,"0b6cff7dc2454494d8194f1748e5e0aa69f11e4793ee4fbf6a5f36a2f825631e")
--setManifestid(301644,"6972015510605659542")
addappid(301645,0,"117a6f3bf468c644662086b03be84c1d261d05627eaafa077776cf3d5a507708")
--setManifestid(301645,"8518208942256569172")
addappid(301646,0,"4fac840cb7f9f94e866839c5038822ebc97a25603a228af4791cbdae65cee82f")
--setManifestid(301646,"718902021122217225")
addappid(301647,0,"b40feb34bb9dc2734621107d878010bded38a948830fc669aabe95dd10bb9602")
--setManifestid(301647,"1770727325585529333")
addappid(301648,0,"eb307050659919f5d6f06e6d43d6f830ed7d577a83629f647dc7fb63b388553d")
--setManifestid(301648,"2622718477007953629")
addappid(301649,0,"b5966c5b79722af27f1203fc33bad122858c372828bbf51c51f8f0380d8193d8")
--setManifestid(301649,"9055412374246968548")
addappid(350350,0,"d29150a79821258cf0d58fe4243767bf6f9309d3ac8482e11b5a149f5789a5ee")
--setManifestid(350350,"4431114700816209547")
addappid(350351,0,"3ff3e69e43200c80a698bc4022eee75a387716ea516186c3e9efa8daf5ba47aa")
--setManifestid(350351,"2488557444616293419")
addappid(350352,0,"baac96e5a543a966de1ab8913b10f86570bf142bd381716927a6eae4c935ba96")
--setManifestid(350352,"2184998934591897282")
addappid(350353,0,"2f1b2877dd5c38ed8f807f51d764805d524f0a5a5c13074b90ab21898acf2777")
--setManifestid(350353,"4931658970056569572")
addappid(350354,0,"68518fe71ab809807043315532f7eaf2df615af49792679c648658f4a5647d21")
--setManifestid(350354,"3489031477280955180")
addappid(350355,0,"e54bfdcf4cb3934afd8864bd2a5927b231683c79a312432d1e8b011a3a794a32")
--setManifestid(350355,"2622447744127956008")
addappid(350356,0,"089fb68dad0484b31152e79d45aa50d958783cdb9efb2f0e4476acc8cddc25ac")
--setManifestid(350356,"1032179419647441099")
addappid(350357,0,"9fcc72da0a1e0bff6c4bd382d6fe91b2fefbb91feb2f92d2c46312d101867333")
--setManifestid(350357,"5553284230915669580")
addappid(350358,0,"aa570cf6abc73181de72aac059d7aa5028005277eb8d157a67bde6e5534b2100")
--setManifestid(350358,"8869681891059620166")
addappid(350359,0,"40ed63e2bf3f79c424f805a0ce4e7e8e9681f687227de564fe5f024d28494517")
--setManifestid(350359,"4798984787030030407")
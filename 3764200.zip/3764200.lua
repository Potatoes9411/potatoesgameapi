-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3764200's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:46 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(3764200)
addappid(3990800)
addappid(3990820)
addappid(3764201,0,"bdf443ffde6449192b9863c0fa5e3cda31fdaa5e4d33e5bcded62dc2085b7cb8")
--setManifestid(3764201,"2990234554016452841")
addappid(3764203,0,"b2e820287e6e3f32d1ccb3f2f8c95ec3783e8c0a75abab5d311a0a648626fd92")
--setManifestid(3764203,"5266604904838445059")
addappid(3990800,0,"f5bf116706491176c9eee46a96fe1faa70b3f771d75ccb34f0c8962097a907e5")
--setManifestid(3990800,"9181787779883827112")
addappid(3990820,0,"9ae4713cb4114effdd34d1cd54dbda8a560f27a05aef06fbaa0370748f69d15c")
--setManifestid(3990820,"509708311968316285")
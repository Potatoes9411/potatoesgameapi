-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3381120's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:27 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 24
-- Blacklisted Depots: 0

addappid(3381120)
addappid(3381120,0,"237a8efafb92aaeff9c2e05502f71b57aafa57365141fae5b1caf9d132b21426")
addappid(3542730)
addappid(3542740)
addappid(3609190)
addappid(3609200)
addappid(3609210)
addappid(3609220)
addappid(3609230)
addappid(3609240)
addappid(3614750)
addappid(3614760)
addappid(3614770)
addappid(3614780)
addappid(3614790)
addappid(3614800)
addappid(3614820)
addappid(3614830)
addappid(3614840)
addappid(3614850)
addappid(3614860)
addappid(3614870)
addappid(3614880)
addappid(3614930)
addappid(3381121,0,"728de21056163f61d9e9347d5812d2dbfd24a3b450348920c66a269e77b23b8f")
--setManifestid(3381121,"1643103123723552264")
addappid(3542730,0,"2ec9177285c7ce702785ac004ecb38825a5bd33ffadc0f4da621aecf06cc362f")
--setManifestid(3542730,"7994990115406199451")
addappid(3542740,0,"cc0d4cb89faded38a8de620c8252390b1c1faeef46aec65a849eb4c7ef5b3376")
--setManifestid(3542740,"9020244916149448009")
addappid(3609190,0,"d41c60128a717f37fd1e3edc7ba50fb00f13838f3df71841ae1d37f0534515c5")
--setManifestid(3609190,"1174060647497092254")
addappid(3609200,0,"f3c2ac8a0317d757ac6870a8b77afd9784dfa6313dd632a1a9d2f5f3d59dfb6f")
--setManifestid(3609200,"1130907835557355863")
addappid(3609210,0,"3be7e7afc8d8c561fce987d75c7f24a43110446dd2ee12be6b7fc94c7a560ef4")
--setManifestid(3609210,"8280569291679211379")
addappid(3609220,0,"bf5077dda229f0836f7b502ff540ee28f7eaf4faee39d45588c8e167da647940")
--setManifestid(3609220,"4590657482933862106")
addappid(3609230,0,"cf2067651a8e9a7df64f900c679eac97f1406605d82adc27484628289d070dd0")
--setManifestid(3609230,"4038047570974992257")
addappid(3609240,0,"8910c52f52cdd35759cba7a94fb389bed3c15ab330fe1778b5bab961635d3e28")
--setManifestid(3609240,"3792473835916121489")
addappid(3614750,0,"121806f11f8efd93eb2dff21bb5feaf89dcdabfc8af016f613d7a3ff583d905d")
--setManifestid(3614750,"4782995379939239164")
addappid(3614760,0,"0b9240d84c3a2b0b67c797373e0f08ab213e810eadc6ee27fee57a49aa7a054a")
--setManifestid(3614760,"5312483756762964401")
addappid(3614770,0,"39fac8c382bf3d6e57c1b94c94c1ce88d680a0d6009e2d093cb1e1861c95d039")
--setManifestid(3614770,"3309189279362368310")
addappid(3614780,0,"53a054ffdba4616a2dcacf69062d533812d48ccf35039d64c219446189d29e5a")
--setManifestid(3614780,"3065530261292081867")
addappid(3614790,0,"0acb922afafa44e01569e30c41c93d20376a06aec2f5943c9e9e6d50648cb8bc")
--setManifestid(3614790,"5952347974815242692")
addappid(3614800,0,"b4eb303a64793f101bfe75e6f2fe77741c92f5c153c240d57c8829c67d9babbf")
--setManifestid(3614800,"7275318055808884663")
addappid(3614820,0,"6a12a858ddb2a2fd0f640424acfdcf8ecbf8f2a50308b6c60dff93a44873ca5f")
--setManifestid(3614820,"7157716308054688004")
addappid(3614830,0,"e5170edc19c5227c464d4b33f463c219e5dbd0ef1febfcaa4fbbfc769f274ffb")
--setManifestid(3614830,"6891144017054421169")
addappid(3614840,0,"5082bd2dc021de5849f2768e5654b73ae9d861191d3ee19188607a467729848f")
--setManifestid(3614840,"8896060910710551413")
addappid(3614850,0,"d9960ce7d5bcde64a0a08bbdd9872dffaedd960d72f1457cb024419c1aaf9c03")
--setManifestid(3614850,"8319981011963293454")
addappid(3614860,0,"d280f76a1c0860d6a615e7cfd31ab554706861e37dea34c4e1753795ea2e0145")
--setManifestid(3614860,"2179181022905907402")
addappid(3614870,0,"d51f3929d629485460c08f69c0b3c6f563495d51bf77951a231ad80fe3d89a1a")
--setManifestid(3614870,"9142329843269206526")
addappid(3614880,0,"3c061e6132f978c3c22b4fe848556831ab96c077844ad783f977e74d8ee6ecaf")
--setManifestid(3614880,"3431019706727342507")
addappid(3614930,0,"db06701b466916ff797fa3990e6f810fac323e2cb7815e5443a343ec5ac675e1")
--setManifestid(3614930,"5428749486384415331")
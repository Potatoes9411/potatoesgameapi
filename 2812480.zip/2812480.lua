-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2812480's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:01:01 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 2
-- Total DLCs: 0
-- Blacklisted Depots: 5
--   Depot 2812451: Blacklisted
--   Depot 2812671: Blacklisted
--   Depot 2812611: Blacklisted
--   Depot 2812453: Blacklisted
--   Depot 2812452: Blacklisted

addappid(2812480)
addappid(2812481,0,"6a6125fd39d8e2b14b876b8a80d4c9759eb1a2a4dea5cbca31be0d1af0229ef8")
--setManifestid(2812481,"5262991014048659019")
addappid(2812482,0,"f35ee11ea8834c5f0730aa3d0a1b4d7966003d706a2157958424d6a3477a4f6f")
--setManifestid(2812482,"276151916071044410")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 4181110's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:55 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(4181110)
addappid(4181111,0,"b440cc420748cf604099a44b8d3d9b811dee8f6a87f31d297120d23dd18606e7")
--setManifestid(4181111,"2851667555963485122")
addappid(4181112,0,"b5421b21c0aa59bb42433ea99c1db279a7fc4814b83b944283e81694dccba0b1")
--setManifestid(4181112,"3803986689337798645")
addappid(4181113,0,"f91a5d550e2da020760597c660c24464b64ce79fa29170cc1718a99cf5e26f63")
--setManifestid(4181113,"7211713373216492015")
addappid(4181114,0,"c3e06f748087367b3f3a8c656edc46bc31c5206a7980a2f60b9be111fa359128")
--setManifestid(4181114,"6819422073683052543")
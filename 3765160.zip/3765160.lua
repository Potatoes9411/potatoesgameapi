-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3765160's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:46 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 19
-- Blacklisted Depots: 0

addappid(3765160)
addappid(3765160,0,"5b78c900a7483608719389bdb43ac66413c1beaf10878512157810cd0e229fc7")
--setManifestid(3765160,"8585531978810969086")
addappid(3765161,0,"dec7c6938b25c7b90eefbd85a2e84be916e7289cdabd94713733fd34dc2f626c")
--setManifestid(3765161,"463597309013094828")
addappid(3765162,0,"d92d5e23abd92584c7b48ff2bd0f7033f98fa681330047aa6b0d6aee47f9c5ed")
--setManifestid(3765162,"4692767067116231120")
addappid(3765163,0,"e28594b3a3b4c1f77d879a9df782217ffdd19570e4d9a18d3af983d3af86400b")
--setManifestid(3765163,"3536381136854163161")
addappid(3765164,0,"5627f5990063e55a6c6f25a4579163970a8c9fd6c845a0750da768a690c527df")
--setManifestid(3765164,"2690981102785675969")
addappid(3765165,0,"8fe55cc058b4aecd71e5b8cbfaecb61d30be04ca3121fe8f2e5d183ce24bb47e")
--setManifestid(3765165,"3372319281870848331")
addappid(3765166,0,"1791ca8899f063922d175458a6067be292632eea16ca5c838b426301bb946c17")
--setManifestid(3765166,"6644924975375537323")
addappid(3765167,0,"572ec0647cf77e5e1cb122f3fa21b7b598f6b035f3aa2c0d490a11343271b1c7")
--setManifestid(3765167,"6655793360999509162")
addappid(3765168,0,"466a90b27615d577b4ff8aba555bf546f0f00838289d326415382b15e9f44798")
--setManifestid(3765168,"2170958313401670839")
addappid(3765169,0,"9a4377061875358f35c9797bc335721fe1682a19e547e8e6d6836304ad093ca2")
--setManifestid(3765169,"1229462446582818494")
addappid(4103310,0,"2466b3575be7858ab659350b2f1651a676710b7da8ca07e5c6ca1f23c7e17adb")
--setManifestid(4103310,"4314241904812971766")
addappid(4103311,0,"ca977d0b630c655c92a11d10f7fcf59ea0db5b525fb5fa2ebb1adac4f5d25510")
--setManifestid(4103311,"2142941781390019904")
addappid(4103312,0,"85f79e03829ed62930013e897854a7d29477ed657cc481010c8f47f1f9d94d1c")
--setManifestid(4103312,"3445933748561110620")
addappid(4103313,0,"4120b2a7be8366c0cf7e7912e65f9dcf9e529ea0744d3f3141de9f27ba1de65e")
--setManifestid(4103313,"3065019163804094086")
addappid(4103314,0,"422e842b2682602b5ce006edd294c37bc195bd8492b61391b8cfeeea2484c97e")
--setManifestid(4103314,"3990792079306013209")
addappid(4103315,0,"5f197b98e69802abac686b1cf32b68e2b288ab1b83adfea4d7e7788777314685")
--setManifestid(4103315,"57775054859163230")
addappid(4103316,0,"1183a2478c25a5f4486b2a7b5401f8c1951403416a56f5283952970f3c9c64d0")
--setManifestid(4103316,"3605226351882688578")
addappid(4103317,0,"474a70d08205e001e8983e086704f4c5a767c71aad98cf371b666f1cbdfbe1c8")
--setManifestid(4103317,"6276886648458934384")
addappid(4103318,0,"32563e8356a07f84b6423ae90d1653a8724a8eee5b3e7a1ccd285b2e1cc162a7")
--setManifestid(4103318,"4958506426563187185")
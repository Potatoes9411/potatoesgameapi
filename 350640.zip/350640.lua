-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 350640's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:33 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 18
-- Blacklisted Depots: 0

addappid(350640)
addappid(459460)
addappid(350641,0,"34250b46fccba475fdb0461ef0446aaf59eedee59381ce0a5552098820051f17")
--setManifestid(350641,"7966217916078695193")
addappid(350642,0,"3f2b39c40fdf1584b915fc43cd81431992f5200d4eb2171ed15c09d363679113")
--setManifestid(350642,"1708732834047170927")
addappid(350643,0,"f108b1325a22a7b771f4a23c108a309d20723fc3bcb1f2ea11901e16d47a1835")
--setManifestid(350643,"591383356763888446")
addappid(350644,0,"6694aad0aa1725ae0a31ce2be8acf24420e969f304c9f8b6e03c72204cb24c3d")
--setManifestid(350644,"4624587159733300925")
addappid(350645,0,"e482a6742261466970350f091f7e0163683831b6a2bdfe8b568f49da087016bc")
--setManifestid(350645,"2392315309599583796")
addappid(350646,0,"0828ed9e82f16699f16d31e8b2c1bdf59acb65aaa8a17b64afeb036ab35fea19")
--setManifestid(350646,"6248668892888356225")
addappid(350647,0,"1fc33e239097dc654796f7231ddcd537225891376449534226be1ddb8d0541fb")
--setManifestid(350647,"9027999592872141330")
addappid(350648,0,"68058db483e909f24d782165becf9ff9115855174a428acfa5ccd7adb74244b5")
--setManifestid(350648,"6665176286780629514")
addappid(350649,0,"27e5757f8a418a2c9be09035bfcd479f48367edb420fa29e3d46877a8cf7fd69")
--setManifestid(350649,"6218847273057844970")
addappid(350650,0,"5762416a60502c004f77ccedc0a7cdf46e6dac19d73119146f89e1600bd37ecb")
--setManifestid(350650,"3777799376791598065")
addappid(350651,0,"715609277ddda81fb258841184398b1ed825d8bf15738e05587d031b499ae730")
--setManifestid(350651,"4777725750604820694")
addappid(350652,0,"27ce800eef018e335789758a15fc17f4c5cdc9e6ecc311f14d221b832e0f3e98")
--setManifestid(350652,"2600877031434313000")
addappid(350653,0,"6a092381752ebb8e29b58c41c6feb5dc70683346296d3963611193e0c8e220f0")
--setManifestid(350653,"7794399523805123744")
addappid(350654,0,"bf3f59aa00fd7d17ddb245991ed9ee6a5bf1d7adfe3b07bdcac50534f1f83cd0")
--setManifestid(350654,"6546433887891574789")
addappid(350655,0,"c200b3e500402962919ab267cd6c523495b389d0b38622b922830fac1646ce76")
--setManifestid(350655,"2863900101053535763")
addappid(350656,0,"505e8cf767c1a6d0c39e9ff6c5ce0ba0649bee7e16891ccfe757342e9218ae8f")
--setManifestid(350656,"7870947591905499969")
addappid(350657,0,"5a252f565caeb976df8c0afb975fbd0d8341ac21d2dd47c9c03f45932727fd50")
--setManifestid(350657,"3137313473532644046")
addappid(350658,0,"d98734637414002d29c94ecfd06e02b0f08103f72884f6bb13d2c919876a6f52")
--setManifestid(350658,"2784985946058245885")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2420590's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:59:32 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 13
--   Depot 2420116: Blacklisted
--   Depot 2420112: Blacklisted
--   Depot 2420243: Blacklisted
--   Depot 2420117: Blacklisted
--   Depot 242051: Blacklisted
--   Depot 2420244: Blacklisted
--   Depot 2420115: Blacklisted
--   Depot 2420241: Blacklisted
--   Depot 2420111: Blacklisted
--   Depot 2420114: Blacklisted
--   Depot 2420242: Blacklisted
--   Depot 2420119: Blacklisted
--   Depot 2420118: Blacklisted

addappid(2420590)
addappid(2420591,0,"546839bf5dc58928e2f8536c7d7a0c2ccf1cf94f89c0ac6a984e2ccf6737bcae")
-- setManifestid(2420591,"6614284492873294362")
addappid(2420592,0,"4f6347b1dd28ce33f406efc2f464f2e1c6f96a20b85c42d099f8209cc6ec40b1")
-- setManifestid(2420592,"6918548454045311330")
addappid(2420593,0,"090723882dbc404d0d58df5a1d28b6297603842651dd93f7c42d0460282fbed3")
-- setManifestid(2420593,"409131212748711397")
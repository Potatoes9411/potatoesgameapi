-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2641430's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:00:26 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 2641: Blacklisted

addappid(2641430)
addappid(2641431,0,"b6559d9db75f06a76626dfe43ba57cd6241d54bc03aaeea8d1363eec8a51a755")
-- setManifestid(2641431,"4254268694651458646")
addappid(2641432,0,"b56e3d7642c483619c3a55f99406175f376dd943506eb6d31030d9912731772f")
-- setManifestid(2641432,"3988263887698700415")
addappid(2641433,0,"ef153172ec4be78e7bf13cb852c36a76e0b18de6288944a7201ae6d24aafdee9")
-- setManifestid(2641433,"1241388989001093970")
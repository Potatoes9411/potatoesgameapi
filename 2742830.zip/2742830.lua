-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2742830's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:31 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(2742830)
addappid(3580220)
addappid(3993450)
addappid(2742831,0,"c2a5386e1f6feabad976ffd5e88028153d29a7d432483ee3763229bff9075fcb")
--setManifestid(2742831,"1826092964533251897")
addappid(3580220,0,"6a48b119fa0f4779ec8618000d21337750db9a1e0eac4f89cdf1afb16ea4a7ec")
--setManifestid(3580220,"5756384931734052985")
addappid(3993450,0,"7b7c0154d34e61c411d6cbee7be3ae571e2de654b27d75f2632d0cb1e786fbf0")
--setManifestid(3993450,"8605106753921413412")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2091500's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:52 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 2
-- Total DLCs: 0
-- Blacklisted Depots: 11
--   Depot 209163: Blacklisted
--   Depot 20913: Blacklisted
--   Depot 2091333: Blacklisted
--   Depot 2091021: Blacklisted
--   Depot 20912: Blacklisted
--   Depot 2091331: Blacklisted
--   Depot 2091332: Blacklisted
--   Depot 209161: Blacklisted
--   Depot 20910: Blacklisted
--   Depot 20911: Blacklisted
--   Depot 209101: Blacklisted

addappid(2091500)
addappid(2091500,0,"4f8d0e38ba63caee6d61c829e87f11c54a7afd5af4f65f04f7781d3767fb9332")
addappid(2091501,0,"4e845660c7eeae140561f31c279fb36b625f9c0277bda568e4a729dc867f16c3")
--setManifestid(2091501,"8997824064011326882")
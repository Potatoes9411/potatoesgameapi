-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 238750's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:59:23 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 4
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 2387921: Blacklisted

addappid(238750)
addappid(247852)
addappid(273480)
addappid(273490)
addappid(289570)
addappid(249740,0,"50295ad68c9644d9620fbb120f6a279c42e3c4561bfabb873edf6a17283d26f4")
--setManifestid(249740,"8170479550565178779")
addappid(238751,0,"a381f9792e1ebad56fc354e307dd22459a78f958549cbc94b70c8794ed227369")
--setManifestid(238751,"1281845346525417200")
addappid(238752,0,"40c0b8e3bc161ff03c89c203adb6c4cd838aa1b92f830c771d957fd47dc4fe7c")
--setManifestid(238752,"8130953805583141825")
addappid(1716751,0,"84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
--setManifestid(1716751,"1719625392615074191")
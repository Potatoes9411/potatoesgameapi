-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1942280's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:56 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 5
-- Blacklisted Depots: 1
--   Depot 1942101: Blacklisted

addappid(1942280)
addappid(1942280,0,"bf5b1b4f28c4d1839b85a86e3bfdabc5435f8cc848ca968aec505c86c6ecb52e")
addappid(2868390,0,"d7b9838655889932b120a4bd3426b37af101b334e6602a5898a1d54e4dc8f0f8")
--setManifestid(2868390,"2777400755728569813")
addappid(1942281,0,"414bbd1359869bcea73f5e7f3a911ba4a8f487dee2cf0290cd2409f9ae410582")
--setManifestid(1942281,"277496248407528484")
addappid(1942282,0,"3494683F2E70AFB7AE55048CE6D4C4FD6139904D7D783355A35BBAC4D1FD2A3B")
--setManifestid(1942282,"4040803135800041291")
addappid(1942283,0,"15D4A4598C84D88D00A61EF4BAEDBD99BBF62E47402A887EAD1872B8AA5C89E7")
--setManifestid(1942283,"5286060675495211046")
addappid(2868390)
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1817230's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:09 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 2
-- Total DLCs: 0
-- Blacklisted Depots: 10
--   Depot 1817075: Blacklisted
--   Depot 1817072: Blacklisted
--   Depot 1817076: Blacklisted
--   Depot 1817077: Blacklisted
--   Depot 1817074: Blacklisted
--   Depot 1817079: Blacklisted
--   Depot 1817071: Blacklisted
--   Depot 1817078: Blacklisted
--   Depot 1817801: Blacklisted
--   Depot 1817491: Blacklisted

addappid(1817230)
addappid(2076280)
addappid(2314670)
addappid(2314700)
addappid(2365950)
addappid(1817231,0,"0b72efdcb9381949af6d0260210821349bfd5047d33c3ed7e6a62e5fbbc9c816")
--setManifestid(1817231,"4289256744881784924")
addappid(1817232,0,"1fd310294fa59e457d3df62891cb2a4b9285b3e6a7d97adad3bdbf70106d4e4f")
--setManifestid(1817232,"6199582218233338422")
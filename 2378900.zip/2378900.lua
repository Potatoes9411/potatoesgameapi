-- Made by F1uxin, Discord ID:965053505901588521 | Discord Server (TGP | The Galaxy of Pirates): https://discord.gg/VfCxRsFyFe

-- If you're interested in distributing these files please dm me on discord (UserID:965053505901588521) 
-- (I don't care if you send them to a friend or to help someone, just if you add them in your bot or have them widely available then i would like to know.)

-- Socials: https://guns.lol/f1uxin

-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid", save the file, then add the lua file, (i think you can add the manifests too but I would just add the lua file to ensure it works).

-- If you have any questions feel free to dm on discord (UserID:965053505901588521)


-- Main stuff to actually add the game, DLCs, & depots.
addappid(2378900, 1, "5d5af2080591bab55c149876e568463033216f6ac49bb9d57e3edeec66115024") -- The Coffin of Andy and Leyley
addappid(2378901, 1, "7e8df27c22fc52c5f740357a93710dcdb613817ef5c9e61763f20eb28b73d525") -- Depot 2378901
setManifestid(2378901, "3682254389579820333", 744803416)
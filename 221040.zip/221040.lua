-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 221040's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:05 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 13
-- Blacklisted Depots: 0

addappid(221040)
addappid(228580)
addappid(232490)
addappid(232491)
addappid(232510)
addappid(232530)
addappid(232550)
addappid(232570)
addappid(232590)
addappid(235560)
addappid(236080)
addappid(228580,0,"2424887018c8183e1490b98ae7786a90d24e24cb4c46a61c123930c78811ab97")
--setManifestid(228580,"8273703995269190886")
addappid(232490,0,"5576dff2e35fbdbe881daa2b22f385222145d8b2016560f8b83f15a8275b90b5")
--setManifestid(232490,"4766891803519297317")
addappid(232491,0,"ce138b6addc4abf27fdae757fee938ddc6cc2a0fc526ddb484c39f0b022293f3")
--setManifestid(232491,"1501175007995626401")
addappid(232510,0,"869fa259e1abbcfb8025c3df14623821df402e9d48f7fb24fba8c705c072a868")
--setManifestid(232510,"3325491477400887902")
addappid(232530,0,"9c993db672f4e320225bbfab9902a6fae2222734c907028fcb48eacd096a1578")
--setManifestid(232530,"4578502731029880419")
addappid(232550,0,"6affc24729a4aa5d5f02e24aaf03e5f0421bad2aa32c382f53bc5bc17778b3c7")
--setManifestid(232550,"6419035047511949838")
addappid(232570,0,"7272f338b0b950923367dc0643d2ef343c943311af70b29001da02e114e31c90")
--setManifestid(232570,"4380680925184539415")
addappid(232590,0,"de3eaf13095e5567e271b41dd9ccc82f4f25a75b3a7d360dc52164bd56b08b62")
--setManifestid(232590,"5373308995109810588")
addappid(236080,0,"7cb295a70dfbb52b081ad5da1559010aba2c5244a4eb50a78970b04a2da695eb")
--setManifestid(236080,"7387874972474539378")
addappid(221041,0,"0caaeec12d875fdc90b98bc67e35c76e8783d1dcd937cf35c40a9c24e3a6255d")
--setManifestid(221041,"8522634851660930798")
addappid(221042,0,"6a1e95acc180950d80167ccc4f012db4f7db4bd51e7816f2a00359383633a0bf")
--setManifestid(221042,"6745134263174508495")
addappid(221043,0,"02962ce3b494d53c57bd61a826554005fb222503e6c0060bd26e2cc579a50b77")
--setManifestid(221043,"5001018017832008532")
addappid(221044,0,"3dd6e6a48115cfd940f98db42ea65096953bfeb0f276b9920dac8b314ac80baf")
--setManifestid(221044,"8789929426254680097")
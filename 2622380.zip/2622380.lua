-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2622380's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:00:22 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 5
-- Total DLCs: 0
-- Blacklisted Depots: 2
--   Depot 2622: Blacklisted
--   Depot 2622821: Blacklisted

addappid(2622380)
addappid(3319490)
addappid(3515600)
addappid(3515610)
addappid(3531720)
addappid(3637850)
addappid(2622381,0,"c3e9ccfedcda0cd10e53938e15261130b2e166007d2ca8f13aa5a05f06bd2630")
--setManifestid(2622381,"3117199117883238448")
addappid(2622383,0,"c6e496ba5ae5c8bfa358f3a7d923ec39964fa0a41c4fa77006249fe34e677af2")
--setManifestid(2622383,"4090476371378011797")
addappid(2622384,0,"029f67382779483e0b34bc2f1a1fae303e7f83a4efead9ed076448f386afd28f")
--setManifestid(2622384,"2688544108317953872")
addappid(3515600,0,"698188f58b73df7953b831a1e83a2b75cce4a3ec24d6c8ea3e3869bed96219dd")
--setManifestid(3515600,"6335101482081834234")
addappid(3531720,0,"7869ded55b93c8a360d2b867c0f4dd91e0e1eb8a1de01d69a93c907a736d996c")
--setManifestid(3531720,"455446701844620366")
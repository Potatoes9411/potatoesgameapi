-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 432380's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:59 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 5
-- Blacklisted Depots: 0

addappid(432380)
addappid(432381,0,"d5474073e484cdd10dacad0bab0c523ec95f53ebb93ad41332fa0a1ddf56c348")
--setManifestid(432381,"9198002354028220952")
addappid(432382,0,"bfb7ef03574034f5ed31e5bf7f612d28afe7919c537dde72b3fe5e8949a2f8da")
--setManifestid(432382,"7840226053957404212")
addappid(432383,0,"5e6103b1bea6d2290699d74503b591b123668bbf4e4782ea0f4b383b58c72772")
--setManifestid(432383,"1408448849203255139")
addappid(432384,0,"08d0bcfd5ba1bbd091ec231fc90156e6dcd924d30a73d4f757b4827b227c7763")
--setManifestid(432384,"8109569713581766606")
addappid(432385,0,"e9c46a9fe9df08193a2626fb714a0db7691fc69c29d97391e155bb0f49cdc917")
--setManifestid(432385,"4533304830795170466")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2216830's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:58:38 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 5
-- Total DLCs: 0
-- Blacklisted Depots: 5
--   Depot 221681: Blacklisted
--   Depot 2216771: Blacklisted
--   Depot 221682: Blacklisted
--   Depot 221683: Blacklisted
--   Depot 2216241: Blacklisted

addappid(2216830)
addappid(2216831,0,"7746df12b2bd4b831d8cb37e93f32255bd4f7eb1f5cf7120cda16756f44665c6")
--setManifestid(2216831,"8668276512970102607")
addappid(2216832,0,"3930e7ee91cb86c07d98b372bf5c7cd2c25f4410ff8c0d03af1b32ad71b7ea0e")
--setManifestid(2216832,"12367875578477684")
addappid(2216833,0,"7ba3de8cf1419c115233a71bee09f917a40a5ae972641acc4a205e6ae7a8d4b8")
--setManifestid(2216833,"8506205990165851770")
addappid(2216834,0,"1168caa391b5b3a16aac043cccb1d89b8bdfd859a019a8804254aee6a6c96d47")
--setManifestid(2216834,"4947001783250240058")
addappid(2828508,0,"86a8e078c58ea7fbf57bdf1b2611116fe069f5e590cfa11058ca6610e0961700")
--setManifestid(2828508,"5145691608909662874")
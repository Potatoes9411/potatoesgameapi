-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2338510's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:13 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(2338510)
addappid(2338511,0,"836b610c7c48e2864f6b250c86d82e081e4896cf4c01508252c9ea65e5f6139f")
-- setManifestid(2338511,"2552906802736424766")
addappid(2338512,0,"00ec12a4a43889fbcfce36cb1685964528fecdd6fe3ff93f2441a9a67f9de168")
-- setManifestid(2338512,"292530717409979626")
addappid(2338513,0,"33ec349cbfac8b02700e7c927645cd557b0ad8eef8b443edd61b746a9e619d8c")
-- setManifestid(2338513,"8117256113418486450")
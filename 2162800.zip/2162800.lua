-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2162800's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:03 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(2162800)
addappid(2162800,0,"615a243c485abe945a4ff4a2a3e6a1663325ef15432b30f2f772d747cb1a0d2f")
addappid(3075620)
addappid(2162802,0,"163ae6ae731b47cb94170aee0ed8a4d4ecc62c6082bc319cc270e20c5eb0f759")
--setManifestid(2162802,"6750290469553450360")
addappid(2162803,0,"9b7c2e9a0f8d2a28b522233286436b360fffb4830d45a69a5a0bf35573da8647")
--setManifestid(2162803,"5601829478146343248")
addappid(2162804,0,"aba21c81613972e41bf5e0131f382113d13fbdee073a02f7065cfc4256630232")
--setManifestid(2162804,"3938120160665648466")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3315800's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:24 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 5
-- Blacklisted Depots: 0

addappid(3315800)
addappid(3315801,0,"ba213fa3290ce16f247e42df2dfd40a9cf79729ef3624d1e817c07619339ab80")
--setManifestid(3315801,"8565672399745284608")
addappid(3315802,0,"0e4975095889c8a8076038bc7d1cce1581f7829ccdbcdefd5c75124c2c91e84d")
--setManifestid(3315802,"6322717299131688147")
addappid(3315803,0,"e299f034c495aace746c426151717bd2c3d149a3b9bf0523573a048ea32130ec")
--setManifestid(3315803,"5505887044643590820")
addappid(3315804,0,"359890583fcbe1693182e9a1cb8403d49cd73f5d4eeec37bd0ae6a754d2e5b53")
--setManifestid(3315804,"1845971767816363281")
addappid(3315805,0,"44b5c74be4124b3fb03545c13e930f576f79555e0a49dcfea5eaf76e0c76a522")
--setManifestid(3315805,"2938132418714775863")
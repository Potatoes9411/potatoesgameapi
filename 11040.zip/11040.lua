-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 11040's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:38 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 6
-- Blacklisted Depots: 0

addappid(11040)
addappid(11041,0,"5f07d895a954bc13c3a3083e9871145e318cbf4e5d54ac4d834354663301d682")
--setManifestid(11041,"482487261110174438")
addappid(11042,0,"0c416991f2088b7dae316501047dd94dae7f51eed138f1429d31bce5e341dad7")
--setManifestid(11042,"552939041209488854")
addappid(11043,0,"00b3e52738ada4ae4789393be122371ffccff940170b4af159c370e337fe528c")
--setManifestid(11043,"3856660354436097364")
addappid(11044,0,"f5eb194317ee7f992460beba8db0dcf988acd2c6341eec92775a1ae5c678086b")
--setManifestid(11044,"3725878411739183055")
addappid(11045,0,"816dbd8838aa3dd347e645f4b40fa24143a3b6caafed311aa6f62e3a3f5b9c9b")
--setManifestid(11045,"283914382315451049")
addappid(11046,0,"517e185a0076ecb7aa6d425db767b2e5513df78947f529f675e19c93a7d45435")
--setManifestid(11046,"5310894628399476394")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2949580's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:01:32 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 1
-- Total DLCs: 0
-- Blacklisted Depots: 25
--   Depot 294942: Blacklisted
--   Depot 294999: Blacklisted
--   Depot 294996: Blacklisted
--   Depot 294993: Blacklisted
--   Depot 294932: Blacklisted
--   Depot 294914: Blacklisted
--   Depot 294934: Blacklisted
--   Depot 294915: Blacklisted
--   Depot 294994: Blacklisted
--   Depot 294923: Blacklisted
--   Depot 294913: Blacklisted
--   Depot 294995: Blacklisted
--   Depot 2949261: Blacklisted
--   Depot 294917: Blacklisted
--   Depot 294926: Blacklisted
--   Depot 294998: Blacklisted
--   Depot 294921: Blacklisted
--   Depot 294990: Blacklisted
--   Depot 294916: Blacklisted
--   Depot 294927: Blacklisted
--   Depot 294919: Blacklisted
--   Depot 2949321: Blacklisted
--   Depot 294992: Blacklisted
--   Depot 294920: Blacklisted
--   Depot 294968: Blacklisted

addappid(2949580)
addappid(2949581,0,"85081af97dd5e355512fb526cd99075f1f2a1631b0285fd9412eec3e9195d498")
--setManifestid(2949581,"3347681605236332604")
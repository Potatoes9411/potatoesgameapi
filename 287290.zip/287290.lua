-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 287290's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:01:12 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 25
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(287290)
addappid(319810,0,"53a39700c8494c1a0aecd11cfc46c5fa1892b2e0d362601cbfd2be669a9e1d4e")
--setManifestid(319810,"8868881723047000134")
addappid(320350,0,"9776346fd31d33f094d42b1649b2d5e067971f1d322bc6c27bf2362378f6a35b")
--setManifestid(320350,"2283563465610488288")
addappid(320351,0,"7aceae0a437a8f22e55ec2fd0d70c2439f568e900eedce12b871b43c6c803008")
--setManifestid(320351,"5751501780775513507")
addappid(320352,0,"7a268e53783fdbc08d534ac971b7a696b770f23942803ca6d4d08bbdb0f0fca7")
--setManifestid(320352,"7954170132868010200")
addappid(320353,0,"15309a8e76ea76eda0d5fc2b81c59e97a44267f711454761e4247914c4f8635c")
--setManifestid(320353,"2134910798229961555")
addappid(320360,0,"9075a49f112b50412bcef290df8dfb0fcada5659a2884af000557bdf48fbf0bc")
--setManifestid(320360,"215137073275298612")
addappid(320361,0,"57da5165aa4915f42b703687917bfdc325932221fb1d359eb8ff376a3c545588")
--setManifestid(320361,"721423778186482167")
addappid(320362,0,"d08c7c74e61ad89f3e2fbb957c536dd103242971f5532d02bab19016675c8963")
--setManifestid(320362,"1901076864279174336")
addappid(320363,0,"4d3ba9e7d186d5abfeab5733ba3b66ad6bcd60d7979ca307bc6c8be6355ea5a4")
--setManifestid(320363,"6218749976762703332")
addappid(320364,0,"7c13b56551645ea86768f63c481daf346ffd0460159b1ce443fce7b7eb44ab6a")
--setManifestid(320364,"1636079505706795906")
addappid(320370,0,"c40e38eb2cd77e678e1d0199fee37c345fb4867dec3fbbe7184bc01b45fc5575")
--setManifestid(320370,"1792920206027701399")
addappid(320371,0,"894a8419dd99d9d4789ad3fdb26af975ddd2ed9392410ff09221fa91676e9220")
--setManifestid(320371,"8758334265280692826")
addappid(320372,0,"e303e0b4eba747c6beac716d23246f4540a05c6bd10e3dc7d16d0996ebcd62ea")
--setManifestid(320372,"3705913608377087123")
addappid(320380,0,"2ce8b359bc397de37a4894ec5279ff1b32590f978bb14d48021824e7c8f7469a")
--setManifestid(320380,"320423243038783490")
addappid(320381,0,"be3f46901f12ae522a3200a4bbcc5e31564a63a7f8120362198fe2de665b556c")
--setManifestid(320381,"1977461528599587408")
addappid(320382,0,"1bc60e607a66ea348be45a08469b6f9d5548a2c75c6af0ee9510bf5ad81bc8f4")
--setManifestid(320382,"1120496101071368155")
addappid(320383,0,"292114b7d25dcdd90ffdf2ae70bf4221837ed533514e18d6261b2ef4f0b08dac")
--setManifestid(320383,"1910462192276798612")
addappid(320384,0,"12a2834066ac426d0a7645d83cdda941fc19f3ceb446dc8e5fee5f6dd700d902")
--setManifestid(320384,"1385284676476203127")
addappid(320385,0,"78d89fded00bc816adb18a065ebacfab71db55c1a97b2f96bd6e47ce0c6c51c2")
--setManifestid(320385,"2498186336388008405")
addappid(320386,0,"3690861be3638379dbba02777752f7ebcb1d54de1737c8c95d0c7f7f3aafbd29")
--setManifestid(320386,"5487441784683558905")
addappid(320387,0,"f28a03bbe6ac4171bcde880aa1d66e83a0ebeb0c111a87abcf7048a4eea6d101")
--setManifestid(320387,"1316366148040976862")
addappid(320388,0,"c1308298693c0dd251da63594ebd524590841e68dbf0e328907fd4ecb8f26770")
--setManifestid(320388,"3753480374332702052")
addappid(353310,0,"fb47ed848fbd5a65bde94ef5fd88d17670c0dfc48aba5f5a91be5eaed3fd443d")
--setManifestid(353310,"8453554956492323464")
addappid(353311,0,"b96c56908603fbd2bd84bab165bdbf7cfb17dd8a5be97954c00da20897407d8e")
--setManifestid(353311,"4959558947909571185")
addappid(287291,0,"bc5ba048977d68842139f6abbd30e78adb6c33ff7d7ff1724d6594768c1def46")
--setManifestid(287291,"7492799466495753753")
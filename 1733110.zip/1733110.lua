-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1733110's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:00 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 4
-- Total DLCs: 0
-- Blacklisted Depots: 7
--   Depot 17335: Blacklisted
--   Depot 17331: Blacklisted
--   Depot 17339: Blacklisted
--   Depot 17336: Blacklisted
--   Depot 17337: Blacklisted
--   Depot 17338: Blacklisted
--   Depot 17334: Blacklisted

addappid(1733110)
addappid(1733110,0,"6c3007e160b8db8a1534cdc04cac231c5c141e4e9b82978d69a5070e6d012665")
addappid(2885390)
addappid(1733111,0,"2aefb5610aff8c017b461ec4f3da8d7a17a426b0d4ab6bf30df2bd99c391e208")
--setManifestid(1733111,"5142121594268572435")
addappid(1733112,0,"c8a5dfd8f65bf5c949c255c8fca8b013076e98f57ade13f59f7109a416664253")
--setManifestid(1733112,"8903157209862138943")
addappid(2885390,0,"f576d68dd367d474b2cab70ca21aa4b1ea75eacc3fbf41c70eb2913bb1c8541d")
--setManifestid(2885390,"2309400059646761733")
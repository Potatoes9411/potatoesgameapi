-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2180100's Lua and Manifest Created by Potatoes9411
-- Proton Hotfix
-- Created: June 17, 2026 at 06:54:44 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 10
-- Blacklisted Depots: 1
--   Depot 2180681: Blacklisted

addappid(2180100, 1, "Unknown")
addappid(2180101, 1, "b3d890b258520e34c7483c6658634ebc2406dbdd52e86287aa289f305ac32365")
setManifestid(2180101, "6589937511724656773", 0)
addappid(2180102, 1, "Unknown")
setManifestid(2180102, "Unknown", 0)
addappid(2180103, 1, "Unknown")
setManifestid(2180103, "Unknown", 0)
addappid(2180104, 1, "Unknown")
setManifestid(2180104, "Unknown", 0)
addappid(2180105, 1, "Unknown")
setManifestid(2180105, "Unknown", 0)
addappid(2180106, 1, "Unknown")
setManifestid(2180106, "Unknown", 0)
addappid(2180107, 1, "Unknown")
setManifestid(2180107, "Unknown", 0)
addappid(2180108, 1, "Unknown")
setManifestid(2180108, "Unknown", 0)
addappid(2180109, 1, "Unknown")
setManifestid(2180109, "Unknown", 0)
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2144640's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:58:02 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 4
-- Total DLCs: 0
-- Blacklisted Depots: 3
--   Depot 2144487: Blacklisted
--   Depot 2144486: Blacklisted
--   Depot 2144485: Blacklisted

addappid(2144640)
addappid(2144640,0,"7ca07b384ee60a80dd525456c888cf96619c7dad0c985f1d3fc0ec77c2ebeb9c")
addappid(3124440)
addappid(3142480)
addappid(2144641,0,"0a49695ed1feda3f6ad84629f01e5139b5793585af34810d1dbd600c5236c9bf")
--setManifestid(2144641,"5300263745427523283")
addappid(3124440,0,"5e5fe8829907e57c8d5c1c7a4fe0b54508623d0209237e8d2a11f073beae7932")
--setManifestid(3124440,"8072980921453709180")
addappid(3142480,0,"4ea89a642735f6b393f43e6955abb72aa78b652ee20420c3d874ddd29d1f9b96")
--setManifestid(3142480,"9043632041574392878")
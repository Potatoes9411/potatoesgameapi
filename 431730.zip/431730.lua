-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 431730's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:56 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 7
-- Blacklisted Depots: 0

addappid(431730)

addappid(431731,0,"ae6b4c4a88a371a4fd21577125f5ea30c0357ad7fd53b71e8e13151e1514f4a8")

--setManifestid(431731,"7719082479930692856")

addappid(431732,0,"bec3c1ab314a7950683c46967d19437a9585000dddd7cc3fe7b574890393cf03")

--setManifestid(431732,"5119504951584476512")

addappid(431733,0,"f8646edb63b1b41fc6a30339ab7e1a709f1a284c339d0ce5cb6f882ae45cad99")

--setManifestid(431733,"3611208017966391006")

addappid(431734,0,"78ff2ab0af57dab38635940ac44bb5403b0b82d742b819af46cbffed547a02c5")

--setManifestid(431734,"6464956817324409796")

addappid(431735,0,"a651627fae9ad10f137f7fc3baa8c713a220adb9cf7e050b9bff74805d2352f8")

--setManifestid(431735,"4371491280479930910")

addappid(431736,0,"1caf34b165502358dfcccd0d5ea126936c906b0f4a5596b003213fd75f2728fc")

--setManifestid(431736,"8176451254745515920")

addappid(431737,0,"a18f54a17911f5849254ed64da3a3ada5aa5b347b9065c7961f19d6e77069c1b")

--setManifestid(431737,"4834045670614581305")
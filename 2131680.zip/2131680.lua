-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2131680's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:58:00 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 2
-- Total DLCs: 0
-- Blacklisted Depots: 7
--   Depot 2131633: Blacklisted
--   Depot 2131632: Blacklisted
--   Depot 2131654: Blacklisted
--   Depot 2131011: Blacklisted
--   Depot 2131644: Blacklisted
--   Depot 2131642: Blacklisted
--   Depot 2131652: Blacklisted

addappid(2131680)
addappid(2131681,0,"e5b5860d0f5df9eb8eaee3a850ed74d1af440183694c9b7b8ba794d61ded777b")
--setManifestid(2131681,"2417906007247880811")
addappid(2131682,0,"899494a75b3ed1b05ae78b85ee635ed8fbbb534ef6999cf5f70e7970d780e130")
--setManifestid(2131682,"4864065857334375780")
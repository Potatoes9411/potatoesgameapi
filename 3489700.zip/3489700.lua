-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3489700's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:32 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(3489700)
addappid(3596170)
addappid(3596180)
addappid(3596190)
addappid(3596200)
addappid(3596210)
addappid(3596220)
addappid(3662250)
addappid(3489701,0,"2266ca31f6f2666ebe75906201e72f9398694030ff1c8214aacebcf74dc94ee3")
--setManifestid(3489701,"2747626496734343426")
addappid(3596180,0,"a55f79607c32a7e24a388464ddc3cfbc91b2dcee6691061bca3fb32d231ccb32")
--setManifestid(3596180,"8344797041293440177")
addappid(3596190,0,"1e65f8baa259f487dcdc1d3dce1e198dd23c9f7b77236e4e56fcc9f6b915a449")
--setManifestid(3596190,"6588499701851943951")
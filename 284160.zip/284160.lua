-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 284160's Lua and Manifest Created by Potatoes9411
-- BeamNG.drive
-- Created: June 17, 2026 at 06:53:49 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 10
-- Blacklisted Depots: 2
--   Depot 2841140: Blacklisted
--   Depot 2841141: Blacklisted

addappid(284160, 1, "Unknown")
addappid(284161, 1, "0e77f1cd7bb3169d9885cc26c7d2ef9fffc02c8c49671bec7b7308dd6cf86229")
setManifestid(284161, "90495859774692543", 0)
addappid(284162, 1, "Unknown")
setManifestid(284162, "Unknown", 0)
addappid(284163, 1, "Unknown")
setManifestid(284163, "Unknown", 0)
addappid(284164, 1, "Unknown")
setManifestid(284164, "Unknown", 0)
addappid(284165, 1, "Unknown")
setManifestid(284165, "Unknown", 0)
addappid(284166, 1, "Unknown")
setManifestid(284166, "Unknown", 0)
addappid(284167, 1, "Unknown")
setManifestid(284167, "Unknown", 0)
addappid(284168, 1, "Unknown")
setManifestid(284168, "Unknown", 0)
addappid(284169, 1, "Unknown")
setManifestid(284169, "Unknown", 0)
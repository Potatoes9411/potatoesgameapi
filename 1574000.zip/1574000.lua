-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1574000's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:56:41 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 1574901: Blacklisted

addappid(1574000)
addappid(1577540)
addappid(1807800)
addappid(1574001,0,"045607dda7329602fd5a11ffa52761ea30b46caeb9afe89c287448bc86941977")
--setManifestid(1574001,"7069286497366255038")
addappid(1574002,0,"87ee3cb9e8966fbfa5a8900bb8769d0c301b55d8b284c09b46a21673b5bd2169")
--setManifestid(1574002,"6615088700649553786")
addappid(1574003,0,"752df02daf3712fa78c04735170ec06e65306c0397fec15486dd70987f0f0a04")
--setManifestid(1574003,"4090409183798525022")
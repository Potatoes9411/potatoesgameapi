-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2089630's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:50 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 1
-- Total DLCs: 0
-- Blacklisted Depots: 14
--   Depot 2089203: Blacklisted
--   Depot 2089207: Blacklisted
--   Depot 2089208: Blacklisted
--   Depot 2089205: Blacklisted
--   Depot 2089200: Blacklisted
--   Depot 2089209: Blacklisted
--   Depot 2089730: Blacklisted
--   Depot 2089733: Blacklisted
--   Depot 2089201: Blacklisted
--   Depot 2089206: Blacklisted
--   Depot 2089204: Blacklisted
--   Depot 2089202: Blacklisted
--   Depot 2089831: Blacklisted
--   Depot 2089840: Blacklisted

addappid(2089630)
addappid(2089631,0,"def2446ad5022067f84d4d31d68388959aa288d7402c7886f3e9162625ebce04")
--setManifestid(2089631,"8913812651450869699")
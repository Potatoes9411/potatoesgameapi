-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2909400's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:01:21 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 4
--   Depot 2909790: Blacklisted
--   Depot 2909871: Blacklisted
--   Depot 2909581: Blacklisted
--   Depot 2909251: Blacklisted

addappid(2909400)
addappid(3260630)
addappid(3260650)
addappid(3260660)
addappid(3260670)
addappid(3260680)
addappid(3312260)
addappid(3312270)
addappid(3312280)
addappid(3361450)
addappid(3376810)
addappid(3260630,0,"39c8633805b12cb219e18d1665139d9ff5dd2a8ad30517ce3b29f1f935641f61")
--setManifestid(3260630,"2312058563762645934")
addappid(2909401,0,"7ab31662f5cf76b4197f27c340a2a0589dc4713c137aadfd22b281df42c07a56")
--setManifestid(2909401,"6351449259010459507")
addappid(2909402,0,"fd15686ace81b2e7a839997e1bcc40d7dd9c15f49ce21714252771aa357fd67f")
--setManifestid(2909402,"8874976628106391332")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1669480's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:50 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 7
-- Blacklisted Depots: 0

addappid(1669480)
addappid(3544160)
addappid(3544170)
addappid(3544180)
addappid(3697660)
addappid(3707380)
addappid(3743320)
addappid(3743330)
addappid(1669481,0,"86379ba94d829db600d16fb1a8228f1311045edc0905cd7f55c8e674028ce2e8")
--setManifestid(1669481,"4827611955625665804")
addappid(3544160,0,"907cfcb846ccb3902d350463e48db5bb1b98ec8850923efc377194340541da16")
--setManifestid(3544160,"8356537324760999203")
addappid(3544170,0,"9996513aa6cad3d5710da64183e284b73b62ded8ef8e8ff593cfa67634592351")
--setManifestid(3544170,"420946172877143068")
addappid(3544180,0,"210235486e18fe8d63473108a57641fcdbd4a2c673695d22e25b148138cdd881")
--setManifestid(3544180,"6423584201876442664")
addappid(3697660,0,"7a1b1c50379f373233659c2752efbd243877e437a08464c12dd718be2496e83b")
--setManifestid(3697660,"7677613033911163998")
addappid(3743320,0,"d19bec86ce212ba3c315f2baf7027efd91340fa6e62c89fd9f8bb1530c2cec68")
--setManifestid(3743320,"4628579506854312355")
addappid(3743330,0,"19ec17815de90aa3ba91854c3aaf515a2a895e2c0b17e6c34993cfc53efaf366")
--setManifestid(3743330,"6756484149332319012")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2400770's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:59:26 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 4
--   Depot 2400513: Blacklisted
--   Depot 2400641: Blacklisted
--   Depot 2400511: Blacklisted
--   Depot 2400512: Blacklisted

addappid(2400770)
addappid(3233000)
addappid(3908110)
addappid(2400771,0,"2702fa62592dc31adb894183b5c31b2408a5c5e3050c2c263441a0319cf00c3c")
--setManifestid(2400771,"8100823364049317574")
addappid(2400772,0,"aca4df4be197d145c81d925aaff43e8ab99f40932adc112e35f89e6cdb2c6253")
--setManifestid(2400772,"6606054109452572370")
addappid(3233000,0,"a4944acb674c6afff8251dfb07f4cabfcce477eac25c724619ec3b5e1ce5c0bc")
--setManifestid(3233000,"3437469253914081200")
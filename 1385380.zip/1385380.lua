-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1385380's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:56:24 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 4
-- Total DLCs: 0
-- Blacklisted Depots: 2
--   Depot 1385101: Blacklisted
--   Depot 1385291: Blacklisted

addappid(1385380)
addappid(2168960)
addappid(2325780)
addappid(2511580)
addappid(2666340)
addappid(2879680)
addappid(2879690)
addappid(3185630)
addappid(3185640)
addappid(3185650)
addappid(3473700)
addappid(3473720)
addappid(3795420)
addappid(3875470)
addappid(4013420)
addappid(4194030)
addappid(1385381,0,"212b4c54a7dadad3bb6a4a55088868dde54c128e58d7ce4afab3363c77ba1383")
--setManifestid(1385381,"8133528815012064858")
addappid(1385382,0,"18b37f64253b8d3e91a2b06f6a1e6446857b10fc0c3ef5dc99fda4e626054e9b")
--setManifestid(1385382,"80371309749591664")
addappid(1385383,0,"0671ea1b8cec86cac27391f005068b3758b9c4bf96d10f781893e87127a6b0c0")
--setManifestid(1385383,"1837076602595693793")
addappid(1385384,0,"5f65b73ec54888e940b46ea6f2de6b59069f8242617e44dde98d89adbf9d67a1")
--setManifestid(1385384,"513631380412175880")
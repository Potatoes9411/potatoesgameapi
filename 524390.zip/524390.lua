-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 524390's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 07:00:01 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(524390)
addappid(228985)
--setManifestid(228985,"3966345552745568756")
addappid(229004)
--setManifestid(229004,"5220958916987797232")
addappid(524391,0,"d0f906dbe47db053001d53f1890e418dc5d4d140d59eccf92ef66dff1f1d8898")
--setManifestid(524391,"8657387553729234608")
addappid(524392,0,"62f8228a77ed5a3cee2fd802c9afe806f501b4195cc37d66a5868be915a2d0b6")
--setManifestid(524392,"2473024292580695322")
addappid(524393,0,"24e1ec96a5877bd7352a4bf230ceb831592d4253b2d866cf16a89929bfbce826")
--setManifestid(524393,"3659946098419544439")
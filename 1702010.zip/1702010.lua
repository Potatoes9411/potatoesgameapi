-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1702010's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:51 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(1702010)
addappid(2513030)
addappid(3325090)
addappid(1702011,0,"f2e8eeb7cc1689a1ea8d6629b4508f6e7fecbce67e6f357edf333595eb339b5c")
--setManifestid(1702011,"8855693855504757592")
addappid(2513030,0,"18ec3a5505eba0fcd5921c7b689e7e8c9e1a0ff493714a27b24b3a7956a4e5bc")
--setManifestid(2513030,"6526575232393551523")
addappid(3325090,0,"9673fa9fb2c44fc342de6241970c6daff349558022f1267890bc136c73831a31")
--setManifestid(3325090,"7941291621359893864")
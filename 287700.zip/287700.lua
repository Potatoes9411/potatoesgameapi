-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 287700's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:36 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 2
-- Blacklisted Depots: 0

addappid(287700)
addappid(406540)
addappid(406560)
addappid(406580)
addappid(406590)
addappid(406600)
addappid(406610)
addappid(406620)
addappid(436030)
addappid(436040)
addappid(436050)
addappid(437230)
addappid(437231)
addappid(437232)
addappid(437233)
addappid(287701,0,"f1c3bbf22c23c0777bf23c71491e2398e216ade65fbd5597762b7fb64165dd4f")
--setManifestid(287701,"2518831260221836800")
addappid(287702,0,"5fff13d6b2e316f81e7fbce5e82cc9e77fdcc6c1daa0f723a3f347c1f2017287")
--setManifestid(287702,"5656962073680694207")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3586200's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:36 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 1
--   Depot 3586531: Blacklisted

addappid(3586200)
addappid(3586201,0,"eafd696be425c4717b7489a3a5339657e220f90e5f738f6080fbed9fbd4db2f4")
--setManifestid(3586201,"3349753276026728158")
addappid(3586202,0,"a084c9799ffdf8883f0e2338aaf470d934c29196674269db6605fc1031ee816d")
--setManifestid(3586202,"5303718065539927345")
addappid(3586203,0,"67de20e0cb9a846d0002ede4e0f497a4c577082711b3513325fbb03747bf7bb1")
--setManifestid(3586203,"2527757226890470067")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2868840's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:35 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(2868840)
addappid(2868840,0,"efe405b7cd4ee75b6961f28ad8ba9aa57a9e57057857dbd921e56ad3b347cd3b")
addappid(2868841,0,"ed043fd4ac0899cd0b5fc59d5407115ff4f87793b162ba16fe49c7e2893938ab")
--setManifestid(2868841,"4714514708397941145")
addappid(2868842,0,"7036cfd5ff85a70ca002aeddf573311c3906b0f7d8d83d099592e759ddca5b31")
--setManifestid(2868842,"5723017024281513170")
addappid(2868843,0,"6e4518ed758f09a3fb1c07ed1ef14a8ccfb4bac6e1fc452adc1e1d8a1c024e42")
--setManifestid(2868843,"5980382945911826237")
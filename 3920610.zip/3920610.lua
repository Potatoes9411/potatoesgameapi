-- Made by F1uxin (UserID:965053505901588521), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/NmmpgnAgen)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:965053505901588521)
-- And if you have any questions feel free to dm on discord (UserID:965053505901588521)

-- Socials: https://guns.lol/f1uxin

-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)

-- Main stuff to add your game.
addappid(3920610, 1, "8c9b8ce81e2921eea49b102eed1821aa883ad85645ff92115830bb24cbfa0bfc") 
addappid(3920611, 1, "12bffaedca2f7ee446211ba60b97b8262a19e282d803fde20b020cdd0d8ab780") 
setManifestid(3920611, "420622446576928235", 37447999995)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") 
setManifestid(228988, "6645201662696499616", 29212173)
addappid(4123380)
addappid(4123380, 1, "373ac671ea014e7cf29c347bbb4f27efa8fb93238f339504fa412757e9bd6b0a") 
setManifestid(4123380, "5477310769368099630", 1930386333)
addappid(4122450) 
addappid(4123350)
addappid(4123360) 
addappid(4123370) 
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1237320's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:56:03 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 6
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(1237320)
addappid(2079300)
addappid(2093240)
-- addappid(2079301,0,"db37953f414051736b6e659e9146fa2e081148a94633fbea635610f79d6588da")
--setManifestid(2079301,"3849979216096899603")
-- addappid(2089730,0,"dfb354863019c75a8143f9e7073ed589df096057283247fe5e16c1c6225667f2")
--setManifestid(2089730,"3889377523269958120")
-- addappid(2089733,0,"3dedee464853a2702ce024319deb87d57c6e2e404a328bce05f71b18a2649faf")
--setManifestid(2089733,"5603185428396252058")
-- addappid(2089840,0,"cf0ee3bde87a208b2bf9425b695b287a2997de71728df89f826fca1667197f85")
--setManifestid(2089840,"71486794841630932")
-- addappid(2093241,0,"9eac17d35c7a4d92c2bc39bbfcd5a64c61df1d4aed6c5dc7bad49f962d4780bf")
--setManifestid(2093241,"5565202849344929598")
-- addappid(1237321,0,"9c57e01f36d7bf7a77b07678b08a0e690d785dfbcd9a421ae1fc2157741b5ccd")
--setManifestid(1237321,"2773324310090316887")

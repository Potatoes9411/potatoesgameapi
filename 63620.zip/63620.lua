-- Made by F1uxin, Discord ID:965053505901588521 | Discord Server (TGP | The Galaxy of Pirates): https://discord.gg/VfCxRsFyFe

-- If you're interested in distributing these files please dm me on discord (UserID:965053505901588521) 
-- (I don't care if you send them to a friend or to help someone, just if you add them in your bot or have them widely available then i would like to know.)

-- Socials: https://guns.lol/f1uxin

-- If you have any questions feel free to dm on discord (UserID:965053505901588521)


-- Main stuff to actually add the game, DLCs, & depots.
addappid(63620) -- Cosmic Osmo
addappid(63621, 1, "21edb707c57d6f16c7090542a01a9f99094247634868f04fc49422ef73f5750b") -- cosmic_osmo_content
setManifestid(63621, "395749874867263964", 204704842)
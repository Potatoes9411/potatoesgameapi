-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3500390's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:33 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 1
--   Depot 350080: Blacklisted

addappid(3500390)
addappid(4059840)
addappid(4059860)
addappid(3500391,0,"febf6d8948ae4c2e1a199fa36f58cbfd6c5b3d81c130a612604f803316f5326b")
--setManifestid(3500391,"4414609150574936853")
addappid(4059840,0,"e36991eb8125945b9f99b2c11323010a5a918ad3f07b8bb7dc199a5cb4c49b42")
--setManifestid(4059840,"2274394409022129768")
addappid(4059860,0,"a4a1b191f1d28dd691f0e9197d0f156a0781b407a466d44a7e455aa97903b032")
--setManifestid(4059860,"1976583030948263159")
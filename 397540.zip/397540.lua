-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 397540's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:52 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 11
-- Blacklisted Depots: 0

addappid(397540)
addappid(397541,0,"88f77a801ca63cd0492b040858a57b62b748c774c5a1046d397b58b0c2cf836c")
addappid(397542,0,"64915689531d1c5e242ad493e198ee1a61a5757f84de8ed77e09f08a76c30847")
addappid(1232256,0,"7de46f8b2674a72ce84a910d86a255f02e6225ba00490119d3281e7dc2a4bcfa")
addappid(1232257,0,"201e40a8cc715029d3b43ea2fc07f83de91ddf73484115ed3225014584d6e6b4")
addappid(1233060,0,"f9f0b5e50d586c47ec01453408ce945c3038a22649a7b87505bf8bc91bc90486")
addappid(1233061,0,"72210c059f9f275f8f1c144209d5aa3a37c079f001ab59cabb1a114e606773cf")
addappid(1361830,0,"b601b7eb94614a5eb2b6f877b86e12c6fb79f7527ff4b1b7bf59d0a8b5b088aa")
addappid(1361831,0,"4a0968e321be58b271250dc3ab2ada1f3917b543d06f70e18f6da4a425844e5c")
addappid(228986,0,"51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5")
addappid(228990,0,"44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8")
addappid(229033,0,"9a789440bbc16131547ac6c062e5f168f7684da533a2899a71fdfaaeec21efc3")

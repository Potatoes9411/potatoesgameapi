-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2292800's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:11 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(2292800)
addappid(2292801,0,"eabaeaf0e86b550dc3dfb73dbfc87bf0ef141f3279e04f2e41ed631dc95c8f08")
--setManifestid(2292801,"4452691404151183904")
addappid(2292802,0,"7a289474a74fc72804ca64ca9f591d55f818de4a9735a0d632cc35d703d75ed7")
--setManifestid(2292802,"7913904129346798329")
addappid(2292803,0,"a87e91706df691b1d3a12b0b4d30d275ce14e2cbe02eb5d8af7ad8789552776c")
--setManifestid(2292803,"7140817813275851861")
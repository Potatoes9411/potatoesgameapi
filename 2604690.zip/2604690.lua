-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2604690's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:00:17 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 3
--   Depot 260476: Blacklisted
--   Depot 2604420: Blacklisted
--   Depot 2604491: Blacklisted

addappid(2604690)
addappid(2604691,0,"13296a58f6dcc80abc9435037005e817d8bf7c55bdfc41cfa7b69dcf209b7a0d")
-- setManifestid(2604691,"5109135419653780002")
addappid(2604692,0,"6840367f80736b251de348ba43cd7d0864174726f9970ec26ecaec4c81c45d50")
-- setManifestid(2604692,"341086347751642115")
addappid(2604693,0,"8b6de2c99e1bced7fb933575a0ea4d0236e40383d398c47930fd5967b42debd1")
-- setManifestid(2604693,"7707209378490821573")
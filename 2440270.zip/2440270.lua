-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2440270's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:18 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(2440270)
addappid(2440271,0,"dd032cc89523b67386b8f9c3eee496e1b6dedbf58d4ade15593e1b0f2fb9bbf4")
-- setManifestid(2440271,"4370100423949876626")
addappid(2440272,0,"c8cfa662cc9b565f46bbab0ed0f8408c3ceac2f92f8e86f95bae3bd344f29ddc")
-- setManifestid(2440272,"7201845872966001400")
addappid(2440273,0,"11c0a44eaf396baf46a9de22e68a8359f1c4e8f0ca18bd5b9646e7517caf62dc")
-- setManifestid(2440273,"8445083384505386739")
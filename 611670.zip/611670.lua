-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 611670's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 07:00:04 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 11
-- Blacklisted Depots: 0

addappid(611670)
addappid(611671,0,"1954b005f098c0b728ffb025193b3cd158a0ba414cd1313f1f71dbc3b216944d")
--setManifestid(611671,"3877383290467193767")
addappid(611672,0,"0d43fb9c02f61aed4427e57f6c3eeb9a22e962e4033bd574e55226ad7c9e55d7")
--setManifestid(611672,"1928013110065929089")
addappid(611673,0,"4dd9d036679051aff33806421299a6c57d9f0ad211fafb4ef0641f4eda78cc6a")
--setManifestid(611673,"4815482462544068657")
addappid(611674,0,"ea7729849ef0a50c02974a4504e1ac1305ffadf535a75b8b5224f5c120a480a3")
--setManifestid(611674,"1870271470279661303")
addappid(611675,0,"1fd3a8b3181b2e684cf7814083761b3341015519b4f665bd775e4eef9d770771")
--setManifestid(611675,"1030179458833278956")
addappid(611676,0,"59af015d179fd6576fc79e0da544c1bbbdd7e6f3e0c722554c6398a2274f2833")
--setManifestid(611676,"8886890815580383395")
addappid(611677,0,"10aa4916b4b0c966876d347dcc12705cdf9fda7b34306bbad419d95a9fbc2379")
--setManifestid(611677,"1677132629223966488")
addappid(611678,0,"48df4e99974a616f9d53a1ad0fa49d70aab24e0d51464120d4f85f5def9835b4")
--setManifestid(611678,"2469242488019796501")
addappid(611679,0,"fa3ef8074babacd54f4d400f9d26c0e708a9bad78dc36204f0a133e95144fdf7")
--setManifestid(611679,"865322299747175442")
addappid(824120,0,"1131768d48658f75a1c23ddc045ec6b28cb7e50f15327d99b08dfe6875ce30b4")
--setManifestid(824120,"7631913855644462826")
addappid(824121,0,"711a8e4a21f9720cb6beb933566b382543c8fe5e4a328e4efdb70397f6c66bba")
--setManifestid(824121,"8068773427951618792")
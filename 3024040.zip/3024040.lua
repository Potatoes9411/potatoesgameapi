-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3024040's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:42 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 22
-- Blacklisted Depots: 0

addappid(3024040)
addappid(3024040,0,"aaa00f3f7864c4619f9fc02c864424ca1a58a6d542b078c5284071c63dac2fd5")
addappid(3030340)
addappid(3030350)
addappid(4483540)
addappid(3024041,0,"e6dbd7bb633ba99b181c4f2b78584081739b918d60bb52b8a6414f7ec6a20d68")
--setManifestid(3024041,"4857037221968744870")
addappid(3024042,0,"cee5bb3c6821879a73a463e874470c6cf6291ca212a81e7a2c8b8a93c1972c05")
--setManifestid(3024042,"3757063865144812432")
addappid(3024043,0,"4c1134b41a5a46469b7d2243d9186953e7a488baef357d51dc9eb396a4cc46f6")
--setManifestid(3024043,"873171419003072363")
addappid(3024044,0,"81cc4f80b71ad448ede20a2640db15b2811e3e12b6d22d0d546ce3505642589e")
--setManifestid(3024044,"1088137779042847973")
addappid(3024045,0,"a561c929568d6348a419ecaceb98bb546ff2a2627a3961c87edc23dcc4e3cfef")
--setManifestid(3024045,"3965076937109870448")
addappid(3024046,0,"425cd1425f5e185c8d4f3fe53fba1cda0ea7879d02467283110e3e3acc7f23e3")
--setManifestid(3024046,"1744273595177814768")
addappid(3024047,0,"57c1a0ce1a0390ec70df63de6c6f7c065da56e05c83d0e54e46eeb292224614c")
--setManifestid(3024047,"2465317626921213985")
addappid(3024048,0,"7bb3a4737514c91349f81cd0318b3e66b5dfcbb4698fcd09a6eac88916dcb5fa")
--setManifestid(3024048,"8503801240290362869")
addappid(3024049,0,"7e215232c33f220ef09930ad2e3c6948ec70f2d14d33d7fef41d56e61e0db245")
--setManifestid(3024049,"108622452884032418")
addappid(3027330,0,"d91fb801febe39725557fdfcf82946ad7884e0b4e5aa7630522dea88f5d96212")
--setManifestid(3027330,"4863648196327894203")
addappid(3027331,0,"c43237459cf4603c8f4f70918b33e291d077819defebef4c0746273b8e14241e")
--setManifestid(3027331,"2433713479464448064")
addappid(3027332,0,"4117bd075ae087d0ec72666d3a234a004490138e87f87e05514f79b295d2e649")
--setManifestid(3027332,"6757471873019351740")
addappid(3027333,0,"371d29f78230e1fcec6e970770877372b517071b9134f84cdb3aa69a4f1b23e6")
--setManifestid(3027333,"19447405754157312")
addappid(3027334,0,"53d9efd5c358b53006191a10fa895c206ad769ab309015ea6aa42784bbcf0804")
--setManifestid(3027334,"5199314581566169748")
addappid(3027335,0,"7b0984c1f09baeb8b0d6368f28852f5151d161085f076702f75f8a0f8e86ddd6")
--setManifestid(3027335,"1622291478146198421")
addappid(3027336,0,"b5eb09168ec6aa689e7b1b7ec0f81ddffc813ac57951a4ecc14329d86b96adcc")
--setManifestid(3027336,"3519338426316120626")
addappid(3027337,0,"43a08c7dc38ee35c9749cf489fd36dd27a0abd54bc10a88631db9064bef31cd7")
--setManifestid(3027337,"2766038872151769556")
addappid(3027338,0,"72e0e7c4eac3cd13bef785415306f8aa6502570479395ed788e11a06462776eb")
--setManifestid(3027338,"8570109290297095864")
addappid(3027339,0,"28702311291eea464ba64a8380e75df96855073b2599b1e6209d36c6f4aa28b5")
--setManifestid(3027339,"5242013273423535851")
addappid(3027340,0,"62cf5a8053dee99101a84f5ace1d5332fa3ca9aa49204745f9eb9cff406a3594")
--setManifestid(3027340,"7574405747014823854")
addappid(3027341,0,"b706ae3f59d5b4c9affb04e4e69958495620a4209c5b546bd1bea638829c7fc7")
--setManifestid(3027341,"2421163427219067889")
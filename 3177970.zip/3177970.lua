-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3177970's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:19 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(3177970)
addappid(3177970,0,"587d40f5f69a60cf4ae9d1f82b9bcc5e7a8be6d0028b3228c320042030fa21b6")
addappid(3513460)
addappid(3177971,0,"559e6e3450ca7058329648e9292f360d400970bf869e4a68440e07912d3ac476")
--setManifestid(3177971,"6038910921347479193")
addappid(3177972,0,"cac467301f8871e1599a50e2c350b2b16b9ef3adf04cbbd932dd4a6d22fc479c")
--setManifestid(3177972,"8630593831466891285")
addappid(3177973,0,"c0227822f255bb0836dc6ea94d39abc7a62fb9ba541ea8d3162b11962a12fb92")
--setManifestid(3177973,"6911224253340460026")
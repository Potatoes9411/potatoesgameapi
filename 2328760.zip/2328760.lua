-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2328760's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:59:05 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 1
--   Depot 2328120: Blacklisted

addappid(2328760) -- Pinball FX
-- MAIN APP DEPOTS
addappid(2328761, 1, "ebd3cd9ab224746406fbcb2a4d335eaf3c716feea7869b67121f22b2ed8401ef") -- Depot 2328761
--setManifestid(2328761, "4884146215064203071", 44775525809)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
--setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
--setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(2351792) -- Pinball FX - Star Wars Pinball
addappid(2351793) -- Pinball FX - Star Wars Pinball Balance of the Force
addappid(2351794) -- Pinball FX - Star Wars Pinball  Thrill of the Hunt
addappid(2351795) -- Pinball FX - Universal Classics Pinball
addappid(2351796) -- Pinball FX - Jurassic World Pinball
addappid(2351798) -- Pinball FX - Secrets  Shadows Pack
addappid(2351799) -- Pinball FX - Williams Pinball Universal Monsters Pack
addappid(2351802) -- Pinball FX - Indiana Jones  The Pinball Adventure
addappid(2351803) -- Pinball FX - Williams Pinball Swords of Fury
addappid(2351804) -- Pinball FX - The Machine Bride of PinBot
addappid(2351805) -- Pinball FX - Williams Pinball World Cup Soccer
addappid(2351806) -- Pinball FX - Williams Pinball The Addams Family
addappid(2351807) -- Pinball FX - Williams Pinball Twilight Zone
addappid(2351808) -- Pinball FX - DreamWorks Pinball
addappid(2351809) -- Pinball FX - World War Z Pinball
addappid(2351840) -- Pinball FX - Garfield Pinball
addappid(2351841) -- Pinball FX - MY LITTLE PONY Pinball
addappid(2351842) -- Pinball FX - Peanuts Snoopy Pinball
addappid(2351844) -- Pinball FX - Godzilla vs. Kong Pinball Pack
addappid(2351845) -- Pinball FX - Crypt of the Necrodancer Pinball
addappid(2351940) -- Pinball FX - Grimm Tales
addappid(2351941) -- Pinball FX - Wrath of the Elder Gods
addappid(2357270) -- Pinball FX - Star Wars Pinball  Heroes Within
addappid(2357271) -- Pinball FX - Star Wars Pinball  The Force Awakens Pack
addappid(2357272) -- Pinball FX - Star Wars Pinball  Unsung Heroes
addappid(2357273) -- Pinball FX - Star Wars Pinball The Last Jedi
addappid(2357274) -- Pinball FX - Star Wars Pinball Solo Pack
addappid(2357275) -- Pinball FX - Marvel Pinball Original Pack
addappid(2357276) -- Pinball FX - Marvel Pinball  Marvel Legends Pack
addappid(2357277) -- Pinball FX - Marvel Pinball  Vengeance and Virtue
addappid(2357278) -- Pinball FX - Marvel Pinball  Heavy Hitters
addappid(2357279) -- Pinball FX - Marvel Pinball  Cinematic Pack
addappid(2357320) -- Pinball FX - Marvel Pinball  Avengers Chronicles
addappid(2357321) -- Pinball FX - Marvels Women of Power
addappid(2370400) -- Pinball FX - CastleStorm
addappid(2370401) -- Pinball FX - Carnivals  Legends
addappid(2370402) -- Pinball FX - Core Collection
addappid(2370405) -- Pinball FX - Williams Pinball Volume 1
addappid(2370406) -- Pinball FX - Williams Pinball Volume 2
addappid(2370407) -- Pinball FX - Williams Pinball Volume 3
addappid(2370408) -- Pinball FX - Williams Pinball Volume 4
addappid(2370409) -- Pinball FX - Williams Pinball Volume 5
addappid(2370410) -- Pinball FX - Williams Pinball Volume 6
addappid(2384910) -- Pinball FX - Homeworld Journey to Hiigara Pinball
addappid(2384911) -- Pinball FX - Borderlands Vault Hunter Pinball
addappid(2384912) -- Pinball FX - Brothers in Arms Win the War Pinball
addappid(2452710) -- Pinball FX - Honor and Legacy Pack
addappid(2452711) -- Pinball FX - Williams Pinball Whirlwind
addappid(2500340) -- Pinball FX - Williams Pinball Star Trek The Next Generation
addappid(2590200) -- Pinball FX - South Park Pinball
addappid(2677500) -- Pinball FX - Star Trek Pinball
addappid(2677510) -- Pinball FX - Game Night Pinball Volume 1
addappid(2677520) -- Pinball FX - Charity Pack
addappid(2677530) -- Pinball FX - A Charlie Brown Christmas Pinball
addappid(2915800) -- Pinball FX - Universal Pinball TV Classics
addappid(2947920) -- Pinball FX - Super League Football
addappid(2947930) -- Pinball FX - Pacific Rim Pinball
addappid(3169940) -- Pinball FX - Goat Simulator Pinball
addappid(3169950) -- Pinball FX - The Princess Bride Pinball
addappid(3225380) -- Pinball FX - Williams Pinball Volume 8
addappid(3749300) -- Pinball FX - Tomb Raider Pinball
addappid(3913690) -- Pinball FX - Williams Pinball Volume 9
addappid(4022690) -- Pinball FX - Williams Pinball Scared Stiff
addappid(4022700) -- Pinball FX - Williams Pinball Elvira and The Party Monsters
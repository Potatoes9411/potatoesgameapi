-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3065800's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:44 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 14
-- Blacklisted Depots: 0

addappid(3065800)
addappid(3569730)
addappid(3569750)
addappid(3569830)
addappid(4055980)
addappid(3065801,0,"0e21278144bf376c7d8a34cb2a28b38a275c0948bd8fc261dd86cba20a0b8ea3")
--setManifestid(3065801,"5824324816702037678")
addappid(3065802,0,"38a83f9c6804a02c2d936cf077be40121279da28d9e149a70a1e8ca56f42b259")
--setManifestid(3065802,"6442289980321782345")
addappid(3065803,0,"2496fa9f81f8aacaacfac61694400da95175f86b031427303fd5b0cff59775cb")
--setManifestid(3065803,"7600558926671633231")
addappid(3065804,0,"a9fb32de62e3185f7da88c5cfeebfa8be3e95f12fe7947c202c6c72cffd9463a")
--setManifestid(3065804,"5384055525140175288")
addappid(3065805,0,"d9c1100fd72d15632afa42ca88ef15942940bf1d9fe988e7ccd4f89956d9f1bd")
--setManifestid(3065805,"6798413815054975099")
addappid(3065806,0,"cbbe4001937a5869feb979a0735838178e11f396145a8ba3b429605559571e11")
--setManifestid(3065806,"1842476772863531743")
addappid(3065807,0,"64134cffcc214f0050db0303a38ff31eb6f9b0bd8bfc6fe6c54d7491cd2bfedf")
--setManifestid(3065807,"581092934313707647")
addappid(3065808,0,"c0465c21465d02c42fefc99f192d3fc7706c0fb1d5137d43eda0a230d32bd81d")
--setManifestid(3065808,"4176749539103506725")
addappid(3065809,0,"c70d1f620b43534dba5c2f6fecba228b93987bbe9e13b73e5ce82dcd44e9dd83")
--setManifestid(3065809,"1118728261617079316")
addappid(3551860,0,"38ae85dcafe40d80464799e89aba553a4a38b5056beecd7c1baa4e572a87d8b1")
--setManifestid(3551860,"6409813731161644720")
addappid(3551861,0,"95915f90c16210b1e78922f01e3256ab2d8cc91ce74f77a2a60b49eb8600dbfc")
--setManifestid(3551861,"4985956776007147203")
addappid(3551862,0,"7be7f43cb3baac63b8b48b58634ea732cb0e4dda0f16bbe34d08e3c86d5817c4")
--setManifestid(3551862,"4110728772883807589")
addappid(3551863,0,"3add136df05da956359e78385400e4f12ceb9ef369a49143158612d4a0414217")
--setManifestid(3551863,"99105723743314082")
addappid(3551864,0,"7ebd0fd7666847e4a3b10ee9ef53948296bfccdd0edb1f0167265d85b5f1c7e3")
--setManifestid(3551864,"5543324602787742492")
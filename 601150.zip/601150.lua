-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 601150's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 07:00:03 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 33
-- Blacklisted Depots: 0

addappid(601150)
addappid(940500,0,"db321935bd04473cba18b369e1acd0473cb81e2bb55da69831ad41dcdf53e017")
--setManifestid(940500,"7413960716303235231")
addappid(940501,0,"28000509908ca2d0497e06d545c29cecfab409c0bb6a5bf751ffc234d12c9857")
--setManifestid(940501,"5229117904072034661")
addappid(941950,0,"8146b03fb25b17f21109ba91ea88540806e540385eb7bd6ed55a64f22db3053d")
--setManifestid(941950,"1733062317174775810")
addappid(941951,0,"b5e89454b9414c94fab3a1237e3c6151e14ec0525878de309d604e30e6d24e2f")
--setManifestid(941951,"1793548331382100654")
addappid(941952,0,"8dff48be626e1466d5f18f3f928cf632c786a147e8ef01e4cc923f299ae06204")
--setManifestid(941952,"7836766670222491839")
addappid(941953,0,"2483c086da18c77fca6d239e76ae60418ebad0a7fbbe85c43a732bdf63a4f478")
--setManifestid(941953,"8310295697438327235")
addappid(941954,0,"22905c649c0a7638085caf1e214cb2baa0b318ce6e85e390cfd57b57d70acc44")
--setManifestid(941954,"837912433757808297")
addappid(941955,0,"6cd170931e9c36ade24b4efa0e76e557ccee246c7899889d20ddfc2761568f0e")
--setManifestid(941955,"6069115808325012717")
addappid(941956,0,"840af37970ff6003db44925b89968dbc86f18a4f5ea7728a1b0527ac99767ee2")
--setManifestid(941956,"5302859582744244072")
addappid(941957,0,"36fb473794fc8ea317869c201a1e126cf16b054c69132fc5d6db7c693fa6a09b")
--setManifestid(941957,"6916454231030537530")
addappid(941958,0,"b676ca88b7d114adbabc10ecc30bab4799e64f22c33446b6a32e83b457454f8e")
--setManifestid(941958,"8571966787997831230")
addappid(941959,0,"57e54ceec36fa9afb6cef347ba469cfc614c41f3eeeb6cb5ba21b5531ec5b069")
--setManifestid(941959,"356846819042459435")
addappid(941960,0,"b0ce9acf93f79c995ec418457777b85f9083c219e2350d862f4b27b1c46cc03a")
--setManifestid(941960,"6463853996233742067")
addappid(941961,0,"9ad10323310d52b75d24327b4492681b195879888808e6b7676584ee73e602a4")
--setManifestid(941961,"8880438414751949738")
addappid(941962,0,"fc71c9a1af83ec94a44bfe222d0bfd90e656a41f630d450c91f1e390ce8a0e27")
--setManifestid(941962,"2042862104026645730")
addappid(941963,0,"9347ac6dd53eb62c2fd10b9d4cada1c0d75590f7b23af361635ada1adbd8576c")
--setManifestid(941963,"8463787236633176238")
addappid(941964,0,"27a459ec4dbbb6c57cec3bbb0918eac697c410b77c0b6f58b6952b1e647823ff")
--setManifestid(941964,"6178417925001500048")
addappid(941965,0,"0859cec81d7a2d700a41952dc882dd2e6bb1ff8e3ddbb80efbe4e844859e05cb")
--setManifestid(941965,"4567030356497547206")
addappid(941966,0,"e7d494f9e5d03fbe0de65683b16e9c497a14d52b382582cbb56c082cbaa9665e")
--setManifestid(941966,"3894647195957834299")
addappid(941967,0,"83ca5459c1ac0c148a804381066fbe0169e4fb7164c778cb87c127d90a729986")
--setManifestid(941967,"4320090065644073508")
addappid(941968,0,"8a5969464b691846bcc55329ad079d4942db5462ef2dadca33b2542de8c060ad")
--setManifestid(941968,"7938728316001059583")
addappid(941969,0,"25c71ada00c2ab00725ff0a0357419440a4d8ca8d53c2c01840ccd1584b0a081")
--setManifestid(941969,"1975364972596125654")
addappid(941970,0,"9160a2957b443567516304ee567195f1d1b764b953a3a87696a475ed70bac0f4")
--setManifestid(941970,"6530594450675633820")
addappid(941971,0,"3cb4fb3259a27f93ba55d57e33095f05f37b0857d6910a295adef2f76f06264f")
--setManifestid(941971,"3217701174541188638")
addappid(941972,0,"a635a59c448abd85e82f66725f165e3ada3836a52d3085a42ae457ce2c9a0495")
--setManifestid(941972,"4382130040615286187")
addappid(941973,0,"73e516d5614a82b39a3871c7d7ec531a64d733433d0074eaaaeb8fba88b760b4")
--setManifestid(941973,"8505788485278530046")
addappid(945600,0,"75c3bd851a87a16db2f06576a3c2fe55a5a46fadd905763369ac503d9f4d6b34")
--setManifestid(945600,"1049804611294232219")
addappid(1432640,0,"ad27e4adecfeebddb59585bb0cc782ff19110b37e71727db16773fc7f163c5f2")
--setManifestid(1432640,"5156559174384676617")
addappid(1432641,0,"cf7ccae95bbb188fb00c15fff94110f47da8b1a81568b97ac048d8b08d8ff565")
--setManifestid(1432641,"4622666309481266876")
addappid(1432642,0,"b934aa77981e2ec0ba78938cee0a6784c0f3d6e90275ebaed59103671c8af5c8")
--setManifestid(1432642,"3752668043537101024")
addappid(1432643,0,"d766c1b6bf790cbc12456eee09056a8f6ca4022fac09312f11b98a5a5ad0faf4")
--setManifestid(1432643,"6950015429532708433")
addappid(601151,0,"8044d37b8d329e3e7d4a9006b3714cf2fab0d9e01f4c52e8bf9de594d7d56616")
--setManifestid(601151,"5034340940015103443")
addappid(601152,0,"c7b902e53de220fc8e8c2c70865f3715efb354728b674632f29c0a05d0106b49")
--setManifestid(601152,"37045512487732505")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1857080's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:12 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 3
--   Depot 1857951: Blacklisted
--   Depot 1857952: Blacklisted
--   Depot 1857091: Blacklisted

addappid(1857080)
addappid(1857080,0,"83b0560e7dd05cd8c6f1c190b12c52b9c79ee662bc1a087f6b495244c6fbc6b8")
addappid(1857082,0,"da7ba42e5dc0fab717beb28a4fbae2ec0da3e4805937202e20fd4ada15520b16")
--setManifestid(1857082,"2279820343410092222")
addappid(1857083,0,"d31765f2383e42a54b6614804aa4f36915de4b8d6615fdcdcfce3f873f158f82")
--setManifestid(1857083,"6066517445633955551")
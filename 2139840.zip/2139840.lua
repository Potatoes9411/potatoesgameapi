-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2139840's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:02 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(2139840)
addappid(2917800)
addappid(3499570)
addappid(2139841,0,"8e5a3c405ffabd82d236d99d5583d2b3836f045da51e2328b307e3001f8c5977")
--setManifestid(2139841,"2471489941724014279")
addappid(2917800,0,"dbc011392a0ba87ff9bac5b4416119c300fedab9b8c80bee0d84805f333e1759")
--setManifestid(2917800,"3951830197964649115")
addappid(3499570,0,"3caa208f290f0c77823ae9ae7f9736373723d430c540abf078a841a91b486352")
--setManifestid(3499570,"8198624794878999465")
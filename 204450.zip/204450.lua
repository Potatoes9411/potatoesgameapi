-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 204450's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:59 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 4
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(204450)

addappid(204451,1,"3d148329ddf232af3fb18f4858b48bb6996f9ad8e772fd2c704514914bf422d9")

--setManifestid(204451,"6466535045316228659",23199330)

addappid(204452,1,"8e9a42fdf74eee72bfa07718ed0ae0aef8cb3566eb7493a64f15977ca7683ded")

--setManifestid(204452,"779876568638164487",2205953421)

addappid(204453,1,"8831bf46c3566b71a12f27a27e95fd784a2485c1d51d3e4ae59c0b0c58c640b2")

--setManifestid(204453,"6249518467060031795",2762578409)

addappid(204454,1,"707c61aedb78b4c745d9030527750bd9ed00d3004bc8344257ccacf41190b701")

--setManifestid(204454,"611700607188462372",1787680)


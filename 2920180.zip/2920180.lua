-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2920180's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:01:24 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 1
-- Total DLCs: 0
-- Blacklisted Depots: 21
--   Depot 292034: Blacklisted
--   Depot 292044: Blacklisted
--   Depot 2920511: Blacklisted
--   Depot 292045: Blacklisted
--   Depot 292001: Blacklisted
--   Depot 292039: Blacklisted
--   Depot 292035: Blacklisted
--   Depot 292031: Blacklisted
--   Depot 292046: Blacklisted
--   Depot 292038: Blacklisted
--   Depot 292041: Blacklisted
--   Depot 292048: Blacklisted
--   Depot 292036: Blacklisted
--   Depot 292032: Blacklisted
--   Depot 292033: Blacklisted
--   Depot 292047: Blacklisted
--   Depot 292037: Blacklisted
--   Depot 292042: Blacklisted
--   Depot 292043: Blacklisted
--   Depot 292040: Blacklisted
--   Depot 292049: Blacklisted

addappid(2920180)
addappid(2920181,0,"c991e78f71c3d139fc38b1f94c5e6b3b3c797d7acc3467503336001248139e19")
--setManifestid(2920181,"2849280858722539793")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 209000's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:50 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 22
-- Total DLCs: 0
-- Blacklisted Depots: 11
--   Depot 20906: Blacklisted
--   Depot 2090371: Blacklisted
--   Depot 20905: Blacklisted
--   Depot 20907: Blacklisted
--   Depot 20908: Blacklisted
--   Depot 20909: Blacklisted
--   Depot 20903: Blacklisted
--   Depot 20902: Blacklisted
--   Depot 20904: Blacklisted
--   Depot 2090850: Blacklisted
--   Depot 20901: Blacklisted

addappid(209000)
addappid(237613,0,"14824687eac8cafa76c06faf6dd87bd8120b058514c5732eb2446fb389de3cb9")
--setManifestid(237613,"59544344938750174")
addappid(237615,0,"aeb4adf888d0b5bcbee2974c5b8d3b5168b9c6a966e90b9b87f32b9a0781475d")
--setManifestid(237615,"42058695844308960")
addappid(237616,0,"510adce639c375a38e5a15dcf4167530fbe254156255f942ce2c6383370797cc")
--setManifestid(237616,"86300889472213919")
addappid(237617,0,"7eebb41ca166843c438b20dfbb7a8e9e3118776ccac673418393a060f3baa6f8")
--setManifestid(237617,"47616188141389102")
addappid(237618,0,"9f7bc073e0c50f4a9b20811ae5abea8f9ae98cf4533d79a9edc3423ff96d1de4")
--setManifestid(237618,"238727171855921815")
addappid(237619,0,"9e975f440061a632e2632cbab6381d062a0377697f9cd8b5b4baae0561781306")
--setManifestid(237619,"2968141500099658504")
addappid(237620,0,"984bd32ad0fedd1bd5ba00eecb5581ef6bdb0de49dfc802bf3c85ebb776a6965")
--setManifestid(237620,"291659265756130075")
addappid(237621,0,"dbe0682e42186c4645b17cbef630152fcd945bf8db52af15a9e698f179203f9b")
--setManifestid(237621,"193572760426704607")
addappid(237622,0,"ff61aa614ba3ff2b3a25de5762d8114e7afb7a2bf679730dfd3c4b95f34f7e95")
--setManifestid(237622,"447688492637553775")
addappid(237623,0,"3ea5c90b5c11e18fb70c151909ba805022d3765b2470342e70c4d2ff9a65c03b")
--setManifestid(237623,"164024816323774951")
addappid(257070,0,"90d24fd39def59cc38c2b91ee308ec8a53e01970f72a6942499d7018bf253a96")
--setManifestid(257070,"386829247995520577")
addappid(277830,0,"6c15ae569ddecfe0f84c2fa337cc7483e124646a7c616bac6ee548ce6f6a8375")
--setManifestid(277830,"5403156598974731213")
addappid(209001,0,"f5c100e9d6d4f1a524c3704ff3ef0e14933ca21f52c57fb607302527856d99ea")
--setManifestid(209001,"3461941926504860294")
addappid(209002,0,"bfa7a84d592cab2693fe595a5f60612759a409377e68b01dff493425fc710c8f")
--setManifestid(209002,"5279375398140027418")
addappid(209003,0,"a77395939294ede504549b276cf392f33229c12cf25a92640d658904b740594d")
--setManifestid(209003,"6072903106311597909")
addappid(209004,0,"a02b22c7093dbc7c27960996cbe5b8d7e84d3249e0fb37614c803468ad87b989")
--setManifestid(209004,"6962761681899419745")
addappid(209005,0,"e0bf4517c3964dac1250280f7d11e70cf2789347ae475200ed8f3e8766bfa4b9")
--setManifestid(209005,"8862212808483926542")
addappid(209006,0,"ac849826385f5ab7fbcebe89dfe2765bb2e42f877d59293814f3320e76a6199d")
--setManifestid(209006,"5317034876422030410")
addappid(237611,0,"f43e366258baf0e175af8b1a3c72dae9451616dc8422bc0b0bffb47f5ef72032")
--setManifestid(237611,"104515676782256082")
addappid(237612,0,"9348a1875140552d806f6bd09e956f54cf0ddcb897f975231d894d5c5b494b11")
--setManifestid(237612,"85033816772681601")
addappid(237614,0,"6fca7e127f49b34286c449384862aad750a20e894b27d34295a69d831d0b1a62")
--setManifestid(237614,"263483447526310295")
addappid(250960,0,"7ea3aba98e7d2484dc3df0a93b78902df72e82793e03a54826a4c0e122212f51")
--setManifestid(250960,"1142759452489079425")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1432320's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:45 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(1432320)
addappid(1432320,0,"8ec1bb0d94a61594f9a08f4b3aeb0373f8527dcd9c4f746ea513c3c68f262b20")
addappid(1432321,0,"99bc05320984dd6078a99518238843bb7fc37cef65bd423e3194683fbb9c4457")
--setManifestid(1432321,"3448429212337948823")
addappid(1432322,0,"895724ef060c75590e7961c174879706c5be370003c34a59e5f6306ba2502759")
--setManifestid(1432322,"5882186711933687410")
addappid(1432323,0,"551fe99e54c7a9fa061b96ff8bb42e56f2f19106f1679922ae47d087b29687c7")
--setManifestid(1432323,"6808011651695841759")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 78000's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 07:00:06 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 10
-- Blacklisted Depots: 0

addappid(78000)
addappid(78001,0,"865fce9e0b0dcdcfc4031e276e5b63e9b7c5a8c51d718f9a2a05eb14a0bf23fd")
addappid(78011,0,"de804aeeb35ac6a23409fc1b9ed40441dd810ee0bd3f8c50266705b2072fa573")
addappid(78003,0,"6e2ac360a81f5d4364e527c5e1b3f676cffa0897947d643be9f710d831463379")
addappid(78004,0,"55daba45c7648037e59f0172938d292b8b31ce3c107679849712db8fbd4df672")
addappid(78005,0,"6d8ae29e7ffa025ec04aefb0400fbcaa99a721bd432bcae0f8f2ef6e9fd5576f")
addappid(78006,0,"fc87301f4a6436d49edf95f3f6bed9167780ce343979ff00efa8d709db147fe6")
addappid(78012,0,"2eeede1652fa4a45d9864c401d16d92554b678bc760c76aa2f961e70574c4e0d")
addappid(78013,0,"bfb6aa7f1788c0dfa6d7e90ab7cd048d837717c3df40e9f72fcce2f1ec2be4d6")
addappid(78014,0,"9ec697875da3d54311decd097fe86f459266d7d4d43d967ad6611ea29d9759bd")
addappid(78015,0,"73777494611ccdad8feaff491d574376a36258a0e870492219ee2b175ec94e1a")
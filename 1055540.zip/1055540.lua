-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1055540's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:37 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(1055540)
addappid(1055541,0,"357f3583b508bf2b30b0ef89c3473521718cbc8b93c0c54310a4c47c8d15bdf2")
--setManifestid(1055541,"8994416012488509370")
addappid(1055542,0,"bf61fb6ad4ff0581ec0c16d2c5682ad3440abd78d64bd9d78f541b8c58049d1e")
--setManifestid(1055542,"8544185365233604858")
addappid(1055543,0,"f18ee22cbd474dc50d6ca97b6661b3d912dd2d6157eedefa3e8ae2efdb30c65e")
--setManifestid(1055543,"149383706910377774")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 233720's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:59:07 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 6
-- Total DLCs: 0
-- Blacklisted Depots: 3
--   Depot 2337093: Blacklisted
--   Depot 2337092: Blacklisted
--   Depot 2337091: Blacklisted

addappid(233720)
addappid(317960)
addappid(233721,0,"d35dca79d15aceeb962840cc06af9c61dd038f5cf9283e469663fd63ee090a5a")
--setManifestid(233721,"8469634463222804287")
addappid(233722,0,"63af86194cc3a9165b47d4344897c1743432d6742191044190b5b204d2b8ccfb")
--setManifestid(233722,"3024770143432895355")
addappid(233723,0,"a0811369f5094519a9e049496ad5bd2c1aae633160a78379d4ecd72818a89356")
--setManifestid(233723,"2273141338475583055")
addappid(317960,0,"ccd7ea8b717679799cd07c3fdce7e842480e377d8f9fe60df8b41f7900eabab5")
--setManifestid(317960,"8797057588258470615")
addappid(317961,0,"2b6038ba81cbc0cd78b769403e6822aa29cf3717c0b645c48f41d41dfab893a7")
--setManifestid(317961,"5653254213267219564")
addappid(317962,0,"a5d9976e325380413a3388d77d30a268d8e28b8702e4e370b08f98178ffb4660")
--setManifestid(317962,"7756701100521687015")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2962480's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:39 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 2
-- Blacklisted Depots: 0

addappid(2962480)
addappid(2962481,0,"d9345f83134c749ad77cdb18ce1544ee36df1df3b93db011fdd4e9fa5236874c")
-- setManifestid(2962481,"6792619105171433661")
addappid(3699311,0,"e6fc101b1e5399cd878cad8d69a41fb4f1ac44bbc23373f6ee91f1146de0f4a4")
-- setManifestid(3699311,"6569860395868396042")
addappid(3699310)
addappid(3699300)
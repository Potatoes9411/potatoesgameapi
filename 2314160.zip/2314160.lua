-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2314160's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:59:00 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 2
-- Total DLCs: 0
-- Blacklisted Depots: 25
--   Depot 231437: Blacklisted
--   Depot 231432: Blacklisted
--   Depot 231440: Blacklisted
--   Depot 231433: Blacklisted
--   Depot 231436: Blacklisted
--   Depot 231445: Blacklisted
--   Depot 231441: Blacklisted
--   Depot 231447: Blacklisted
--   Depot 2314211: Blacklisted
--   Depot 2314210: Blacklisted
--   Depot 231435: Blacklisted
--   Depot 231448: Blacklisted
--   Depot 231442: Blacklisted
--   Depot 231438: Blacklisted
--   Depot 2314260: Blacklisted
--   Depot 2314280: Blacklisted
--   Depot 231431: Blacklisted
--   Depot 231446: Blacklisted
--   Depot 231443: Blacklisted
--   Depot 231439: Blacklisted
--   Depot 231434: Blacklisted
--   Depot 231449: Blacklisted
--   Depot 231444: Blacklisted
--   Depot 2314282: Blacklisted
--   Depot 2314212: Blacklisted

addappid(2314160)
addappid(3812850)
addappid(4202680)
addappid(3855050,0,"dd1a6b1ef84c589594a42a46ababbdb918e4d2e3cb6a944d7ea3b742d6222591")
--setManifestid(3855050,"7579042551228100704")
addappid(2314161,0,"5be7927a7b9161b7c4faa65d50810e4337a6ec964921f4cc0d37d8003e72bed0")
--setManifestid(2314161,"282157817096321198")
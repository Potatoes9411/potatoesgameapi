-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2092840's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:52 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 2
-- Total DLCs: 0
-- Blacklisted Depots: 8
--   Depot 20922: Blacklisted
--   Depot 20926: Blacklisted
--   Depot 20924: Blacklisted
--   Depot 20928: Blacklisted
--   Depot 20921: Blacklisted
--   Depot 20925: Blacklisted
--   Depot 20923: Blacklisted
--   Depot 20927: Blacklisted

addappid(2092840)
addappid(4012990)
addappid(2092841,0,"5e4d0f245900061c32fbb61025c8bd3b4aa38919205b6fd83ba4ecadcdedcc83")
--setManifestid(2092841,"1091308342735319525")
addappid(4012990,0,"048df12b5011da9da9abe27ac49ce45dc2545810c56653a3a066c1281fda6c76")
--setManifestid(4012990,"92848684427552922")
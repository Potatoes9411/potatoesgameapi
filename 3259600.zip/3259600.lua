-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3259600's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:23 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 10
-- Blacklisted Depots: 0

addappid(3259600)
addappid(3811090)
addappid(3811100)
addappid(3811110)
addappid(3811120)
addappid(3811130)
addappid(3811140)
addappid(3811150)
addappid(3811180)
addappid(3811190)
addappid(3811200)
addappid(3259601,0,"ae634a9eec6e2ae45901364376e5c088e269ae26071c8b7741b4a9b681bdf85c")
--setManifestid(3259601,"4368272776508149825")
addappid(3811090,0,"c6402a39e57409af780a6941b3eb551458899ac990877fc4eae4085a0e6cd963")
--setManifestid(3811090,"1726989443599217291")
addappid(3811100,0,"4c981d6c3b8f831fbb44d55631fb10454974be174034b5ca814d4eea4d3d4141")
--setManifestid(3811100,"6680185506960841905")
addappid(3811110,0,"fdb0f863798896be92f76b7738c9a5e7a6c9b6616d4afd4e28216cbae0aa631f")
--setManifestid(3811110,"5582534334480437529")
addappid(3811130,0,"3b21d7253db784922ca1da073dc42392f86a5587d1df1ed179a785d0a566e4bd")
--setManifestid(3811130,"7148128073758934615")
addappid(3811140,0,"a58f936ebf74e67c496ff9a3d0b66f546b135f0c14a6b707e810826aca58e4de")
--setManifestid(3811140,"6837260327279170376")
addappid(3811150,0,"e9bed5ce6ec95fe658b145fca48a06912af4d94bfc6c38af456d842ab497e8b4")
--setManifestid(3811150,"2011724045367097077")
addappid(3811180,0,"1b0ebc42b6b1c083f7dc0eaa131088d447042cd8e0d680f449dd3a8e00e79ac0")
--setManifestid(3811180,"2324035484672952823")
addappid(3811190,0,"3418124474c4fe5bce32cb7cf2b4ca3f0698edaf99193c2e2cf2c72971009845")
--setManifestid(3811190,"855954021459458753")
addappid(3811200,0,"53d15104d853e8522237c04e3f7b4abedf19103b727dd89001134724511fb2e1")
--setManifestid(3811200,"5367784109417800236")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1559680's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:56:40 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 5
-- Blacklisted Depots: 0

addappid(1559680) -- Amazing Frog ? 2
-- MAIN APP DEPOTS
addappid(1559681, 1, "274a5cc627fe54c61daf8e1c089fc62ea53d53af956d035a58954c7b29547de0") -- Depot 1559681
--setManifestid(1559681, "7943043988990674140", 0)
addappid(1559682, 1, "bd324a3eba603f0e521137580660afe5afc50023b3be624ada2164da28abb35e") -- Depot 1559682
--setManifestid(1559682, "666998565393049857", 19623249280)
addappid(1559683, 1, "90cff56b240f85f55656d8c919fbddb718b2602b75af0e67b33fea9e715f6ce0") -- Depot 1559683
--setManifestid(1559683, "4358714261370130508", 19803271955)
addappid(1559684, 1, "1874fb0631c957c745e56cd62ea389bc062b1b7da9cc2cef7ac9acc182d1abaa") -- Depot 1559684
--setManifestid(1559684, "7281860947020450905", 21439305709)
addappid(1559685, 1, "4ff214750d1dbc262b90b948faa222b1f167973c0c882a40748733e15f69b9f7") -- Depot 1559685
--setManifestid(1559685, "7521177261182080383", 19606073514)
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 220440's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:05 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 7
-- Blacklisted Depots: 0

addappid(220440)
addappid(223791)
addappid(223790,0,"84ed6b57c32b4629f5cc2274674cb95f00d4b65d067170bb9a2f0ba4ffbd76a6")
--setManifestid(223790,"7654700979379588386")
addappid(223792,0,"8ca028cec8d61d9c12f8ea45f546d2c50f66aa8a2ddbda601a042ab68e909b0a")
--setManifestid(223792,"5445163040217040808")
addappid(223793,0,"e839ea49e739fb933e04b272dedc90509e470ad48ad698e48433772c64ef86fd")
--setManifestid(223793,"4639589247481781479")
addappid(223794,0,"770976d9313911624d8e4af965dbf09742bbb2388f6838e9071f34468f33c0e9")
--setManifestid(223794,"957085678202193145")
addappid(229080,0,"2d5f510f44b55ffd17e3fe6d09bba6d2751544fd151293553fa4466dea0660ef")
--setManifestid(229080,"1173515098563360562")
addappid(220441,0,"aed2b190f9b8ea15e6f1e22aed2d339f162f17b8673f06124dd11e1ea45b11be")
--setManifestid(220441,"8660867655925405335")
addappid(220442,0,"390e4902a68f3b732b8e42fe6fe3ccea44c54c19421e21eaa9860842c26fa973")
--setManifestid(220442,"8284177927415320138")
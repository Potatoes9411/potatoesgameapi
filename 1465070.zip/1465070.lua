-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1465070's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:56:33 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 4
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 1465471: Blacklisted

addappid(1465070)
addappid(1465071,0,"1415a107722524a2fbf0afed7076e502036b7e38e8a8b2be8d290acad9eb6dac")
--setManifestid(1465071,"2864573165763786580")
addappid(1465072,0,"d822c4e7a565d842645dc99d737e7d47ceeb3997fb1cd993a7b4b43f42fe447a")
--setManifestid(1465072,"297053684054949748")
addappid(1465073,0,"9b9d44853e19700574fe271a0f001ed1fe9d0db842817322222556a7f4cf980c")
--setManifestid(1465073,"2369929532892592971")
addappid(2562561,0,"378693b54e965dcf055312c03b36d9dda7d38da62aa9901c3ed981a9633a9670")
--setManifestid(2562561,"1597315070126164061")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 220200's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:58:15 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 36
-- Total DLCs: 0
-- Blacklisted Depots: 20
--   Depot 2202577: Blacklisted
--   Depot 220245: Blacklisted
--   Depot 220244: Blacklisted
--   Depot 220255: Blacklisted
--   Depot 220253: Blacklisted
--   Depot 220249: Blacklisted
--   Depot 220243: Blacklisted
--   Depot 2202578: Blacklisted
--   Depot 220256: Blacklisted
--   Depot 220251: Blacklisted
--   Depot 220242: Blacklisted
--   Depot 2202011: Blacklisted
--   Depot 220252: Blacklisted
--   Depot 220241: Blacklisted
--   Depot 220248: Blacklisted
--   Depot 220246: Blacklisted
--   Depot 2202579: Blacklisted
--   Depot 220247: Blacklisted
--   Depot 220250: Blacklisted
--   Depot 220254: Blacklisted

addappid(220200)
addappid(220200,0,"3a42a764ab5cc99e105f368e08e8c9762964f379cae1c443ac00df56311d9667")
addappid(283740,0,"7f076af9d7b24550805795745b696da514bf774de04bc39d12853b31187c970e")
--setManifestid(283740,"2443136430323483651")
addappid(283743,0,"b22533b47510dc54f5cbdeaf941776f1067c037d4865d94bed0fe0f5a58129b0")
--setManifestid(283743,"7486872015074120441")
addappid(283744,0,"280842c2cd82a9df2a2cacb1c37b10fa28447f0ee7fd0888edc16c7e57d81055")
--setManifestid(283744,"5205655790012932055")
addappid(283745,0,"b6c2082f9a90505b54c4e38fee2436258dabd60a18eef105597469955e201460")
--setManifestid(283745,"6395620313709645497")
addappid(283746,0,"f171a5a07ab6d5e5ea07cfb2b1e018f9602fbb9419bebdaa30d1e6bbed9bd46e")
--setManifestid(283746,"7253980953688230007")
addappid(283747,0,"796950ee27d7c06525bfe15279eb67b5913480270020875cf6a9014cf0b49436")
--setManifestid(283747,"7329406018471187241")
addappid(283748,0,"b47fb1b25246cb366eecaf11ee5690e728eca21a2545d16c0646a3a57412c96e")
--setManifestid(283748,"3931195855752949491")
addappid(283749,0,"cfd1ae4cdf043c6130c796ab834eb4dc2f4962012e340674fa9218fc75ebb2cc")
--setManifestid(283749,"643362983342728812")
addappid(807350,0,"740f402a828bca0f458f283df537b1a34b9053d47a34f6b06873e0c613b03862")
--setManifestid(807350,"4731056394051162987")
addappid(982970,0,"d1e8eb87b77ffccaa8d73506918683e65cffb6b70484a354e6fc33c9af99a5fc")
--setManifestid(982970,"194154484222638030")
addappid(982971,0,"d51815d2a19e8636db39f73ee4a912e57c29bd096563a9371a048cf850d5a3c3")
--setManifestid(982971,"2022721560690933980")
addappid(982972,0,"714c53b46b0a34b514696c838f1a9140b9524ca3f894eb40782fc1177ec4eb91")
--setManifestid(982972,"2446219790806602401")
addappid(982973,0,"0a4cddda2dc4ec5e5e9337fe327b25ba6c54b5481bbf70a20006b050cf38636b")
--setManifestid(982973,"5781851745347615732")
addappid(982974,0,"8c5870db783ec68a05c167a73255000a79863940b605af1a0e53375532318357")
--setManifestid(982974,"3380980933618026025")
addappid(982975,0,"a99f84b5c58617b2991c8943b13fde555b5778582bdcbd7c80ccc66825df409f")
--setManifestid(982975,"14196008539958699")
addappid(982976,0,"9740b760b43733bb193d052c634e6640a2c01e28f13bc9dda0175926484f2699")
--setManifestid(982976,"2749404271761332898")
addappid(982977,0,"c0e6ea7d6a4d21b85f7d47908fb932c35a7fb2d14ffd6728a2495bb139e00d4c")
--setManifestid(982977,"3079579928753281626")
addappid(982978,0,"4313fb1a02268516c4ee56e0c4dbc9ccffc2ccc6d23259265bd9f7dc322077f9")
--setManifestid(982978,"5874266035924219455")
addappid(220201,0,"ebb45304cb6479dd16c67337eb3938a1ef55df437f425c96428701829f4ea17a")
--setManifestid(220201,"6331816835925954858")
addappid(220202,0,"9e8e07a271167d65803914cf070937cdcbd2579ce64469a5863b3b9d6b1775e9")
--setManifestid(220202,"6145727205642015120")
addappid(220203,0,"14a5938964e96492302798e26bae7d2956f7cfd3145fba7255a0a9a8ac24605f")
--setManifestid(220203,"5744742415595933520")
addappid(220204,0,"1c02d529a25c71569f3c23f1b4b8593ff1ef2b564ccd0bf476f81f4085aafcf5")
--setManifestid(220204,"895421221909357680")
addappid(220205,0,"da4ecd1436c2854f1bdd0e8ca5535ee36204a976535d75028e827f2f78e3a075")
--setManifestid(220205,"8073598277300090923")
addappid(220206,0,"8b22eb9de912dc70db3d13abbefb6173582184f43035b6797cf49305ad911fb7")
--setManifestid(220206,"939141202072334643")
addappid(220207,0,"8e7bacaf62bed645a727836ac3ca42f47d8fa9b3b7e00b745fd202a0d4e9c713")
--setManifestid(220207,"8266439066111296104")
addappid(220208,0,"6c0e816856190fa2900bb3147c9bd98a51cea683f4be2b5e92bc3bef46866b40")
--setManifestid(220208,"6506278945653714142")
addappid(220209,0,"fe7a8909cc78da952a1f7d0021eeb3df0685f7a6e2e0071411bb21555b117878")
--setManifestid(220209,"2010052161041755576")
addappid(220210,0,"21ecae68dce08cf59135e4eb49f44799dfdad7c3f28ebd0a16cb35c801114ff7")
--setManifestid(220210,"5206490517007059532")
addappid(220211,0,"43b0893bcbd28d0d2e39a3b5f5aebb69907ec9d529333845e26deba411741316")
--setManifestid(220211,"3901531883767526193")
addappid(220212,0,"61def03b0ab69e385f5f0d2f8a90900388872b505af866abef3f7277fad257f5")
--setManifestid(220212,"78739687081486078")
addappid(220213,0,"d33e7273ed3129303b88c8f817432753a38e7b3e63eebb6423f5c61cce5dc859")
--setManifestid(220213,"1660641291841592914")
addappid(220214,0,"9d537f407d93bfdb432575e5167da542f41d93e7fee3d09e1a0e6ce74863754c")
--setManifestid(220214,"8229629602796981387")
addappid(220215,0,"7872bcd108d61924c2273ce9789a8504b38327f1b61363bbe60879e19b435833")
--setManifestid(220215,"4776840543670162301")
addappid(220216,0,"0ee55c284a3441c3e8d97b5e45502e52039edf9927404bae341733430ec82a2a")
--setManifestid(220216,"9167099533421805932")
addappid(220217,0,"c8fa2dde08014b438be450aba2b36adde1e4fe856c5a1363a66618ac37315f0f")
--setManifestid(220217,"1542059352249819159")
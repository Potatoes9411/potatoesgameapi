-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1337890's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:56:18 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 4
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 1337490: Blacklisted

addappid(1337890)
addappid(1767420)
addappid(1337891,0,"40fb1cf6aa4fb344641076e3fd89a29ef31558be28e5a74ee5e540038eeaeb58")
--setManifestid(1337891,"235638613751142987")
addappid(1337892,0,"9be478adef8d1588784982561ead014e20a674fdc2268c33a61c775c4c6a6fd2")
--setManifestid(1337892,"1244538928470598599")
addappid(1337893,0,"53f4b25e4243209d8f2706b5957723728dbee82a423e9186fb3465d9863a137d")
--setManifestid(1337893,"2050932630376514108")
addappid(1767420,0,"78b2f75702906842b70642bf955b1354e1f9512a11aede168d4d75f58a87d485")
--setManifestid(1767420,"2456101199851882364")
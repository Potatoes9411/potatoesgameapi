-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 32330's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:22 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 5
-- Blacklisted Depots: 0

addappid(32330)
addappid(32331,0,"3f030450b19be8520dd1d7dd2b76b84ccaa0e2bef6df534d098d136e7f5f80cd")
--setManifestid(32331,"5952564723665979214")
addappid(32332,0,"9f578d10670fb80d7fd902ddbb192a96aec96613a52dd50c58335be09e75be56")
--setManifestid(32332,"2501864487432370764")
addappid(32333,0,"40a083260fdecac3b811ddb1ad4853c80c3e0cf4c368fc2658f74114c0d11261")
--setManifestid(32333,"6501304229755146686")
addappid(32335,0,"2658a2a617662f6f40983442ad390aeba625b569e3a9ad52a0e80f203521abd6")
--setManifestid(32335,"1217194974168217355")
addappid(32336,0,"a1ca8cc26eead94b7be9d756564118d2d87e66ebc22ae5001f7ba0e17b187831")
--setManifestid(32336,"7921700809484652698")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3180610's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:20 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(3180610)
addappid(3180613,0,"16FBD0AF7BF7D634AC10270E922D0D84C055726BB725CAC315CB4DD6F5DB2BA1")
--setManifestid(3180613,"5692951390775144066")
addappid(3180614,0,"F0015B3E09AFCCCBBF464AA837EAC6C24CD60E104BE6F24DD795E21F19D4E5DD")
--setManifestid(3180614,"532880521092095059")
addappid(3180615,0,"18AC374FBB79E412B4D7C2B99C54987F2F930B7A0D46953D902AF7A9D24A4C79")
--setManifestid(3180615,"8713203820474712789")
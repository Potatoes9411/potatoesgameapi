-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1278480's Lua and Manifest Created by Potatoes9411
-- Smart Game Booster
-- Created: June 17, 2026 at 06:54:02 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 11
-- Blacklisted Depots: 0

addappid(1278480, 1, "Unknown")
addappid(1278481, 1, "Unknown")
setManifestid(1278481, "Unknown", 0)
addappid(1278482, 1, "Unknown")
setManifestid(1278482, "Unknown", 0)
addappid(1278483, 1, "Unknown")
setManifestid(1278483, "Unknown", 0)
addappid(1278484, 1, "Unknown")
setManifestid(1278484, "Unknown", 0)
addappid(1278485, 1, "Unknown")
setManifestid(1278485, "Unknown", 0)
addappid(1278486, 1, "Unknown")
setManifestid(1278486, "Unknown", 0)
addappid(1278487, 1, "Unknown")
setManifestid(1278487, "Unknown", 0)
addappid(1278488, 1, "Unknown")
setManifestid(1278488, "Unknown", 0)
addappid(1278489, 1, "Unknown")
setManifestid(1278489, "Unknown", 0)
addappid(1289950, 1, "Unknown")
setManifestid(1289950, "3907069322538973504", 0)
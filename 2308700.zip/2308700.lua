-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2308700's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:58:59 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 2
--   Depot 2308692: Blacklisted
--   Depot 2308631: Blacklisted

addappid(2308700)
addappid(2308701,0,"6e2eca33fa1b8367f8b403fbe8ec2d139a26e2c60a943e316f1dcd16edd9f882")
--setManifestid(2308701,"7063185816076286956")
addappid(2308702,0,"374521054d7c39ba1ae9f25abb6bb34d3ba5e665e5e8fe8cd0dfa779fdb68c1e")
--setManifestid(2308702,"2006436122382576256")
addappid(2308703,0,"dc01a4b5b00a3482cc2ea329e307c45bf0e930aeeb91e3d3b44b3263b8c12088")
--setManifestid(2308703,"2649111520407201093")
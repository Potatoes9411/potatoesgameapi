-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2370310's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:59:19 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 2
--   Depot 2370571: Blacklisted
--   Depot 2370001: Blacklisted

addappid(2370310)
addappid(2370311,0,"02f5114ea61fcffb147027d58604b0e0b5f0b13642c08041994a98e280999c9f")
--setManifestid(2370311,"3483219399514914945")
addappid(2370312,0,"759010ccee10bf4b8b02635f4841b9a642296ad1bb3b1f4b43d2b4a766c0b85a")
--setManifestid(2370312,"8248953021799896122")
addappid(2370313,0,"a11a02f15a594b5fb813d211569e4cf190379b793fe4023c29330012c470ccda")
--setManifestid(2370313,"3419089302473263781")
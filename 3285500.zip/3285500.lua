-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3285500's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:24 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 5
-- Blacklisted Depots: 0

addappid(3285500)
addappid(3285500,0,"a72e9be4f0a2395e9f01c8fc97a29f9ed4d8345a0604f8e66151de58ce08a588")
addappid(3786750)
addappid(4243340)
addappid(4243370)
addappid(3285501,0,"d540ff5a3e564eb42dd7bc7fcd2767ba878e869bde88b3b99f21372cf43fe116")
--setManifestid(3285501,"9129263997121899207")
addappid(3786750,0,"8ea8b93dc597304b744fb21727c260bb3f2940dde0fc68d4cce2c9c1a2cdbecf")
--setManifestid(3786750,"2102585071659237461")
addappid(4243340,0,"57752722713cf916021e2f04f6b6defc1e7f5aa24f70b51a6ac22f976c87b40a")
--setManifestid(4243340,"7585080945568092154")
addappid(4243370,0,"ba963f04f7a4ba05544c87cae97abf780b1406d2a7e4906183e04a17e5d0ad1e")
--setManifestid(4243370,"8251698704868364907")
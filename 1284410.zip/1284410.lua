-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1284410's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:56:10 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 7
-- Total DLCs: 0
-- Blacklisted Depots: 3
--   Depot 1284472: Blacklisted
--   Depot 1284192: Blacklisted
--   Depot 1284471: Blacklisted

addappid(1284410)
addappid(1288440)
addappid(1284411,0,"b4cf4afd8eeb499a6acaf240167a6533e792b4bc1d5fdd6d15cd7139b12dd9f8")
--setManifestid(1284411,"2489956541878757100")
addappid(1284412,0,"9ba94be7146078072633928c53dbf225831777bd0a6a05f194bc3bfce4c053fe")
--setManifestid(1284412,"4935063395709817286")
addappid(1284413,0,"650d3822a1c9cfc4d8a216e443b97a5c880dea998e8d9cc90b18eda8d42a12e3")
--setManifestid(1284413,"8705463241603602173")
addappid(1284414,0,"b350f1adf75e9abda18394b2f716561156c0eabb960cdffdde4b3abef1edf445")
--setManifestid(1284414,"6378204103458909152")
addappid(1284415,0,"c1bae2e8ad347fb19a97f6a7165db325fa2cc2a906abc4c0ce2935f7b8d92b90")
--setManifestid(1284415,"7452089957955849820")
addappid(1284416,0,"966c05fb33286e72da3eb562aceefdd04286d9fcf01932c1fc853941f6aab989")
--setManifestid(1284416,"4315113866844441972")
addappid(1288440,0,"c237d9e0cd701027e822be12d2cb9b0ffe4dcdd03eb4b88831e5f1774ab537fb")
--setManifestid(1288440,"8298190714473974302")
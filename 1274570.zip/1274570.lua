-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1274570's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:42 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(1274570)
addappid(1966630)
addappid(1274571,0,"b56991abb013052ba7ef6d1e0982f0ca99bbeeb631057347267102c6967c1537")
--setManifestid(1274571,"928231702282729008")
addappid(1274573,0,"b67b5c5c44139818a0d7ddb9d1103a724ca404a87bde4d78fe257fc352f0f36d")
--setManifestid(1274573,"7183760786468765853")
addappid(1966630,0,"9b579f914a2ba495ad1e0b1e1a1fc21c8e578ee933fb6bfabd9f138124244587")
--setManifestid(1966630,"7348617984918166394")
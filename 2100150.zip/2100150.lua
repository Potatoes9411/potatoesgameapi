-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2100150's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:54 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 1
-- Total DLCs: 0
-- Blacklisted Depots: 9
--   Depot 210015: Blacklisted
--   Depot 210017: Blacklisted
--   Depot 210014: Blacklisted
--   Depot 210012: Blacklisted
--   Depot 210019: Blacklisted
--   Depot 210013: Blacklisted
--   Depot 210016: Blacklisted
--   Depot 210011: Blacklisted
--   Depot 210018: Blacklisted

addappid(2100150)
addappid(2100151,0,"4c275f0c8c843b7c9d9636e1929dd2cd1ee1ce0f1d0ffb0746cc2c0468f2b161")
--setManifestid(2100151,"5863164819340678477")
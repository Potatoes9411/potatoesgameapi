-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 4249100's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:55 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(4249100)
addappid(4249101,0,"53fc73ab0ec4b9e6fa4c415e4613c5bdc044ae2462c6c4d898c070822af245e0")
--setManifestid(4249101,"2720404463246186191")
addappid(4249102,0,"cb84cbcb9b6a7d9781651ff812f235d78189a6b8603a6a8d55e23029b727b5d6")
--setManifestid(4249102,"4977007747338078760")
addappid(4249103,0,"f118404bcd07c1213340ef0763197e9fcbce44aaeb046f5c467ffae95d585f20")
--setManifestid(4249103,"5764709108843764437")
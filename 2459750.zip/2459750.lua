-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2459750's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:59:44 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 1
-- Total DLCs: 0
-- Blacklisted Depots: 2
--   Depot 2459491: Blacklisted
--   Depot 2459551: Blacklisted

addappid(2459750)
addappid(2627830)
addappid(2627840)
addappid(2627860)
addappid(2627870)
addappid(2627880)
addappid(2627890)
addappid(2627900)
addappid(2627910)
addappid(2627920)
addappid(2627930)
addappid(2627940)
addappid(2627950)
addappid(2627960)
addappid(2627970)
addappid(2627980)
addappid(2627990)
addappid(2750830)
addappid(2459751,0,"82dc4d1024f9965fd0116391d2d66a0d2cb57c9d92b32dc4f4e6e18a6cf39bc3")
--setManifestid(2459751,"6014394387934146655")
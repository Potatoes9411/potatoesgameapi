-- Made by F1uxin (UserID:965053505901588521), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/NmmpgnAgen)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:965053505901588521)
-- And if you have any questions feel free to dm on discord (UserID:965053505901588521)

-- Socials: https://guns.lol/f1uxin

-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)

-- Main stuff to add your game.
addappid(2475460) -- SOS OPS!
addappid(2475461, 1, "35d0fe1da8af85fe194219860e7c34c03d704ef29aecc959c8c1029a906fbbc7") -- Depot 2475461
setManifestid(2475461, "3207022865059729063", 2923328020)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(4312180)
addappid(4312180, 1, "4f3e44891ccf30717c80c8104fea215631c1419246c9203118058d3dc21de474") -- SOS OPS - Digital Artbook - Depot 4312180
setManifestid(4312180, "1471988885834590676", 36323561)
addappid(2902230) -- SOS OPS - GUNS N OPS
addappid(3086710) -- SOS OPS - TRIALS
addappid(4446280) -- SOS OPS - BACKROOMS
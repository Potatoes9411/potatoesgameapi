-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2190220's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:58:12 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 2
-- Total DLCs: 0
-- Blacklisted Depots: 2
--   Depot 219094: Blacklisted
--   Depot 2190761: Blacklisted

addappid(2190220)
addappid(2790910)
addappid(2790940)
addappid(2790950)
addappid(2790960)
addappid(2790970)
addappid(2791100)
addappid(2808300)
addappid(2920470)
addappid(3340370)
addappid(3340380)
addappid(3340390)
addappid(3340400)
addappid(3728710)
addappid(3728730)
addappid(3728740)
addappid(3728750)
addappid(4270280)
addappid(4270290)
addappid(2190221,0,"d94856de16f133e42d1d1c4c4c4bd5fb5c79ab25709f242ad77cd1cd5b69ba96")
--setManifestid(2190221,"7218476396907984165")
addappid(2791100,0,"2a3437e1e75880812d6836420d39450fa6a965142dfbf0fe5b1ec7936b5e0f70")
--setManifestid(2791100,"6891064590758046517")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 949230's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 07:00:08 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 20
-- Blacklisted Depots: 0

addappid(949230)
addappid(2427730)
addappid(2427731)
addappid(2427740)
addappid(2427744)
addappid(2887600)
addappid(3350700)
addappid(3535990)
addappid(3740440)
addappid(4156790)
addappid(4331590)
addappid(2427741,0,"d2166f8c2e87ec7b0900a190c9cc19ee010fdd65fd616e23a0f5e7c86ab7f6b4")
--setManifestid(2427741,"438974973343020455")
addappid(2427742,0,"10f591eaa4714450e076677b7e7769008213ced4a34ee7d8680ab9e56ef4fe49")
--setManifestid(2427742,"7552307450690748413")
addappid(2427743,0,"b69c0f20602c6d566bb0b1fc34738968384c495c701d6c514a95eb71d13b0a2b")
--setManifestid(2427743,"6492682286361914639")
addappid(2427745,0,"3ab8a19fe1ec5a750b6a807a30203880c99504c321500a7e64e18c361e7cce0f")
--setManifestid(2427745,"3710823592724179000")
addappid(2427746,0,"0942886d7a2f91351b71e76ac8bb8f6f6aa4379ded6936690fb219345679a50b")
--setManifestid(2427746,"3599726097608043890")
addappid(2945610,0,"bbe5da829bb0f945cca502394f4e116a571e24dc9d17942e537ba40cca9e5edd")
--setManifestid(2945610,"2993533374734752647")
addappid(2945630,0,"948d67b9b3f9a86527dbc70fb2c69ddb3163cbba5f848c838a600ba5c1ab760f")
--setManifestid(2945630,"2449260315622315362")
addappid(2945640,0,"e1c2ffe0f3139d1e9dcce3914e56e42316024a30f289013e5b0a76181bf18325")
--setManifestid(2945640,"8533092457037685235")
addappid(3054840,0,"02aead37a548fa148998bd2698389d9b497ba84680d8a1ca3116bb3c79208415")
--setManifestid(3054840,"4418427781040991518")
addappid(3055040,0,"3b44a007515e566327cfc4ed209b8c71ffe4789a4a12fe3659caae3bf23440d3")
--setManifestid(3055040,"1717807990026297671")
addappid(3055080,0,"e39253ba495db02d1cb4cd69a6b9a7aba7b0d9439b2ee13cea0d153364b73267")
--setManifestid(3055080,"7368325153196266226")
addappid(3579760,0,"e2d84887eb4a063ad947d4415584043d4f5e19246605264ede10f1381feeaef7")
--setManifestid(3579760,"2124768731922674455")
addappid(3579770,0,"02d4d058fada73b743578f08a8e299d2629ff9c0e0c6d9e91c02c84767f3d89d")
--setManifestid(3579770,"6480230126968480766")
addappid(3579780,0,"1328cd2de8813ed99054ca606fe3beabb146c94e93576b9f539eeec0fe6247f8")
--setManifestid(3579780,"4134300156493126872")
addappid(3579790,0,"fb3b8ff0129675b1fe8d56df96c57967abd116ed3a9493c3aa9198fd48872e7e")
--setManifestid(3579790,"3152829517946950614")
addappid(3579800,0,"6f9f1c7e0ed9f74492f3e3ee9d52d48e9e5fe3b9164e4eb5d728603b34cc23da")
--setManifestid(3579800,"1296127626803180328")
addappid(3579810,0,"8c30a42cd78c0000dac3bec7719e272506de74f660f54a8af7c88fd46666f8e1")
--setManifestid(3579810,"7298211655948922027")
addappid(3579820,0,"b3cdc2b0984a50cd02e4bed24d6689dbab0f8abfc30513718d774d6f2d36d635")
--setManifestid(3579820,"8038891213862972712")
addappid(3579830,0,"4da3896587e0ac89aa98ffd0073c5938c251bc528711e9691e862d787a5dd738")
--setManifestid(3579830,"524071386827207299")
addappid(949231,0,"eadf0796a624164bd8838fc14a95bd34b9c41e87048bbb4a23b86f0b77c1fb67")
--setManifestid(949231,"6417973219256484918")
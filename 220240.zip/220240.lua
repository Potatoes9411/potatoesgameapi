-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 220240's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:58:16 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 21
-- Total DLCs: 0
-- Blacklisted Depots: 21
--   Depot 220211: Blacklisted
--   Depot 2202577: Blacklisted
--   Depot 220205: Blacklisted
--   Depot 220208: Blacklisted
--   Depot 220201: Blacklisted
--   Depot 220217: Blacklisted
--   Depot 220216: Blacklisted
--   Depot 220212: Blacklisted
--   Depot 220207: Blacklisted
--   Depot 2202578: Blacklisted
--   Depot 220206: Blacklisted
--   Depot 220214: Blacklisted
--   Depot 2202011: Blacklisted
--   Depot 220202: Blacklisted
--   Depot 220203: Blacklisted
--   Depot 220215: Blacklisted
--   Depot 2202579: Blacklisted
--   Depot 220204: Blacklisted
--   Depot 220210: Blacklisted
--   Depot 220209: Blacklisted
--   Depot 220213: Blacklisted

addappid(220240)
addappid(226451)
addappid(226452)
addappid(226453)
addappid(226454)
addappid(226457)
addappid(226459)
addappid(220241,0,"3dc1c40f6a253fbda33a9cef065e0df1cb4e16b53ab150559cfc67c95bdbc0aa")
--setManifestid(220241,"5896142001500010150")
addappid(220242,0,"6ae4acd7928642d198f34b7d89a6ffa7ca0f1d41c998127c2d9ac2c8056be57d")
--setManifestid(220242,"668508214988670452")
addappid(220243,0,"103327274fff7f9d54d4fec5995dbe31d29f1ca01e1ce8d6da4bbb46a20e83c0")
--setManifestid(220243,"8436900324818409435")
addappid(220244,0,"986b445fe4b091f0728c11019f1c17e82c96e966dd2274b472148222cf564b1e")
--setManifestid(220244,"1446238701376931089")
addappid(220245,0,"9c76858d3b47e4f4b02c56426b76a3385aa8b20e46b3dc39d6fd0bbb8bf99e9b")
--setManifestid(220245,"2540975046130074424")
addappid(220246,0,"e2415a5c12c4a30dc2c2a931338b016cc0cb845e123574cb3f0a3e330ab2cf05")
--setManifestid(220246,"90934089515212202")
addappid(220247,0,"156f4584cf999337becb0b52fe1d153f991d54863a5a691be78b0ecd6edb1425")
--setManifestid(220247,"3278778596397332424")
addappid(220248,0,"85c54a6e0950d80a075aee537af97046460aa6ec1687c86b735d60caec9fb767")
--setManifestid(220248,"7502707974879090242")
addappid(220249,0,"0123b2bec7f102edbe9687d092263ca258b512f8f7f6e7086542d440fb01af80")
--setManifestid(220249,"3443261590545127881")
addappid(220250,0,"4c1fb62fc31755bfb4ca6e8488488789486477910b9fdeb851474b136b4e21b6")
--setManifestid(220250,"6256856753241859048")
addappid(220251,0,"979027d6b7eb05fc2b80c377203c94ffcd2a04f316187c9d76a84424195d4935")
--setManifestid(220251,"3092477369987826489")
addappid(220252,0,"a08dabf711d0dd85d278a65c29208867cc28b4324fa0f32a0d84d176385f75cb")
--setManifestid(220252,"1007747486412002922")
addappid(220253,0,"1a84e70789a71107cbc04f1b270421c85aa26fe217c2d7e97202d1ccd1383d1f")
--setManifestid(220253,"3502071805828553100")
addappid(220254,0,"6769dd40329d22e1b37ef3cdc2893b5846ec445153160fb87b138f45bcb8b599")
--setManifestid(220254,"1263460290778726057")
addappid(220255,0,"ee326194cf98b5abd347e5e16d2d4a7dea0285a9e859d6f580587b50a85fb99a")
--setManifestid(220255,"7412199545536898917")
addappid(220256,0,"2fc1d80bddb5da522cb2cac92f358ece42610f185ed04367ff2eb1f8f24b5ded")
--setManifestid(220256,"2375629037347470307")
addappid(226451,0,"32f9d8f1f8398b650cf25ec427e88f503613111e482926a6cb8e6f20426c016c")
--setManifestid(226451,"8532199382147047194")
addappid(226455,0,"1f05a0a4ab5bf7a681e5903b3516eb50fa31f7ee676f3913bfd4ad7110fb82dd")
--setManifestid(226455,"2306901777804086020")
addappid(226456,0,"d974d3b6f97b04e42ee91c19e64d3b35f1528495e864d9b8bfc34d406a6f6db7")
--setManifestid(226456,"3836955638345779953")
addappid(226457,0,"c59177dd49df61e1203f03d37b0227827b6209454a14baeb77bec655912927b2")
--setManifestid(226457,"8756461153186112053")
addappid(1716751,0,"84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
--setManifestid(1716751,"4132506267642462151")
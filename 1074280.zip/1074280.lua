-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1074280's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:55:27 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 2
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(1074280)
addappid(1074281,0,"73674bee51f88f7ffb06f3ba7562c5eecef1e1421718ec8431d1475b7123d503")
--setManifestid(1074281,"6582581575037414954")
addappid(1074282,0,"088ac17eeb9d4d23da7b0cdc1ec0fb6abb6c19748ecaedef7b208ca0a1ff3914")
--setManifestid(1074282,"8538235696057765331")
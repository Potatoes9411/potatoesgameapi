-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2753600's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:00:50 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 4
-- Total DLCs: 0
-- Blacklisted Depots: 3
--   Depot 2753972: Blacklisted
--   Depot 2753901: Blacklisted
--   Depot 2753971: Blacklisted

addappid(2753600)
addappid(3624980)
addappid(3624990)
addappid(3625000)
addappid(2753601,0,"c79707c0a6b3c96c9e1f39f9d6eeda3f26d55486e0db297d9e4d3f68cb0e577c")
--setManifestid(2753601,"5542831098723761075")
addappid(3624980,0,"c8bf85edf32973ec85e17b6d89469e94ebac8cbd41418c069294cc800b10d6f9")
--setManifestid(3624980,"1452237863178260842")
addappid(3624990,0,"95509dc4a951e21dc6d60e48b5ae02ae3aae93de32e030e49cd165129f55617f")
--setManifestid(3624990,"7138346213818034088")
addappid(3625000,0,"8ab670d7c2b5afa80a9ccd8b248c6c7853677aa43dc6932d9fbeee4d7aad6b47")
--setManifestid(3625000,"9157965007693585085")
-- Made by F1uxin (UserID:965053505901588521), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/NmmpgnAgen)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:965053505901588521)
-- And if you have any questions feel free to dm on discord (UserID:965053505901588521)

-- Socials: https://guns.lol/f1uxin

-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid", save the file, then add the lua file (i think you can add the manifests too but I would just add the lua file to ensure it works).

-- Main stuff to add your game.
addappid(3597510, 1, "b0b9f1b37c56c86628a64d6982429590813fa9219099e3a4f3c0cf3838a523ca") -- MyRobot
addappid(3597511, 1, "20a9245e2e2494164435cb49d11659377835af056535e5aced1c0905b7a5ee63") -- Depot 3597511
setManifestid(3597511, "8390209466256927228", 2329428811)
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 443970's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:59 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 2
-- Blacklisted Depots: 0

addappid(443970)
addappid(228983)
--setManifestid(228983,"8124929965194586177")
addappid(228985)
--setManifestid(228985,"3966345552745568756")
addappid(229005)
--setManifestid(229005,"7992454656023763365")
addappid(229020)
--setManifestid(229020,"5799761707845834510")
addappid(229030)
--setManifestid(229030,"1043465440436835055")
addappid(229031)
--setManifestid(229031,"7746630274301172884")
addappid(229032)
--setManifestid(229032,"3616495131483866412")
addappid(229033)
--setManifestid(229033,"2059065101492814639")
addappid(443971,0,"f2835ca65117621a95f1ecf8b2726b2d06272fe1da8ba64925fb4e83787a1ebb")
--setManifestid(443971,"4358793379974736227")
addappid(747520,0,"0e5129b4df2efe8e97e2c4da2ce50732efcc57045b941779b966f88c609bc0a3")
--setManifestid(747520,"1538013555250168230")
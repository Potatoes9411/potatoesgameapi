-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2420240's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:59:31 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 4
-- Total DLCs: 0
-- Blacklisted Depots: 12
--   Depot 2420592: Blacklisted
--   Depot 2420116: Blacklisted
--   Depot 2420112: Blacklisted
--   Depot 2420117: Blacklisted
--   Depot 242051: Blacklisted
--   Depot 2420115: Blacklisted
--   Depot 2420591: Blacklisted
--   Depot 2420111: Blacklisted
--   Depot 2420114: Blacklisted
--   Depot 2420119: Blacklisted
--   Depot 2420118: Blacklisted
--   Depot 2420593: Blacklisted

addappid(2420240)
addappid(2420241,0,"cc5d192b991d66b12dc5491e90d843430a13f9768173b872178c716ed29b262c")
--setManifestid(2420241,"4378044608238094186")
addappid(2420242,0,"7c64dff3db51a51e9e39ee98825533e389fbbbb35ba77197c5e6a81bc37964f6")
--setManifestid(2420242,"9100734202314378482")
addappid(2420243,0,"2304c4cbd2615d6aa9543c5afd7cd3d05023eca1585e55b6b5bb66c7876da4a0")
--setManifestid(2420243,"1033270837896902495")
addappid(2420244,0,"93f579212a414b86100eaaebfd1d9686835f8802bfb28943e91bf9bfed52e4a0")
--setManifestid(2420244,"4710639606455607268")
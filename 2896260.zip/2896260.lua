-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2896260's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:01:19 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 2
-- Total DLCs: 0
-- Blacklisted Depots: 4
--   Depot 289652: Blacklisted
--   Depot 2896382: Blacklisted
--   Depot 289651: Blacklisted
--   Depot 289653: Blacklisted

addappid(2896260)
addappid(3420191,0,"5a003dfef638b3d6a51f51cbb1705646b1331df6652be9a2295d62d1e68fb3e0")
--setManifestid(3420191,"1077079943116864888")
addappid(2896261,0,"c82ef318eb2b98fa3a40efed97d8f237b4e34de5005b21e17c5c661bbb4e831a")
--setManifestid(2896261,"2940862460280734674")
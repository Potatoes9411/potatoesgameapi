-- Made by F1uxin, Discord ID:965053505901588521 | Discord Server (TGP | The Galaxy of Pirates): https://discord.gg/VfCxRsFyFe

-- If you're interested in distributing these files please dm me on discord (UserID:965053505901588521) 
-- (I don't care if you send them to a friend or to help someone, just if you add them in your bot or have them widely available then i would like to know.)

-- Socials: https://guns.lol/f1uxin

-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid", save the file, then add the lua file, (i think you can add the manifests too but I would just add the lua file to ensure it works).

-- If you have any questions feel free to dm on discord (UserID:965053505901588521)


-- Main stuff to actually add the game, DLCs, & depots.
addappid(3341650, 1, "29446a046e12f8925dfe49bdd46608af23b422b7206e5fbeeaacdde3e2f3ba78") -- PIGFACE
addappid(3341651, 1, "8ae8fafb929e566abf110e8a587ac70c739d2b587e586966ccb8629c86a21ac8") -- Depot 3341651
setManifestid(3341651, "7159530524438977398", 458973071)
addappid(3341652, 1, "d3eac060f7e0acc3f7477f420cc1b44f339eea28f47325ccdc67a6fa581d87a5") -- Depot 3341652
setManifestid(3341652, "1200708658416912023", 448457179)
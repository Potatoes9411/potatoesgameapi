-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1058830's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:38 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 6
-- Blacklisted Depots: 0

addappid(1058830)
addappid(1664540)
addappid(1668790)
addappid(1668791)
addappid(1058831,0,"3f26db997b2f0251aeb078e6ea68fba45a9b67c18863ff4c467f6f03aa0eeae4")
--setManifestid(1058831,"5999136588727482460")
addappid(1058832,0,"de813043e58eacf88f155d5ea29ae67c2db721b05892742680892b29872caddb")
--setManifestid(1058832,"8498737681076530136")
addappid(1058833,0,"0cfbdacb00c012f9bd209b7cfd60b9f97f9ccf8de14d8dfeac47198d63e8624f")
--setManifestid(1058833,"3768519923007276380")
addappid(1664540,0,"1f2524ed33a3c11d30d6f2fff2588dd755f3580da01c0c112cdbb63faa8f6f05")
--setManifestid(1664540,"8251443907781431168")
addappid(1668790,0,"1f931f673b51c59f94252105c8c93fabe144d8240f5377da2f268333bb27be5b")
--setManifestid(1668790,"1699410753823597012")
addappid(1668791,0,"64a1081e7e6d408a166bf3cf058fd384486eef13abdcbbc477f3dec90267f5a2")
--setManifestid(1668791,"5830248334723563290")
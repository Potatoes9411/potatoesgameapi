-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 349040's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:32 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 18
-- Blacklisted Depots: 0

addappid(349040)
addappid(416410)
addappid(416424)
addappid(435160)
addappid(416420,0,"6da23438c5d60737c065d092cc5554380a92cdc3af0f1845f9afde3b92c8ec94")
--setManifestid(416420,"40672943479631225")
addappid(416421,0,"4e05609d087895d65deb6c9f2abd47057d4ca152e3348f7de32f8aa92fee868a")
--setManifestid(416421,"2732989314762671464")
addappid(416422,0,"ea4da58e74eac5a31e2438897667d70e0279c0a76460216932a0f7a18fd74a7e")
--setManifestid(416422,"82372446095607410")
addappid(416423,0,"772f5ae3581182804685e3cba0307be6b363d6b95b7f4e822fc39d0fb38547f3")
--setManifestid(416423,"51543784152758255")
addappid(495160,0,"51a6160181a36342b12a5a20f4cf646c371d8fece6b92d3077608001a6e94694")
--setManifestid(495160,"4329254603532854209")
addappid(1142330,0,"5d15e98459fd64db5e6c648eca639326767a8a2bbee7c3c64244c0b3cd57348e")
--setManifestid(1142330,"6981791585030199060")
addappid(349041,0,"a2bc6391431ba0c509c7c64483a6a287069355845f082ddabd65946f8b5f5a1e")
--setManifestid(349041,"466904989965013797")
addappid(349042,0,"745657a624eb759e5dbe7074c730eaec65fa515762c2860d581898c7f323aad4")
--setManifestid(349042,"4781962691495625946")
addappid(349043,0,"897638cae5c16d5184f5f81979b5f7200d8274b38a4533e05df2d0678d39e53f")
--setManifestid(349043,"8701540704013016369")
addappid(349044,0,"41018cfa7b42cbc12b3ce7eb3561c790c4ed19001c22875196274e2d214d8183")
--setManifestid(349044,"7598657215920648700")
addappid(349045,0,"3daeb76211a4e33a99603bd45fc2098bed2a3340b4369e27faa8c675c9b6ff15")
--setManifestid(349045,"1672862195389831466")
addappid(349046,0,"447389274e3143c4cda419ed7e55e7b1853e43c9ed59e0533526efcd975747e8")
--setManifestid(349046,"7875414149252292342")
addappid(349047,0,"22762b0789511571aacdf6ddbcae35c29d4393e15d0b9d687fd3b85ee6c4e6a6")
--setManifestid(349047,"2820124058878706807")
addappid(349048,0,"7e7923b06305d6c360be11963a3feeba945242f6f8a154934f300fded8594622")
--setManifestid(349048,"2915359124936233149")
addappid(349049,0,"882b465e23a5ae80855b5740889441804da8d10859264eb81766549284f66c2c")
--setManifestid(349049,"7135184964776273959")
addappid(352410,0,"f9f781653d91cfa36539469fbe4e61f45d338f51237cfe837581d96990558418")
--setManifestid(352410,"6484480131915952183")
addappid(352411,0,"d4a469b6907246533187cca78283280825cfa3b0cc7afcc2b26edeb9b16b1933")
--setManifestid(352411,"3002284486267246739")
addappid(352412,0,"7d85c049fd91857b2585541deffec38bc2687268233052d72e38a0eb072b6e37")
--setManifestid(352412,"1644355053840635530")
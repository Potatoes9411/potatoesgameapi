-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3267900's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:23 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(3267900)
addappid(3267902,0,"eb29641a981c643dd2492131a9f5eba97db5a7bc6919166b9bb41acd775c14a8")
--setManifestid(3267902,"1280490280101437935")
addappid(3267903,0,"5315E0D7E8BD6FF4EF7BF0C5D2DF3AAB2FBD10E325A0F4902B49AEAF517FC6DA")
--setManifestid(3267903,"455111102171189452")
addappid(3267904,0,"2df4706f4565a7a0f123b01fba4714faf7b237ab4f0578632171b4049c383518")
--setManifestid(3267904,"4236368863958984936")
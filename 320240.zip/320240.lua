-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 320240's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:20 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 19
-- Blacklisted Depots: 0

addappid(320240)
addappid(320240,0,"3fb5c589749f6325196d8622f7d4a22ca997e6d93524f743627864d0ae6b9402")
addappid(919000)
addappid(1024770,0,"ceb86289f1edda52769ae06453c4f68d8d77b57a5e22cf0daa1d828bf6eb1502")
--setManifestid(1024770,"2823181110545092915")
addappid(1024771,0,"1f14cc72e3c89027a73b8cdd9f74ff877522515c3a7068910616814f19e77248")
--setManifestid(1024771,"9162278124795425277")
addappid(1024772,0,"53c097a2d498f42fcc868793c22252197f832ebe50e779043237444659bcf26c")
--setManifestid(1024772,"6362428716831575853")
addappid(743541,0,"9ccf59d7fad9b8fa93eebb3536382f587ae7527cbc536eb11b62a3a9a25e03b9")
--setManifestid(743541,"665758502996438489")
addappid(743542,0,"9a1c708a9944a5b741530c682184484f440b268dd1792607e7a774b3c0606dd1")
--setManifestid(743542,"300283842008206441")
addappid(826260,0,"730f0b41ae3600210ce5d98d7c190c703318911e5db42bc25ef9a23f3154ba69")
--setManifestid(826260,"8273853679665060326")
addappid(974570,0,"e8bb2da157e8c93c70c248726e761b17159fada35fbc9186111cfe34330afd36")
--setManifestid(974570,"4445891124303452814")
addappid(974571,0,"7ab5f2e7e02f2bfa4da5df8bfdfc6143297bd532a929fdc0ac0afb839aa0ce6a")
--setManifestid(974571,"3803816333213688732")
addappid(974572,0,"b87449d961ffc94d0ad02ec925e914bbb39668eef7b036683d6b7d4c251cdac9")
--setManifestid(974572,"8175736514191119293")
addappid(974580,0,"d5ee66803b89f488853c2ad14716d40d01d5207a4037ffb68579e4c722d43b94")
--setManifestid(974580,"6024991011910762438")
addappid(974581,0,"9de582c46c290d5792984087b462fd56bb3dec8eda1869c73ebb5367f5ab9b44")
--setManifestid(974581,"2739476925785352263")
addappid(974582,0,"155cfe7e96ba302344a518a6e876194a1f8ce86713d28547193efe9843e4425d")
--setManifestid(974582,"1985651836552117550")
addappid(320241,0,"ed4d83e33d05319a4e3b27c21ba20baa6d156fb20362dcfd87a4e8c613ff696c")
--setManifestid(320241,"4351820987386405070")
addappid(320242,0,"22e8ab5dc40e7a3a1d1df8e5f4f32b94fe32d1661ea759545d4eadf92fc4310d")
--setManifestid(320242,"7071755618435779761")
addappid(320243,0,"b0fd34a6792ed286bc88bc888bbcef8e28de78f44528da83f291a8d9321a0824")
--setManifestid(320243,"1505874624471643823")
addappid(320244,0,"b4db053d76c226c8fee46b4746106d008a7ab7ccc97c8da9a2602dcfbbba7f91")
--setManifestid(320244,"2096929865554626181")
addappid(320245,0,"783570828fb603f83f692e885754548d99838dff4e4686706435b7399a9f628e")
--setManifestid(320245,"9047687308523318114")
addappid(320246,0,"57c5e79f0bd9ce4c47ef7c4650533653f2ca619510b5533dfd5b76c6e3341601")
--setManifestid(320246,"6202781156451450288")
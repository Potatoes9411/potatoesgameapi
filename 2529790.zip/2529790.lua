-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2529790's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:00:01 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 1
-- Total DLCs: 0
-- Blacklisted Depots: 14
--   Depot 252952: Blacklisted
--   Depot 252951: Blacklisted
--   Depot 252963: Blacklisted
--   Depot 252964: Blacklisted
--   Depot 252955: Blacklisted
--   Depot 252960: Blacklisted
--   Depot 252956: Blacklisted
--   Depot 252961: Blacklisted
--   Depot 252958: Blacklisted
--   Depot 252954: Blacklisted
--   Depot 252962: Blacklisted
--   Depot 252953: Blacklisted
--   Depot 252957: Blacklisted
--   Depot 252959: Blacklisted

addappid(2529790)
addappid(2529791,0,"03c60dc289ec3cdddbc924a04d5f9cf10a1f248a2fa65ccc021fdeb6670499ca")
--setManifestid(2529791,"2446585505490506437")
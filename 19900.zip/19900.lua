-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 19900's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:32 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 7
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 1990111: Blacklisted

addappid(19900)
addappid(21960)
addappid(19901,0,"c21afb5887d399bed13311cbcefc03dbe5552ad116a12ecbe56fe4ae069e862c")
--setManifestid(19901,"3673361057961369345")
addappid(19902,0,"91591bb723c176e6d6afae850f9b4047010247d4a1a26008b409bef474d8cdd3")
--setManifestid(19902,"9155719787324890368")
addappid(19903,0,"d3abd6b840eae547bd34f32d7928494304327351db5704f3c6545053171f1f8f")
--setManifestid(19903,"407630865862319198")
addappid(19904,0,"37d01ab596c4414c076ea853e54b112a25b1c2448add301d8ec1f5680d289f4c")
--setManifestid(19904,"6126982062191436208")
addappid(19905,0,"5d235dcc7cce0c0dadc4f74567d15b59f33b016449585a9403b5eb7053451a61")
--setManifestid(19905,"3493246412726470268")
addappid(19906,0,"444337f5a842722ec48294b7091394cd18c63a0a00837fc2d045990a613d6f65")
--setManifestid(19906,"7743973407637979881")
addappid(21961,0,"d941019d3d54cf464a67976dbb0dd0b5c26630cae2f4a5ed03e2d71b7f084740")
--setManifestid(21961,"2265566049842091901")
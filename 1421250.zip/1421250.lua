-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1421250's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:45 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(1421250)
addappid(1600150)
addappid(3787220)
addappid(1421251,0,"26c7441369eb15b5a36a102139161693464b46afa6f77cc7744ea95f920ece2c")
--setManifestid(1421251,"9068107250753705148")
addappid(1421252,0,"0179a2642033cb165f6992abded21663174ebdb683dade998bef17cf1aa13af0")
--setManifestid(1421252,"6790386510909991781")
addappid(3787220,0,"c9edd435068cdbc2aac07cfa826cda1b8db0e3a820b6de7c23832f2f0bbcb076")
--setManifestid(3787220,"5610793731797059023")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 21690's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:03 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(21690)
addappid(352000,0,"dba46409b51f3da1c7669a74a091ce7725eb5969705192edbb9ba3f9abd096d3")
--setManifestid(352000,"455789278129163691")
addappid(21691,0,"b3ad2af3d25d179accc032ae7853c6f8a916bba21b5f0be9f11f22f0938110a4")
--setManifestid(21691,"2911490666295175655")
addappid(21692,0,"556f26dec9fcd54f1ecb0f2af6b1259a325a3eed959c0b242c83fa176c74971d")
--setManifestid(21692,"8019335905957731486")
addappid(21693,0,"a07f44cc54133c4921ca14f7014ea4a5fd0aa0dbc36d13f3d7abe5f3be00c564")
--setManifestid(21693,"3603548504038570692")
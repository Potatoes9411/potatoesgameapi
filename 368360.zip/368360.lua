-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 368360's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:42 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 6
-- Blacklisted Depots: 0

addappid(368360)
addappid(368361,0,"2ae9e0ceea9fa82714b84c935be78ba81079c2a262113051c5fa634a29804699")
--setManifestid(368361,"6075978047945216467")
addappid(368363,0,"ef8ba55610beb7b64ea12aa6841c7915c109713db9847ec3a3795ff72fdf869e")
--setManifestid(368363,"6065576068917307370")
addappid(368364,0,"abebb6eabe4d79da75b4eedd4991ed0c620708feabc16b4106183bcf892583b1")
--setManifestid(368364,"6596565914329182381")
addappid(368365,0,"c0a0ee89acc3419ac7476d34852b51ad791eb12e36a43aa07de20ce6ea69b266")
--setManifestid(368365,"2340842001239944030")
addappid(368366,0,"903fd4f5c27dd32b6d461d027b8068046de105d0d649a47efebb330228e5b95b")
--setManifestid(368366,"4368570733143951820")
addappid(368367,0,"cbea14a4cdcedfed26d44652dd11dd982ccf368f476804d9fba917b1dc5a819a")
--setManifestid(368367,"5771844987335981140")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2067050's Lua and Manifest Created by Potatoes9411
-- Squirrel with a Gun
-- Created: May 16, 2026 at 04:45:23 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 11
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(2067050, 1, "Unknown")
addappid(2067051, 1, "Unknown")
setManifestid(2067051, "Unknown", 0)
addappid(2067052, 1, "Unknown")
setManifestid(2067052, "Unknown", 0)
addappid(2067053, 1, "Unknown")
setManifestid(2067053, "Unknown", 0)
addappid(2067054, 1, "Unknown")
setManifestid(2067054, "Unknown", 0)
addappid(2067055, 1, "Unknown")
setManifestid(2067055, "Unknown", 0)
addappid(2067056, 1, "Unknown")
setManifestid(2067056, "Unknown", 0)
addappid(2067057, 1, "Unknown")
setManifestid(2067057, "Unknown", 0)
addappid(2067058, 1, "Unknown")
setManifestid(2067058, "Unknown", 0)
addappid(2067059, 1, "Unknown")
setManifestid(2067059, "Unknown", 0)
addappid(3715570, 1, "Unknown")
setManifestid(3715570, "Unknown", 0)
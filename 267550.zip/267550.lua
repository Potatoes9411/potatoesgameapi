-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 267550's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:00:33 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 14
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(267550)
addappid(286910)
addappid(286911)
addappid(286912)
addappid(286913)
addappid(286914)
addappid(286915)
addappid(267551,0,"04dd3829762dc4e391c5dc81b1262094cbb8d7810f7017111dd95092ae140f3c")
--setManifestid(267551,"6217816470569200398")
addappid(267552,0,"8a3ced7859d531f58cbb35009e4670b16686745d45f4f7d0f41b996c4834a3b4")
--setManifestid(267552,"8237097105513432045")
addappid(267553,0,"5adbbc11d3a1ce1ffacfdbdfdfb9ea4357f8196837eddf5e1feb6ab39a2a9f33")
--setManifestid(267553,"6946169156450336704")
addappid(267554,0,"5588f553e461f38b5c775997aa66909af0035e9991987027a4a1b41e5d8fc9f7")
--setManifestid(267554,"4169879273930013139")
addappid(267555,0,"4506e6f6907a1693c824eb7a2f08772198fd07c46d923b70dcd6da2a8bbef609")
--setManifestid(267555,"1757749374073337260")
addappid(267556,0,"961e20547d04b976d4cbf3143737e43bd88d550f808661004722e43c0a9fef1c")
--setManifestid(267556,"672808828550552554")
addappid(267557,0,"9042443822955c69bc62d33edf174fcfdde75493bd192724ce353834e611f6f0")
--setManifestid(267557,"9139376179169848067")
addappid(267558,0,"929b559e43f6061338714d43d7d5f214d39a9974091cc731ef37af896dc22f72")
--setManifestid(267558,"8149856904250414620")
addappid(286910,0,"5252f5acab6817660b884d9f02a28ac3d9b8862aca62ba7b892b4c9bf22fcff5")
--setManifestid(286910,"5501426235777094317")
addappid(286911,0,"b91bcae94baeba7c40e1905f068e21587bd947bad650e26341078acfb6ca42f9")
--setManifestid(286911,"928273075209619740")
addappid(286912,0,"52caa3063f92a027c1511d97c97511558a6222de9e50ec5cbf29baea9e7c0c40")
--setManifestid(286912,"563234625403322468")
addappid(286913,0,"31952590d414a22d5158f2a3dcc956ed5fcca84a81825f0d0347c28dd605aad7")
--setManifestid(286913,"1393143416676027006")
addappid(286914,0,"a925a288f9162013bab8c33a848bf5c5f0d700d8329ba256062162a5cf9187db")
--setManifestid(286914,"870872215230150878")
addappid(286915,0,"f467cc43a6242a65717a255bd43649f32e5c564724275f470ccfcebdb4d80d11")
--setManifestid(286915,"3586444822452921394")
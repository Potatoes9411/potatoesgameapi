-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3208880's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:21 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(3208880)
addappid(3208881,0,"34dd01ace890a6f94ea75e377325d639a05a11a09ff8deff3a690ef1e5d96225")
-- setManifestid(3208881,"7868982605634033160")
addappid(3577720,0,"211290cafd5dc11c5fa63d07649e9ac46e0a0bc11536329c83f0c76459d1d05d")
-- setManifestid(3577720,"5697056513131323978")
addappid(3577730,0,"ed22e32251f2722950428edc73435cd397da28fa3573de1ccfed89b9fff4d0e3")
-- setManifestid(3577730,"6793204456295648869")
addappid(3577740,0,"be966b809a1563c14b2e3d4e4c59e8d00c14a0e1c3a78c17486e910861ab3443")
-- setManifestid(3577740,"2048132225973406555")
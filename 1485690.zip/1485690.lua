-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1485690's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:56:34 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(1485690)
addappid(2239080)
addappid(1485691,0,"74a35a5e7fd10a48ec9f16870df9575e1389402128f49fef01a6e5ca65a3a282")
--setManifestid(1485691,"6262064825271092391")
addappid(2239080,0,"845274ae026e4eee4d1f9acab311bbffe8fcb552b8a878898066b472e97c20c5")
--setManifestid(2239080,"5588315491262859765")
addappid(2239081,0,"82c4137c68eaaabd30476fe11bdcee3b17fb3831d13ea0236a03b48154d6b63b")
--setManifestid(2239081,"4507019552982981583")
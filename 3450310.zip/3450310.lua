-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3450310's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:30 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(3450310)
addappid(3450310,0,"abdc499f4638e2d977e16203b7173a9af729319f625704e136ec1b194032572a")
addappid(3698980)
addappid(3699010)
addappid(3865300)
addappid(4091650)
addappid(3450311,0,"8e55f9c055e30102dd092568a62262d3e5c812fc6708b9ed1ba03bdbe15dc456")
--setManifestid(3450311,"2222112637396278699")
addappid(3450312,0,"8e3d3c7051dc0ba1a4320aa4fb02d83724de0150342f7c05e4b1b126f611dfd5")
--setManifestid(3450312,"3453957695214033514")
addappid(3450313,0,"559435c494fa76bc572eb78918ebd2a4046f80a9de65280538e793d66f5d34b0")
--setManifestid(3450313,"4517633088382396561")
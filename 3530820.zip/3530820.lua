-- Made by F1uxin, Discord ID:965053505901588521 | Discord Server (TGP | The Galaxy of Pirates): https://discord.gg/VfCxRsFyFe

-- If you're interested in distributing these files please dm me on discord (UserID:965053505901588521) 
-- (I don't care if you send them to a friend or to help someone, just if you add them in your bot or have them widely available then i would like to know.)

-- Socials: https://guns.lol/f1uxin

-- If you have any questions feel free to dm on discord (UserID:965053505901588521)


-- Main stuff to actually add the game, DLCs, & depots.
addappid(3530820) -- Puzzling Places - 3D Jigsaw Sim
addappid(3530821, 1, "d28d9ecbd7a185726b6707775ae43a63f67a9a88a2f563555f9e7c7482833a18") -- Depot 3530821
setManifestid(3530821, "8130546115462160680", 3224048551)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(4521570)
addappid(4521570, 1, "69098482169fb44c3906e9e74d3b5bb116f15378cbd9f3d61390f7fe5a31ed6e") -- Puzzling Places - Ancient Egypt - Depot 4521570
setManifestid(4521570, "2889222473828851158", 575487995)
addappid(4684150)
addappid(4684150, 1, "54ee7e61b2e9390d128362a473828eec1897f60053d3352a42fa872362be5780") -- Puzzling Places - Behind High Walls - Depot 4684150
setManifestid(4684150, "3914728631193577390", 485856137)
addappid(4684160)
addappid(4684160, 1, "0f9a24c2c73736b921e17447ac56ad314601157f7594217ff25d807c7e7150fb") -- Puzzling Places - Mars Desert Research Station - Depot 4684160
setManifestid(4684160, "8001738725155318886", 438772319)
addappid(4684170)
addappid(4684170, 1, "f2819b4b1ef2fe56fbb213c7110fc5468bdbab838288abb4b8be4c2d021045b2") -- Puzzling Places - Variety Pack Vol. 2 - Depot 4684170
setManifestid(4684170, "3400958953092385432", 417898348)
addappid(4684180)
addappid(4684180, 1, "bab6dc2c1da58d52d16a498e3d383c15eb6b624433bb44e912bac45a62129832") -- Puzzling Places - World Heritage Tour - Depot 4684180
setManifestid(4684180, "3444394987201113202", 839086445)
addappid(4684190)
addappid(4684190, 1, "2b4f62aa48879ce80ab6c65cd2258bfc62c40ffd3e3a5613da629a647b9d4b94") -- Puzzling Places - New York City - Depot 4684190
setManifestid(4684190, "7309438852398777436", 636555636)
addappid(4684200)
addappid(4684200, 1, "3f292fdb1aa2342b6c7579feb645beab80f0326175e5d3717102dffd840cd629") -- Puzzling Places - Return to Greece - Depot 4684200
setManifestid(4684200, "7796684893367065027", 681194036)
addappid(4684210)
addappid(4684210, 1, "2eec44927bee894f0dfbb15b085a397f76f24d7e11af59857053a094ada047b0") -- Puzzling Places - Tokyo - Depot 4684210
setManifestid(4684210, "7419808101917236702", 670583059)
addappid(4684220)
addappid(4684220, 1, "749e5f80467e43a156cd32fcb14369e54104ef374368b48f14a6fe4b0f4a2b86") -- Puzzling Places - Springtime Pack - Depot 4684220
setManifestid(4684220, "5151314684834782986", 989510817)
addappid(4684270)
addappid(4684270, 1, "773bfd97ed26fd6965cf42bdedd4be721927d0f5b2d818b3e83764bba4a306fc") -- Puzzling Places - Halloween Special The Haunted House - Depot 4684270
setManifestid(4684270, "9074017546950543955", 174673356)
addappid(4684280)
addappid(4684280, 1, "2ab057ec90f13f1b6ffad29db3115c3be104fe364974d3e4857bd7520b4e7d9b") -- Puzzling Places - Halloween Special Draculas Dinner - Depot 4684280
setManifestid(4684280, "5567069452135800627", 171749476)
addappid(4684290)
addappid(4684290, 1, "f2729465d3cfe2a9f6c2dccd6786498a944c615ec0dba7250f6486a24b08a68c") -- Puzzling Places - Holiday Special Driving Home for Christmas - Depot 4684290
setManifestid(4684290, "4337998478539558837", 301985244)
addappid(4684310)
addappid(4684310, 1, "7ad8283b2b409372994323c538326607eac37d3e99f2b62d5afd769aaa35e817") -- Puzzling Places - Monastery of Batalha Day  Night - Depot 4684310
setManifestid(4684310, "8378612961776873541", 311581693)
addappid(4684340)
addappid(4684340, 1, "370f905ab736de42b5395db652af5b1cb3b4faaeea826908b05c9e6818926684") -- Puzzling Places - Summer Dive - Depot 4684340
setManifestid(4684340, "5242972443224540441", 323160533)
addappid(4684350)
addappid(4684350, 1, "7dceaa6f8d8fb50061afc951f00778c242badd7a47a1a44b90757f35bcbf3038") -- Puzzling Places - Halloween Special Undead Afterparty - Depot 4684350
setManifestid(4684350, "6128793547576644595", 346406850)
addappid(4684360)
addappid(4684360, 1, "5dfee3eb430726acfbcdbb0198ea051b18936b10026e047a64819b5e8e7f2f67") -- Puzzling Places - A Painters Dream - Depot 4684360
setManifestid(4684360, "4130188389798352861", 308552307)
addappid(4684370)
addappid(4684370, 1, "b8ad4221c928e1909531624e85deb804496ed6000a37a156215ffb10e553e824") -- Puzzling Places - The Kings Port - Depot 4684370
setManifestid(4684370, "4921343948836722422", 296977480)
addappid(4684380)
addappid(4684380, 1, "70ef98a5a5a049c7978458cdf3eb66baf01c88c34a1ada8c839fc169070d3c89") -- Puzzling Places - Our Planet Earth - Depot 4684380
setManifestid(4684380, "3643488411969981708", 368021586)
addappid(4791780)
addappid(4791780, 1, "ee3b6d09867f97d54b10a9ebe78548dbc7c3800a60490766bc60ca6178d17de5") -- Puzzling Places - Monthly Pack 44 - Inside  Out - Depot 4791780
setManifestid(4791780, "4496158681701759298", 1006467079)
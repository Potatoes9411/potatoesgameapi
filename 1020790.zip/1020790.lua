-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1020790's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:55:22 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 1020541: Blacklisted

addappid(1020790)
addappid(1020790,0,"9f68fbfc5c958fc71ebbfd872f331b90ea558aaa7c36ac423503c0f55233f347")
addappid(2171320)
addappid(2171321)
addappid(2171324)
addappid(2171325)
addappid(2171326)
addappid(2171327)
addappid(2171328)
addappid(2171329)
addappid(2171330)
addappid(2171332)
addappid(2542820)
addappid(2594760)
addappid(2674900)
addappid(1020791,0,"20b22cbbc47231bd29023b51d8a6fa2c019ad774840d245064799912ea48b105")
--setManifestid(1020791,"1061767113913208859")
addappid(2542820,0,"290c05f9538952fbafab1381ad8516cb900a835310db3701bd21461afa343090")
--setManifestid(2542820,"2745812014487487415")
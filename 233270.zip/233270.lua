-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 233270's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:59:06 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 15
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 2332411: Blacklisted

addappid(233270)
addappid(236590)
addappid(236591)
addappid(233271,0,"8315dec9a2ddcc5c059a1ca00d18516eb296dc7538488359c064bc72e2580ac8")
--setManifestid(233271,"5439058854678686011")
addappid(233272,0,"9f362a0a29d63e7dd5e5830c069c89bc73c9d8821c05d1f8fce5d7cb04ad3cc2")
--setManifestid(233272,"4836578367993039033")
addappid(233273,0,"a2d54910001b9c1fbac5331a3db7e41d71114c4e1f4c903f93c57bfe8d151cab")
--setManifestid(233273,"5487171258687035441")
addappid(233274,0,"c63182fdff89171bdaccbef2f5dfecbc06b27b9c4f0d5af743eb9cb75176eb21")
--setManifestid(233274,"7777681346067846616")
addappid(233275,0,"1aa1a040b2d00f319f559fd067a5ac15cb52be1bb992288783b68ff0439aaf44")
--setManifestid(233275,"6106842746289136169")
addappid(233276,0,"1f2db89e1d9f5c92c64d5e3b1356905ed510efe7aac9badd6d9c9c598c8f3b3a")
--setManifestid(233276,"651291319822119236")
addappid(233277,0,"3a72976af497b234b598a54791e2cf189694c51eba17073c9cde5887c99cdf9a")
--setManifestid(233277,"7024967757142890937")
addappid(233278,0,"6983d94b02fa9f88a94041b660627d2e796f0e58c082151d3de6a5cd96d38174")
--setManifestid(233278,"9171019242207172716")
addappid(233279,0,"5588fad7ccc31321ebdb749e7a5ef7c742866c5b5ce43b46613bc165ae662a89")
--setManifestid(233279,"7749982960665436279")
addappid(233280,0,"dd45f7d996c068c2f23517d5d2c4775d8ccc69a19743819b67e2633b4586460f")
--setManifestid(233280,"6407469055372918697")
addappid(233281,0,"93bc888c58929cc1d81ae1553cbd653cdabf4c4752a96a902ef76fc78321b6d2")
--setManifestid(233281,"1545908752462243822")
addappid(233282,0,"a40670bef3cd8bcb98b1c10516813edb4e55983dc4ea159c89296ca1168c7aa6")
--setManifestid(233282,"4691540797136331227")
addappid(233283,0,"a440a60b0e4c5930417bdb500ec187d104cf73fab780758600720105297b69a3")
--setManifestid(233283,"8616632010971844518")
addappid(236590,0,"1ba1787ecbcbb5b2b6d7b22f7c84abb5384a9c32ded804607b72bb08dcb4954d")
--setManifestid(236590,"5035396541820682940")
addappid(1716751,0,"84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
--setManifestid(1716751,"4132506267642462151")
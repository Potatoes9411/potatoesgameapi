-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1290270's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:56:11 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 1
-- Blacklisted Depots: 2
--   Depot 1290001: Blacklisted
--   Depot 1290761: Blacklisted

addappid(1290270) -- Vampire: The Masquerade — Night Road
-- MAIN APP DEPOTS
addappid(1290271, 1, "148a239c347a4dda889f2f64a24ef3afe100c6b7d8d43acfff0443320d9037cd") -- Vampire: The Masquerade — Night Road Content
--setManifestid(1290271, "1010586524042802510", 331568318)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1421370) -- Vampire The Masquerade  Night Road  Usurpers and Outcasts
addappid(1561110) -- Vampire The Masquerade  Night Road  Secrets and Shadows
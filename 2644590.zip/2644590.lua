-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2644590's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:00:27 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 2
-- Total DLCs: 0
-- Blacklisted Depots: 11
--   Depot 2644361: Blacklisted
--   Depot 2644873: Blacklisted
--   Depot 2644611: Blacklisted
--   Depot 2644892: Blacklisted
--   Depot 2644891: Blacklisted
--   Depot 2644893: Blacklisted
--   Depot 2644: Blacklisted
--   Depot 2644362: Blacklisted
--   Depot 2644051: Blacklisted
--   Depot 2644872: Blacklisted
--   Depot 2644871: Blacklisted

addappid(2644590)
addappid(2644590,0,"2b3b9c24862df683b11a012c2fff2a7163c994aa1a5ee0296aad3527e072e304")
addappid(2644591,0,"f73171ad2295fd1043efbcba62ecb3f6626829607334bc412a46e3fac5ae0f53")
--setManifestid(2644591,"8990496265523584485")
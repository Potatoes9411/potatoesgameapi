-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2780360's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:00:53 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 4
--   Depot 2780810: Blacklisted
--   Depot 2780981: Blacklisted
--   Depot 2780891: Blacklisted
--   Depot 2780800: Blacklisted

addappid(2780360)
addappid(2780361,0,"7148b8c5166bd496374619d17140bf3ee7b9b771e770d45bc6370a4976285cf4")
-- setManifestid(2780361,"388909364257526628")
addappid(2780362,0,"fb8a65aa85dcb43094b9c433d1339719489e07cadb6a2a8aa6df53ebb8143eb1")
-- setManifestid(2780362,"8450575824480081156")
addappid(2780363,0,"b547a9fd9f423e70d6e996baffc2d6be88762b0e62b6141fe49fe3aefd6551b7")
-- setManifestid(2780363,"7906450499239559297")
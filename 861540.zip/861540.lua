-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 861540's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 07:00:07 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 6
-- Blacklisted Depots: 0

addappid(861540)
addappid(861540,0,"46e2b7f282a43d0077bc0eb5c3e4b3a8679be18606ec603d86a23975be42222b")
addappid(861541,0,"e2d360359f3cab047b458cd919079a6cb56277b698da2ccb7335767f01475cde")
--setManifestid(861541,"3440123193488866730")
addappid(861542,0,"084f662543b4fee4dd3643576bf9b6d571c077ccfe3c8f6dd12ec2ab5cecdf88")
--setManifestid(861542,"2612466654341090027")
addappid(861543,0,"5a005c1ae99c6ea670f79dea6be1a8f304d0c9a76d0893bc6913c7dc912acdc7")
--setManifestid(861543,"7638799216073655501")
addappid(861544,0,"5f04432e3941dfb6966df7d762b3eea73a91697c52f289ae2291c871a807113a")
--setManifestid(861544,"4505794216639419682")
addappid(861545,0,"6505164a5635b313b5d3b101d25b6ddc6ee597bf62789c095f5cf5d8f39cdf19")
--setManifestid(861545,"3439686638281531027")
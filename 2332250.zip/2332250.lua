-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2332250's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:59:06 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 1
-- Total DLCs: 0
-- Blacklisted Depots: 14
--   Depot 233283: Blacklisted
--   Depot 233271: Blacklisted
--   Depot 233281: Blacklisted
--   Depot 233272: Blacklisted
--   Depot 233277: Blacklisted
--   Depot 233280: Blacklisted
--   Depot 2332411: Blacklisted
--   Depot 233276: Blacklisted
--   Depot 233279: Blacklisted
--   Depot 233275: Blacklisted
--   Depot 233274: Blacklisted
--   Depot 233273: Blacklisted
--   Depot 233282: Blacklisted
--   Depot 233278: Blacklisted

addappid(2332250)
addappid(2332251,0,"bf20d56fd5e652db114c1eff55117eb9d6f95b5e55323aeba9a83fd47d6bbf02")
--setManifestid(2332251,"8695113468762071784")
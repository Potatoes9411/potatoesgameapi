-- Made by F1uxin, Discord ID:965053505901588521 | Discord Server (TGP | The Galaxy of Pirates): https://discord.gg/VfCxRsFyFe

-- If you're interested in distributing these files please dm me on discord (UserID:965053505901588521) 
-- (I don't care if you send them to a friend or to help someone, just if you add them in your bot or have them widely available then i would like to know.)

-- Socials: https://guns.lol/f1uxin

-- If you have any questions feel free to dm on discord (UserID:965053505901588521)


-- Main stuff to actually add the game, DLCs, & depots.
addappid(4255580, 1, "105b378e77b9cad7b861c872aa5f4e7e85e678340727b614da2a84fe169c9290") -- Mouse X
addappid(4255581, 1, "aa4c00e5e89a211d2168823cfc0ab5d8080fb921d46daf7a498ed6d9b1d6a6f9") -- Depot 4255581
setManifestid(4255581, "5934864511575795904", 182679270)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
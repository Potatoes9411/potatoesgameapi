-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 221100's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:58:20 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 4
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(221100)
addappid(221100,0,"1166f7815221fcc3afac8682ba307d6496101848e6483b6bb838551f2923ae64")
addappid(2968040)
addappid(3816030)
addappid(830660)
addappid(1151700,0,"ed6fa275132bd015ad355b4058b0e4af4a79d000c2f912d1e28a19185ef3c1eb")
--setManifestid(1151700,"3323236725842480808")
addappid(221101,0,"9d9c5d3d77309bbe701a3f018cea877d22d07160b4ea2b65bdf261d0dc399c15")
--setManifestid(221101,"4044402423104295141")
addappid(221102,0,"fe6ef04ad5778ee58766d4c8b7057fa84feb52c2cc0155d808fb40ca1bd42789")
--setManifestid(221102,"6257360505448895155")
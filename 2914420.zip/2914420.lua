-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2914420's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:01:23 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 1
-- Total DLCs: 0
-- Blacklisted Depots: 3
--   Depot 2914120: Blacklisted
--   Depot 2914152: Blacklisted
--   Depot 2914151: Blacklisted

addappid(2914420)
addappid(2914421,0,"f5aa4bc12166e8e3c136aaa533b42f9a0caa15d10e1c3c5c4d507b7a932185f4")
--setManifestid(2914421,"3499947612866946853")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 254700's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:23 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 6
-- Blacklisted Depots: 3
--   Depot 2547982: Blacklisted
--   Depot 2547981: Blacklisted
--   Depot 2547983: Blacklisted

addappid(254700)
addappid(272260,0,"887fbc832b41f133430f20d78b365b07c724dd04c51ddcc48f879d907c4fd055")
--setManifestid(272260,"8170509752846139490")
addappid(272261,0,"e899c415aef8a533e80abb6c72b6bf3602f0b9b064c1bbb381a655667c576336")
--setManifestid(272261,"4849919482799769104")
addappid(254701,0,"138bb1e5f555bb1881214eced9844b83b643695fc8726786a42b42a3f5c27902")
--setManifestid(254701,"6999377187357974260")
addappid(254702,0,"058a874bbbf796de8ae730aad32795572400bfc1404392b872a3302908e81889")
--setManifestid(254702,"7568911904646837022")
addappid(254703,0,"ed74776e6c965e3350288b1d290aae4e39c94c62e8173e014c085027e5b9e07d")
--setManifestid(254703,"3343076949474248393")
addappid(254704,0,"870c561ed9cbeb8f5733db64c240b45b609f1b8440890d999af03e206733d31d")
--setManifestid(254704,"7927591321049438693")
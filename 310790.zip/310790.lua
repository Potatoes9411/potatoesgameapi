-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 310790's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:45 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 6
-- Blacklisted Depots: 0

addappid(310790)
addappid(333630)
addappid(310791,0,"22339baa4088b74620ca32ad42a8b2aee19f19c6a74f69783e15ed93800ae052")
--setManifestid(310791,"6063129916817183673")
addappid(310792,0,"19f76e591aed58ccd9c7f88f4c756340913cdbf4e909df93d8ba0e9d9ce784bb")
--setManifestid(310792,"6816591634959749630")
addappid(310793,0,"3d23995b2bccaf040619db2433fa44107ab4980d087a591164ceb180251855ac")
--setManifestid(310793,"1144251810863564490")
addappid(310794,0,"1179b9ffeac609b68cb25838413eabb1dcffaa3a04ede02a225bb8178de7bdbc")
--setManifestid(310794,"1307562684197234198")
addappid(310795,0,"45fad7b8475b90b8ca16d27b9b967c4268167aa7099e25d18517047db73e728f")
--setManifestid(310795,"1216529145201090682")
addappid(310796,0,"d63663572b6915c367e67d403014ef1c704e564c88f93c0ba4613c4cf03beecb")
--setManifestid(310796,"6597629922024249398")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 40800's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:53 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 6
-- Blacklisted Depots: 0

addappid(40800)
addappid(969710)
addappid(98011)
addappid(969710,0,"a04242b1f5cb97808ad527ea154a7b29e7d24a133cb943e832ebc57c356aa1a2")
--setManifestid(969710,"9030929104429239407")
addappid(98011,0,"b54a8be91d6223e22beaa4c5415f00aef71770d682068b7999855d6ba1e543ff")
--setManifestid(98011,"915545047853675884")
addappid(202941,0,"e81a93a26c224c42af1e8b013dc148809b870d1718fd970fca8be9afda5ac806")
--setManifestid(202941,"7909665330530849751")
addappid(202942,0,"7456550b7c6035613e2dce4b1e5330096bd2949510d0174327e0456092632dbf")
--setManifestid(202942,"5927010178477174585")
addappid(40801,0,"cdba07a99af206aeb16f77b2fb63ef6d5a7b9323bb7a92e48244fd597013dcca")
--setManifestid(40801,"5234313430832523474")
addappid(40802,0,"64a9ded61e049fd8ab73451c519acf2321c6419b6924603516861486a2df1982")
--setManifestid(40802,"6556596646716197166")
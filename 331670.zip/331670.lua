-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 331670's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:25 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 6
-- Blacklisted Depots: 0

addappid(331670)
addappid(2828508,0,"86a8e078c58ea7fbf57bdf1b2611116fe069f5e590cfa11058ca6610e0961700")
--setManifestid(2828508,"5145691608909662874")
addappid(331671,0,"295372223bc653333de3767fd317e07ce45cde8991fcd08255602cfc39b4f169")
--setManifestid(331671,"3025208085012167773")
addappid(331672,0,"195367601959a14b67005a609f1b92f187930fe6d2cdc12184b88feed8a5c609")
--setManifestid(331672,"1930310580463545147")
addappid(331673,0,"052ed98d80316537e337c3af303719d4392ebb5d824f704914a3bcd3bea07976")
--setManifestid(331673,"5597167193466821044")
addappid(331674,0,"4392430d227f8f13ee87ea444af47225aed64a2043728add6dd8a8565a8ecabc")
--setManifestid(331674,"7769939223823843189")
addappid(331675,0,"3c278fec1ccb47c44ca0f8e785c67a1257a5b8890493fd2e4e495474ddfc7b60")
--setManifestid(331675,"4707960372324195334")
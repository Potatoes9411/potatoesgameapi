-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2138720's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:58:02 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 1
-- Total DLCs: 0
-- Blacklisted Depots: 11
--   Depot 2138336: Blacklisted
--   Depot 2138334: Blacklisted
--   Depot 2138338: Blacklisted
--   Depot 2138335: Blacklisted
--   Depot 2138333: Blacklisted
--   Depot 2138339: Blacklisted
--   Depot 2138332: Blacklisted
--   Depot 2138711: Blacklisted
--   Depot 2138331: Blacklisted
--   Depot 2138330: Blacklisted
--   Depot 2138337: Blacklisted

addappid(2138720)
addappid(3469160)
addappid(3469170)
addappid(3469180)
addappid(3525370)
addappid(3743380)
addappid(3743390)
addappid(4002110)
addappid(4002120)
addappid(4031620)
addappid(2138721,0,"c1a2b9eea7346395b175b2d8458f566dcabe83b99822111d3446a5ce377bdc52")
--setManifestid(2138721,"8310989468902537208")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2356150's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:59:12 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 1
-- Total DLCs: 0
-- Blacklisted Depots: 20
--   Depot 2356783: Blacklisted
--   Depot 235604: Blacklisted
--   Depot 235612: Blacklisted
--   Depot 235618: Blacklisted
--   Depot 235607: Blacklisted
--   Depot 235616: Blacklisted
--   Depot 235608: Blacklisted
--   Depot 235603: Blacklisted
--   Depot 235613: Blacklisted
--   Depot 235605: Blacklisted
--   Depot 235619: Blacklisted
--   Depot 235614: Blacklisted
--   Depot 235617: Blacklisted
--   Depot 235601: Blacklisted
--   Depot 235615: Blacklisted
--   Depot 2356782: Blacklisted
--   Depot 235606: Blacklisted
--   Depot 2356784: Blacklisted
--   Depot 235609: Blacklisted
--   Depot 235602: Blacklisted

addappid(2356150)
addappid(2356151,0,"3061395ab01738e6770d6b9d069f772ef613dfa197d38c259a7602e5f1e6d8d8")
--setManifestid(2356151,"8234968148157106306")
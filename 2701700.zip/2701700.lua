-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2701700's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:00:41 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 6
-- Total DLCs: 0
-- Blacklisted Depots: 4
--   Depot 2701721: Blacklisted
--   Depot 2701441: Blacklisted
--   Depot 2701661: Blacklisted
--   Depot 2701801: Blacklisted

addappid(2701700)
addappid(3352570,0,"022fe7cb197b2917937fbdf1d8b2570c68cb40f132e43e12da84d73201e49090")
--setManifestid(3352570,"7171058449910880576")
addappid(3645630,0,"ea989b494e203fee4f27d10f6f0bf96e8c3f33c7493bdced6a929e4f851f71f9")
--setManifestid(3645630,"8630273399606830531")
addappid(3762030,0,"2056e764d70d4ab9bdb04a32255015ea1dcf321d3887bb1e7b26feb1bfc9c699")
--setManifestid(3762030,"7855821871686166546")
addappid(4024720,0,"ccd2d363c6954f39fde2414911b344a4301873fe15542606898bf17485ee5759")
--setManifestid(4024720,"6254748597036639063")
addappid(4197260,0,"e92e895dffd11fc8bb7b3789ddb32f0799d449f70e9a4145cfdc07fa4a809833")
--setManifestid(4197260,"2200330140680033700")
addappid(2701701,0,"b76ebf3606bcb620ac016cbd1b82209d33f969e6b2208f59946f2d562d0f1c06")
--setManifestid(2701701,"7853699066934538915")
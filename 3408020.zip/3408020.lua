-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3408020's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:28 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(3408020)
addappid(3408021,0,"06b203b03761769ea4747b17e56bb3c7fdee7ebb845c7097f5ca02824cd8a738")
--setManifestid(3408021,"5529429549785869495")
addappid(3408022,0,"ca07380d8b7779783d27129ff779aab8a6fe8ba9c2a61126f52ecdbda3c7067b")
--setManifestid(3408022,"2494840266519243865")
addappid(3408023,0,"8af839c1d8a7ec14cd075409a3f8d93b4206d4e4f09bcef4602696dda8f1526b")
--setManifestid(3408023,"2807049169860509142")
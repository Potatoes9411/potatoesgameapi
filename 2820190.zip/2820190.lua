-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2820190's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:01:04 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 1
-- Total DLCs: 0
-- Blacklisted Depots: 12
--   Depot 282080: Blacklisted
--   Depot 2820751: Blacklisted
--   Depot 282079: Blacklisted
--   Depot 282083: Blacklisted
--   Depot 2820701: Blacklisted
--   Depot 282078: Blacklisted
--   Depot 282082: Blacklisted
--   Depot 282081: Blacklisted
--   Depot 282071: Blacklisted
--   Depot 282077: Blacklisted
--   Depot 282076: Blacklisted
--   Depot 282075: Blacklisted

addappid(2820190)
addappid(2820191,0,"aba37d9e3c98a2cc729f1162c67ae8e68c11ec737a37ae198e0182c5d7342386")
--setManifestid(2820191,"8836809572030230103")
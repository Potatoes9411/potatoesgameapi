-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2168150's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:58:05 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 2168261: Blacklisted

addappid(2168150)
addappid(2168151,0,"dc9c2e8ccc529df4f80d2d190e612120d557536a9c5f93d7480f0524cd951725")
--setManifestid(2168151,"1455968709478129570")
addappid(2168152,0,"84a61835d5b64643c93b9599b418ac0c47a989e87bf3ed5eb0582e62b8d9eac3")
--setManifestid(2168152,"148205085760903526")
addappid(2168153,0,"5c370b2236711cf0f470b66f0d7c25569bdc4ab1128d889f3e34b8287fe61565")
--setManifestid(2168153,"6989779433070871795")
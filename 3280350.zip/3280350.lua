-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3280350's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:24 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 14
-- Blacklisted Depots: 0

addappid(3280350)
addappid(3669120)
addappid(3669170)
addappid(4119250)
addappid(3280351,0,"adedba4e249ea03aa263769ddb3bccd36a54816bbe471c73c51c5b1569187d00")
--setManifestid(3280351,"2607477176974537684")
addappid(3280352,0,"4a43534f83813efc865429cc3edb56f45db455c86e8373827711e5c447f0d7e3")
--setManifestid(3280352,"7451498967293988058")
addappid(3280354,0,"7010c7c1c501ba95ec42f5545dcfc4ee462ca97e854e4c0c3eccb61cbaf26c84")
--setManifestid(3280354,"6192873018491771353")
addappid(3280355,0,"50cfe1f0f242308653ad05a8b8fe9584fa351541b3d791dc5aad88551f1c7d7e")
--setManifestid(3280355,"8778380903344259947")
addappid(3280356,0,"07766d818c98a30b9be759700331449b058d782e839b4aac64b95657b6c82874")
--setManifestid(3280356,"1048323885302250340")
addappid(3280357,0,"2a099de8b315d9bb7ad6ccd9589c278e59cbee17b5d6661c886a0d9c9ec84f86")
--setManifestid(3280357,"6907394593365258098")
addappid(3280358,0,"9c26057431edb93a11cad7a246c2b765391eaf18e38d1bd8a9c2a7433fc69aaf")
--setManifestid(3280358,"7310126732521444880")
addappid(3280359,0,"1da8c06ccf9373407642f3320f2150fc3fc35020faf8967c6a506e3d882ab34a")
--setManifestid(3280359,"3501722085141087279")
addappid(3669121,0,"b25594517feb73aa10cd13ffc9507e027aac8dd2fe4c451547f6b4401f74d318")
--setManifestid(3669121,"7911449249511130970")
addappid(3669122,0,"640832b483b5a8f5dac50d55e17ef9a31d9b5f58f29b6ea5c85a41a0dfb0342b")
--setManifestid(3669122,"5648819044024192892")
addappid(3669123,0,"a2aba5b5b71722e792d695f883c5d6b62ed57f286bc0b9d3b4f84578f1335076")
--setManifestid(3669123,"3798818004235048972")
addappid(3669124,0,"647404e49ca916a3796b7839067145587e75bcb75957e706a0979ae21dc25d0f")
--setManifestid(3669124,"5935004088472077409")
addappid(3669125,0,"33b649ba960e4412464f28b70beb09f3567216daaa0bbd08879019f78d945b1f")
--setManifestid(3669125,"7925816387879957204")
addappid(3669126,0,"b95d6ff8f985523cf9b2826e9eac6d66c0a794de6d064972b193fffc7ca538b7")
--setManifestid(3669126,"3076020091720019374")
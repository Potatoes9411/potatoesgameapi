-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 222880's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:09 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 5
-- Blacklisted Depots: 0

addappid(222880)
addappid(228983)
--setManifestid(228983,"8124929965194586177")
addappid(228985)
--setManifestid(228985,"3966345552745568756")
addappid(228990)
--setManifestid(228990,"5087715316087945828")
addappid(222881,0,"7f6a345589c40ed3219cf61c8dcab19dc29b21cce2724fbf37d66d35c6bab45a")
--setManifestid(222881,"1126888633636088522")
addappid(222882,0,"03b23b12e29cdb5298dbc3ae75f93457430f514da5007568ea9bb5b7858cd18d")
--setManifestid(222882,"8952076168263683470")
addappid(222883,0,"f60604541bf6c8d2d9101a76b866496372df0f947c9154734d07824413396a00")
--setManifestid(222883,"6866083906643020698")
addappid(222884,0,"442e79eb2ef23374e531f936c0744b20f705852957c3ec7a42bb3378e2950769")
--setManifestid(222884,"4874402851781940787")
addappid(222890,0,"8341bad422a07ababf09db80b6f14a8b0474be502b5388109bd0d42935a8475e")
--setManifestid(222890,"2140895414899844075")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 12120's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:55:47 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 4
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(12120)
addappid(12121,0,"d89825855fd6f4b802378b6110effadaea8db612d89de6cf00f75dc92f898bf0")
--setManifestid(12121,"242870450180196986")
addappid(12122,0,"eaa6ab82216553e3e53f1de147e88096b378cbc8b0cd488fd2c4d047ff263389")
--setManifestid(12122,"5085199700668523983")
addappid(12123,0,"b6246a66a369124f35879ade188971257e9827d14f178abace4d759001e6191a")
--setManifestid(12123,"3229936372288409207")
addappid(12124,0,"020b11d09c31b51ddf1f3de13d5a2e420501f31de6638914b7ecfee4b15e3fc8")
--setManifestid(12124,"1305660839026218242")
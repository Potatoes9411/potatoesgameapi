-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2359470's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:59:13 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 1
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 2359171: Blacklisted

addappid(2359470)
addappid(3344210)
addappid(3344220)
addappid(3344230)
addappid(3422360)
addappid(3422370)
addappid(3422380)
addappid(3652050)
addappid(3652060)
addappid(3671390)
addappid(3712840)
addappid(3747170)
addappid(3761150)
addappid(3852720)
addappid(3891280)
addappid(3891320)
addappid(3917360)
addappid(4036060)
addappid(4092820)
addappid(4092830)
addappid(4095280)
addappid(4147020)
addappid(4192300)
addappid(4238150)
addappid(4238160)
addappid(4398580)
addappid(4452400)
addappid(4509770)
addappid(4554580)
addappid(4597120)
addappid(2359471,0,"fae5ab274cd384def39251b423becea322c959a06e5ec256ba8460c38b2b79c3")
--setManifestid(2359471,"6730386385089860402")
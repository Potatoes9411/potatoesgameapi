-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2873050's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:01:13 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 1
-- Total DLCs: 0
-- Blacklisted Depots: 12
--   Depot 287392: Blacklisted
--   Depot 287379: Blacklisted
--   Depot 287375: Blacklisted
--   Depot 287378: Blacklisted
--   Depot 2873661: Blacklisted
--   Depot 287376: Blacklisted
--   Depot 287374: Blacklisted
--   Depot 287373: Blacklisted
--   Depot 287377: Blacklisted
--   Depot 287391: Blacklisted
--   Depot 2873662: Blacklisted
--   Depot 287372: Blacklisted

addappid(2873050)
addappid(2873051,0,"a2d8836db35ab5be6eadc3d79e6b87988bb66f936eb70be4ea062691b84c703c")
--setManifestid(2873051,"6979057794253499922")
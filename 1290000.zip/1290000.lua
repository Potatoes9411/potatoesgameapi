-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1290000's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:42 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 15
-- Blacklisted Depots: 0

addappid(1290000)
addappid(2088510)
addappid(2088511)
addappid(2236950)
addappid(2464650)
addappid(2562180)
addappid(2593910)
addappid(2593920)
addappid(2593930)
addappid(2736310)
addappid(2736320)
addappid(2736330)
addappid(2983890)
addappid(2983900)
addappid(3077590)
addappid(3202500)
addappid(3202510)
addappid(1290001,0,"e1f9c3c77548607fe5ec8fd39e594dc6926e14264a94ac69596edc9a4c1c5d2d")
--setManifestid(1290001,"1220066493861247784")
addappid(2236950,0,"57599a6ca6afdc5976b0a58f3b1fcb3112af8c0a49e22deaa617135d4fdbbe0c")
--setManifestid(2236950,"5797815025118046867")
addappid(2464650,0,"aa72be5f1b0234d84153fd284facc44dca5863b88713f127f15b594ebaef6984")
--setManifestid(2464650,"7910315142882863444")
addappid(2562180,0,"d74d4632fe8e399ed87416813dd465b40bc45462a77d35f69f85413227b63613")
--setManifestid(2562180,"6030682696584484659")
addappid(2593910,0,"59c05971823cd8abd340351687bd5fb89d6ef70ee901b16e73d3cdc36b975be4")
--setManifestid(2593910,"9115266583198901408")
addappid(2593920,0,"ad003411baaef219c8442fd9a83b29359c7537fb74d5fa472b2d3ccaf12b9afc")
--setManifestid(2593920,"8430617064611281586")
addappid(2593930,0,"1114218c44c7c72cef8710a7a4e4f335a6cff4fb36aaa5d44c57e1e4af33793a")
--setManifestid(2593930,"9141974814283262715")
addappid(2736310,0,"edc8d287c458dc45aa67761dc2ac255ccb772971d1e8522d4e023f7333024065")
--setManifestid(2736310,"491923310737937234")
addappid(2736320,0,"49e417c7af0d5f6e53dfa4576e7610564fc68ed6a3d8009fee06b6ea59720c68")
--setManifestid(2736320,"1233812463116222762")
addappid(2736330,0,"22a8358563f081910be407d8b5ea9dc8dd73c68c119d34c2d9f618d520eb262e")
--setManifestid(2736330,"2596884068056883832")
addappid(2983890,0,"ba4ae8d51fc2d5967e67e49574c38f050eaff58627ce5829dcdcb0be20fd8652")
--setManifestid(2983890,"8738490745880930339")
addappid(2983900,0,"1420cd0c58565f5997903e49b7a2261e30d70ba5e78f2aebc7cd0806234f598b")
--setManifestid(2983900,"8077614349638701324")
addappid(3077590,0,"830871220b6ba45f9820857669f81e11224826d5be12f1b345efa3dd465a5f9e")
--setManifestid(3077590,"8259880888867499637")
addappid(3202500,0,"53e33dbab85b3a9db56d327375a1a77dde92c34660e8caf25d32ad03227eb2ea")
--setManifestid(3202500,"5392937703851851778")
addappid(3202510,0,"cdfb6525cf03d973b8fd2e05918e4a75b1c5aac212d97aa2091acab9ffd557c4")
--setManifestid(3202510,"2171645551738676370")
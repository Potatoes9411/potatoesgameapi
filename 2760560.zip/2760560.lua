-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2760560's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:00:50 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 2
--   Depot 2760791: Blacklisted
--   Depot 2760581: Blacklisted

addappid(2760560)
addappid(4277070)
addappid(4277080)
addappid(4339000)
addappid(4339020)
addappid(2760561,0,"ac37c0a1bf3f91a4cb04f16b963e95e76007027ec18d154eeeb5cc6ae164eff0")
--setManifestid(2760561,"6592054372826693343")
addappid(4339000,0,"867df084e2c5cef3410de17d23ec1ac39e33aa23c12b8306c8abc9c865ccfc21")
--setManifestid(4339000,"8544583366762777513")
addappid(4339020,0,"f064232607d205cb1a38033c122d2e3e199890b2629f080dd601b12fc831f021")
--setManifestid(4339020,"4993221923045226295")
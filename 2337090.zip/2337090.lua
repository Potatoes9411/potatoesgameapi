-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2337090's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:59:07 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 3
--   Depot 233721: Blacklisted
--   Depot 233723: Blacklisted
--   Depot 233722: Blacklisted

addappid(2337090)
addappid(2337091,0,"ffb0ad0231fbb8858705e7408218662ad87751b32d04fbcd91ce83277a398cec")
--setManifestid(2337091,"127102511751741064")
addappid(2337092,0,"a60742e9aa9d0c22e9a41d56f1e0090309a7f62311bdc4d163b839669dd0ac59")
--setManifestid(2337092,"7662567845763486372")
addappid(2337093,0,"4b130638e381c0a0342fa3010bc13aa118812e519b01e4c03495ad4c045eba4b")
--setManifestid(2337093,"6953665316869543855")
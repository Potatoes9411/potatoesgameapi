-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 20900's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:50 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 13
-- Total DLCs: 0
-- Blacklisted Depots: 8
--   Depot 209002: Blacklisted
--   Depot 2090371: Blacklisted
--   Depot 209001: Blacklisted
--   Depot 209003: Blacklisted
--   Depot 209004: Blacklisted
--   Depot 209006: Blacklisted
--   Depot 209005: Blacklisted
--   Depot 2090850: Blacklisted

addappid(20900)
addappid(20902,0,"2216d9d965164b211e80b35ca56d0e81918c54d2f2f2923d84a07806aa108d5f")
--setManifestid(20902,"8624046092271445364")
addappid(20901,0,"7d49abe8382d62d650257322037f65f9be5bce659821cc4ec4bddbd1f2fcd274")
--setManifestid(20901,"8428448618762971564")
addappid(20903,0,"9b71d294063b93c811aaefb5e5fb00064525aa79e0d7380892e4f34a5e3efb4e")
--setManifestid(20903,"5511715626304589445")
addappid(20904,0,"022d3e8331e89e109eb940dc8a257b362ed02502dd6b97314ff39f0c3eb73378")
--setManifestid(20904,"7575838134038214131")
addappid(20905,0,"25b0ebf44bd3f37b6c07e498d93529ee051b8628611b41c5b5a08d85fe011c14")
--setManifestid(20905,"1239865348526158074")
addappid(20906,0,"e72fed5ec10620c411de9184e52a906fbab8b3ae6aff49f4429b94f7dc91ec72")
--setManifestid(20906,"6634447591030099264")
addappid(20907,0,"d6c8b8dcfb60d9410ef4c0559b4ac54ef219262fbcc5e654757a3ea05142cc6a")
--setManifestid(20907,"4101310451162182760")
addappid(20908,0,"7674d1cfd2cf98957b5eda5bcf522483974b6fedaac43cf5394a3f82b7d51e75")
--setManifestid(20908,"5365119562542516736")
addappid(20909,0,"e412c8d70c7b578fabb00eb6f999dcd8d7ae6dcd1f13e2439d9a4f036104f436")
--setManifestid(20909,"9177085296206191725")
addappid(20910,0,"33442bb73147048b46038b3e4cdbc477d8323c12a80f5036f01a71e316144745")
--setManifestid(20910,"8647435729719117490")
addappid(20911,0,"2d9953d35d89bcf88258fab25a653523705d4ce31d6cf11108ea9f1bfa876dc4")
--setManifestid(20911,"4705144054070210001")
addappid(20912,0,"cfb392c61e8788913ab140768f0a6ac3324cecea1f247594beddc52ac650da14")
--setManifestid(20912,"6777832894182196767")
addappid(20913,0,"07627110cba972ba6a48f48717df47bf6d9a40529537d9829b45a6452bffd538")
--setManifestid(20913,"239666657320591226")
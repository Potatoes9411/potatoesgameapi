-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2114350's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:56 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 2
--   Depot 2114742: Blacklisted
--   Depot 2114741: Blacklisted

addappid(2114350)
addappid(2114351,0,"b21308a571b40a558790e6c17c249e397eb7c99a619e6b32a943aa50670a1868")
--setManifestid(2114351,"9140190665555139256")
addappid(2114352,0,"e52e79848eda9d7bc5ccedb45f55fefa16f0ce461e74f7831449eeb775240bbc")
--setManifestid(2114352,"3974022475448182500")
addappid(2114353,0,"223b5fcc8637721d31bc6b384a5c264537d0425478aa98886e847f94ab6f341d")
--setManifestid(2114353,"6262753383634841922")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 4249120's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:55 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(4249120)
addappid(4249121,0,"0a6f8590bf8328fa294f7102f3c7b6626d7b2acb1beb253984d33ebda81c71ac")
--setManifestid(4249121,"4813242977047693292")
addappid(4249122,0,"cf2be876833b58ed52ee5433bad25567cf3653cdbed97cba7a25587722d05894")
--setManifestid(4249122,"6812386929732299454")
addappid(4249123,0,"75355fe03a0ccb5b3cb8ed4db1ff846465f8b773738d1211e59e0ecdd39ef1a9")
--setManifestid(4249123,"7773311513018434435")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1929290's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:56 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 5
-- Blacklisted Depots: 0

addappid(1929290)
addappid(1929290,0,"77e4135ba1847c076ce998aeb8d2c093cc84707b3e51e4f6444a3e7850bc677c")
addappid(1929291,0,"91ae978375944c164d52183a42b80bcba7be0c3e9862e50167fe9820c43ac287")
--setManifestid(1929291,"6058400077018530689")
addappid(1929292,0,"5c41ab13934489b51a533de03142ca6b8f47a1c5a53a51e10ad09083678729af")
--setManifestid(1929292,"1720550194588438130")
addappid(1929293,0,"8ed9a633f088e50d10c11fedf9b4780cbbede6974f96d9502322ae84a2becc8c")
--setManifestid(1929293,"6046671979821148261")
addappid(1929294,0,"7c1731d6590b9e7c43e6bfb3a413657bc494a857f00c283f40e18f0ab4a88a5c")
--setManifestid(1929294,"8771531664468338123")
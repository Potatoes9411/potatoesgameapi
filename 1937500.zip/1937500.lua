-- Made by F1uxin, Discord ID:965053505901588521 | Discord Server (TGP | The Galaxy of Pirates): https://discord.gg/VfCxRsFyFe

-- If you're interested in distributing these files please dm me on discord (UserID:965053505901588521) 
-- (I don't care if you send them to a friend or to help someone, just if you add them in your bot or have them widely available then i would like to know.)

-- Socials: https://guns.lol/f1uxin

-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid", save the file, then add the lua file, (i think you can add the manifests too but I would just add the lua file to ensure it works).

-- If you have any questions feel free to dm on discord (UserID:965053505901588521)


-- Main stuff to actually add the game, DLCs, & depots.
addappid(1937500, 1, "554b64fb08e6e1e962d242a0227acad43b08eef3762a6b85c42c81b311ae97e0") -- Let's School
addappid(1937501, 1, "88b023a604b78607ab4a19ae2c69a3067612b1293aa6b9411294c80b2adcde37") -- Depot 1937501
setManifestid(1937501, "7172727564563361972", 2102495599)
addappid(2802470) -- Lets School - Water Towns Furniture Pack
addappid(2901410) -- Lets School - Magical Castles Furniture Pack
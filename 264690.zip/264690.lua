-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 264690's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:27 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(264690)
addappid(396920,0,"366f6d708b7f426c62014c8ad0f7b0be324fa983004de53c230ac9b620041de4")
--setManifestid(396920,"15451960426729799")
addappid(264691,0,"e8adf2ce27d152b197809703505c8618190e0e8eedbc4b281f12c6e87ba94436")
--setManifestid(264691,"3516338525963492715")
addappid(264692,0,"01531a7098e23591cd4f8753fc5b70f07862735c10da66752a1f66d67b14a70f")
--setManifestid(264692,"7099936555364177664")
addappid(396921,0,"82caf5dee21737f415dd5e9bf7189cfb378a5c12d7ac81e41a74821e9dc1610b")
--setManifestid(396921,"525565727462974164")
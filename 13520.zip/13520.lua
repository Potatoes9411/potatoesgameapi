-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 13520's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:56:20 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 5
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(13520)
addappid(13521,0,"12106f233eda3051d702308d07c2efca7d8ed17cea2e8e299d2d53b493f74be0")
--setManifestid(13521,"3398519126760686940")
addappid(13522,0,"f9f47d0f353a463edf451f5981f5209164fc32f151b7661faa285efcecb40a12")
--setManifestid(13522,"8589580670542872989")
addappid(13523,0,"ce8ce97d5b3a252efa8a9ea0ca53af3ab25fdb58dc01ad78ec25affb63929282")
--setManifestid(13523,"2377300152408370832")
addappid(13524,0,"d6e9bad7360a6c837afd3b532f46c327e784854b842adf75f04dc402c3f4b0e5")
--setManifestid(13524,"3814605791113543967")
addappid(13525,0,"57b1f9ec452ea4065a7e034ea9c54024757e8762bb278651ff1e76df9d317e16")
--setManifestid(13525,"5402160486968523353")
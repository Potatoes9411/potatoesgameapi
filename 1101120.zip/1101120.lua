-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1101120's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:55:35 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 4
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(1101120)
addappid(1101120,0,"4ef29a56e9d84abcd7b195e6cae58ca374bb032990f7b62764cb3fb44e9e617e")
addappid(3288480,0,"3e3828e344ebf5ebf060fc7f1f19dcae7a71a9958a5835a0d654c341e6bb2445")
--setManifestid(3288480,"3102284432893326063")
addappid(3499740,0,"63a9d9fe6089d6fbce2643a0960797b4771b2f47bc22d24e96e0fa1702495095")
--setManifestid(3499740,"2213590162360887405")
addappid(1101122,0,"b82f041de94c4180a238a248cb18c8fdbc3d3f0ac8dda0152b6c70e6e2e9a28a")
--setManifestid(1101122,"8185700246974534312")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1982940's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:57 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(1982940)
addappid(1982942,0,"461ca38a3daea4fe2ad59789d20a0a9fbf313dbf40e7293f8ea6db233544ebfa")
--setManifestid(1982942,"6179542577445342333")
addappid(1982943,0,"71183e6d5de9598b94abca1bced1e16ff15396a84ec1f7db45e8bd07c0c65c94")
--setManifestid(1982943,"6263158799020575096")
addappid(1982944,0,"dafde2a08b2ea7fe6c1a1fbfad0282550ee31eeb91537928d3247c7f963b7283")
--setManifestid(1982944,"8477319095315629854")
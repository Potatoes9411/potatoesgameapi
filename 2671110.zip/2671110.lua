-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2671110's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:00:32 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 2
--   Depot 2671011: Blacklisted
--   Depot 2671231: Blacklisted

addappid(2671110)
addappid(2671111,0,"882804b0f3eeb42d220c1ed21d90dd7bd5dc0e463b022702222b25f42df9120a")
-- setManifestid(2671111,"678269866572789928")
addappid(2671112,0,"95504769f797acc84a056d93710f57c17a5815913a7e5c7e4e80f0aa5c471f8f")
-- setManifestid(2671112,"7661617780135790758")
addappid(2671113,0,"6ad609b05dddb835b316192a6c4622ed96979238b40de436eeac8fa0d6f15803")
-- setManifestid(2671113,"7338247604491434691")
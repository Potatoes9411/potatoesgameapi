-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 11140's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:38 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 6
-- Blacklisted Depots: 0

addappid(11140)
addappid(11141,0,"5959039d53e23e5260a4787741645f00bc69b409c92106fc1df70c4cb29dfc3d")
--setManifestid(11141,"4501249361925039053")
addappid(11142,0,"a35ff1c23c38e410c03163b0ab7f0aef0686d647badb1efbc6797e396f23330b")
--setManifestid(11142,"1599380209657094347")
addappid(11143,0,"9f9d9738ec799d00ae8febcd5f6a6e173ea3ad71aae5b057374628cb213b844b")
--setManifestid(11143,"7119852849412443927")
addappid(11144,0,"341e3e85639869984bfa937981d4218c7b0c997808b080cbf16d14afbc6b9fc8")
--setManifestid(11144,"3590997592598183036")
addappid(11145,0,"8575a09b6967308cc6157184ace8896d34df3f3004d496c067cb9c2a3fc2f073")
--setManifestid(11145,"3173867340958387160")
addappid(11146,0,"e73a9e252d607e6faafc3205a2aa255e0a99a082d6b55d84bf4a2ec40bb9e057")
--setManifestid(11146,"2985874171469229617")
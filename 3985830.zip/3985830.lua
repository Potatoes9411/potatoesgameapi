-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3985830's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:52 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 19
-- Blacklisted Depots: 0

addappid(3985830)
addappid(3985830,0,"daeb424b7f30b863a7ee68c929cc383944bd04c221520e1a6e76223b6449406d")
--setManifestid(3985830,"4140302920855767270")
addappid(3985831,0,"7121dd82efb94899c91960287204bdfb47ff7db7a674ef1e24cd09b0908193f6")
--setManifestid(3985831,"3044889222345353045")
addappid(3985832,0,"a68264fa7b587d062b107768158f1d4b986ae7dcf8348f93e0c44e9751c554cc")
--setManifestid(3985832,"9217318433541372130")
addappid(3985833,0,"9a3555fb6f2f3197354fc43e67f38ec9a826876e16a3b18d0920bcbefe0f7b09")
--setManifestid(3985833,"6000554156898813190")
addappid(3985834,0,"d6b1309d8f4fd2cafc8d2b265099881de43560cb0d220beeb1ac8c28a9fa0411")
--setManifestid(3985834,"4541647686057173189")
addappid(3985835,0,"af6b689d91e332b2c3af3273a1547f3f5e59ddde42686f884b83ae63f6999153")
--setManifestid(3985835,"8112331678784149760")
addappid(3985836,0,"656412200214e28cb80a7d2f81735f3a6ac9fbb5942db69036aba1e7297df555")
--setManifestid(3985836,"4951061893368825438")
addappid(3985837,0,"5d6d0bfaa2e6cb60b4323ac4aca41502dd33b2c8a0e2868d874cfed73d477fbf")
--setManifestid(3985837,"9220972275587001695")
addappid(3985838,0,"c9fc6b52dd8132ecca63c84e6345646924c20bad5ed1b97c3aa251b13375f513")
--setManifestid(3985838,"3129838973915114207")
addappid(3985839,0,"88d1b8dc45f43ddd6c05c3c54350cb479307c8d987f1522a303f83f9b858f112")
--setManifestid(3985839,"3316328177493170084")
addappid(4103370,0,"fa2e0d9a4f5c448ab5a2a9102f6c2f954e17c77556994baa0b227d28921a01b8")
--setManifestid(4103370,"6273899420490538036")
addappid(4103371,0,"fd304c3da047a4bfc6455b4df1afb6ea0ffda4f81674cb14d255024b0ecab2ea")
--setManifestid(4103371,"3164190185465492600")
addappid(4103372,0,"f75b03d620fe2b1e0876f4850c18a4dcfcea135a65a112394efcbf6ad74e15d3")
--setManifestid(4103372,"7633443361541983573")
addappid(4103373,0,"5329959fcb8b5542738acbd892fe999bdec5b6f2e2d2a679e2d3848677bcfa46")
--setManifestid(4103373,"1385659770603348217")
addappid(4103374,0,"33ed2918cdefe2508e89bb0f3af1855ef7efed16f64bdc95e799e26a6f919a2e")
--setManifestid(4103374,"6687188484246649681")
addappid(4103375,0,"97537a0233502bf68d593c183dadb38122b7b9d6cb869daa982b6b84074c8116")
--setManifestid(4103375,"8622535738100138677")
addappid(4103376,0,"85c12a9c6ab328fb8cab8d59769027ddaaf6ebe773c91051f2bcfdbe2782d001")
--setManifestid(4103376,"4066427098537655909")
addappid(4103377,0,"907cdbb1b9b376de9fd5786ff67980f14315d400fd86cb55fa4927ea813541fa")
--setManifestid(4103377,"4305204798980909741")
addappid(4103378,0,"6273b08984dc0eb612cfdd440e0599ca648786c50a0ba143483710f1388e594d")
--setManifestid(4103378,"3659344420934240793")
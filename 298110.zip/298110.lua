-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 298110's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:01:37 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 8
-- Total DLCs: 0
-- Blacklisted Depots: 20
--   Depot 2981096: Blacklisted
--   Depot 2981099: Blacklisted
--   Depot 2981104: Blacklisted
--   Depot 2981106: Blacklisted
--   Depot 2981105: Blacklisted
--   Depot 2981092: Blacklisted
--   Depot 2981097: Blacklisted
--   Depot 2981094: Blacklisted
--   Depot 2981091: Blacklisted
--   Depot 2981071: Blacklisted
--   Depot 2981103: Blacklisted
--   Depot 2981110: Blacklisted
--   Depot 2981090: Blacklisted
--   Depot 2981591: Blacklisted
--   Depot 2981107: Blacklisted
--   Depot 2981098: Blacklisted
--   Depot 2981093: Blacklisted
--   Depot 2981095: Blacklisted
--   Depot 2981101: Blacklisted
--   Depot 2981102: Blacklisted

addappid(298110)
addappid(324340)
addappid(324341)
addappid(324342)
addappid(324343)
addappid(324344)
addappid(332220)
addappid(332221)
addappid(332222)
addappid(332223)
addappid(332224)
addappid(332225)
addappid(332226)
addappid(332227)
addappid(332228)
addappid(332229)
addappid(332230)
addappid(332231)
addappid(332232)
addappid(338620)
addappid(343700)
addappid(345910)
addappid(348080)
addappid(353870)
addappid(298111,0,"90765df7a812f66db8794bd7b41b398e9b12fe77ec22caaff1442644d2c2c91d")
--setManifestid(298111,"1142172031228046975")
addappid(298112,0,"4f2126199ab0506f24ed8517d6b0e0c2ecf3a5cf4adbb2e5b32efbf21f3bb2e8")
--setManifestid(298112,"6331152839583468439")
addappid(298113,0,"e524b5855fe79757f864359e1de9606d4a0ab23ecd59b79f2af270bd97f497c8")
--setManifestid(298113,"5328801845298185678")
addappid(298114,0,"2218dbe36d21dd99bf8e46cbf5cb8e9c91897c36983a14363f38dd29d82e94d4")
--setManifestid(298114,"2463208696266802422")
addappid(324341,0,"0a4894abdd94b40c7464d6beced29025b9b2c3b1476d44fdff2697e82edb34a9")
--setManifestid(324341,"3810704983363922262")
addappid(324343,0,"8bcb7ae406c8a5325315decbe096d6b0afecf265d66514a10a1fe242be970690")
--setManifestid(324343,"8840893055567759529")
addappid(324344,0,"47c247776a41ae1192804e89b02b35c7567a9f87b280d3e49bab395db669e1da")
--setManifestid(324344,"5351965743619922824")
addappid(1716751,0,"84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
--setManifestid(1716751,"4132506267642462151")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1336120's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:56:18 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(1336120)
addappid(228983)
--setManifestid(228983,"8124929965194586177")
addappid(1336121,0,"a7834896172f1c81be446e9cdb1b2baf9c9bd305d752b2d2b260c3d79bd92f21")
--setManifestid(1336121,"1666077157003644963")
addappid(1336122,0,"e1ac8447884f56b49a1f635450081742fd6d391dea9365a5689c43a8ffb8245e")
--setManifestid(1336122,"1805504714171477609")
addappid(1336123,0,"6346726b91fff8a0121dbec3432a88fa9c44bc9f0b9bcca0306a43c647c61a4e")
--setManifestid(1336123,"8139033383933096476")
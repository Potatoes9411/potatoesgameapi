-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2344520's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:59:08 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 17
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 2344321: Blacklisted

addappid(2344520)
addappid(2453170)
addappid(2453190)
addappid(2572010)
addappid(2572020)
addappid(2572030)
addappid(2575620)
addappid(2575630)
addappid(2575640)
addappid(2721550)
addappid(2721560)
addappid(2721570)
addappid(2941030)
addappid(2941050)
addappid(2941060)
addappid(3043530)
addappid(3184520)
addappid(3559880)
addappid(3958690)
addappid(3958700)
addappid(3958710)
addappid(3958720)
addappid(2344521,0,"bf58e60bf2aca37197c7bc279a6b48b726131fa8b6d07bd12909d8a251252c65")
--setManifestid(2344521,"2539835684306169178")
addappid(2344522,0,"8b885b87e01a772da363b1cd92f8fb0faac6f727acb321aef2ae9c4ce938a4bf")
--setManifestid(2344522,"5493799499514638736")
addappid(2344523,0,"95a541fb3a2967fb73875c96ad8f56e3cbb5e3eafb742a4a1671847e722b543a")
--setManifestid(2344523,"6692416246619492543")
addappid(2344524,0,"5eab48ada2fbd0681f2548f19de28ffb437ab06f912c4adef37b7d4a1d82df40")
--setManifestid(2344524,"2664061983950482287")
addappid(2344525,0,"222f83dd58e78880080c90ac47ec8b18598682e8d9cf1eb5d9c971838ae9982a")
--setManifestid(2344525,"5113357402838444845")
addappid(2344526,0,"36773de6a67ec1ab03be4f3608e84d6065093969f89f13a78938d568c64dbcdc")
--setManifestid(2344526,"506494207530894876")
addappid(2344527,0,"e9ca21ab9bc1f84a13c3ab8c2d16770896c62bded180208739d12966d0a5a74e")
--setManifestid(2344527,"23348008507162815")
addappid(2344528,0,"8208caaf454b35c95674eea8f70a58cc4daf109424ce89ff87f15a06e0c57002")
--setManifestid(2344528,"3838676472020930513")
addappid(2344529,0,"cc7acfe91d9730e4bf1d3d18e3c3c508c138f3308b65e1b5430171c037ad1b72")
--setManifestid(2344529,"7801836540938856344")
addappid(2452970,0,"02d4526ba2550dee890eb72533f01be38dbfa301a86b4c9ce95bf1a00cb4320f")
--setManifestid(2452970,"6334188361615282797")
addappid(2452971,0,"26b03b20e224538d7f7d02d44f1b6e6a64dc028b2950ae50570a6871607a168d")
--setManifestid(2452971,"8655490883633844504")
addappid(2452972,0,"d7bf30f74044cedc899e1a38a4ade22b52a682d843b76a530652c0b4a7510a29")
--setManifestid(2452972,"2468599227163246450")
addappid(2452973,0,"8e3ae2409f103be46cbd55a941b370d6a19438516d0cf68c4fea29a7e2a0c018")
--setManifestid(2452973,"6153426071124923585")
addappid(2452974,0,"6db8a9ba8df12b66ed9f14a1e18c176f6a44522ab7c4ca3b37e9964ea0a3eb5b")
--setManifestid(2452974,"3811061031161249105")
addappid(2452975,0,"22c898c54175ad295a2c2794c9ea4b44278e36f2a4f65362d48b6cbe284388ea")
--setManifestid(2452975,"3863801266928114140")
addappid(2452976,0,"88ea785161f2912b8884373d4e8cdb42c8105a3f689cd44c89116d9b38abd476")
--setManifestid(2452976,"7443804239273748063")
addappid(2453170,0,"962a85322d266e4dc3ca0de3fe2d065dd2c270c3322c73ceb0d742f960ceb77e")
--setManifestid(2453170,"3956578326678164150")
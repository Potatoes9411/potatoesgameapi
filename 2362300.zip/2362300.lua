-- Made by F1uxin, Discord ID:965053505901588521 | Discord Server (TGP | The Galaxy of Pirates): https://discord.gg/VfCxRsFyFe

-- If you're interested in distributing these files please dm me on discord (UserID:965053505901588521) 
-- (I don't care if you send them to a friend or to help someone, just if you add them in your bot or have them widely available then i would like to know.)

-- Socials: https://guns.lol/f1uxin

-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid", save the file, then add the lua file, (i think you can add the manifests too but I would just add the lua file to ensure it works).

-- If you have any questions feel free to dm on discord (UserID:965053505901588521)


-- Main stuff to actually add the game, DLCs, & depots.
addappid(2362300) -- Train Sim World® 4
addappid(2375893, 1, "14bc27b00671244e747c77913c0a4b58229b4f9b524f42da37d5e3f3bc51c399") -- Depot 2375893
setManifestid(2375893, "3180667650178067971", 3863309980)
addappid(2375897, 1, "140cf106ae192e8f02bf635fed7e5bd870e3bcf1de51cb01f83908802355d2ed") -- Depot 2375897
setManifestid(2375897, "249182008624866446", 243084824)
addappid(2375899, 1, "4e4f09779b7731d340df3c38f3d313ee5aaa76f229a54ab013fbab78d6391bb7") -- Depot 2375899
setManifestid(2375899, "4325386951710437674", 110598186)
addappid(2362301, 1, "5c28a8cc7448571e38afbf570dbc022fba78b1ed1f93251fad277a7e10d3e79c") -- Depot 2362301
setManifestid(2362301, "7710047912173684528", 6870709140)
addappid(2458270, 1, "35b8acac12cbc475a8c1b932747191e88ccf05fff78894d1039540e2966be74f") -- Depot 2458270
setManifestid(2458270, "8777298662792374256", 6361)
addappid(2458271, 1, "58eea04b1e62e8287cb007ba643b604f82e0662c1300f45f2f4bb2c9e3925a49") -- Depot 2458271
setManifestid(2458271, "7105083459137518083", 6366)
addappid(2496070, 1, "69a195d59f781ba09ecc7e5d52b422b1bfc1278b49801cb6385cf2e4236db4e9") -- Depot 2496070
setManifestid(2496070, "5302488899988632614", 19567709)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(2375860)
addappid(2375860, 1, "6c528fc8ac9e87e71ffba7ca0aed31a8c7b746054c573d8b2ee6573d2b6ba9f1") -- Train Sim World 4 Compatible Great Western Express Route Add-On - Depot 2375860
setManifestid(2375860, "3055625643836853698", 4604663463)
addappid(2375861)
addappid(2375861, 1, "1f02e74ddc545893f097b48d3a9a84409730d081c0283e15f315272fa1f66367") -- Train Sim World 4 Compatible Rapid Transit - Depot 2375861
setManifestid(2375861, "2218506588967695651", 3863002913)
addappid(2375862)
addappid(2375862, 1, "94ab95911230fda6f429aaba27802a2d6846bd0e90b0faa8bc08e62fac35597a") -- Train Sim World 4 West Somerset Railway Route Add-On - Depot 2375862
setManifestid(2375862, "4406595251674016274", 2370993192)
addappid(2375863)
addappid(2375863, 1, "4d66614d661dcff068370dc23dc2f0904879067a1c2a868df3dea74dc8353d48") -- Train Sim World 4 Compatible Ruhr-Sieg Nord Hagen - Finnentrop Route Add-On - Depot 2375863
setManifestid(2375863, "4833420999018399346", 3699140082)
addappid(2375864)
addappid(2375864, 1, "4c3c2da75cf82d52d1b4918cc0263f90becdb467860340be786e714e6dfc63ba") -- Train Sim World 4 Compatible Long Island Rail Road New York - Hicksville Route Add-On - Depot 2375864
setManifestid(2375864, "517141247491113261", 4503725550)
addappid(2375865)
addappid(2375865, 1, "01709886aa11d0892f05903796d82206c0ce2f9d817819d987882fa1b6aa6c77") -- Train Sim World 4 Compatible Northern Trans-Pennine Manchester - Leeds Route Add-On - Depot 2375865
setManifestid(2375865, "3227063754643002007", 4837891719)
addappid(2375866)
addappid(2375866, 1, "e0a8ee0c4264753c76f85d5554fdccb2b933e7240ba78c1831302684b0974410") -- Train Sim World 4 BR Class 33 Add-On - Depot 2375866
setManifestid(2375866, "3625827293368922530", 87099810)
addappid(2375867)
addappid(2375867, 1, "7a68f98ded3ed08571dbc616c4251c2929484c2f48125c6c7e2acd7626c64afc") -- Train Sim World 4 Compatible Main-Spessart Bahn Aschaffenburg - Gemunden Route Add-On - Depot 2375867
setManifestid(2375867, "3623205920818164180", 3368537275)
addappid(2375868)
addappid(2375868, 1, "9220e2bfea96289475302eb9218b531965372bef1702c9f6c91e9f4605f550f0") -- Train Sim World 4 Compatible DB BR 182 Loco Add-On - Depot 2375868
setManifestid(2375868, "8632137859478503691", 236051161)
addappid(2375869)
addappid(2375869, 1, "fc1232f0bb21185b44dcb29f6e6159eb6b4fe611fe858cc676fde82f474e28d9") -- Train Sim World 4 Compatible DB BR 155 Loco Add-On - Depot 2375869
setManifestid(2375869, "3439422020805097380", 152460937)
addappid(2375890)
addappid(2375890, 1, "3f6aaea2ff075873cf87d7cc4c1590433ee6d961991a22a3e862cc4d6294135e") -- Train Sim World 4 BR Class 52 Add-On - Depot 2375890
setManifestid(2375890, "4358180416514416578", 84275047)
addappid(2375891)
addappid(2375891, 1, "28ea2a93c8d3db50fd6fe4a50506f463fea84ae1e2f0e45e01421e95da7ae151") -- Train Sim World 4 Compatible BR Heavy Freight Pack Loco Add-On - Depot 2375891
setManifestid(2375891, "1533799160513540183", 233992449)
addappid(2375892)
addappid(2375892, 1, "f466b27c76442f5a540fadf9dd5db12ea885f8a8186728703db7a861b3f23864") -- Train Sim World 4 Compatible Tees Valley Line Darlington  Saltburn-by-the-Sea Route Add-On - Depot 2375892
setManifestid(2375892, "6663497768737931613", 4239175303)
addappid(2375894)
addappid(2375894, 1, "0917698c6c3e9a1511e6015cfe3aac16bc47dc367abef5c40e8c326446addd69") -- Train Sim World 4 Compatible Rhein-Ruhr Osten Wuppertal - Hagen Route Add-On - Depot 2375894
setManifestid(2375894, "6752603939378614879", 4455125794)
addappid(2375895)
addappid(2375895, 1, "3359bd4fff7df9dbf4d34ea17bcd8f572c3481601b5cea39d282195263045e53") -- Train Sim World 4 Compatible BR Class 31 Loco Add-On - Depot 2375895
setManifestid(2375895, "3141842714392950543", 135114192)
addappid(2375896)
addappid(2375896, 1, "0eecb347acd5e9c8c327c02d887eb9b0ff111313fe56772f2607d1a68391edb4") -- Train Sim World 4 Compatible East Coastway Brighton - Eastbourne  Seaford Route Add-On - Depot 2375896
setManifestid(2375896, "5804427388671362104", 3903601516)
addappid(2375898)
addappid(2375898, 1, "bf1a7d2e7f2be6bece4641113d4aea920ba931323813a3bd5fffde74a3dd4cab") -- Train Sim World 4 Compatible Canadian National Oakville Subdivision Hamilton - Oakville Route Add-On - Depot 2375898
setManifestid(2375898, "2920969449323155536", 2511809085)
addappid(2375900)
addappid(2375900, 1, "011c355871e5108b8134dcf52b2e57b28249b28e2af280227dca3f4689dac99b") -- Train Sim World 4 Compatible Hauptstrecke Rhein-Ruhr Duisburg - Bochum Route Add-On - Depot 2375900
setManifestid(2375900, "3981408822505908004", 2868244708)
addappid(2375901)
addappid(2375901, 1, "03e2f451fb54cef6cc8a158b7d9c988ac7e978cd73517f276232aaa09bd7c008") -- Train Sim World 4 Compatible DB BR 204 Add-On - Depot 2375901
setManifestid(2375901, "8112356440017985902", 122232509)
addappid(2375902)
addappid(2375902, 1, "a7da68861fc96d47077170f744911c24bd1a3e3e3a22c15134ae2be4ea93fc3c") -- Train Sim World 4 Compatible LIRR M3 EMU Add-On - Depot 2375902
setManifestid(2375902, "7373805677422295573", 134058606)
addappid(2375903)
addappid(2375903, 1, "eeef994f492745710d1f2578013376261104aaa53f187c18e2debd7e5d30d9b6") -- Train Sim World 4 Compatible BR Class 20 Chopper Loco Add-On - Depot 2375903
setManifestid(2375903, "3548303504413545548", 134103023)
addappid(2375904)
addappid(2375904, 1, "411fa9c731eed3ac8f96db8aeb5d2659c017ca58f58c9f858d9be6ce963bfe97") -- Train Sim World 4 Compatible Isle Of Wight Ryde - Shanklin Route Add-On - Depot 2375904
setManifestid(2375904, "4139994214593542702", 2358311103)
addappid(2375905)
addappid(2375905, 1, "1ba825f315800441ea8edf74268ba4887c5eb05cbca6b964185ebf8e2ef5cf9a") -- Train Sim World 4 Compatible Hauptstrecke Munchen - Augsburg Route Add-On - Depot 2375905
setManifestid(2375905, "7129898533750850393", 4497067293)
addappid(2375906)
addappid(2375906, 1, "2a70061e88ce4809738114d7079fdd4a827867d22c8109e013c996e40aa6309a") -- Train Sim World 4 Compatible DB BR 363 Loco Add-On - Depot 2375906
setManifestid(2375906, "90569720451145791", 179894884)
addappid(2375907)
addappid(2375907, 1, "244e986751444de91cde7396a98d0b4b70b84a40cd99a12a97d48ac8834b5552") -- Train Sim World 4 Compatible Southern BR Class 313 EMU Add-On - Depot 2375907
setManifestid(2375907, "4873384037188849257", 157694451)
addappid(2375908)
addappid(2375908, 1, "53ee353b9a69e1ef74f3dc1739f130035b7fc66f9be2d0cfe7ac51139132f6e0") -- Train Sim World 4 Compatible CSX C40-8W Loco Add-On - Depot 2375908
setManifestid(2375908, "6667411706219870575", 224599727)
addappid(2375909)
addappid(2375909, 1, "d0dbc2c4537cdcce33e904dd147c93855a5a227ad93bf44773a348032bf8ef18") -- Train Sim World 4 Compatible LGV Mediterranee Marseille - Avignon Route Add-On - Depot 2375909
setManifestid(2375909, "1258210966849412270", 3969087688)
addappid(2375910)
addappid(2375910, 1, "83a2315563ba4887761d2a8f944527f9e3dfe830613c9fbf1544991fee430381") -- Train Sim World 4 Compatible Arosalinie Chur - Arosa Route Add-On - Depot 2375910
setManifestid(2375910, "1084642229259192335", 3911098035)
addappid(2375911)
addappid(2375911, 1, "ba7a29b53e0b1a4055d9c0d3a95b8f851a8a08739715ddcdc8142e5e40576878") -- Train Sim World 4 Compatible Cane Creek Thompson - Potash Route Add-On - Depot 2375911
setManifestid(2375911, "1838687691318270267", 3740549148)
addappid(2375912)
addappid(2375912, 1, "955ce5132c554728779648e007b1164d98349da3fdee0874a858bf9a7e0cdfb0") -- Train Sim World 4 Compatible DB BR 187 Loco Add-On - Depot 2375912
setManifestid(2375912, "3707784306739593841", 209026980)
addappid(2375913)
addappid(2375913, 1, "d349b1361a15755ff2c955111146f142832690c0adb5deea1e53b1f100fed9c9") -- Train Sim World 4 Compatible Diesel Legends of the Great Western Add-On - Depot 2375913
setManifestid(2375913, "2671068787969573624", 445268049)
addappid(2375914)
addappid(2375914, 1, "9643e580841e56384c121958bb69822ec481975b87f90585e99dac06de6286cf") -- Train Sim World 4 Compatible Clinchfield Railroad Elkhorn - Dante Route Add-On - Depot 2375914
setManifestid(2375914, "3722076362892668454", 3783576054)
addappid(2375915)
addappid(2375915, 1, "cf9a444663e2fa7e76df1daee5934f90cf5fce6952e2adf606ce5699b6caf2e0") -- Train Sim World 4 Compatible DB BR 101 Loco Add-On - Depot 2375915
setManifestid(2375915, "868332787623218806", 175204241)
addappid(2375916)
addappid(2375916, 1, "daea30d427115ea9c0fa0c1953c2c93b3c021b1e9b9ba333e59ff1bf3268cd3d") -- Train Sim World 4 Compatible Hauptstrecke Hamburg - Lbeck Route Add-On - Depot 2375916
setManifestid(2375916, "3802421490263309096", 4604362340)
addappid(2375917)
addappid(2375917, 1, "6ade3eb3d0a302f53148d25febdabc97932e307f28826a0bbaae201f726ca6a3") -- Train Sim World 4 Compatible Cathcart Circle Line Glasgow - Newton  Neilston Route Add-On - Depot 2375917
setManifestid(2375917, "7257105671242603793", 3364334749)
addappid(2375918)
addappid(2375918, 1, "e3532f4c90294e8a7b204dd151bb61c2cfe054ed8c8ee7654fb6d9499551d4bd") -- Train Sim World 4 Compatible London Underground 1938 Stock EMU Loco Add-On - Depot 2375918
setManifestid(2375918, "563273689173806487", 246497947)
addappid(2375919)
addappid(2375919, 1, "ddc40c9c01d062c9416b981eb2499130cea9498885ccfdd7549f7627b0cf5b93") -- Train Sim World 4 Nahverkehr Dresden - Riesa Route Add-On - Depot 2375919
setManifestid(2375919, "1736790564574156560", 7023872302)
addappid(2386100)
addappid(2386100, 1, "bb2a54d8e7980c35dd10d3f81942b1088a56c06d03decd7159a0e7eb907576a8") -- Train Sim World 4 Compatible Brighton Main Line London Victoria - Brighton Route Add-On - Depot 2386100
setManifestid(2386100, "8192020902503372571", 6732754777)
addappid(2386110)
addappid(2386110, 1, "3431609b77eb5e760100e55410a02f264007c1706e8949fa3274088aa2f19187") -- Train Sim World 4 Compatible Northeast Corridor Boston - Providence Route Add-On - Depot 2386110
setManifestid(2386110, "2204047109103751370", 5375672916)
addappid(2386111)
addappid(2386111, 1, "1103b17f7855d826dbbc073bf53d9270d0501e34f0844ffb60fe8f4c9c75e30b") -- Train Sim World 4 Compatible Horseshoe Curve Altoona - Johnstown  South Fork Route Add-On - Depot 2386111
setManifestid(2386111, "633197218493319488", 5484533383)
addappid(2386120)
addappid(2386120, 1, "2e615cba8a2de9b840718afd1e0cb10a305a004b899d08aeb732e44872955ddd") -- Train Sim World 4 Compatible West Cornwall Local Penzance - St Austell  St Ives - Depot 2386120
setManifestid(2386120, "8399276941182448020", 3329397207)
addappid(2386121)
addappid(2386121, 1, "52b798deccd266135d0e48803a148c48178efb2fb8f6a2819dcd319ed3f0445e") -- Train Sim World 4 Compatible Sherman Hill Cheyenne - Laramie Route Add-On - Depot 2386121
setManifestid(2386121, "3340260035782072258", 5763379863)
addappid(2386122)
addappid(2386122, 1, "66029e4aa548bd10feeff7b959804592b484dde1daa5f54cebd3f00d833284b1") -- Train Sim World 4 Compatible DB G6 Diesel Shunter Add-On - Depot 2386122
setManifestid(2386122, "6633079908577565502", 172983412)
addappid(2386123)
addappid(2386123, 1, "9086014c035928090b0e519ca5d13e236404d86c35e2cc8923c431013925256b") -- Train Sim World 4 Compatible RhB Anniversary Collection Add-On - Depot 2386123
setManifestid(2386123, "476230453559053923", 280342885)
addappid(2386124)
addappid(2386124, 1, "3b90e9892b3201ffe3f090f8b324c72170ddaf50330969fc17cb30626995d7bb") -- Train Sim World 4 Compatible Tharandter Rampe Dresden - Chemnitz Route Add-On - Depot 2386124
setManifestid(2386124, "7921999276662812396", 7060114008)
addappid(2386125)
addappid(2386125, 1, "ee3e023f970101c58b68e8907eec02e6f8efb9169c8cab73bf16d96d7cb7bdbb") -- Train Sim World 4 Compatible S-Bahn Zentralschweiz Luzern - Sursee Route Add-On - Depot 2386125
setManifestid(2386125, "2283975630011909060", 4139240633)
addappid(2386126)
addappid(2386126, 1, "f135ececb75a056962901a85502db83349c2762ee190335db80e7acca8591bce") -- Train Sim World 4 Compatible Harlem Line Grand Central Terminal - North White Plains Route Add-On - Depot 2386126
setManifestid(2386126, "4809504667664273616", 5154459408)
addappid(2386127)
addappid(2386127, 1, "5a39f4037619c6b73a47a68561ee2424b1e4e65cf6529273f366576c11388c33") -- Train Sim World 4 Compatible Schnellfahrstrecke Kassel - Wrzburg Route Add-On - Depot 2386127
setManifestid(2386127, "8099504358460069811", 11286467758)
addappid(2386128)
addappid(2386128, 1, "c83370ba1064069b36ba268d4851433f34618696ce000939de6430715ad5565f") -- Train Sim World 4 Compatible Cajon Pass Barstow - San Bernardino Route Add-On - Depot 2386128
setManifestid(2386128, "7368832985032104841", 8503121939)
addappid(2386129)
addappid(2386129, 1, "64aabe777ee0d1976a708e8d21d023b1af875d1ed57c9d3e8ddd6549825c6c69") -- Train Sim World 4 Compatible Southeastern Highspeed London St Pancras  Ashford Intl  Faversham Route Add-On - Depot 2386129
setManifestid(2386129, "3050224408203363354", 7702831211)
addappid(2386140)
addappid(2386140, 1, "442c39938fd3767a7ed32e90d19a0771ca09c653d32215b9a95ca9d6eeac55b5") -- Train Sim World 4 Compatible Spirit of Steam Liverpool Lime Street - Crewe Route Add-On - Depot 2386140
setManifestid(2386140, "2922158432588746949", 5374692955)
addappid(2386141)
addappid(2386141, 1, "c58c94c36e383700d1b43af67b3d8de124b9b212ac48fb62ea167288e1e1f728") -- Train Sim World 4 Compatible Niddertalbahn Bad Vilbel - Stockheim Route Add-On - Depot 2386141
setManifestid(2386141, "7326744272645493058", 9344652722)
addappid(2386142)
addappid(2386142, 1, "0224e7b4c63944125b07fe8c7fc9c537adc90c4e7377d5a14323a419bfd3b5dc") -- Train Sim World 4 Compatible Schnellfahrstrecke Koln-Aachen Route Add-On - Depot 2386142
setManifestid(2386142, "2820941259247303507", 4151989532)
addappid(2386143)
addappid(2386143, 1, "dc5dc09fcbe62adab66b689cd63463bcec38ecdf539762f68b6bb82eb45822ff") -- Train Sim World 4 Compatible Bakerloo Line Route Add-On - Depot 2386143
setManifestid(2386143, "4687214933813551137", 4614062302)
addappid(2386144)
addappid(2386144, 1, "e12cc827aafae5ecc288b985543e73ba26b7c4c7b47bf46d1ef4af8c1fe676ce") -- Train Sim World 4 Compatible Sand Patch Grade Route Add-On - Depot 2386144
setManifestid(2386144, "2974257440651763133", 4090724485)
addappid(2386145)
addappid(2386145, 1, "0f06a8a7d642d727633b7a965d52bf699a6b428e77a3b3113575f9a6f9408e87") -- Train Sim World 4 Compatible Union Pacific Heritage Livery Collection - Depot 2386145
setManifestid(2386145, "4247611723341366651", 437150337)
addappid(2386146)
addappid(2386146, 1, "12147db07b8970d89838638d748940102cf3b312ad07cc4da4f98f12e614a601") -- Train Sim World 4 Compatible Island Line 2022 BR Class 484 EMU Add-On - Depot 2386146
setManifestid(2386146, "8084010577353554353", 2948731890)
addappid(2386147)
addappid(2386147, 1, "5c745542820a220a111feebfb3930190ea4d8654979780acf3bc93a3345cdc5d") -- Train Sim World 4 Compatible Rail Head Treatment Train Add-On - Depot 2386147
setManifestid(2386147, "8738050421823853854", 220641259)
addappid(2386148)
addappid(2386148, 1, "51d4a60d824b82a497b70bba643b2a82c8dd52fa4167b3005d065832dd663366") -- Train Sim World 4 Compatible Santa Fe F7 Add-On - Depot 2386148
setManifestid(2386148, "4160096932595950436", 302005250)
addappid(2386149)
addappid(2386149, 1, "2b2bba2701b06f2df6f59f195c3e01b4b839bcb0b9b7f827ee70ee60fb79d01b") -- Train Sim World 4 Compatible Dispolok BR 182 Add-On - Depot 2386149
setManifestid(2386149, "2908460566391716695", 159677557)
addappid(2386150)
addappid(2386150, 1, "f450ee6a48052bbc72dd62878b73aa059caad8eb6cc22b8bf3e0744c73f9059e") -- Train Sim World 4 Compatible  Birmingham Cross-City Line Lichfield - Bromsgrove  Redditch Route Add-On - Depot 2386150
setManifestid(2386150, "5219037632952463262", 5202246922)
addappid(2386151)
addappid(2386151, 1, "d2a80c87f5e7a62ad48852476be64681f687fc5dacdc3f871c34f0f8a1c1af65") -- Train Sim World 4 Compatible Bahnstrecke Bremen - Oldenburg Route Add-On - Depot 2386151
setManifestid(2386151, "5030517281948650696", 4957194993)
addappid(2386152)
addappid(2386152, 1, "c1704253c9af767c29b62a69d89219803e473ed2c06c6eefc9eb310959f819e6") -- Train Sim World 4 Compatible New Journeys - Silver 1972 Stock Add-On - Depot 2386152
setManifestid(2386152, "4606265574517549692", 165156581)
addappid(2386153)
addappid(2386153, 1, "6a97ba1e13d2e9f286f917d569575786286ec2e51e5560feaf7b3774cec24170") -- Train Sim World 4 Compatible New Journeys - CSX SD40 Add-On - Depot 2386153
setManifestid(2386153, "4672013024368141567", 304820861)
addappid(2386154)
addappid(2386154, 1, "761f8ba00dd307270255b78e029d222b6a436362f3dcd0cc8b088922c618622f") -- Train Sim World 4 Compatible New Journeys - S-Bahn Kln BR 423 Add-On - Depot 2386154
setManifestid(2386154, "8683438901886930239", 140222972)
addappid(2386155)
addappid(2386155, 1, "4d5225509f456b47c9ecf9ab6a886084f494a9f52b5b58419ddfd41833a45104") -- Train Sim World 4 Compatible The Holiday Express - Runaway Elf - Depot 2386155
setManifestid(2386155, "1130333258078263991", 1211968579)
addappid(2386156)
addappid(2386156, 1, "d1accec7489920169343bf59e2c98f73027e4107c9396cf14945d43e6011c3fc") -- Train Sim World 4 Compatible ScotRail Express Edinburgh - Glasgow Route Add-On - Depot 2386156
setManifestid(2386156, "5091678280900594427", 5399397318)
addappid(2386157)
addappid(2386157, 1, "708b4e1d8761d249ca3b74242cf34fb3368ef1e85921bcbc510a227ab43987fe") -- Train Sim World 4 Compatible West Cornwall Steam Railtour Add-On - Depot 2386157
setManifestid(2386157, "7901884812564270237", 514096551)
addappid(2386158)
addappid(2386158, 1, "9fcb5062185cea290fb1f48a206b88a5439c15e09f0a20f885dd5a7410f9ddd2") -- Train Sim World 4 Compatible Amtraks Acela - Depot 2386158
setManifestid(2386158, "7279492293040104140", 216862696)
addappid(2386159)
addappid(2386159, 1, "5c0430537cc43a7da92f95c199957b15d3874e92e786eb3a8850cb84be6935aa") -- Train Sim World 4 Compatible Thameslink BR Class 7000 EMU Add-On - Depot 2386159
setManifestid(2386159, "5904898505467776257", 223978122)
addappid(2386170)
addappid(2386170, 1, "e787bc846697d07bd1d93e621f36e5a6103db0158c3cdd427779ec4ff3ea5337") -- Train Sim World 4 Compatible Northeast Corridor New York - Trenton - Depot 2386170
setManifestid(2386170, "1759014178010235", 6693808707)
addappid(2386171)
addappid(2386171, 1, "c2a899df1c8254e193c3545f094919f4483601a2d36724c6ac7d9077ed3e25c1") -- Train Sim World 4 Compatible Peak Forest Railway Ambergate - Chinley  Buxton Route Add-On - Depot 2386171
setManifestid(2386171, "1405561691828395587", 7089898474)
addappid(2386172)
addappid(2386172, 1, "e4021a4d657e9e5821576e3b7b412aefe1587a43852aa8b85cad701571e035bb") -- Train Sim World 4 Blackpool Branches Preston - Blackpool  Ormskirk Route Add-On - Depot 2386172
setManifestid(2386172, "386501018477960944", 9335665380)
addappid(2386173)
addappid(2386173, 1, "cc932f750f265cffec7bc65bc63241f9ccc750dee20456f813c7a00154cedc50") -- Train Sim World 4 Compatible Linke Rheinstrecke Mainz - Koblenz Route Add-On - Depot 2386173
setManifestid(2386173, "1196128410337054861", 6109029879)
addappid(2386174)
addappid(2386174, 1, "644d2980b282795e538e92c08fdba43b128824793c52777f3a1176ffc2cffe8c") -- Train Sim World 4 Compatible Midland Main Line Leicester - Derby  Nottingham Route Add-On - Depot 2386174
setManifestid(2386174, "3962516454061152482", 5208266383)
addappid(2386175)
addappid(2386175, 1, "e87b483623d10170f95c14f3eec8eb6b9e8d64f0f282b39e86afa6ec49efbee1") -- Train Sim World 4 Compatible BNSF SD70ACe Add-On - Depot 2386175
setManifestid(2386175, "3542941665999244540", 282047746)
addappid(2386176)
addappid(2386176, 1, "881893aad18fcec083b70a4715c73dd1e2a9d028170b04bf3522ebd4733e7ddd") -- Train Sim World 4 Compatible Rail Operations Group BR Class 377 Add-On - Depot 2386176
setManifestid(2386176, "5596821275109563371", 264460019)
addappid(2386177)
addappid(2386177, 1, "413521eec9a1775fb69a61c332d82dff579b06f665e720d46a2abdf1f2ca48b3") -- Train Sim World 4 Compatible DB BR 403 ICE 3 Railbow Add-On - Depot 2386177
setManifestid(2386177, "5430197322402187750", 443271121)
addappid(2386178)
addappid(2386178, 1, "d9bed8d0364bbfc9d316db76d3b9d1a38cfe6e409d33c11b47cdbff8f6cecb35") -- Train Sim World 4 Railpool BR 193 Vectron Loco Add-On - Depot 2386178
setManifestid(2386178, "5419283605912640637", 167178292)
addappid(2386179)
addappid(2386179, 1, "6f4db6b0f848ba1baed6b44cc864e97a14a66b1efda35a1eda02de4aff616965") -- Train Sim World 4 Compatible Glossop Line Manchester - Hadfield  Glossop Route Add-On - Depot 2386179
setManifestid(2386179, "7928618367393277756", 4015257435)
addappid(2386180)
addappid(2386180, 1, "29fca53624dc36bd448b2d9fdd8fcd2fcea716123db26620e2c81d09b078401c") -- Train Sim World 4 LNER Class A3 60103 Flying Scotsman Steam Loco Add-On - Depot 2386180
setManifestid(2386180, "7625818590743791634", 377151052)
addappid(2386181)
addappid(2386181, 1, "f3029ab363522414ce20370ff890efe58746e96b4c5af1641236ac4b0cac9ef0") -- Train Sim World 4 Antelope Valley Line Los Angeles - Lancaster Route Add-On - Depot 2386181
setManifestid(2386181, "8025721912380868193", 9292907232)
addappid(2412500)
addappid(2412500, 1, "ccd09cfb1286966f449bcc3230c7011f312746ed2f70f3591bbc534c715d76a6") -- Train Sim World 4 East Coast Main Line Peterborough - Doncaster Route Add-On - Depot 2412500
setManifestid(2412500, "3578920217797411454", 7884892984)
addappid(2412501)
addappid(2412501, 1, "ccabe4f94cda02af259943133974a3b02cfa82630eac2e7ed48ed5ec4873548b") -- Train Sim World 4 S-Bahn Vorarlberg Lindau - Bludenz Route Add-On - Depot 2412501
setManifestid(2412501, "249092947449953903", 7441701459)
addappid(2531150)
addappid(2531150, 1, "06939ffe5f26f79c63cfb34683867a01d14dc2adae7fe5d8b136a3ac78426557") -- Train Sim World 4 Compatible Norfolk Southern Heritage Livery Collection Add-On - Depot 2531150
setManifestid(2531150, "4677513091142765235", 311785206)
addappid(2566220)
addappid(2566220, 1, "a576b6a99cfe3db9ff857498c481d4c8b75514a6bc6b70ffe447497a340b2f05") -- Train Sim World 4 Maintalbahn Aschaffenburg - Miltenberg Route Add-On - Depot 2566220
setManifestid(2566220, "4535806928072740627", 4705526264)
addappid(2584070)
addappid(2584070, 1, "893344dba025f7760ca495a1a10fad27d1f6499727aa38f7e43169a032950eeb") -- Train Sim World 4 RhB Arosa Aggregates Pack - Depot 2584070
setManifestid(2584070, "4396033764368939067", 224103647)
addappid(2584080)
addappid(2584080, 1, "8be6e94ae43d379241fd8c46d5820b6aabe5fbf39363ec79d266e45d08aa9637") -- Train Sim World 4 Cargo Line Vol. 1 - Petroleum Add-On - Depot 2584080
setManifestid(2584080, "239690387440622827", 343743536)
addappid(2584090)
addappid(2584090, 1, "318fcca9e502e3b43e15808884fbfe515d926777a328a95152e6fe1142869bc2") -- Train Sim World 4 Centro Regional Railways BR Class 323 Add-On - Depot 2584090
setManifestid(2584090, "6395447328307369096", 197689591)
addappid(2584100)
addappid(2584100, 1, "85d7fe6ca26d36c82eea511976c8e4ff530199e2790ed2f1f588f2d7c449b20a") -- Train Sim World 4 Edinburgh - Glasgow Engineering Express Pack - Depot 2584100
setManifestid(2584100, "7197394118445739820", 342964371)
addappid(2584110)
addappid(2584110, 1, "6cc313299aeeba6bc14f5c0c9ff4dcc9287fcb907ea5fafd67588b6338277632") -- Train Sim World 4 Berninalinie Tirano - Ospizio Bernina Route Add-On - Depot 2584110
setManifestid(2584110, "4901113848340661793", 5035756926)
addappid(2584120)
addappid(2584120, 1, "9d9d5f743a062e692b39d6be05593e0f4cb1b97f750a9278a77827a2853a7603") -- Train Sim World 4 LIRR Commuter New York - Long Beach, Hempstead  Hicksville Route Add-On - Depot 2584120
setManifestid(2584120, "8151763651764934849", 8513782316)
addappid(2584130)
addappid(2584130, 1, "372b3c16a72724397ed9bc06a943b82346a63d00e60fdeaf4bf7f98feadd7bda") -- Train Sim World 4 Bahnstrecke Salzburg - Rosenheim Route Add-On - Depot 2584130
setManifestid(2584130, "7723962322641772273", 6805661200)
addappid(2584140)
addappid(2584140, 1, "763693447c17a6127b00f3bb83a73df8caee1b57dcd0f4b4e7eeeda1477a4b8c") -- Train Sim World 4 London Overground Suffragette line Gospel Oak - Barking Riverside Route Add-On - Depot 2584140
setManifestid(2584140, "334903439131861277", 5546352099)
addappid(2584150)
addappid(2584150, 1, "cdf94715ad55c01d26b1f5f3e4b967d84deb3e3c6894d19d668b6cef4fec8e78") -- Train Sim World 4 Cargo Line Vol. 2 - Aggregates - Depot 2584150
setManifestid(2584150, "4153962048355943252", 219372539)
addappid(2662100)
addappid(2662100, 1, "59df2c2432e37a89f13a267fb8a87f892bb7baf5efc785a68e9ac6c24a21534d") -- Train Sim World 4 Fife Circle Line Edinburgh - Markinch via Dunfermline  Kirkcaldy Route Add-On - Depot 2662100
setManifestid(2662100, "3830894382895516804", 7000221876)
addappid(2662110)
addappid(2662110, 1, "6202d13f2584c29a63c9ad85f8f86f487bc9d6670bbfb6f01300f9971344589d") -- Train Sim World 4 ScotRail BR Class 158 Sprinter DMU Add-On - Depot 2662110
setManifestid(2662110, "351219780501074611", 171948044)
addappid(2662130)
addappid(2662130, 1, "2d3c2eb7573150a8926f67fb589569f7aae98d7da9b1a71ab85ba6a797689fa0") -- Train Sim World 4 Semmeringbahn Wiener Neustadt - Mrzzuschlag Route Add-On - Depot 2662130
setManifestid(2662130, "8227015828320127132", 6864479461)
addappid(2662160)
addappid(2662160, 1, "d89e7447615d1ecdc4cea3d63b9b4b51f2befef26a98a52731cb659a79c0efea") -- Train Sim World 4 DB BR 218 Diesel Loco Add-On - Depot 2662160
setManifestid(2662160, "8344609329493715759", 267822568)
addappid(2662170)
addappid(2662170, 1, "335bef4e37e115711d16a04e2ca34538eb4d60b256807443a9c9803ab783bf87") -- Train Sim World 4 Expert DB BR 101  IC Steuerwagen Loco Add-On - Depot 2662170
setManifestid(2662170, "545350854378857481", 383558128)
addappid(2789570)
addappid(2789570, 1, "59aa9fcb94b8a31679fc6ee2a1aee96a4b707f1b93831a980ee2957021005040") -- Train Sim World 4 ScotRail BR Class 380 EMU Add-On - Depot 2789570
setManifestid(2789570, "913194709388150785", 250408263)
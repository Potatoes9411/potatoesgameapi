-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3412900's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:28 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(3412900)
addappid(3412901,0,"1b0053e043a4cdd8f620d8ab2263f9d03add55596f64923327c1633cbe8ade64")
--setManifestid(3412901,"4200642685779388946")
addappid(3412902,0,"7e0c2a3d2f9eb574e066a6848d94f45a64d95fa86deb5b27c7a5cd5655f665f0")
--setManifestid(3412902,"3310393538293215961")
addappid(3412903,0,"1c78b9c94482c21c05ba0936eb1daf7bfb82d2917b2ba176a011567ac6d1897b")
--setManifestid(3412903,"3469690694165530182")
addappid(3412904,0,"e472012bec404331d0a06079441f61ce3eeaf6cbb409f1af9dffa609d21ef815")
--setManifestid(3412904,"5466482407002457299")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 11190's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:55:37 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 10
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 1119571: Blacklisted

addappid(11190)
addappid(11191,0,"b31503bd117921fac8f5a5724e43c010253b89f34ca9d900d0f9f1460c8a725a")
--setManifestid(11191,"6515582178921425345")
addappid(11192,0,"c6009b17db581ec5016eb9b3c2b1d7a54dcff04ba8d4706094e7e6ac66f26d27")
--setManifestid(11192,"800249783983923577")
addappid(11193,0,"62b0a6c5c1aa32e2597fa079581dee52da49d79390c68b49343597770d862778")
--setManifestid(11193,"7962660265770081119")
addappid(11194,0,"6cb9d9f4f2e9b61d3d4a4c9646b3d5d5f5461085580ac40e5776c42525b9b029")
--setManifestid(11194,"3346425424291967177")
addappid(11195,0,"5f7c52d8a7cc1e5de9e0e2692d0c1dc10023fe0d14e2717e8255bb5e9aa27e0b")
--setManifestid(11195,"133447600060479832")
addappid(11196,0,"a0c0328e458df4f4a9c0ffcc072f1d4a4a4e1cde77050fdfb796a4f60f8c0014")
--setManifestid(11196,"4115258975269959999")
addappid(11197,0,"d0e37e380ba23599cdcce5872c34555dbbfea2c3c05431e67dc64102fd9001df")
--setManifestid(11197,"3869416273827406897")
addappid(11198,0,"a7ca88ca9ad8457203f619e597ffd35d4d2aeb4da08221819f59fc39eb1b6429")
--setManifestid(11198,"7255580171206369713")
addappid(11199,0,"15368b0849e819a9fcacbf2fda1f336197e14c9e693c17ce2a78e84e6fa41d75")
--setManifestid(11199,"7181978972855077684")
addappid(212331,0,"5b470445487deb606012aea378cd061b9930382d172ae06b2e631e8512f8e222")
--setManifestid(212331,"7587765053878882854")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1129570's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:39 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(1129570)
addappid(3225390)
addappid(3265360)
addappid(1129571,0,"935ab3832e28a8b5f78e186f4fe8c126614978599d03ccc079bfcb638d5c26cf")
--setManifestid(1129571,"3573291195679134267")
addappid(1129572,0,"0d775dff9ac37058d65a83ffc37683eefeb59f4f75c3532a7521bd0b13d0e6b2")
--setManifestid(1129572,"6240189635197075233")
addappid(3225390,0,"1b0d7f0259e77baed39b0ea0bdcd7207bc9e70452ff1e34d95858a78c18dffe0")
--setManifestid(3225390,"7131817753326613103")
addappid(3265360,0,"5e0c11cbb73a2b13463f8371493e7d790c38d40aa5569cb8162e27e2ca6247c4")
--setManifestid(3265360,"7533600506520075449")
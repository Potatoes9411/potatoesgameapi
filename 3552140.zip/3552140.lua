-- Made by F1uxin (UserID:965053505901588521), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/NmmpgnAgen)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:965053505901588521)
-- And if you have any questions feel free to dm on discord (UserID:965053505901588521)

-- Socials: https://guns.lol/f1uxin

-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)

-- Main stuff to add your game.
addappid(3552140) -- Retro Rewind - Video Store Simulator
addappid(3552141, 1, "8527bf46fe5454e6c8956a042fb1aee9a9792d7f4c73ebe85ab6924dfcc1c0fe") 
setManifestid(3552141, "597674519106065238", 1866360519)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") 
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") 
setManifestid(228990, "1829726630299308803", 102931551)
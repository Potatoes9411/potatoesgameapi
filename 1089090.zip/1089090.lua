-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1089090's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:38 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 16
-- Blacklisted Depots: 0

addappid(1089090)
addappid(1203043)
addappid(1203044)
addappid(1203045)
addappid(2458610)
addappid(2469230)
addappid(3798490)
addappid(1130840,0,"139786567849d65b72a9e95a65a33c440aab4f87e84f16c5967eece9f002c31a")
--setManifestid(1130840,"382959669369915622")
addappid(1203040,0,"23721734da64a0e0eed9e25288becfacbd86526db03272187e504b5a454ce809")
--setManifestid(1203040,"1037522985104359193")
addappid(1203041,0,"bf69c2c5c04fd1c592fc1d9ff6100309b370feb381996dfc7586d5a0fbc5cc3e")
--setManifestid(1203041,"3289703452675459640")
addappid(1203042,0,"daa2e5d518b63ac6b8878c5ea4c540165ffdc4f7dfa078bfc99e165da8803a65")
--setManifestid(1203042,"8487133234868163393")
addappid(2449140,0,"a5b90a998cb9fd64fa11da5687004b175f17d545d9b5b2d68e8631c6bc2a841d")
--setManifestid(2449140,"4992870228369364071")
addappid(2449170,0,"676e606a6905bec5553299076d2e2cec4d11ccf9cd6f669e7c3d3277e732441d")
--setManifestid(2449170,"2372859754295510374")
addappid(2449171,0,"045e54225fe6c77786bfcd2e7a99f704190372cc286e260d2ec38e4a597cebd0")
--setManifestid(2449171,"4274761634327527371")
addappid(2449250,0,"cb4ad443ede1955f0390dfd14006088a10213c6a97269acc9454b933b2395d30")
--setManifestid(2449250,"3459187442548351688")
addappid(2452120,0,"b54bcf33357770b5d13a1e145d50d48aaa4dfed4be53b630f92cb1e4864838be")
--setManifestid(2452120,"7603190901144942853")
addappid(2469232,0,"4db2e09ac0239d465a9b16bbc8a751c66cb387980ce813c30b1773a0ef26c58c")
--setManifestid(2469232,"2820906211075097558")
addappid(2617310,0,"8c03ebaf59f386bc358b416d055f137dce85c2baf4603c07a179b3d6c669f96e")
--setManifestid(2617310,"4136459436573473184")
addappid(2617330,0,"a5a15512c615494b0ac80cd28d8aaf459e3b5ea8c2b8071caac2ade8b61d6b45")
--setManifestid(2617330,"2413082009446378633")
addappid(3798480,0,"d2ef4e6b851e5ac5cbb5538730ca14e8dd37e1eebe81f4debf9b0b71a356bad5")
--setManifestid(3798480,"3613911204377030935")
addappid(3846080,0,"bf9e74c7282f3322f89ecf01ab0a507ae6db747f612e7753813d5afcbedb2922")
--setManifestid(3846080,"6052221571313314111")
addappid(3846090,0,"c1c033f3a5b121486e5dd1a33e9157b7b3859dba5372c4dbeb1627cbd6d9e9e4")
--setManifestid(3846090,"7463743725217791757")
addappid(1089091,0,"49964ca34e77b3aee8889132d8de8da22521d34a3cdfbfda9c74bdfb995a6bd3")
--setManifestid(1089091,"8456438783315868429")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3551340's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:35 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(3551340)
addappid(3551340,0,"052016d88278aada4bc94cc5d3fbef162105991acf65634e80e5fb0fb5fd3304")
addappid(3551410)
addappid(3551341,0,"a4f9c46a0797978fa0b278dac08a0f473872fc74c6b6d9bf45b30d56e33a42c7")
--setManifestid(3551341,"7759922098115499616")
addappid(3551342,0,"31edad03a3daebca77afad83adb899f2ff6611d949738ad3d15e708da8f2c7ca")
--setManifestid(3551342,"2316048148012738763")
addappid(3551343,0,"5ff6a006dff3e4ea6364310a8390ffc5f4754c3928150ea5719009c21074a607")
--setManifestid(3551343,"379356579208158339")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1049410's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:37 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(1049410)
addappid(1049410,0,"b26cfedae29d54a4070130f05dc1ea5e88a4a14f1b3f38e899667e46856b0bb7")
addappid(1049411,0,"e31233e6b65f2a9bc367c15c7bb132f1d9f0d8812222f22f072d74b78ce4daf9")
--setManifestid(1049411,"3646111955971398231")
addappid(1049412,0,"5e185815008cbba983f7ca6022dbd09dbf7bd5cf60ec34b328e583c337c3d48d")
--setManifestid(1049412,"3891342746257394329")
addappid(1049413,0,"2aa29e12cf628421a5b1391cf45cbb1258d24a2c01973be9070237e1e406e3c9")
--setManifestid(1049413,"3065443301679919409")
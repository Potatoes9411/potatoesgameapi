-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1285430's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:56:11 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 5
-- Total DLCs: 0
-- Blacklisted Depots: 5
--   Depot 1285193: Blacklisted
--   Depot 1285271: Blacklisted
--   Depot 1285192: Blacklisted
--   Depot 1285195: Blacklisted
--   Depot 1285191: Blacklisted

addappid(1285430)
addappid(1285431,0,"8a6d0713bb8234964e910075832d88c6121e6c504e0fe677b21a623575cb0cc0")
--setManifestid(1285431,"1348486853657340599")
addappid(1285432,0,"eb3aa73d7a37741c555b5becf7ad720c00607eeb5017de738fcfa0c6b02bacf3")
--setManifestid(1285432,"2636165122121111784")
addappid(1285433,0,"05a3477ba09bea0109b964c6e39c4fdcbaf2ee9053ea1aa26eee34a4380358fc")
--setManifestid(1285433,"6438899955844644085")
addappid(1285434,0,"e58dabb4bc02dd4a3b341fcb5dd4c5b4d1b9275a5ca6dc2ba8156a64d1fbcb16")
--setManifestid(1285434,"7359586019979022352")
addappid(1285435,0,"5e88bfbd28c1b988346cc75a600c098fd5d23d613fdaa3014e0675191fe38bd6")
--setManifestid(1285435,"779432738114521214")
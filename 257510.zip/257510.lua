-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 257510's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:24 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 12
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(257510)

addappid(257511, 1, "4843719744a91ee993422dbc8dd0202e0fa941be20a0f655b91673555114363c")

--setManifestid(257511, "799213806328220919", 0)

addappid(257512, 1, "8dfacc971c64751226828b0c8ba5b8ba193ebd0a7f08c7d6cef537a010633bd1")

--setManifestid(257512, "5631337394047896505", 0)

addappid(257513, 1, "f503cb0cab92a84003faa0e11f6d98fa27a4b43b7978abfb804439e3ba75df41")

--setManifestid(257513, "5434093492489172671", 0)

addappid(257515, 1, "9c05026dd7cc575be500fe888567bad29836915eabe7474ab81ad8b12e658e37")

--setManifestid(257515, "3279814669572335644", 0)

addappid(257516, 1, "a383a8a0ea7ca2ab1c813417a6f41ba8d13922fb851083ae9e606a4850b171ca")

--setManifestid(257516, "7924825898116512954", 0)

addappid(257517, 1, "5c2c6a95629811ec26e49a6b5718bec55c93248beab888c2a3f0e43b177dca84")

--setManifestid(257517, "5072312544050288384", 0)

addappid(257518, 1, "fbce2f04093e29ade04937517ea00430c35e9b4dcf4a1258cb5594127d17c37b")

--setManifestid(257518, "4116596187390052645", 0)

addappid(257519, 1, "18f10e6d9679fae109a8f232f319cbbf8d0e51f81c84885bc31d0d722ea8f2bc")

--setManifestid(257519, "1170103677162582368", 0)

addappid(322021, 1, "4cc399227f1da3852ec607a64517f30254759668916cfe78741766ef468a88ec")

--setManifestid(322021, "8713693664225184971", 0)

addappid(322022, 1, "b4f89cef8fdd6e94588e00930075367a198e78564bbf40584d96940037e85bdb")

--setManifestid(322022, "8229910699963260352", 0)

addappid(358470, 1, "2ed9bdbef9fb9f908fd1a382e38110c718656eec1b548bd252f6c285b1b46f1c")

--setManifestid(358470, "981576150363927305", 0)

addappid(360820, 1, "2d5b4e35ccedfb987251e27ed2c0c0619bc29fa3faafbe3508d4a5f5c8d6230f")

--setManifestid(360820, "924741356918057377", 0)
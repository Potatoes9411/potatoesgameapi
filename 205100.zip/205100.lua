-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 205100's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:42 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 10
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(205100)
addappid(212890)
addappid(212891)
addappid(212892)
addappid(212893)
addappid(208570,0,"d5f8adf6db0731cd395883db60b943cf3c83d2d447084a3111822237c1f56fe4")
--setManifestid(208570,"4109763437725695359")
addappid(208575,0,"ccddbb489f2ba68ba8ab5239862de740f6bfe8871f1d6336bc9364cbf012dd4c")
--setManifestid(208575,"5118738034433535542")
addappid(212894,0,"9db7ad1dd15bd13765ae84a6b4f3a6fb5d6947c4c334781e68f96d244989e52f")
--setManifestid(212894,"6290470269679908951")
addappid(205101,0,"42107f3f2d8fde4d980e3de5a3b6a9548497675b97fb5be88e578964c24991ce")
--setManifestid(205101,"3682254645125751955")
addappid(205102,0,"1e60f542dfd33d42eef0d45965f5c7a19a6949eb1ec97f399700dbc3c85d7dc8")
--setManifestid(205102,"955788823064539748")
addappid(205103,0,"ed518fd42aef448c1043fe291a80632e85207242b8d4d18f7f51a4a80bc644aa")
--setManifestid(205103,"652007769989793428")
addappid(205104,0,"0cf761fe1cf22a43fa7daba45af5368cd11e40fd5e5f8cff7a154f2cf7434090")
--setManifestid(205104,"5584694645485522352")
addappid(205105,0,"a5edbaafa3576d51111b4438ae92e73c92252a0970b1c6ed8367fc7db8a1ce18")
--setManifestid(205105,"3894833290655216485")
addappid(205106,0,"f406f5908d05fc3baa1c5655ca150862c08a29163d2e956d45c22ca43a55ef35")
--setManifestid(205106,"194686839392658586")
addappid(205107,0,"4c832577b21680c03a9dfc8e66a8e7448e5233b9f9037c123be0a7fb36e32dbe")
--setManifestid(205107,"3090641581836335173")
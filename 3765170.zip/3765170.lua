-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3765170's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:46 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 19
-- Blacklisted Depots: 0

addappid(3765170)
addappid(3765170,0,"9cc07f84fb2a723a0a7d4608ffb26e6fe8e18830f7fa1931d0906a19e37f8b76")
--setManifestid(3765170,"2958180077541571393")
addappid(3765171,0,"e3d12fb4e725440c18f9813d24be8d271c369483ec1e3ee924b95e81e74d6dfa")
--setManifestid(3765171,"5794419959419838478")
addappid(3765172,0,"76663c5ea984913b3c0c7f9827ee207e90c4cbc22fda445e5cd38d6a6d0cfaee")
--setManifestid(3765172,"6383755993233829121")
addappid(3765173,0,"cdf242266fdabd4dbb397f647f63ea746baca6cd3757c9a2ac360cbd8da4de55")
--setManifestid(3765173,"5280995721948279194")
addappid(3765174,0,"b4ac0d0736744d3e4c6242c751399246f7ea85596dd497a9d304093712afa461")
--setManifestid(3765174,"3502469188764319474")
addappid(3765175,0,"162a495a7e5b434bd03d1b532d1e4740c8ffeb6bfea96153e60a94f76a895eed")
--setManifestid(3765175,"9142781002452717840")
addappid(3765176,0,"741bf584028bfb57f0b913042443bab5b7d0d66653773f87c8e9b2fd3cf10b15")
--setManifestid(3765176,"39320863833628511")
addappid(3765177,0,"f318430ec2d411dfee82bd2acf95ae861196a9c6cc6767bd1132fe46f1404412")
--setManifestid(3765177,"5229399558737923622")
addappid(3765178,0,"2571f68a47d2c4e91f470f6ccad1c7046f9f25df3a2e2cbc3b99aa113a0b5214")
--setManifestid(3765178,"5865792941624867233")
addappid(3765179,0,"7bff4771826db05cffd157529512153dbbef45d726555ed8c4658837f3ac33d9")
--setManifestid(3765179,"2531241041795662906")
addappid(4103320,0,"949f593843b21ef4f059df4e7ae4bc0299062b3b9eb3fde86161f2c95fd26ae7")
--setManifestid(4103320,"7361243345391996706")
addappid(4103321,0,"46340db5d6a15dbb57aa3b243ff029996cc9105f8879177cbb64f6c5c711beb7")
--setManifestid(4103321,"3585678299982453337")
addappid(4103322,0,"7d1f6cdeb7e7871395ce99fbf71e1567790c4286585af4b3f718216898b88472")
--setManifestid(4103322,"4454935547586856796")
addappid(4103323,0,"452465eef6fe390d8308a245fb37a3dc8442bbe9ba7566c5fe3a08aac1948ea2")
--setManifestid(4103323,"7524386674578249588")
addappid(4103324,0,"fcc8266040c15831b300dd77fb21c724cf470d8a1a445b77a987fc5a17190ef7")
--setManifestid(4103324,"6806164049111649189")
addappid(4103325,0,"86b69ba37a72bdaf241944f524af7351be51867c1bc988cfb191b58ca581a914")
--setManifestid(4103325,"5704713336329698314")
addappid(4103326,0,"f8cccad5b529028c6e7eaf0078d8e2da14c7b0b660ec0c92974d44faab4a1736")
--setManifestid(4103326,"2498949758919595466")
addappid(4103327,0,"435222892412cef127ac2a76cec716d6c379b0e4acc29b43cb4a8481ebb826c2")
--setManifestid(4103327,"5626843836471565483")
addappid(4103328,0,"9f4940f63c84e93f1da5850d3ff97dde592e1446a4e6b882590b260cd4da0624")
--setManifestid(4103328,"1496306230463750228")
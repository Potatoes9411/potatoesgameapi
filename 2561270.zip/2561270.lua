-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2561270's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:00:08 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 2
-- Total DLCs: 0
-- Blacklisted Depots: 19
--   Depot 2561516: Blacklisted
--   Depot 2561512: Blacklisted
--   Depot 2561588: Blacklisted
--   Depot 2561520: Blacklisted
--   Depot 2561521: Blacklisted
--   Depot 2561582: Blacklisted
--   Depot 2561511: Blacklisted
--   Depot 2561514: Blacklisted
--   Depot 2561519: Blacklisted
--   Depot 2561515: Blacklisted
--   Depot 2561587: Blacklisted
--   Depot 2561518: Blacklisted
--   Depot 2561585: Blacklisted
--   Depot 2561586: Blacklisted
--   Depot 2561581: Blacklisted
--   Depot 2561513: Blacklisted
--   Depot 2561584: Blacklisted
--   Depot 2561589: Blacklisted
--   Depot 2561517: Blacklisted

addappid(2561270)
addappid(2889020)
addappid(2561271,0,"4af81c857b1910c3238be9c71a204fd6c9427e7204978fd9ccf76e7ed53a59d2")
--setManifestid(2561271,"5284837656308091350")
addappid(2889020,0,"a9d772aa444625775530340003f701ec172f8dfd6b87bae7933475da74e08bd1")
--setManifestid(2889020,"7826468834563863930")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2588860's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:00:14 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 8
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 2588611: Blacklisted

addappid(2588860)
addappid(2588861,0,"fe0869c13a596e77a02c008faa7e7ca90927d0919ef7f23c40c4a53aa52fd593")
--setManifestid(2588861,"2586688443990856831")
addappid(2588862,0,"7a3dba3d29756b48ee74d57803a6a5a98a55d6cb3e4078acf0330c6be71d2bbe")
--setManifestid(2588862,"6294672279010442102")
addappid(2588863,0,"4524e542d04f3ee3a43cb10c21c35c17f87714a6ae5c42679d6b072f3f7f9cdc")
--setManifestid(2588863,"4116525861259842994")
addappid(2588865,0,"9bfb6607bb8e9648eef4b834b21d388cec4471ec05dbead112681a8ca0d44ad9")
--setManifestid(2588865,"5488064478951815485")
addappid(2588866,0,"138d84ef908fd47c840a15d65020836e50a6ec7595f3bef9bb61085550ddd869")
--setManifestid(2588866,"1632535410630251695")
addappid(2588867,0,"cfffd01f082ae82a79ce2525c340a7ede3a03f2086be2964d28c4e6fa1f6b9f1")
--setManifestid(2588867,"6439199822491857349")
addappid(2588868,0,"01f7467dd9a1e315e8d2ea9f05b3e51a8bdc80c643c1e9ee1baa375bf6a38499")
--setManifestid(2588868,"3763914578200737302")
addappid(2588869,0,"127313082b9d06bb40e0faaa82df57c9b5ff5cb99125b74fb2c9fc4a4a8e0bf4")
--setManifestid(2588869,"6139411588005074333")
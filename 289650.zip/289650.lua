-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 289650's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:01:19 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 5
-- Total DLCs: 0
-- Blacklisted Depots: 2
--   Depot 2896261: Blacklisted
--   Depot 2896382: Blacklisted

addappid(289650)
addappid(324330)
addappid(324331)
addappid(324332)
addappid(330960)
addappid(330961)
addappid(330970)
addappid(330980)
addappid(330981)
addappid(330982)
addappid(330983)
addappid(330984)
addappid(330985)
addappid(330986)
addappid(330987)
addappid(330988)
addappid(331950)
addappid(344600)
addappid(324333,0,"9b07cb83c48f76dd01431636c4dcfed721bbf6d70141900658c6ff573ac15d3c")
--setManifestid(324333,"4731501881144486504")
addappid(289651,0,"8f869005c44f493f984aa111e49e96c4f64e69a4b4078cbfff77f01ce5bb7b8e")
--setManifestid(289651,"3729509919120398706")
addappid(289652,0,"dd7b22e30a71132cc09a5e75b0d8b326d5a0716911cb3b63f6f656fafe0ddad1")
--setManifestid(289652,"2679326884158097457")
addappid(289653,0,"8aa4b40cbc6dc05229d0cdd4f7fc19f1e5b0cebe991d6db3fec2f3ffb906d700")
--setManifestid(289653,"7016661070798178830")
addappid(1716751,0,"84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
--setManifestid(1716751,"2169126266364568976")
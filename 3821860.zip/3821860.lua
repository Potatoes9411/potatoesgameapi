-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3821860's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:48 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 12
-- Blacklisted Depots: 0

addappid(3821860)
addappid(3821861,0,"56a85142e37645d71e3bb2f387027a99f589c7108c832cbdf4b8bfa0dbf3d69c")
--setManifestid(3821861,"8461620926748507527")
addappid(3821862,0,"147aa7b3588346c782e2c1e57a35943cc54b1facce5d8f1fae1b25e63aaf9b11")
--setManifestid(3821862,"2854927737153305900")
addappid(3821863,0,"c10ead20078bcf6d40f8555b930024f4d69ef4c3bfbfed34d88e058b869a5b23")
--setManifestid(3821863,"2277271506378632400")
addappid(3821864,0,"108d52f1960b1eeb7bf3f8961380a2d761b62cba8e8e68791a1c617c1968bf1f")
--setManifestid(3821864,"5896800804441914197")
addappid(3821865,0,"19a25fe31331b095767bac3f575806511467ea951d8430946bff19a711c0c676")
--setManifestid(3821865,"5662694339166773651")
addappid(3821866,0,"db18b7e702237aa57ab77edea9336ce259532028bac45c33a2a3759c567d81ea")
--setManifestid(3821866,"937960132923139780")
addappid(3821867,0,"de0f319117e3eb45e39e11e92d6ea9a31180008b05cf734e8d2f720ead5ee92b")
--setManifestid(3821867,"8361859219433882172")
addappid(3821868,0,"284602a9ccbf3a00aed228bfc623456c0c6c798bafd62acb45e46d087ab0a353")
--setManifestid(3821868,"7894561838150730133")
addappid(3821869,0,"5006365898ea82ab9439520cdb411d89e872a6ba256a3f1726f84095c9ed7624")
--setManifestid(3821869,"6853135577908226297")
addappid(3843170,0,"764df8db9cfcb34462e8c11f37970b7ee0333f3eb50c1060522e51f26d3cd4d7")
--setManifestid(3843170,"3114599408825949702")
addappid(3843171,0,"26cf0a4a4a08ebc94a9d0762f45e6ae4424400722f9fa4f57420ca3acb7a740c")
--setManifestid(3843171,"8574518453391335607")
addappid(3843172,0,"a0b8fa68fc0dd849489509d6489cf908bbc31cb74473a6c1b54e95bf2384ccf5")
--setManifestid(3843172,"8198825322362488631")
-- Made by F1uxin, Discord ID:965053505901588521 | Discord Server (TGP | The Galaxy of Pirates): https://discord.gg/VfCxRsFyFe

-- If you're interested in distributing these files please dm me on discord (UserID:965053505901588521) 
-- (I don't care if you send them to a friend or to help someone, just if you add them in your bot or have them widely available then i would like to know.)

-- Socials: https://guns.lol/f1uxin

-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid", save the file, then add the lua file, (i think you can add the manifests too but I would just add the lua file to ensure it works).

-- If you have any questions feel free to dm on discord (UserID:965053505901588521)


-- Main stuff to actually add the game, DLCs, & depots.
addappid(2988140, 1, "457c2f2f2a4728af1ac335fe27fb8a227573cf63fa98943fff1809bacf3a4f00") -- Lacrosse 26
addappid(2988142, 1, "c596e12e3b5fe9762b00b765e20f1a34367181ba911a1b1250721e1b2516cfb8") -- Depot 2988142
setManifestid(2988142, "2377149785074234595", 4619973494)
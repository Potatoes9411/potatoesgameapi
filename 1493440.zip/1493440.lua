-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1493440's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:47 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 1
--   Depot 1493711: Blacklisted

addappid(1493440)
addappid(4171980)
addappid(4171990)
addappid(1493441,0,"885b50a2965195447f630d3b629ac75440f44061f773b5685d235475f31c35d8")
--setManifestid(1493441,"4169408400893735965")
addappid(4171980,0,"58908e7448aab8a8888d4573dd7843672bdd427d6bd656a37b8a397f8aaa398b")
--setManifestid(4171980,"8072862159648802848")
addappid(4171990,0,"3c9906af2db2c099e3dd8b8960a8dee9284243697889b3d164a4ad23ca8ab0a5")
--setManifestid(4171990,"7056929270663257242")
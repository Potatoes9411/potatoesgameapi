-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 637090's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 07:00:04 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 5
-- Blacklisted Depots: 0

addappid(637090)
addappid(799750)
addappid(799751)
addappid(799790)
addappid(911930)
addappid(1047180)
addappid(1151170)
addappid(637092,0,"72e809a00199a64ddb64c1717150de9181f02271843a6ea5311727ef05dc121c")
--setManifestid(637092,"3571434299329528407")
addappid(637093,0,"5f0d196f62d8d69788898d9edbed872c3b429190cda48731c2577a728ce32731")
--setManifestid(637093,"8187034275620793063")
addappid(637094,0,"123cab6b69f00e7573e00655bc5149ca1e274d68b9c23523cddafc512250f1cb")
--setManifestid(637094,"3849333830107924190")
addappid(799751,0,"f07fbc91a9f25211123f652288f7db0fbe95d46a7eeeca2895ec26a1f3143b8f")
--setManifestid(799751,"669435259793615635")
addappid(799790,0,"27dd0fce73456d746fe86022a47bc1c659327ab510c97dbc03c8522008926f7e")
--setManifestid(799790,"2702170670973061830")
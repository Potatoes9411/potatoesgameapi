-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1573630's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:56:41 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 4
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(1573630)
addappid(1877500)
addappid(1573631,0,"e47b77bbf1b8440ac53dadbc9640dafe74243aed7d250296ae926ab01356d890")
--setManifestid(1573631,"3190223048175232446")
addappid(1573632,0,"6e41d4c76b0232df5cbee017061b97c9d2af0701d533b63bee0ccac926a7fefa")
--setManifestid(1573632,"3440999525313122424")
addappid(1573633,0,"55838faa47b4f06573f74fbec5fc39f7f343f54c99d2be32861bd054f143add5")
--setManifestid(1573633,"795881017960112872")
addappid(1877500,0,"b6bd8efa6ea8c1b4163d1682455c7b646d594c9426bee14f6e0939b4c8d52996")
--setManifestid(1877500,"5995499802956706869")
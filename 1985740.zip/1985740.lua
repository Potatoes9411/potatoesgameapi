-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1985740's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:28 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 1
-- Total DLCs: 0
-- Blacklisted Depots: 18
--   Depot 1985811: Blacklisted
--   Depot 1985827: Blacklisted
--   Depot 1985822: Blacklisted
--   Depot 1985818: Blacklisted
--   Depot 1985814: Blacklisted
--   Depot 1985829: Blacklisted
--   Depot 1985823: Blacklisted
--   Depot 1985813: Blacklisted
--   Depot 1985825: Blacklisted
--   Depot 1985812: Blacklisted
--   Depot 1985819: Blacklisted
--   Depot 1985826: Blacklisted
--   Depot 1985816: Blacklisted
--   Depot 1985821: Blacklisted
--   Depot 1985815: Blacklisted
--   Depot 1985817: Blacklisted
--   Depot 1985828: Blacklisted
--   Depot 1985824: Blacklisted

addappid(1985740)
addappid(1985741,0,"a3252f3aa3682f681667989ab6df551e3683e9cc90488b7083056835f2694317")
--setManifestid(1985741,"6281014900095781921")
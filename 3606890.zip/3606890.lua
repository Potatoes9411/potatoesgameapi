-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3606890's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:38 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(3606890)
addappid(3606890,0,"17448557704ad5d0cdb584cbd619c96deb0bb01a036ae39498c0f5b4e04cd277")
addappid(3606990)
addappid(3958950)
addappid(3958960)
addappid(4085930)
addappid(4387380)
addappid(3606891,0,"37cce33183ad0a0855c91edbd4e8920e5537e2b66c1ec405cac79bc6e9407e46")
--setManifestid(3606891,"419177017874968405")
addappid(3606892,0,"44120e26fefc70e26c7bb33459bebab914cd8f0433f451edcdbbe85c216cf2a9")
--setManifestid(3606892,"2849653246939446098")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 313120's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:17 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 5
-- Blacklisted Depots: 0

addappid(313120)
addappid(313120,0,"fcf7ff6e658aeb78d794c09662c18dc494093ed71baf1777205b9c813df5a13a")
addappid(313121,0,"849e1f5ca5a85b7d1883d504e154f01490217d7bc2833df1fc7d98a613da2053")
--setManifestid(313121,"6975760928047011057")
addappid(313122,0,"2fecf111017e61251145acb462b843363ac5e4c14d79e159bd959ecc5bdfa6dd")
--setManifestid(313122,"4846953430197237657")
addappid(313124,0,"6ce2cedac00fb12dc8f07843b0fe31d9a54240ed7aac46808a4cd1f27df31303")
--setManifestid(313124,"8119282937023648592")
addappid(313125,0,"c13bc2f1874815bd732cf422e4c700677a8cfd88bd454575d5040a8dc90ac287")
--setManifestid(313125,"2689333661829575041")
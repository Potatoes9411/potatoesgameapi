-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 398810's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:52 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 8
-- Blacklisted Depots: 0

addappid(398810)
addappid(398811,0,"40a98e6e401bb452e9c495ead3f58b79e6b6bd25a861d7e0241f0e55953c24dd")
--setManifestid(398811,"7565172631549520087")
addappid(398812,0,"b45b599c6f8a99a2b2daac9f2adaae6d4e0388b2257542e264d5dc4c4ef4ea6d")
--setManifestid(398812,"7333934438320086698")
addappid(398814,0,"48f6de2a7f8f7cfd23bac30fd02ce9c2b408024b5250d05ecdcc9e7527a34798")
--setManifestid(398814,"3635310601173690624")
addappid(398816,0,"0362d51718df43234b993cb1b2fcd837ef3759cef4a8e97b9ee2da0c77abbdff")
--setManifestid(398816,"5282994495237133826")
addappid(766330,0,"8b12a8646b0043d888a46ae85f04980e54923678b703385cc36947f9bb5211a1")
--setManifestid(766330,"8134956397665652945")
addappid(766332,0,"ecef6f173a3f604814476ad5e456019249202edd41265ecfb93bd730291658f3")
--setManifestid(766332,"5610710332623257789")
addappid(766333,0,"36d8387570e42f6d2d00de51ad413c5a44fe00693e42c0ae9630ba250edb9c16")
--setManifestid(766333,"7061169870936659802")
addappid(766335,0,"bf85e905b19e7ec41bffde74c59ad04ec91cdbf513440f24960f65d57f2789c2")
--setManifestid(766335,"418584511506757751")
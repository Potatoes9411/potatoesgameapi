-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1203220's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:55:46 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 2
-- Total DLCs: 0
-- Blacklisted Depots: 5
--   Depot 1203042: Blacklisted
--   Depot 1203191: Blacklisted
--   Depot 1203040: Blacklisted
--   Depot 1203041: Blacklisted
--   Depot 1203621: Blacklisted

addappid(1203220)
addappid(1637170)
addappid(1637171)
addappid(1643990)
addappid(2593020)
addappid(2701570)
addappid(2731960)
addappid(2731970)
addappid(2731980)
addappid(2732000)
addappid(2732010)
addappid(3371820)
addappid(3371830)
addappid(3588860)
addappid(3610450)
addappid(3610460)
addappid(3610470)
addappid(3610480)
addappid(3610490)
addappid(3659600)
addappid(3659610)
addappid(3659650)
addappid(3659670)
addappid(3659680)
addappid(1203221,0,"788b93ea9ea92552d334bdb7fa9caf5f21f98dded4a670c54926bf0a2bd1d74f")
--setManifestid(1203221,"8655094252525740951")
addappid(1637171,0,"63589232719b9b6c05930000563883180320b57145ea3cc62d9ed5d31341c8ef")
--setManifestid(1637171,"2879608132823458419")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1601580's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:56:45 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 8
-- Total DLCs: 0
-- Blacklisted Depots: 4
--   Depot 1601801: Blacklisted
--   Depot 1601571: Blacklisted
--   Depot 1601331: Blacklisted
--   Depot 1601741: Blacklisted

addappid(1601580)
addappid(1601580,0,"b188b56eb26beef5cc8940334590f6202b960b404f64fc45efd499e5b8fa8446")
addappid(2791490)
addappid(2791500)
addappid(2791510)
addappid(4065430)
addappid(1601581,0,"7372485e88b89813dc5250dca3be72fcfa499604514bea173703fbb7bac1f78f")
--setManifestid(1601581,"2271835946225538630")
addappid(1601582,0,"430c4ff745d427259e5934cada320f38cfadad961bdb56a35f4403f2ffeaea6b")
--setManifestid(1601582,"2027672946002995757")
addappid(1601583,0,"be06bc27eb3b8e788a06bae787211c5e406cf846a3aeceffbac54475a447d036")
--setManifestid(1601583,"2157139850469774008")
addappid(1601584,0,"36e9a475072dc9722c31a1fb0e453b8059561f32f293e4fe0b23016f5243ee2d")
--setManifestid(1601584,"6328326313015819129")
addappid(2791490,0,"3f4b6f54645a56bc7991b93bed90155b81354f90e7fb4113e92ed9378980e36c")
--setManifestid(2791490,"5534266034783623960")
addappid(2791500,0,"647f22682ffa05f21b1ea12779b04414782ddf4f2456565761b6ee0f863204ee")
--setManifestid(2791500,"4880495581112128516")
addappid(2791510,0,"ffad03667e8754d84e3dc4638c128fab65e760710bb056d2296e53c6c6de50bd")
--setManifestid(2791510,"3331805174915281558")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2584850's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:00:13 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 1
-- Total DLCs: 0
-- Blacklisted Depots: 11
--   Depot 258414: Blacklisted
--   Depot 258406: Blacklisted
--   Depot 258417: Blacklisted
--   Depot 258403: Blacklisted
--   Depot 258405: Blacklisted
--   Depot 258418: Blacklisted
--   Depot 258402: Blacklisted
--   Depot 258460: Blacklisted
--   Depot 258404: Blacklisted
--   Depot 258416: Blacklisted
--   Depot 258415: Blacklisted

addappid(2584850)
addappid(2584851,0,"0cc7b53273f2b60df6375e015e8eff93ecdf04dbe540211a5de5b69c8fc058a6")
--setManifestid(2584851,"9214663202880866640")
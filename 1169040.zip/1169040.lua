-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1169040's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:39 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 5
-- Blacklisted Depots: 0

addappid(1169040)
addappid(1169040,0,"87c68f2c84f7f3025253c63356a2952bee8fd8c159e881c256ad3937b8bf9ddb")
addappid(3947840)
addappid(1169042,0,"168f31e2f178a84c6ac42b81a49598131bfe33cfe115f6c2188cf87989ebc324")
--setManifestid(1169042,"2639262864618925425")
addappid(1169043,0,"213875f02f19619160afdd222ef457dc27c0d7e35f183f232901e844a9a061a0")
--setManifestid(1169043,"3808748551281852564")
addappid(1169044,0,"98c386b7df6681759cdcdd6723f6addec4555e0a293f06bcc571ed9e576c6785")
--setManifestid(1169044,"5029947587439033340")
addappid(1169045,0,"385d7f0572023561ff4cc1316510498bf711d493334cf01045dae0190206c718")
--setManifestid(1169045,"3292066633334903160")
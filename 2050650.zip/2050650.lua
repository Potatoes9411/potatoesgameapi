-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2050650's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:59 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 34
-- Blacklisted Depots: 1
--   Depot 2050081: Blacklisted

addappid(2050650)
addappid(2109300,0,"e15a644e1234ac8a62f6bd4e1ac16dcd5ee651810325af841f45abeb13ea3121")
--setManifestid(2109300,"5618180671040197314")
addappid(2109301,0,"d2ec1b74333218e11dc8471f4e2057fd825d407a4c47dfc646df60881a5841b9")
--setManifestid(2109301,"360070119915724610")
addappid(2109303,0,"5bf57eede21276d7dbab353eb7272c6e6a7ffca40fd535337f8b64dc1f7df1c0")
--setManifestid(2109303,"9166301326971889287")
addappid(2109304,0,"3d8963f6736172da45ac32e19df3078f2cb2679f4a34cb0b70970e183241ebd3")
--setManifestid(2109304,"382218590876545051")
addappid(2109305,0,"7df756b7ea77cd773635eaba56572deb90e4518e52b0620d47c9cc8ed10b1798")
--setManifestid(2109305,"8874053015552356169")
addappid(2109306,0,"5b1eb1787a6d0500e6cb23a33b19e593c998a07341c04525c9aa0e608d4796ca")
--setManifestid(2109306,"6308526370650425368")
addappid(2109307,0,"cec2c4f51874f8b5d2dc936e3514bc3c6ce3cd790a609e711d1b5be1fc1159d4")
--setManifestid(2109307,"5310837729215635277")
addappid(2109308,0,"cae75fb7131ee6918d86a2ba6b4195e729f93fc11291da373fe66dcfe72856ee")
--setManifestid(2109308,"964709411673088664")
addappid(2109309,0,"8e04a74054c1ecc380723dbed552ab381ea28d8abfef53011f2c42e4989594f9")
--setManifestid(2109309,"2339425891140016912")
addappid(2109310,0,"75ed1eef5aa69f5795bf6d3a5f859964fcbbceb43e3fd401f12f52c1b2801b30")
--setManifestid(2109310,"6423275757951298947")
addappid(2109311,0,"98e7b894d2d5d437f4f5572291055db7dcc846b46381a0f439884cf45ed763e0")
--setManifestid(2109311,"2476102622028354069")
addappid(2109312,0,"ca6584421429d6954970bff9838104fabace1d7bbdd465ddc1ed69a829b8e6ff")
--setManifestid(2109312,"7506742638748304084")
addappid(2109313,0,"5ba6fe4505ceccc8a3944083a0bf83c93f29431035555c3d11fc6d979ea3fafd")
--setManifestid(2109313,"4051934214530803209")
addappid(2109314,0,"06eec89ba4a65d180c33bd61c4ec39f3d0508be30168bda2e522b334cc3395ff")
--setManifestid(2109314,"5791805695380186020")
addappid(2109315,0,"078096d6d8a9b52177c2d9516967c8217edd38adab9a0fa7aef597a6f94d7e92")
--setManifestid(2109315,"1851835095891817569")
addappid(2109316,0,"5ed1c39b1d8517a51ed8bbb86229bf6fbabf378c5fc840ac8325e0d6e389afba")
--setManifestid(2109316,"3660849741169791736")
addappid(2109317,0,"206ee9679d9ce3b9eaadd476ea046359fe6ad35bc32360a934c0c418f74d766f")
--setManifestid(2109317,"2524887058062613558")
addappid(2197320,0,"0999af210483a4459d353d089e0727b1190514eb185300991694b4134ff6e3ed")
--setManifestid(2197320,"3550619730862869173")
addappid(2197321,0,"1b3ceddc3b357bd920ff08b1b9e0876fbf0563c0eba014c12303e59ebc1fcad6")
--setManifestid(2197321,"222693115030592431")
addappid(2197322,0,"ff522c3cc49b24fd23a6c9d773633f8106a58d651ea388510f30e84d8d5bd81c")
--setManifestid(2197322,"3468692957561704498")
addappid(2197323,0,"3a7d63a31ff30659e396bb425ceb400f56f53793c2800609ddbdc086e893c657")
--setManifestid(2197323,"1816669983052022714")
addappid(2197324,0,"e3a63d0ad7cfd4b8315137590d5a66ab5fff6bf511fa1a5520df85d8eff2122c")
--setManifestid(2197324,"1058648903756395119")
addappid(2197325,0,"39a56b508a0a4b8fa065e2470d9e5451c122a27cddd5a5cf91453caa0e5d2391")
--setManifestid(2197325,"2168598182656536079")
addappid(2197326,0,"f18885d2598a61c0a712d6c4452efccbfdcb3358e1054c116bed505004c69898")
--setManifestid(2197326,"630496112153249121")
addappid(2197327,0,"f16897d51802fea5d0198c8870cfb0725d3f7bf5341ead388b2bca9e639948ed")
--setManifestid(2197327,"6760043746706895726")
addappid(2197328,0,"fdd5655f102bf3913333ea1a5aadc4db2f34a1c3c901f3ec0be6549b00982f6f")
--setManifestid(2197328,"2116811573730420534")
addappid(2593601,0,"0ffe9348c534de9bf4b6a78756ea7000342ee455955bdb3c9907647a8a54d3a9")
--setManifestid(2593601,"250738809514482736")
addappid(2593602,0,"f9501bc9c97442dde06f2ff3f76872f20e2fd1547d783bca2298255511d633b5")
--setManifestid(2593602,"6030123579290928368")
addappid(2593603,0,"4c299b473a1b33986943c47e4a91f1197a4d41e8add79560a3d400c72da86024")
--setManifestid(2593603,"2819509152078889264")
addappid(2593604,0,"d5432c606302330b1a5abeab670c76f3e12f769f5dd06ccab028798abc897bde")
--setManifestid(2593604,"7483567945042610142")
addappid(2593605,0,"e99e850123c13ebb59988d506238f4bbb1e1c2611777d293fab41e0f803b12ef")
--setManifestid(2593605,"4698757027778697512")
addappid(2593606,0,"c93b565a89a7827a82a91d4a65c2c2f3ec3d4f8c191c7f0f2ec4b23598d96e9e")
--setManifestid(2593606,"3760171765598114571")
addappid(2050651,0,"c3bc4be6ae2c98c50f2ba78469906e43be35b408daf8d49f420aaf6cad275b2b")
--setManifestid(2050651,"3430910069996494890")
addappid(2050653,0,"219060cb9daf307498b27b009af1468282599d2d3fdf2b23729c0bd833b84053")
--setManifestid(2050653,"7120063014618181746")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 582010's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 07:00:02 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 2
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(582010)

addappid(582011,1,"da6b97dc25e43b8f7ceaf9bcdbfba960f2e3e855b855fc47975d58a68d3f7688")

--setManifestid(582011,"3388885539667572621",54985540625)

addappid(582012,1,"92d06583c95939873c5c33658cd8b1111fa209a4c7576207565e942fa78eb888")

--setManifestid(582012,"5526886592091189537",50644138247)

addappid(601100)

addappid(743980)

addappid(759450)

addappid(759451)

addappid(759452)

addappid(759453)

addappid(759454)

addappid(759455)

addappid(761590)

addappid(761591)

addappid(761592)

addappid(761593)

addappid(761594)

addappid(761595)

addappid(761596)

addappid(761597)

addappid(761598)

addappid(761599)

addappid(762170)

addappid(762171)

addappid(762174)

addappid(762176)

addappid(762177)

addappid(762178)

addappid(762179)

addappid(762910)

addappid(762911)

addappid(762912)

addappid(762913)

addappid(762914)

addappid(762915)

addappid(762916)

addappid(762918)

addappid(762919)

addappid(763690)

addappid(763691)

addappid(763692)

addappid(763693)

addappid(763694)

addappid(763695)

addappid(763696)

addappid(763697)

addappid(763698)

addappid(763699)

addappid(770970)

addappid(770972)

addappid(770973)

addappid(770974)

addappid(770975)

addappid(770976)

addappid(770977)

addappid(861870)

addappid(861871)

addappid(861872)

addappid(891730)

addappid(896580)

addappid(960781)

addappid(974300)

addappid(974301)

addappid(974302)

addappid(996720)

addappid(996721)

addappid(996740)

addappid(996741)


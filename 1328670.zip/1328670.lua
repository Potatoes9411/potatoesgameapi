-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1328670's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:56:16 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 10
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(1328670)
addappid(1328671,0,"1b520c64f75ebe1a7f790333c5853f8b457add2b86420baf131e3745da969f7a")
--setManifestid(1328671,"8624289317820175979")
addappid(1328672,0,"69d012c8068dd2c4629138cbec801bbb0a734de4599de6fe2bb6474998f28b39")
--setManifestid(1328672,"6245399057144560046")
addappid(1328673,0,"a221c0fffb7d13defb492a08b2b374f4c7985e350949704da3c5b898281b9b8c")
--setManifestid(1328673,"1093442016851462013")
addappid(1328674,0,"2cb09b62df0a5695580ee9fee27f68f82ca5da05dc6f7f3bf8a7fdcf4c2d8ec8")
--setManifestid(1328674,"714752994269792427")
addappid(1328675,0,"9a76443f9117cc6c61740bed586fdbacc37f1e75253263fbf9a1da1b1fa2c79e")
--setManifestid(1328675,"8839585240582289122")
addappid(1328676,0,"1ddb6edf2f05c57067bd35342fa6d29a565858b6980cdae592d9260b07c1249c")
--setManifestid(1328676,"8330674821888864767")
addappid(1328677,0,"96579200c174b23b82fef4c3a1c5edf870062c0d3b853fe93ea5b0280aa45f75")
--setManifestid(1328677,"506201563779209150")
addappid(1328678,0,"e8c1cfa35825cc97c40ee7f2ff2f294a3187d21c9f276f736c1daa8b660335a5")
--setManifestid(1328678,"6913537578765169955")
addappid(1328679,0,"aa32bd82a4477fea9f805725a12c6514ef11cbc069f1029161abfde1451d9e22")
--setManifestid(1328679,"6021402890254141810")
addappid(3340991,0,"023daedb070e5af8704dc88ee0af829f5c11923d2e6a42cca11ba5713b9f4491")
--setManifestid(3340991,"1045137092521996070")
addappid(1393160)
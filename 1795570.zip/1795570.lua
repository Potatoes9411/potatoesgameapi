-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1795570's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:06 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 4
-- Total DLCs: 0
-- Blacklisted Depots: 2
--   Depot 1795511: Blacklisted
--   Depot 1795311: Blacklisted

addappid(1795570)
addappid(1795571,0,"b55d329d52e6d553098a0ef98629e71da01a814186f3dcb22057fa3959f78ec3")
--setManifestid(1795571,"1781849249783795395")
addappid(1795572,0,"24489338c26fa7480bd044fae3a1be2728d41939cbdcbaa907fd2f92fb1de963")
--setManifestid(1795572,"5673517190065960408")
addappid(1795573,0,"b3239716efdc1aafaa1c74dc19580db9c677078121efe749abb39faae3c01030")
--setManifestid(1795573,"2594005839417946272")
addappid(1795574,0,"9f933976a094db12b516fd3eda365dc0b075695387827b1b98eff72fb55a3d62")
--setManifestid(1795574,"6895209893685505498")
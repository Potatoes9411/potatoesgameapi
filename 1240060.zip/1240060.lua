-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1240060's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:56:03 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 2
-- Total DLCs: 0
-- Blacklisted Depots: 9
--   Depot 1240444: Blacklisted
--   Depot 1240448: Blacklisted
--   Depot 1240449: Blacklisted
--   Depot 1240441: Blacklisted
--   Depot 1240445: Blacklisted
--   Depot 1240443: Blacklisted
--   Depot 1240447: Blacklisted
--   Depot 1240442: Blacklisted
--   Depot 1240446: Blacklisted

addappid(1240060)
addappid(1240061,0,"96beb02c693855c8614214eb84be8b4a6319ec724365c3a30185ec162b1cfe77")
--setManifestid(1240061,"2451626169883568495")
addappid(1240062,0,"e34adc0d51d782f99f125d8b7c0d2bab14c12cc3303374fcee4da4c2f736b2dd")
--setManifestid(1240062,"2938965297363477427")
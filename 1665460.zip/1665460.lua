-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1665460's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:56:52 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 19
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(1665460)
addappid(1996790)
addappid(2095940)
addappid(2095941)
addappid(1665461,0,"2624d08cc505e348325f11d468d4d89bb07791230ce61d05cb1873d1ae84475d")
--setManifestid(1665461,"7624879061037978309")
addappid(1665462,0,"6468be30e6c14cfb049f40a81b556205bba2e8cfd53daccaf3f4ac04486f2e6b")
--setManifestid(1665462,"476443243239654858")
addappid(1665463,0,"c7b43c0521608c98c2a0e5f9dbe82a906d9f6fc6f10412e71d00cba9432cdc2d")
--setManifestid(1665463,"967534010047199460")
addappid(1665464,0,"33b1b22bda3287036523f6d9e029adb88146b2c08914c99b640a7380564ea2c3")
--setManifestid(1665464,"1800125933083118839")
addappid(1665465,0,"249318f4fd438324736f1832153ae5e27ad78ff8de0e429b34d7089a6d12a8b0")
--setManifestid(1665465,"2625453917637287379")
addappid(1665466,0,"f1179d852efc69124a99916f5dceafb388fd461941e7aaa251addeecb04b44fb")
--setManifestid(1665466,"3069495207944386123")
addappid(1665467,0,"dc689aa871d86a819e17c71ae32bbda021ab8d7f41173a760296a812c2a6c5b7")
--setManifestid(1665467,"8634631132738592608")
addappid(1665468,0,"959d938df7ccf817fe8acc801ab56cfe13c35078164e4371670a9c440928ec65")
--setManifestid(1665468,"1265507128576659053")
addappid(1665469,0,"8279fa55d1e93e160f0350fd1be729096f60b1d89ca328292c74792abc8f2a1c")
--setManifestid(1665469,"352462616575495806")
addappid(1672262,0,"d2d104771df15c4f2a45741089da0a72b224ae931d2f7baa277b4747166009dd")
--setManifestid(1672262,"7863878043844521083")
addappid(1673160,0,"a0f3c92838e64017e91d88ce52c85a5c9e9cd04c43718680cf2ebec504420cf1")
--setManifestid(1673160,"6459945098653671125")
addappid(1673161,0,"70e0aa7d86bb45edef97be827e38142e83bb12ff293c97d31fc3661ba7b0c1f2")
--setManifestid(1673161,"817338570908831864")
addappid(1673162,0,"0ab50bc562d25269d26b02e19aa12187b137c6e2cb504e1577f2f0378eaa2ad3")
--setManifestid(1673162,"1695367803415203097")
addappid(1673163,0,"cb35a908057c15f2def5074c86fd3aad95d19d35b8952cfbb17e0704fae092ad")
--setManifestid(1673163,"512191007454960255")
addappid(1673164,0,"4ee945700e05880655ff220f9a52313d5498bdda9eecf9e25099ec7d94aa2092")
--setManifestid(1673164,"5823926129484502142")
addappid(1673165,0,"3df79054c15111981ea9529b939c381bafdde1b635f6c0b23543f6aa13a1d4da")
--setManifestid(1673165,"5507611721820999374")
addappid(1673166,0,"31588c3b1cf11753af7121732d91c7b9a8d0213368159933b209da33e8f6d255")
--setManifestid(1673166,"2755296896673098690")
addappid(1673167,0,"12a92cd4ec5040c04cd1dfb2ed19f2e7ea3a6e0167612438339afe44bd800d2c")
--setManifestid(1673167,"387684102424741394")
addappid(1673168,0,"f2af9ed4d4fc89cdf9de52937f83618419e52ad6b6ffc94528c233257b1eeb12")
--setManifestid(1673168,"3570372640308699600")
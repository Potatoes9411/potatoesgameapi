-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 6010's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 07:00:03 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 6
-- Blacklisted Depots: 0

addappid(6010)
addappid(6011,0,"d3e02b7a8336c3539b3f96c0c750220bb1168cab324590c2c88c074cceeb3aa0")
--setManifestid(6011,"8584153416851488924")
addappid(6012,0,"4c0afa2e651c2412d76dd2963f032ff88c32ca2ebcc2df66dbeeb6860578cd85")
--setManifestid(6012,"5902553837266693337")
addappid(6013,0,"b636cff3468adddc39ce62ba63dd6ef2555e67f55fd8773c0db92c9b3b5d6dde")
--setManifestid(6013,"7820646257669845939")
addappid(6014,0,"a19a476ed387a979adbeb971ca0af81b690b21875fd279551e4f869cd8877d89")
--setManifestid(6014,"6828890150884573577")
addappid(6015,0,"b4d830b9893f2dbe7e217b4fd06025ad5b27784b71021d2c95260f375ae2ebe3")
--setManifestid(6015,"1198054107095209497")
addappid(6016,0,"13b2ac833ba17da2d8cc8042d675588e429681e9ba7b555a4cc0f62a711a9d01")
--setManifestid(6016,"5669880856107212992")
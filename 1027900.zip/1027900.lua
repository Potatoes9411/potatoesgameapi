-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1027900's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:55:22 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(1027900)
addappid(1075870)
addappid(1076380)
addappid(1027901,0,"a375c8e5d6c2a6102050156c4885e46d2f95c0b87dc31cd91050a722b9ce59f3")
-- setManifestid(1027901,"7098121100768238417")
addappid(1075870,0,"e000d7d924a7df00f0beb062df59af7ab8c800f534816ce184062684b55d9687")
-- setManifestid(1075870,"3981423253075269121")
addappid(1076380,0,"ede1c935dd1f424fdb8be49ecbea4e12d486fb2425da399c7dc91e393fae7332")
-- setManifestid(1076380,"5992502866029576168")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1422450's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:56:28 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 1422441: Blacklisted

addappid(1422450)
addappid(1422451,0,"5e41412d5525ec19c3b35b0e7394dd394f3afe8a0a40d308fddf6486c5d5f19a")
--setManifestid(1422451,"9054065176759038305")
addappid(1422452,0,"cec8fb9b3514cdd7394110792bcfdb6b07903f136c0df1f81d7b94b02dc6ca89")
--setManifestid(1422452,"9073881747348687787")
addappid(1422456,0,"e615f3146e84f310bda59c806c74be74c86d1b81aa2b143e8e00a414ac279868")
--setManifestid(1422456,"3849016642827732617")
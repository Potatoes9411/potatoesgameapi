-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2427700's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:17 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(2427700)
addappid(2427700,0,"390494bb2b12665d053b2b0eb8096ac5c377d8a72fcd2e572ec535d2c8de1d4f")
addappid(2427701,0,"40bbfd9e7aaf1830bd55729aa2c13d2eed07e0ed92dd6f9d35ced2a7b7dde436")
--setManifestid(2427701,"7786367227061211429")
addappid(2427702,0,"392b31e91e8d666f24765d8ef4fed439f1e7d82cedd1a8fc17ed77f519ef4361")
--setManifestid(2427702,"2080974973619424166")
addappid(2427703,0,"d37075d18480b1c119cde1ec702d11f47656b77417489db60863bd30cc1e7c70")
--setManifestid(2427703,"1738031031898015277")
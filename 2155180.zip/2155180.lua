-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2155180's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:03 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(2155180)
addappid(2721120)
addappid(3322960)
addappid(4351430)
addappid(2155181,0,"d38873bac59e2a12948771b27a94623a3ece822844d75202b42361f61b5b1504")
--setManifestid(2155181,"8871717823119645321")
addappid(2721120,0,"669357bce75468df0e5d7d4e09d2444ab6dacbc04427ed6fe88482429c099289")
--setManifestid(2721120,"6439517453764568790")
addappid(3322960,0,"346ce58d54bd6101aed396886f8de43ea868f0c24455479ed66d9e321b855ba2")
--setManifestid(3322960,"1244520110520626987")
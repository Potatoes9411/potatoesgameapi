-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2800900's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:00:56 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 3
--   Depot 2800081: Blacklisted
--   Depot 2800250: Blacklisted
--   Depot 2800240: Blacklisted

addappid(2800900)
addappid(2800901,0,"f3c7ea3002f656ee07bab9f10c17dbd3e775a438b4bd5c88a11f4fe3d4c3e9dd")
--setManifestid(2800901,"1267510514695821427")
addappid(2800902,0,"f45ffb01ed8225b6266b07342ffc6d3afdfcdefb1801510be9d94da56a0780d4")
--setManifestid(2800902,"6701051262601544975")
addappid(2800903,0,"ab8beeb1a1eeca48ed84d70cc926a37730c7cb1da5d1037cf883d630c18062d0")
--setManifestid(2800903,"657819473100385544")
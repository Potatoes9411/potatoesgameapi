-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2231380's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:09 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 21
-- Blacklisted Depots: 0

addappid(2231380)
addappid(2231390)
addappid(2231410)
addappid(2231411)
addappid(2231420)
addappid(2231421)
addappid(2231422)
addappid(1716751,0,"84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
--setManifestid(1716751,"8055867430366823504")
addappid(2231382,0,"3eccdc4fe84bf82f170bd4191cd7b7276ea7de0000cdb265f9fdee98866f4694")
--setManifestid(2231382,"1993549197604068611")
addappid(2231384,0,"97daefda6409a51ba03417fbda4543fa4243f92fa4d01149a45cb2c023b06139")
--setManifestid(2231384,"6191132130783445275")
addappid(2231385,0,"c301efddb00c1c611404d3d699f66a465b89ea31fe2e856f5c68b2e36c8073e4")
--setManifestid(2231385,"7528150003558617508")
addappid(2231386,0,"2e4d26cc33df94480ca39c95d50e7a5cba563db2adccfa27919d57cd21d24881")
--setManifestid(2231386,"3871716644723181897")
addappid(2231387,0,"ccf35f023a6305a5d69c60b2bd0fe811320df81a0d9b92d19f20da57bfdd056f")
--setManifestid(2231387,"356052933198522110")
addappid(2231388,0,"0d1ca6bda2c76ae21d204b17b1eb8eee034768f27ead5ba98a99f69b84d614af")
--setManifestid(2231388,"8875633676323003036")
addappid(2231389,0,"e32f9de7fa46187d18ec2cc9c7f14bd1b4a6c94e2d030a5540ffa47bde1724ce")
--setManifestid(2231389,"6754295498337314837")
addappid(2231391,0,"19126356a4f5b11d6f374aced8cf509ccdd8d22ce134089f1e645f6d685c20df")
--setManifestid(2231391,"8656332478848129499")
addappid(2231392,0,"c273cae7d215a52dd2e2b51ae7725d9a2fb4913d73e54e9b87c44d132155ebe7")
--setManifestid(2231392,"1586712820353022283")
addappid(2231393,0,"f3d764f07df9c438e072eb1dd5a7c44f2e835451be234f83111ffe74b003344d")
--setManifestid(2231393,"1334988830508965832")
addappid(2231394,0,"041f5dae9b9dea5d7226c585682dfe29033e15942872f0b74296f16e3250d285")
--setManifestid(2231394,"1433404657799338514")
addappid(2231395,0,"c07b369352a184d2be0097c9051b5681496483c8004fbc2afcbe8a35036dd431")
--setManifestid(2231395,"8837751728476669795")
addappid(2231396,0,"7bd444df55251dc998c96349f6c0289edf3ebb20cbf5bb93dcf6f2164ae8dc76")
--setManifestid(2231396,"1357423432476302083")
addappid(2231397,0,"ade06f5098304372b6c348ee363758b886804b94403c19d51133b2a5effe863b")
--setManifestid(2231397,"7754426185254746237")
addappid(2231398,0,"193c79acdaf43bb9716a432bba0e68a673ff4ef91c399c2e92de29a68991052f")
--setManifestid(2231398,"3588616391123594823")
addappid(2231399,0,"a0388c1b0d1dfceff36f5c40431b7c1acbc948d48d8a917394380cbe0d321d2b")
--setManifestid(2231399,"4976583837086862935")
addappid(2231412,0,"1d0502508f9ecab56e179cb658087f1b275b968e685485a9019e3aea7a478c68")
--setManifestid(2231412,"7944320001532811116")
addappid(2231413,0,"1b2c59b321ba561b0272c63fb48e08c68b14a75066f9bd6c67de559cc5377a74")
--setManifestid(2231413,"6588469859068812024")
addappid(2231414,0,"aa3f012901204f7a421b6ceaac0d78268ccd7336ec1108988c5716b96e9d76ed")
--setManifestid(2231414,"5989215440613661026")
addappid(2231415,0,"e50bea7b6f7c015d8816c3894ad6004d091a62231e030fc65ff20847fdd41703")
--setManifestid(2231415,"6956202546244077416")
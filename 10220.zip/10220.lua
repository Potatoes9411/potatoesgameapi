-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 10220's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:55:22 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 4
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(10220)
addappid(10224,0,"95ec5ff157662354e5bfd42fe2acacd3dfdadae09f419f48a514494d8f3114cf")
--setManifestid(10224,"9021635569006621295")
addappid(10221,0,"155817ac114533bcd3f782e6e898420c9e356ae5c7bf8c8927735c724630e427")
--setManifestid(10221,"1933346114793832631")
addappid(10223,0,"5862193ebdaf99e911d266593c7ced9daf51bfee4a84cc7487697a9d5393bd3c")
--setManifestid(10223,"2059631534238862852")
addappid(10222,0,"838dff761b0a5bad634f0294c2db6631590a2f530632ff27961eaa27932f8095")
--setManifestid(10222,"3056462515788810958")
addappid(2674620)
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1250's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:41 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 12
-- Blacklisted Depots: 0

addappid(1250)
addappid(1255)
addappid(1256)
addappid(1257)
addappid(1374790)
addappid(1379540)
addappid(1379541)
addappid(1935740)
addappid(1935741)
addappid(210931)
addappid(210932)
addappid(210933)
addappid(210934)
addappid(210936)
addappid(210937)
addappid(210938)
addappid(210939)
addappid(210942)
addappid(210943)
addappid(210944)
addappid(210945)
addappid(258750)
addappid(258751)
addappid(258752)
addappid(309990)
addappid(309991)
addappid(35417)
addappid(35418)
addappid(35419)
addappid(35425)
addappid(35426)
addappid(35429)
addappid(98009)
addappid(98009,0,"1a56b7f2c47e6793771a1e9ad64ae9527cd5c64f18c0392ae6e9cdb51781922e")
--setManifestid(98009,"1037980016995672823")
addappid(1251,0,"948100db7737b1e42b84518e4ad90b8957d3cb1c4bde1417ae44ffffdbf30a92")
--setManifestid(1251,"9033622738747915238")
addappid(1252,0,"63619af1635f84aaf89f4e199b11c118fe6f2cc1b5d9ee32c4e27f34e2165d9b")
--setManifestid(1252,"8847646994748097416")
addappid(1258,0,"d18cf52d5a51542928f279c19c1124cf86e9eac11fb756218b3fba1af58ca302")
--setManifestid(1258,"96013688694607881")
addappid(210935,0,"233eadb66d2acac096a4bc5fadb2fb4758899a17c6fbf6fe433c5592da284e40")
--setManifestid(210935,"7563393395723306375")
addappid(35411,0,"5e90f263a39ff0aa3e9e0ace96587284b2184c095ac231e603be44cbda000dd5")
--setManifestid(35411,"906253386388206029")
addappid(35412,0,"dba800cf4bf02fa884ed0bc39695f0bdf8ca4bd02c1feec9462d6419ee7faa0d")
--setManifestid(35412,"8468379892522852993")
addappid(35413,0,"ea63939f49f1d556594eb7e1e766123a552c1d79beca2b9cb7489bcfdf1991ae")
--setManifestid(35413,"3228135026284527066")
addappid(35414,0,"5df9fa1e7461a27775ed92811a64ab5ae935f8148333b9a9d17c81a4c432084e")
--setManifestid(35414,"104832099190976001")
addappid(35415,0,"9438d68a90267aa57aabe35c308be1eb9fce264d10e5f10bc70f110aeaf0c72c")
--setManifestid(35415,"4068632667278647160")
addappid(35416,0,"a37d5144d606e876bfc32e9488d20bd11b45ba267b21cbec5825426b30c00d4a")
--setManifestid(35416,"8230602473846459083")
addappid(35428,0,"55245614dca5ba68071421dcea7c967d952a2b9b5e753b6d89d497ffff1d4c5c")
--setManifestid(35428,"2447789526600632028")
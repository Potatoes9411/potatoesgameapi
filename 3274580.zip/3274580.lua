-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3274580's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:23 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 6
-- Blacklisted Depots: 0

addappid(3274580)
addappid(3749050)
addappid(3749060)
addappid(3749080)
addappid(3749090)
addappid(3874230)
addappid(3874240)
addappid(3875910)
addappid(4168120)
addappid(4168130)
addappid(1716751,0,"84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
--setManifestid(1716751,"8055867430366823504")
addappid(3274581,0,"29f1b2f2b84b5981fe5e3ebadc14b925e747eea87b6556a95001d576acb9beb9")
--setManifestid(3274581,"5163444261535490089")
addappid(3274582,0,"f04b6ff10311fb1d95b43528e4681da8a1b615a31d69275af308d77f93602a4f")
--setManifestid(3274582,"1800057126029927532")
addappid(3274583,0,"dc97a69d99aeaea85bf8ec545b63e9a140606870c2f17f9fec7967c463060618")
--setManifestid(3274583,"3338096086836703251")
addappid(3274584,0,"e8679d4318f2f44fc44ff183048c09321b4b84000680a1675fe1dd5463d2f24e")
--setManifestid(3274584,"2289479757235617996")
addappid(3274585,0,"b08a4e3e71782afe4166e047a91bed2a236df33c2b0d0fe02a7ca3dba1a15912")
--setManifestid(3274585,"3657036694533001802")
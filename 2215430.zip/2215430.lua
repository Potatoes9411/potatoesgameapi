-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2215430's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:05 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 13
-- Blacklisted Depots: 0

addappid(2215430)
addappid(2686280)
addappid(3929730)
addappid(2215431,0,"dfc6d3958470277318949e0773165b9ce5d26f6ae73e2d37b9edfe4b934067a1")
--setManifestid(2215431,"4503498528457882025")
addappid(2215432,0,"b218c016d1b02dd7d4722fe5d6bcf3d44d8a8c978f493678df8a98d855e74c8a")
--setManifestid(2215432,"5130605107956954017")
addappid(2215434,0,"d712c2f977a832063ecdee3943236ccfdfc386c19d05a30c85a880273ab6f110")
--setManifestid(2215434,"880597362622556889")
addappid(2215435,0,"3b81d2d844c42ba84e7f1148c247462c18b8c866280a04ec7911186bbcc980cb")
--setManifestid(2215435,"1741259271972069973")
addappid(2215436,0,"70f30c99113cd922e3922176112072fb0342fa8ea9d70ab21b2b9c9490095bda")
--setManifestid(2215436,"2342834755630514714")
addappid(2215437,0,"e57984af0d5ec477c23316b244de1e09be8a1cc1b7818765e71d229d5b6d025a")
--setManifestid(2215437,"6645149111657224998")
addappid(2215438,0,"7700f2391ea9b7bdeae2d69c20788091cad2d095c83a4c78f0d2ba27673b75d3")
--setManifestid(2215438,"6525424500655659607")
addappid(2374401,0,"178cd22d92120cd366e68ec088399abb594be5eec78799a05eebe3af9b0cc078")
--setManifestid(2374401,"204690583444440935")
addappid(2374402,0,"0618ff72abfe8aed89c4220aa8b4e88ba392647dda99471696237c05b8c0c163")
--setManifestid(2374402,"5900367963458568890")
addappid(2374403,0,"e54d4cd0930e0f16e1e19d6cc7b45cefcc4d7178d2bbbbf0fc9640dd00d884bd")
--setManifestid(2374403,"4982117972751931186")
addappid(2374404,0,"1b65fb40764978104667193422e1797e9a41484825b0a684a881e6a077322144")
--setManifestid(2374404,"7968686865299155539")
addappid(2374405,0,"20e0bd9426f12532d58d6806e810957c22dadd475463bafb50fab9fc147a35d5")
--setManifestid(2374405,"3652298622322133746")
addappid(2374406,0,"0c450f698f7c08adbe60ca98ec5298f7adbd213a8b7e0e016e5acabb22d12d84")
--setManifestid(2374406,"8170256765332020951")
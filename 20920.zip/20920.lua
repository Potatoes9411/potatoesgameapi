-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 20920's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:52 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 11
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 2092841: Blacklisted

addappid(20920)
addappid(228460)
addappid(20921,0,"422ce9a62e74270124898f642cd6680a82b5a38e6df5355114bce1a3ba9e01f8")
--setManifestid(20921,"8223514100734217719")
addappid(20922,0,"8ed7d445083710d9eaaedf3d0b4efb874c1f9f20e4592a067c10fcc26e589692")
--setManifestid(20922,"3780814960985639249")
addappid(20923,0,"8184a90b126793437d45e63790f1a1ab8f4b471bd051f7827fc89cb27b1a3906")
--setManifestid(20923,"6862011465667603014")
addappid(20924,0,"0ad303acc7351993c72e4b268d414d83122c47fa36303c01db198d345291abbf")
--setManifestid(20924,"3594794442703802535")
addappid(20925,0,"7be8e87634ee7e33581fac81d58d7acc80c3c1016062d950cd8ec0b0882d1e4f")
--setManifestid(20925,"5800386476642370826")
addappid(20926,0,"805bd4b649d2922154963262548666e9a470ca75b9d09a2417eecfe47ded88ea")
--setManifestid(20926,"315769246484065383")
addappid(20927,0,"01ff943a47b237a777e411f8dbea92d4ffe9fa165470d7392cce3d87de72d1c1")
--setManifestid(20927,"7361591508551106857")
addappid(20928,0,"4b0458f19e74d96213f3ea7e3a63f480e8c455c643f78ce181fc0f1a6caa00ee")
--setManifestid(20928,"5764482989207420007")
addappid(20937,0,"f5739293fef7415775375580665da10e85fdb116deeb46117d258c48d74ba7a9")
--setManifestid(20937,"903372513047389057")
addappid(20938,0,"6d46e31c91105bf2a2f2f7916d7ccbb516a27878625fac4dc8d18f164f56506c")
--setManifestid(20938,"4226047910205081744")
addappid(288910,0,"161d4e1f29e3ac3895f12bec21c9f0cd794c2f651c2120a029a5a98d51253472")
--setManifestid(288910,"1947434890495899226")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 42670's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:55 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 6
-- Blacklisted Depots: 0

addappid(42670)
addappid(42671,0,"57ee2d1dfbccfc21c9c7cd5d33b173b8f747280202f99fbac5534836ca4696db")
--setManifestid(42671,"2843213203039743973")
addappid(42672,0,"2db0a5e36a26e540cee83f2ae48d007b43cd758c36af0db9f2dc980e1d8621b9")
--setManifestid(42672,"8898920507974856770")
addappid(42673,0,"ec9b68e15ca309c706eac7209e8871ee5c23916a3bb0fa51d3e2b94369bec1e8")
--setManifestid(42673,"5659171675386179861")
addappid(42674,0,"6E837FF124525EA6EB0E075461C66E31C934C437C2F367B5404025D01AA2819A")
--setManifestid(42674,"1064986929430979784")
addappid(42675,0,"280DECBD3BA1868148733CCCAD36008D18279DFDF7CA3A42E3402086FB9F5129")
--setManifestid(42675,"9195708534015647437")
addappid(42676,0,"ea887a84dc2b9622af39b5f12ae39e0c87d0923839016f496784370513ad7bbc")
--setManifestid(42676,"6833480119286375718")
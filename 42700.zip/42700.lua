-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 42700's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:55 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 27
-- Blacklisted Depots: 0

addappid(42700)
addappid(42716)
addappid(42718)
addappid(42719)
addappid(42722)
addappid(42723)
addappid(42701,0,"ddd8000d5816ec84893d070556a6649261339998966a01ee2223be068c9f149f")
--setManifestid(42701,"5564723134361260769")
addappid(42702,0,"0a06c6a7e3239813ec8eaa68b3f825792e50e8f9766d7218440f95cafc414df2")
--setManifestid(42702,"6257032900290287777")
addappid(42703,0,"48e008cbcb32413a3e7645bb624908b69f3c45a1e1bd2d288d710120e7db2872")
--setManifestid(42703,"8741537774138455205")
addappid(42705,0,"12ace44104d1b7194c091d35ced64b2eaa19e0fbc3c21c4c6b0196624408ee3a")
--setManifestid(42705,"3138932303365817849")
addappid(42706,0,"01c5172e023bfeda1a5441d6bd640e5b8b8c70b1882ac68d214e1a6ada4a85b8")
--setManifestid(42706,"357347562299132770")
addappid(42707,0,"4239d3b38cd64b5d20dba2b00d0b170a008574a779a2233da2bf9a8405e165d1")
--setManifestid(42707,"960178958982048194")
addappid(42708,0,"6977051f55833a3bb91c8ca4df029767d7069a9aa15ee46ad2c2233c159b5c86")
--setManifestid(42708,"2954444769787319132")
addappid(42709,0,"765bedbba80d60fb32bd6ece8b768bbcfd0e3c06046aad7f551613c1f485f5cd")
--setManifestid(42709,"4569232414924537110")
addappid(42711,0,"f47b3121d84acb57cf36e8a31252de7aaa36d46cabb5025606c25701af1fc9ff")
--setManifestid(42711,"4595024737384945225")
addappid(42712,0,"5368e07809c82a9de5bdd7d4367711a499bf3c5aaa8cda2a74eed0ec6692f953")
--setManifestid(42712,"5149997040663396999")
addappid(42713,0,"a1c22f61cab5fbe228ca1e586d0995d1c3ce0443ae89a1b69868fb63b237b459")
--setManifestid(42713,"6857315315257409107")
addappid(42714,0,"5fd131f536d8843c93152e3b86d2488f644cc50b67c0a4f7d3ae27584f0d094c")
--setManifestid(42714,"6472729729241488074")
addappid(42716,0,"13ab1ab397e033f161418b426a1085bd18b67f111b9bbb903dd101d8b6579774")
--setManifestid(42716,"5219529921410063376")
addappid(42718,0,"69820ad69e295d2c9d47c4839e89665e898419aa7b5ee63e616e7f5917813c5a")
--setManifestid(42718,"1065439930824857999")
addappid(42719,0,"9353a6d2a3ee0242e27e0263a2cc813b54199b996cae4649a8fd3e68820f68bd")
--setManifestid(42719,"7063395875107468534")
addappid(42723,0,"9cc78f24c57edd7e0339365d42fe9b39b9893bd24a9fd7ab156315016ac59a90")
--setManifestid(42723,"3361073951409360487")
addappid(214631,0,"904a406f1e717b877cb557516d994c9ec6e8af49fd1e1ba8a92925dd1da16565")
--setManifestid(214631,"7802016395965216401")
addappid(214632,0,"481c1e943f158a88f14c744f2881f80e324eadabcf226af94a694ab798245b8a")
--setManifestid(214632,"2605732980233577166")
addappid(214633,0,"1827c09ead4857e3d99ed07af58f7c32f468381b3594c2be3f0de7c441e239ad")
--setManifestid(214633,"982368564698117322")
addappid(214635,0,"2ec4aac7f7b604c205cf17bfbff40afc739beb79ba4493e1db6c98151ff4b98e")
--setManifestid(214635,"7174585141737681556")
addappid(214636,0,"ef90f2445f2f952ba7f1dbf12ada65d4c5b7a4f23a2ea0abe0f029ba17a9d797")
--setManifestid(214636,"6061879198934230124")
addappid(214637,0,"6383ae668b25aa3614f8ba35f8ccf6e643a4a6dda535c4683999d6f2450b89ee")
--setManifestid(214637,"7429125894442942724")
addappid(214638,0,"f87d21994f2c02b7117e4087e5a2bb480a2bd4454214d173df7d122a85469d0f")
--setManifestid(214638,"6985602171318889261")
addappid(214646,0,"ee8525fdbe70362e66f42974cce4b72d5a3adb9fb15fc3f2384d6f086685ab1a")
--setManifestid(214646,"962139694640373478")
addappid(214648,0,"2896d470d4d48f43652d59ee4786b54260f01d2b87bebd371adbf80ad4133f78")
--setManifestid(214648,"8215032655708545859")
addappid(214649,0,"7aa1998611367715c053d2f57dcd29ad635b6f7a1abfb012bf95e3ec914974ce")
--setManifestid(214649,"4205037187636915696")
addappid(214653,0,"81046867559A5BC1DA7150DDB6F8A0BFD0B30A30F6656DA8BD1689B7014BAE97")
--setManifestid(214653,"8132945300873862767")
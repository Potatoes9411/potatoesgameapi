-- Made by F1uxin (UserID:965053505901588521), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/NmmpgnAgen)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:965053505901588521)
-- And if you have any questions feel free to dm on discord (UserID:965053505901588521)

-- Socials: https://guns.lol/f1uxin

-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)

-- Main stuff to add your game.
addappid(3943500, 1, "1399085847050b7060662eb83e9da600f50ae48bbf22d7d47776b9d0844455e1") 
addappid(3943501, 1, "d5bc8ccc17dd8309d568dc4981e92a3e7939a9952e17a510d99f0eebc455c870")
setManifestid(3943501, "3787643116325144105", 1551597036)
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 374320's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:45 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 5
-- Blacklisted Depots: 1
--   Depot 3743791: Blacklisted

addappid(374320)
addappid(442010)
addappid(455380,0,"ee1942ee70f7707eb40415a87cd933fedf4de04aeab6f69421e106ff4b8d3228")
--setManifestid(455380,"398045694410355072")
addappid(506970,0,"2dc303f9e1fc1f45f385b5d262b3b481ed10f11d38e5ca44edf7096a4f280385")
--setManifestid(506970,"2441039608905796121")
addappid(506971,0,"0ce07245c46df4c8b1c5d7bef627f59f34b9fde6ea903ec21ea879cf6d9c10d5")
--setManifestid(506971,"266039425715139370")
addappid(374321,0,"1e1f904451f44a8549008ac8152430dc18288dd22c8edda058afa86b926a4162")
--setManifestid(374321,"6652575487689169560")
addappid(374322,0,"2e8b33176e957bf7c6ed4ad3c34847d1eef1ee846e900e1b4a2b4fc3a51b6c09")
--setManifestid(374322,"6130303443397132373")
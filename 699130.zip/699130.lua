-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 699130's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 07:00:05 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 1
-- Blacklisted Depots: 0

addappid(699130)
addappid(1640650)
addappid(1708020)
addappid(2170270)
addappid(2226070)
addappid(2243210)
addappid(2313390)
addappid(2475060)
addappid(2540380)
addappid(2614650)
addappid(2614660)
addappid(2962180)
addappid(3100200)
addappid(3245120)
addappid(3245130)
addappid(3699420)
addappid(3699430)
addappid(3930030)
addappid(3930040)
addappid(4057370)
addappid(4197300)
addappid(699131,0,"8e1c37df6ec32e30f09ea256f8732eb98b7955ec82c51c49960f0d078d057fbb")
--setManifestid(699131,"666683415766431411")
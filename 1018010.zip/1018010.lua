-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1018010's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:55:21 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 1
-- Total DLCs: 0
-- Blacklisted Depots: 11
--   Depot 10183: Blacklisted
--   Depot 10188: Blacklisted
--   Depot 10186: Blacklisted
--   Depot 1018681: Blacklisted
--   Depot 1018021: Blacklisted
--   Depot 10187: Blacklisted
--   Depot 10181: Blacklisted
--   Depot 1018001: Blacklisted
--   Depot 10189: Blacklisted
--   Depot 10185: Blacklisted
--   Depot 10182: Blacklisted

addappid(1018010)
addappid(1018011,0,"f369e7edc8f5b3ceafff6f9366fbf8d1b5f3ce2d064444f966315ff1b0cbdf4b")
--setManifestid(1018011,"4125351698578021580")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1906020's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:55 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 2
-- Blacklisted Depots: 0

addappid(1906020)
addappid(1906020,0,"af4ad82640a12b5bee71e189ea8bdfc99d9866645f14b50a47ba236aea26fc2f")
addappid(2532520)
addappid(2532530)
addappid(2625150)
addappid(2625160)
addappid(2625180)
addappid(2625190)
addappid(2682130)
addappid(2682140)
addappid(2682150)
addappid(2682160)
addappid(2829930)
addappid(2829940)
addappid(2829950)
addappid(2829960)
addappid(2829970)
addappid(2829980)
addappid(2951610)
addappid(2951620)
addappid(2951640)
addappid(2951650)
addappid(2951660)
addappid(3053540)
addappid(3053550)
addappid(3053560)
addappid(3053570)
addappid(3240370)
addappid(3240380)
addappid(3240390)
addappid(3240400)
addappid(3240410)
addappid(3240420)
addappid(3240430)
addappid(3240440)
addappid(3240450)
addappid(3307470)
addappid(3307480)
addappid(3307490)
addappid(3307500)
addappid(3465580)
addappid(3465590)
addappid(3465600)
addappid(3465610)
addappid(3465620)
addappid(3589590)
addappid(3589600)
addappid(3589620)
addappid(3589640)
addappid(3833680)
addappid(3833690)
addappid(3833700)
addappid(3833710)
addappid(4109240)
addappid(4109250)
addappid(4109260)
addappid(4109270)
addappid(4335070)
addappid(4335080)
addappid(4335090)
addappid(4335100)
addappid(4335110)
addappid(4335120)
addappid(1906021,0,"71625ccc26c54523aca402bba21808bb3473b5fe3428f415a43052c54335af7a")
--setManifestid(1906021,"2282838078819112747")
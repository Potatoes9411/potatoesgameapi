-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2547980's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:23 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(2547980)
addappid(2547981,0,"2a7ed623864376fb640f5dad21b04e367fdbeebac80d79989580edbfb45249b5")
-- setManifestid(2547981,"2957391216793069264")
addappid(2547982,0,"0f36188609511bac7bc7b20b5e5c38eb0aec8f3253820f666fa19fc04b32ce01")
-- setManifestid(2547982,"5218074124607209553")
addappid(2547983,0,"1cbe1447377c146e8b52ea6b8de2b9e8f1583e7d258f83cd3500884624daae10")
-- setManifestid(2547983,"7711346167287646524")
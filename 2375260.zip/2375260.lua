-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2375260's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:59:20 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 4
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 2375531: Blacklisted

addappid(2375260)
addappid(3815930)
addappid(3815940)
addappid(3815930,0,"8785b39a179306c17210e552857c9ccbb0dce383714e8f0cba6a87f7d1587be4")
--setManifestid(3815930,"5935665520287199924")
addappid(3815940,0,"f0a9cedb1104b1ae2deaa1b643a7e5df6e35012fe144dc233709ccdb59c69c14")
--setManifestid(3815940,"5972311625974865768")
addappid(2375261,0,"370bbceb536a246700e8325729577ce7655e800e573c8bd1a10cc035513d6bb8")
--setManifestid(2375261,"5039575246410285209")
addappid(2375262,0,"84f62e505bb37098c956ef8dcebbcdc7435227d23a154c25358ff0fac4be1af8")
--setManifestid(2375262,"127860973384890467")
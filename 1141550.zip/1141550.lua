-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1141550's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:55:39 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 4
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(1141550)
addappid(1618840)
addappid(1812160)
addappid(2265340)
addappid(1141551,0,"51ea3cfe06ce1156a8ca562c78a638afe933250b3252eae6b33100da90016860")
--setManifestid(1141551,"7285463678999915805")
addappid(1618841,0,"72a7c3a287f93de0af9d649e863439c814c5a927366869975fcb02448051b9ee")
--setManifestid(1618841,"762395762634575019")
addappid(1812161,0,"30ff5117f71879b066586288a39519d2ef5c61c0ac9abbcfae147c38ebc64c43")
--setManifestid(1812161,"7458495184317434677")
addappid(2265340,0,"6c50e51b6e62620452f53772ee358721d8a383de99886dea8f0f1d81b5a7f8aa")
--setManifestid(2265340,"8940253925747232941")
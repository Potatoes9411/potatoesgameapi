-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 224060's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:58:44 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 8
-- Total DLCs: 0
-- Blacklisted Depots: 3
--   Depot 2240081: Blacklisted
--   Depot 2240082: Blacklisted
--   Depot 2240621: Blacklisted

addappid(224060)
addappid(224061,0,"1b95dccb34463613e917735aaf08d1b525b8fe739dd85d3cb537aa551f9d949f")
--setManifestid(224061,"902441342317572401")
addappid(224062,0,"cd62e1cfd5835f6de15a9aa435e3455605e4ee68c7d2df31eb255270b9b3d54a")
--setManifestid(224062,"8163029659755953523")
addappid(224063,0,"c57f5d7b7446a66b6f6c7ff9bb60551c0809b868795918e136f58376bd79c59f")
--setManifestid(224063,"3104057046075596770")
addappid(224064,0,"9a34418503b802045b1178d6a831be163ab3cd057546d8d88fd875910dfbe2d3")
--setManifestid(224064,"9034951943485147947")
addappid(224065,0,"0dfecfe02c8e2e523d2ed028b56eea20b65310d104a0f4065cb21f7ebf414a10")
--setManifestid(224065,"5966443289890992442")
addappid(224066,0,"10f70d5182a1e769914588edfe5efed38b18f6d6fb0594757db61d5212b695bb")
--setManifestid(224066,"3402381215480815")
addappid(224067,0,"d367fc2230da5fa8fb9a73d884537089bbf9202d48379488999b0f9909b04055")
--setManifestid(224067,"8633549531911463504")
addappid(224068,0,"4ad7e48bc90a77adba68585a791b30f1009235deefd725dea7e597e599e6ae34")
--setManifestid(224068,"7079399129514840253")
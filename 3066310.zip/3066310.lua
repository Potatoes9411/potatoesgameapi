-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3066310's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:44 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(3066310)
addappid(3066311,0,"b13227c3b248ddf64d6fe196fc436fb336a8a76adcabea15ca5617c56fac68b3")
--setManifestid(3066311,"8424954796587466632")
addappid(3066312,0,"5181382f51e8559a119d314bef36c6bc07daacb143cf981f6f647e4f6ddc1719")
--setManifestid(3066312,"4145089797701380615")
addappid(3066313,0,"c0f5e4c01af46e726a7d745a9b6258467db07505872a5c89776aae1e635dc8ef")
--setManifestid(3066313,"1622718550708227282")
addappid(3650601,0,"1634e3ca73e3bc4bc3ca69c9a97cf952948b835ef194e98db720a3a06adfdcb6")
--setManifestid(3650601,"2185812163326317136")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 252950's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:00:00 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 15
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 2529791: Blacklisted

addappid(252950)
addappid(252950,0,"97978ac90e1684bd157296ba59e97d1abcd1df15d9337e4d6c18d1e1f7ef53c3")
addappid(391680)
addappid(399730)
addappid(405170)
addappid(408610)
addappid(438690)
addappid(457160)
addappid(457162)
addappid(457190)
addappid(457191)
addappid(457192)
addappid(457194)
addappid(457195)
addappid(457196)
addappid(457197)
addappid(457198)
addappid(457199)
addappid(675280)
addappid(675290)
addappid(772150)
addappid(838770)
addappid(910940)
addappid(943740)
addappid(1002130)
addappid(1018530)
addappid(1077690)
addappid(252951,0,"2c5162dd5164c160a18d4a0086a9a540bf27b1879d0a0e7c69e2d5e0b287e681")
--setManifestid(252951,"8895295678436426320")
addappid(252952,0,"e07657ba2a95aa1599fee2e0dc27f86d21c280c6e36295d61a10478251efbd80")
--setManifestid(252952,"4510403162949335447")
addappid(252953,0,"82fe5333148dc6dadd932dd622d8594a3f2cfbc96bdc5dd70a2261ebb90f2c69")
--setManifestid(252953,"2514327339850257685")
addappid(252954,0,"706ffd8207c3bf1bf598421fd53ae108587bcf77f03cd5be2d1bd03e510aacf7")
--setManifestid(252954,"6604331299753353584")
addappid(252955,0,"9cdc308ddc198a1176112ee82dec8c39c35d412a638ea50ffddaec6bb9c112ae")
--setManifestid(252955,"9065328472878819409")
addappid(252956,0,"ed2bc8a848fd33009e08cf5ab297e2530dcf0605e33d2b072e4d8b68ef75da24")
--setManifestid(252956,"316973403359005795")
addappid(252957,0,"0ac63ca60da191510247cf382fdbf94bae44000450557b658a7f93b49fb4457b")
--setManifestid(252957,"550143062542037081")
addappid(252958,0,"fbd245fd77848586642e8c5c02b0478a4810b4e895edbddd11e8771f6a637ed0")
--setManifestid(252958,"8936650610860102348")
addappid(252959,0,"93c5d4454fc08a119685a61c5b02af961a183eefa3550a67b5c64a8b1170d205")
--setManifestid(252959,"4386213019025687925")
addappid(252960,0,"0729c40cd6ccb20223e55f65ff65e386c7ddbe91b91ea3eb3d56d2634e3c6543")
--setManifestid(252960,"4118993315564346938")
addappid(252961,0,"97fc37ccba41374f4d55ae03feeeb2144def3f55ece0856e41f6162a730a81f5")
--setManifestid(252961,"4730643967328491213")
addappid(252962,0,"112d4200f836026eaa24f3ac6ff4c405dada93daa3779ab92e3dd387693c1dbb")
--setManifestid(252962,"3990443630786511251")
addappid(252963,0,"176b94925a2f7f9452c7089ffb870f53bdb9564c993deb43d1cadbc3beedc6b8")
--setManifestid(252963,"4010319018365688560")
addappid(252964,0,"fa024050d977900bd48d5c3e9968694a8161d792487375b1c9ee8944b679c583")
--setManifestid(252964,"6304967143002381104")
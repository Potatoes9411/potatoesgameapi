-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3446680's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:30 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(3446680)
addappid(4048000)
addappid(4048010)
addappid(3446681,0,"1baa52ded4f657a337210ea04dd4cce31d150ce76e78cc0dc32ac8b395de8668")
--setManifestid(3446681,"4024959806575523828")
addappid(4048000,0,"0be5540a4d5f134e97d1c2b280784b13f2921017eb487057db4a06bc67d15e8b")
--setManifestid(4048000,"4419548848859026580")
addappid(4048010,0,"37dd989ccf11cc084b59b1bd725854bdd06a21fe2b51b67bcae6617b5fc04bde")
--setManifestid(4048010,"3190074883419414555")
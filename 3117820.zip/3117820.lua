-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3117820's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:17 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 5
-- Blacklisted Depots: 0

addappid(3117820)
addappid(3117820,0,"5b953b3aff2ae34d4eee90a135eaee5a3e1377be9a5c4c6af9c218072aff7589")
addappid(3728320)
addappid(3117821,0,"6da5c61617ae1bce4dec442e070762a2b581103f5765d3067a24cc1276dd0461")
--setManifestid(3117821,"4890019194367593327")
addappid(3117822,0,"035a90c8a84efd35f026f2ac3856c53f459fed40e95d99e490f0eed947a99be9")
--setManifestid(3117822,"508264723055278820")
addappid(3117823,0,"4041c78dfa1b7b56de279bbaf92f1bd964a745fd067e476ed3302d0a40b90042")
--setManifestid(3117823,"1684709752728303768")
addappid(3728320,0,"6efd49cc3608ae57bc6d0b2e1c1f790c0b6febd6bd548587d1314e7c1acf35ef")
--setManifestid(3728320,"4532337905061516730")
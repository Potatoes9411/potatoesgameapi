-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2655590's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:00:28 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 2
--   Depot 265591: Blacklisted
--   Depot 2655: Blacklisted

addappid(2655590)
addappid(2655591,0,"938cf7542d29fddb19cc588a978b2bcabbf645729522dfbd8d3c2a87e9341e8c")
--setManifestid(2655591,"745607911530649518")
addappid(2655592,0,"015a345af1ac3ee8c7e9449d8f7d06ad5a6ec6eb9331022fb83e2f62bfa9ff24")
--setManifestid(2655592,"3069013839573316105")
addappid(2655593,0,"b28d3585d361b5b9a7583f04cf3bf0f5ea764150e87d61e25484842867151944")
--setManifestid(2655593,"6480423617168097874")
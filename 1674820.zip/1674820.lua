-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1674820's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:50 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(1674820)
addappid(1674821,0,"bc5bb1336bed89caa879622a67ed838203029809307934d8f3ecd7e82888255a")
--setManifestid(1674821,"3313910203750655538")
addappid(1674825,0,"6c11def9c00b61e9050568b2ccfabfef77854fcfc418046156c2e8f2ce05eb4e")
--setManifestid(1674825,"3473342288786103802")
addappid(1674826,0,"c20c09abe6c3e89de508068deca1aa7e1c1b88c8d385f09ed26203bda988970d")
--setManifestid(1674826,"7978270510864244301")
addappid(1674827,0,"18354895e1c5c36ac3ea0e9cffa3a17e4501f30de5dfde264dfc179bacaab6bb")
--setManifestid(1674827,"1769399138187445994")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3008130's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:41 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 26
-- Blacklisted Depots: 1
--   Depot 3008670: Blacklisted

addappid(3008130)
addappid(3592040)
addappid(3707620)
addappid(3707630)
addappid(3707640)
addappid(3707650)
addappid(3707710)
addappid(3008131,0,"3c9721275b2d1577cdbc46948aaef80104cd4f45a9bc32c20e03345c54652587")
--setManifestid(3008131,"7509236200935396898")
addappid(3707621,0,"04cd9ab87835457d4a64c2e33c8bfb34ec9873a58306082dd1554fa31e61b08c")
--setManifestid(3707621,"6257965437662766979")
addappid(3707622,0,"dbba296c59b4dd12cfbf3e831d228341905cbfe72a6f39b9ab9ab535e2aa2390")
--setManifestid(3707622,"2214401054261555775")
addappid(3707623,0,"e7a49cf3e8049304b31ac9af2380050346b19274b6429680fa656ca2ef8132ff")
--setManifestid(3707623,"8410235877528022390")
addappid(3008132,0,"6028aa5b91f9bf95194ec527c2ebdccd62e9a5df423e65ce32a73145aaa6c6b3")
--setManifestid(3008132,"2040647196635303519")
addappid(3008133,0,"434623d389db7ee032958e856f56adcc7da748791f86963e54523321e2e57ee9")
--setManifestid(3008133,"2889995873721136000")
addappid(3008134,0,"9c4e2acba05efb8e83b8b84191c8ea0454009ee00e7fc407eb32ad2c16cd5d9e")
--setManifestid(3008134,"5260456260725768489")
addappid(3008135,0,"d47e689c1f7c949b76c2d74d998ef7cf4db0ebb66ef327e68a4e7e1b4bc931dd")
--setManifestid(3008135,"1242793802549415026")
addappid(3008136,0,"4246c4c3f664e9ac92b6f9bdabea8f9d178d64e7b7f78ce2e47d3261e429d21f")
--setManifestid(3008136,"1147956287995322192")
addappid(3008137,0,"91d23606572ed7cd2a17f0a53854b43ab17be7f90b9121c2e133df6bf9628b15")
--setManifestid(3008137,"2610710909436952689")
addappid(3008138,0,"b087b304a3080e8bb9b868f067c8b57d6eac1c0018d81a8d563cc7dcaf6ca050")
--setManifestid(3008138,"2731636610563680049")
addappid(3008139,0,"9ca49a179625bb0a94c6cef85afa175dbf6f70f640eea01565cf29ee9b89b1a4")
--setManifestid(3008139,"5722097853743569058")
addappid(3061861,0,"2f7e9b1d05e7bc30e55829af984f423c7891ecb354db0e336f3cc8f8115aa9a8")
--setManifestid(3061861,"3443990642255438133")
addappid(3061862,0,"58441f3a3fc23c78ee6ae062b402e98c3881f13b870b2945df538700a9ee98ee")
--setManifestid(3061862,"533191503532783787")
addappid(3061863,0,"5046b1035705c5b2cb125dcffa5f4e5e2fc859a4be1568f05cb1690cd5d8a2ed")
--setManifestid(3061863,"3614014044616581209")
addappid(3061864,0,"38076b913ef2e4d848b83c972e455b0ed335321b7b3275f956819d56618137cc")
--setManifestid(3061864,"7196171371819268793")
addappid(3061865,0,"062b2caf7c45bb6c993a1ccc89d4241601e83976f43b4d7a4ec73b6e87a23baf")
--setManifestid(3061865,"8092312703545691606")
addappid(3061866,0,"da6a491e78d34f913d3a35f81992ad8b9554a45ad3405eb90104535c2a190a1c")
--setManifestid(3061866,"6936106709858183769")
addappid(3061867,0,"72b42328ca9c827d6c99a336214d08101a2d1ea131aa4c646a506d94d5c25594")
--setManifestid(3061867,"6204653115183086554")
addappid(3061868,0,"4a4e46600e98b44593fe9d6c5f32ffaee4984a804a65841da31aa5f3d562e9c5")
--setManifestid(3061868,"1340823629662235461")
addappid(3061869,0,"a3cc7e3956b21127479c97bde2183a0350a0e00b1866e328210cfd18f9449d2a")
--setManifestid(3061869,"6177689421572629022")
addappid(3592041,0,"32f10ad2de76688dc0970aebede422b2921593489edc03e6e1e90d447aeb3890")
--setManifestid(3592041,"8283646749269563448")
addappid(3592042,0,"55b8d3f1f8f7b6a5285b4c11635a22a47948493c275ac657e6a3e7ec22a0912b")
--setManifestid(3592042,"5970552040254970492")
addappid(3592043,0,"d6564bfa4427ac630cf6a83e8a8dd0da310c59f95cb79634b17a8ce1822922ae")
--setManifestid(3592043,"1066585063535786065")
addappid(3592044,0,"d36aeb87d7dc3805c50fbbbbd0a592b0e112ba31cca48aaba4a4b12169ab4a06")
--setManifestid(3592044,"5744279559723215725")
addappid(3592047,0,"a6d2c01076098ca0ecbe70d4ec21e3c3acfe1671974a526ea883096a51067cec")
--setManifestid(3592047,"7688974675603957754")
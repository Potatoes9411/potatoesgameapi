-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2778610's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:00:53 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 2
-- Total DLCs: 0
-- Blacklisted Depots: 2
--   Depot 277830: Blacklisted
--   Depot 2778580: Blacklisted

addappid(2778610)
addappid(2778610,0,"6e71039f7b4e48ec743d0e1d678ab832c7814d3024573b98dee49b5d2eaf7927")
addappid(4309530)
addappid(2778611,0,"ffa4f7ec012fc2a39e3c7b3e800d80beba4be3ed6efb03015e5223379930c503")
--setManifestid(2778611,"1143290051158776690")
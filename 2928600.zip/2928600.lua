-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2928600's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:38 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(2928600) -- Demon Slayer -Kimetsu no Yaiba- The Hinokami Chronicles 2
-- MAIN APP DEPOTS
addappid(2928601, 1, "486448df6cd95d0d663ae6dbc0dc5cb7ed590875a2a7481fee25ffe7572b60fc") -- Depot 2928601
--setManifestid(2928601, "6544946417668235170", 25974484063)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
--setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
--setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3371870) -- Demon Slayer -Kimetsu no Yaiba- The Hinokami Chronicles 2 Battle Attire Tanjiros Kimono (Entertainment District), Inosukes Kimono (Entertainment District), and Uzuis Shinobi Attire
addappid(3371880) -- Demon Slayer -Kimetsu no Yaiba- The Hinokami Chronicles 2 Character Unlock Keys Sanemi Shinazugawa, Obanai Iguro, and Gyomei Himejima
addappid(3371890) -- Demon Slayer -Kimetsu no Yaiba- The Hinokami Chronicles 2 VS Mode System Voice Upper Rank Demons Set (Akaza, Daki, Gyutaro, Gyokko, Zohakuten)
addappid(3371900) -- Demon Slayer -Kimetsu no Yaiba- The Hinokami Chronicles 2 Character Unlock Keys Mitsuri Kanroji and Muichiro Tokito
addappid(3371910) -- Demon Slayer -Kimetsu no Yaiba- The Hinokami Chronicles 2 Digital Version Bonus - Character Unlock Keys Academy Rengoku and Academy Uzui
addappid(3900330) -- Demon Slayer -Kimetsu no Yaiba- The Hinokami Chronicles 2 Core Add-on Bundle
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2879840's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:36 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 31
-- Blacklisted Depots: 1
--   Depot 2879621: Blacklisted

addappid(2879840)
addappid(2879840,0,"7c008af9cef1ad18f5e872860cac36e8f0bf058517ea2dfd0c86b5cf92b65cde")
addappid(2879841,0,"c433321ba6253e0c6d6307cd77101be392e2de78a54bfdb1e27e7f5b6c1e781c")
--setManifestid(2879841,"7172389599758976408")
addappid(2879842,0,"31b5cc0b6efd3f8a01b95c9d01f2eb3146b7b4bf138c0d9a790dada042aad32a")
--setManifestid(2879842,"8729890191801994094")
addappid(2879843,0,"ba93ef87c5cb35d35942f9c9bafb8b6680de41f769d238efadc453a3f21e77b1")
--setManifestid(2879843,"2900199069572921921")
addappid(2879844,0,"e61f373492ca8dc9fd40f1f514c97961cc954c9f990b249b62ef491ec490c4f9")
--setManifestid(2879844,"6652211365781468649")
addappid(2879845,0,"89cf2165ec14f7d28a699a8f74063ec630d790a7fdd35a6956e3a7f8e7c3df29")
--setManifestid(2879845,"5660386619977174783")
addappid(2879846,0,"3d6d67b0f597d8261c1dba9b2b45c7cb5fef71e1ae17461f050179bc1d8c623c")
--setManifestid(2879846,"8442390882080643548")
addappid(2879847,0,"c3754b84d3cc1e47539867285ceb16f5cd6c1d6d114abb7a8885fe178ced0098")
--setManifestid(2879847,"290672213772261880")
addappid(2879848,0,"7904bceff45b2ba879fc08a99f6e05829d002ddebefb594befac8e1c9be9c683")
--setManifestid(2879848,"1378635563474156080")
addappid(2879849,0,"da04d7f4b81f703fa8bb79eebbfb63cc4eb0cbe1578936415e7ea2af78f0ab16")
--setManifestid(2879849,"7062454988022158998")
addappid(3834070,0,"7fd3f747ddf885dec0d796beadf708d418686e5029dcbbca694d78ee636defd6")
--setManifestid(3834070,"5235623822210213851")
addappid(3834071,0,"5a9ef9b77c9ee1c7fe07028675f7df71de661aaa3a81ebb004656e9d381f050b")
--setManifestid(3834071,"501192835271552857")
addappid(3834072,0,"47aa4f34b7707f1fa8dac16c3a2c96900b66c9aac675d38408d8e4e7db1ad7ee")
--setManifestid(3834072,"3674614399954488199")
addappid(3834073,0,"6c83a577b773b53e1dbc8be5391f657eb9225bed94f3c405519367dd33c10155")
--setManifestid(3834073,"4216288177367363")
addappid(3834074,0,"bebe9f4071153d1a0ba72912f2d83aa68ff6dd859b9bbac503cbbc4529104341")
--setManifestid(3834074,"5114835893237369506")
addappid(3834075,0,"31b971e81d39b388251d783b54602d73e0a8fcba205d8fd25c45029407268935")
--setManifestid(3834075,"8469161733501599288")
addappid(3834076,0,"42305852e60df07150de1899f31652360a4e165ee0879274c6cc91ba0098e89a")
--setManifestid(3834076,"4480189121030380979")
addappid(3834077,0,"c399f48167cf4104ba49a789f35d5abcefb29baa0006aab0d6e31831185ac24b")
--setManifestid(3834077,"2099282328493375455")
addappid(3834078,0,"00bdd08582c4afc0c79e8736eac1d4f93d3f412792add04f96bde860d30cf371")
--setManifestid(3834078,"7842062136404635033")
addappid(3834079,0,"473af9af3716e109b56f3996456c2ed86c57bfe248f28f41c3794f0ef8bbe16a")
--setManifestid(3834079,"1963968649858972060")
addappid(3834080,0,"50827602240f383f5d4901dfa65827f315ff9b0e02ace2a887d89264a3f8b56c")
--setManifestid(3834080,"3543291169013595957")
addappid(3834081,0,"9c3f443ccbf72fec39c152ebaa3ba46627a2995b5d31c276445dee16765dbf03")
--setManifestid(3834081,"8984684802404417227")
addappid(3834082,0,"eb44489dbd287db2e2136628971cd8b3468f7928f0e9f82ce796412ca37e2e9c")
--setManifestid(3834082,"3133956579793645531")
addappid(3834083,0,"3f98d19799a965d4c67dad39b94d98e57b9f21a0a62ab63db2499ec79cde64a7")
--setManifestid(3834083,"7287920368778322883")
addappid(3834084,0,"f28ea861c3d7b8987957fdc2644823c50fb237dd504aa3610902912c8d6f2962")
--setManifestid(3834084,"2397426339927247027")
addappid(3834085,0,"506aebe326128408e4e4c1deed57ba89df91d197cb9dc315f9917bb1015ef451")
--setManifestid(3834085,"4721141725354469044")
addappid(3834086,0,"b4f15b0e35f321615088a22958f0e7fe7cf590ff8318285f64ea3feceddedc2e")
--setManifestid(3834086,"2841447299986191987")
addappid(3834087,0,"fd600f609aad61fd67119ec60cbb7f76f983d8b46f1743ddfcfc1dc4fbe58cc7")
--setManifestid(3834087,"4972803665024984692")
addappid(3834088,0,"91195fd55e6e1b9dbeba95b02e22fd8190e6322c847e27a32632a6e6533eefe1")
--setManifestid(3834088,"4206627122060286866")
addappid(3834089,0,"32df8d005bc675bb6452d3d81e4a53b88b0582a522856fadcc31e27c8d780aeb")
--setManifestid(3834089,"5934169077623072668")
addappid(4105228,0,"f3d8565e894b07e49f92acac0a766f1e602ab78093605b82c18eb76bd9dc7b0f")
--setManifestid(4105228,"8810924636468935619")
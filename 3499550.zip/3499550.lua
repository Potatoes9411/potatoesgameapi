-- Made by F1uxin, Discord ID:965053505901588521 | Discord Server (TGP | The Galaxy of Pirates): https://discord.gg/VfCxRsFyFe

-- If you're interested in distributing these files please dm me on discord (UserID:965053505901588521) 
-- (I don't care if you send them to a friend or to help someone, just if you add them in your bot or have them widely available then i would like to know.)

-- Socials: https://guns.lol/f1uxin

-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid", save the file, then add the lua file, (i think you can add the manifests too but I would just add the lua file to ensure it works).

-- If you have any questions feel free to dm on discord (UserID:965053505901588521)


-- Main stuff to actually add the game, DLCs, & depots.
addappid(3499550, 1, "a977913d3b54b5c57a8bc180fae6d7cd3f7201838da6bfdd9e56a66cba297579") -- Mai: Child of Ages
addappid(3499551, 1, "af1e32a98b94cbd7a2457c753ae50a0c0ae615ea2c67d073752ba17d589d13f1") -- Depot 3499551
setManifestid(3499551, "6824387757398878811", 5736650965)
addappid(3499552, 1, "6678c7817c783759f5edc4c0303d42129b14a3f198b697ab7a52ef50bb098b56") -- Depot 3499552
setManifestid(3499552, "3935529117049641553", 5942735801)
addappid(3499553, 1, "f844f39b16321ffcf5bfc6ea7f6aee806625d709c071ee9a7f8f98256a8e2669") -- Depot 3499553
setManifestid(3499553, "8192955985281773296", 5747176119)
addappid(4140630) -- Mai Child of Ages - Storms of Time
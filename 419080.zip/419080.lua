-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 419080's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:55 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 1
--   Depot 4190290: Blacklisted

addappid(419080)
addappid(419081,0,"cda8d2fd4130b89693d5aa7018177a3ff663ccf2dc4fb657fdec5b52ef6ed433")
--setManifestid(419081,"6812606768553420747")
addappid(419082,0,"777a1cb9e4faea09c9e23bdfd1bbf7d4f8aef8bdce06dbb562d180eee0dbda83")
--setManifestid(419082,"7319392315892293118")
addappid(419083,0,"1bef48a1855b02ae4c6be2691efac9a69d13f04cbdf5ed31b495e494e24f6264")
--setManifestid(419083,"8622520829691445757")
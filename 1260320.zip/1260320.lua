-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1260320's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:42 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 1
-- Blacklisted Depots: 0

addappid(1260320)
addappid(228989)
addappid(1260321,0,"9623dafeee383701a837274d2547c7a5cbae7334393d64e82b4d2cdc01ef679e")
--setManifestid(1260321,"8343327074661407536")

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]
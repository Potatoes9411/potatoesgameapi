-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1253860's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:41 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(1253860)
addappid(1524740)
addappid(1253861,0,"a413f0623457407e6ba860cde72d57a4d5d513e80d42e967ed38685a4e80df93")
--setManifestid(1253861,"8014379727297562937")
addappid(1253862,0,"13441a467b473a02914bd2b8cf90c6d4a36fb435236f03e45d86653469da1da0")
--setManifestid(1253862,"22827620122099930")
addappid(1253863,0,"e0a8e4c9c13648b39e396527b45a93eb17075be768614336b436198241b04289")
--setManifestid(1253863,"788059263350330757")
addappid(1524740,0,"90acd5df5808bb42300a25b2ab546ae03b58c568daa7a0907eab140e9d4bd326")
--setManifestid(1524740,"3892863395661252859")
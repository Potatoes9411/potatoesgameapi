-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3932890's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:51 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 2
-- Blacklisted Depots: 0

addappid(3932890)
addappid(4090950)
addappid(4090970)
addappid(4091290)
addappid(4229530)
addappid(4229540)
addappid(4407420)
addappid(4407430)
addappid(4531790)
addappid(4531800)
addappid(4531810)
addappid(4531820)
addappid(4531830)
addappid(4531840)
addappid(4531850)
addappid(4531860)
addappid(4531870)
addappid(4531890)
addappid(4531900)
addappid(4531910)
addappid(4531920)
addappid(4531930)
addappid(4531940)
addappid(4531950)
addappid(4531960)
addappid(4531970)
addappid(4589090)
addappid(4589100)
addappid(3932891,0,"8cf57d9d3c35a5371e82341a2a0aa834b0f4edc929ae700566d6b2ebe66e7210")
--setManifestid(3932891,"2391060395732109613")
addappid(3932892,0,"6a03571f28db62fb25aa43c1c39bf870b8848c97b3624dd0e846023438411904")
--setManifestid(3932892,"6056428799506113701")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1038370's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:55:24 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 5
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(1038370)
addappid(1038370,0,"e9683f3c4c944a14f895040a4bbf68db171cc83c04ab25db9c4bf4c2b9c5cf21")
addappid(1594260)
addappid(1038371,0,"785a7a959bc9170a3750fb05f21c128d937cc9b7dc4e0b15b90a6561e40f0cf4")
--setManifestid(1038371,"1636861904023300773")
addappid(1038372,0,"cc3f76e6e6a3742b0e695147c02b755026b20e2441538b27f90c76142b2a4c7a")
--setManifestid(1038372,"216646044851551622")
addappid(1038373,0,"5b91b5cca7632fb083388fc5f53525f9658983467966571d5e19e704726152d8")
--setManifestid(1038373,"5215516858635517528")
addappid(1594260,0,"ec08c9d96eb6d7592c9312cd47d0ff4012bc14edcf69a4b3dfdf8b759327b1ce")
--setManifestid(1594260,"1070712721167874813")
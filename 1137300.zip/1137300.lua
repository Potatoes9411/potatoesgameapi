-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1137300's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:55:38 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 9
--   Depot 1137321: Blacklisted
--   Depot 1137324: Blacklisted
--   Depot 1137329: Blacklisted
--   Depot 1137326: Blacklisted
--   Depot 1137325: Blacklisted
--   Depot 1137322: Blacklisted
--   Depot 1137327: Blacklisted
--   Depot 1137323: Blacklisted
--   Depot 1137328: Blacklisted

addappid(1137300)
addappid(1581901)
addappid(1581932)
addappid(1581933)
addappid(1581934)
addappid(1581935)
addappid(1581936)
addappid(1581937)
addappid(1581938)
addappid(1581939)
addappid(1581930,0,"21b2c3bb882203d1ccbe91878195906b97cd73888f11cef06a7cfb113d5de579")
--setManifestid(1581930,"4669706638952156099")
addappid(1137301,0,"24ca096079bebd50677ab228e60f5773d36d1f51b7785d03fb1df59262c9388b")
--setManifestid(1137301,"5316678191840518416")
addappid(1137302,0,"e821dbc8dc967006511960418bfaf7398358478114d21612000b8ac396dbeb1b")
--setManifestid(1137302,"3201236683053666450")
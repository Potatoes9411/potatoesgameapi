-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3903800's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:50 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 2
-- Blacklisted Depots: 0

addappid(3903800)
addappid(3903801,0,"147b265e15d7c12af155a8c51d6d97358d4adaf923cb12f6df324dabf7eb56bc")
--setManifestid(3903801,"6437802869432792099")
addappid(3903803,0,"58f2ed2c4f48f930b0a6c8e7bb80cc2d96552543a7aed95b50220e67ba938cfc")
--setManifestid(3903803,"4601903454982537418")
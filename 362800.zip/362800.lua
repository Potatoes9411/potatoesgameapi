-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 362800's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:39 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 1
--   Depot 3628761: Blacklisted

addappid(362800)
addappid(362800,0,"6DBCE6F563108F2423E06E37503E62FC969F434B94887CC2AACB62BE3C87EB1E")
addappid(362801,0,"1F5490EFAF5BB444A1725D2CBD8B319F43132A4B7BDFDE4C55D40C83A9DA88E8")
--setManifestid(362801,"4809940112287591449")
addappid(362802,0,"49A1007F7B3EB87F0A7768780B48FDFAEECAA16D6E29978200A239093C0C87C3")
--setManifestid(362802,"8314728883496697838")
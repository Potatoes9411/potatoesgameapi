-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2400510's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:59:26 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 3
--   Depot 2400772: Blacklisted
--   Depot 2400771: Blacklisted
--   Depot 2400641: Blacklisted

addappid(2400510)
addappid(2400511,0,"f08be77434663a38ec425845293b8bda95d36ff7a388d6750b7a7169681e2500")
--setManifestid(2400511,"3616383146531696880")
addappid(2400512,0,"492f6a3d8ac2649a1c06a2e0c3f57d43056f49ce83f432ab0a56349256f1b86d")
--setManifestid(2400512,"8070630430378065870")
addappid(2400513,0,"fad855e6d88be1c801695aef8326b8b1e27914f761f41a4a89d110df9a7524e3")
--setManifestid(2400513,"6695649262466358175")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2378620's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:15 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(2378620)
addappid(2378621,0,"603820674e8e8be5c370e2f4d5a4b70714c44bce4ba4ffdc55f9a3cd69f8b75d")
--setManifestid(2378621,"1605639499054239244")
addappid(2378622,0,"4b8409dc21d351051d4c4ea166c641fd55de5c3dfce490a7aeba213ebea6e417")
--setManifestid(2378622,"3345057993987601863")
addappid(2378623,0,"b41d7da3b4eafe2c49ea483b1ce6e6a1084635234705f10e92a505c878248fe5")
--setManifestid(2378623,"5460276286608717267")
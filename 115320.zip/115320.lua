-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 115320's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:39 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 10
-- Blacklisted Depots: 0

addappid(115320)
addappid(115340)
addappid(115321,0,"e3194adebf12413cfa342ecde1b0ddc66bd81adfc66ad17f2616d2f0a5f02510")
--setManifestid(115321,"463566073465694220")
addappid(115322,0,"3d7689509f18f07324101c3ec7b69ea574d0e19850b91bc6322bb0f5b8d24212")
--setManifestid(115322,"9048180919412686294")
addappid(115323,0,"c7512012479b7f2eb36c5af3e0721d6c7a1a7b30fbee18e13a27adba94b5550f")
--setManifestid(115323,"7756741017743835184")
addappid(115324,0,"7d8ee96f625a82c8191e46069f244733ac12101c210caa437169a3eb8e41e54d")
--setManifestid(115324,"5304196080885964704")
addappid(115325,0,"67faa76bc924012913caab4abb9604f61318b4bd942dc6485b124217793dd3e3")
--setManifestid(115325,"1644767041622555488")
addappid(115326,0,"2a0ee2ec61ccce4d4a8647f2f5d394ad54ed4ff72dabdcc426a330bfd0e1afa5")
--setManifestid(115326,"3833695619289562819")
addappid(115327,0,"9de5db50458a6f9a8c01f5562172063707a1242812609bdc73335a3547fc8d2b")
--setManifestid(115327,"2166545564719408452")
addappid(115328,0,"1192afe75a30de751af526c446152591cb02640f05bb680448d8399e36bec2b8")
--setManifestid(115328,"3095157929607387828")
addappid(115329,0,"706926bc2419db4262e8834ca365a012ea9c1b5abc645192a5f1fc57e6451b30")
--setManifestid(115329,"6916332080060994995")
addappid(115330,0,"125fd81599acb06df3179910fe2b8b95ca1798f949374a9564086f8d079c0f32")
--setManifestid(115330,"5516098322664057980")
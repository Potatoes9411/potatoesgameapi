-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1985820's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:31 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 35
-- Total DLCs: 0
-- Blacklisted Depots: 10
--   Depot 1985811: Blacklisted
--   Depot 1985818: Blacklisted
--   Depot 1985814: Blacklisted
--   Depot 1985813: Blacklisted
--   Depot 1985812: Blacklisted
--   Depot 1985819: Blacklisted
--   Depot 1985816: Blacklisted
--   Depot 1985815: Blacklisted
--   Depot 1985741: Blacklisted
--   Depot 1985817: Blacklisted

addappid(1985820)
addappid(1985821,0,"7ba5a7877674892cefe31026350d7ec57b1f793de70f0f7f7a6837e2a756f3e7")
--setManifestid(1985821,"8614934844977022274")
addappid(1985822,0,"43213b67597307c6575144964f31ab8499be19de0a87864d1992c2d188db5a4d")
--setManifestid(1985822,"5336869142188293793")
addappid(2093481,0,"60b7a8701a3ff931a3eecb3d0f56a34140f6ff4dc0061414e3576bfbe6e1e076")
--setManifestid(2093481,"4351629546800988521")
addappid(1985823,0,"ebf01c13443a21615b4d387b25ec8988c115052febe0322bacc26af1a8e32467")
--setManifestid(1985823,"314735224572949196")
addappid(2093482,0,"6ca3f2e97418fb866afdea56d7e0437a1cf064314ac5126138b0e5ba9ca0d575")
--setManifestid(2093482,"5910606411886739689")
addappid(1985824,0,"c5b1116289e7d1e674ab9e46cbd6aa75dd25d70d2611000ee8b478fe150714b4")
--setManifestid(1985824,"9201063995439179070")
addappid(1985828,0,"6bc5796d24577e77954aadded9c5909baec45e3a6b3182bd55a60bc4b8d86554")
--setManifestid(1985828,"8817979353694806024")
addappid(2089207,0,"f31dd9bbbd4d5d1cf2b9bfead13fa42b4ccc5045e1bd41b7b6bbf4c721bec298")
--setManifestid(2089207,"510449180814453536")
addappid(2089202,0,"d66b68f5f81222a78609493b049e84e20d65d3d8b840d18d3e743a8a270851c2")
--setManifestid(2089202,"5165772483684794029")
addappid(2089209,0,"f39281ffc37f79fbf56dc8dd2c04e0dc29a4176ef164ef273d018a37df3238bc")
--setManifestid(2089209,"2077148387318880677")
addappid(2093483,0,"ec2f2f50a2a830f9dbeaed3b648441563be377b35d11850e1119a2abbbb2187d")
--setManifestid(2093483,"5529248281599289337")
addappid(1985825,0,"6596c8409480cbc4103523b0dcbe995e69815489539b92692cbb31508b9f7c1f")
--setManifestid(1985825,"6723283642149579676")
addappid(1985826,0,"39e90555cdd3f7982cb622869c3b6b83cc70301bd59946346f326df7f1404e70")
--setManifestid(1985826,"6961365179323518423")
addappid(1985827,0,"bd15afd262bdab1179b08a92d49e51dc5705e8f4dcd86e81ecdc91bb52b94995")
--setManifestid(1985827,"2349833322891913526")
addappid(2093472,0,"e7faac9519d5fc76537228e599cb226ea4b98a1e14584afe0deafe27cfd016d5")
--setManifestid(2093472,"7362418390442576020")
addappid(2093470,0,"cf315b1e4f9939023a6cfd0ca74f3cc35f5c3ab6377609f4a0786e1c9d09d732")
--setManifestid(2093470,"5103708156105806135")
addappid(2093479,0,"5c900549395e36937340c1c996166816aeca6a376348db598c5e29c7dd210604")
--setManifestid(2093479,"971213675393486838")
addappid(2093477,0,"31f2c0f13d393f6c82a51f3ebb20e75eb7ab6a7039dc69de63442364d39b7f78")
--setManifestid(2093477,"1958345506096571446")
addappid(2089200,0,"e2c033cdbf3cc41a3cd1f46d7e7512efb092c2257a3be0f287ce71ee3af4dfa5")
--setManifestid(2089200,"4953948000926219922")
addappid(2089201,0,"65c8bb5ab31ca28776d7e5f4a334554190369f96037e5daf14c8df62f22f4f96")
--setManifestid(2089201,"7067355685948904751")
addappid(2089206,0,"c81a056c1a7852b9029153e297e2c4c8e4668e3c89412eecf7fb5cc7ebfa16c6")
--setManifestid(2089206,"4781239615114042890")
addappid(2089208,0,"5105d1bbc5e66bf6a0ae4ebf0761c23b4c59c551c580512559e86d40b735f866")
--setManifestid(2089208,"5727001053559248738")
addappid(2089203,0,"0fdf9c6ddfa8cd6b58fa05fb71d6d6100e91c4a485e48623f52b6db49d247ff0")
--setManifestid(2089203,"4582648428637551612")
addappid(2093471,0,"8bc630ba3d0d8d8c09916c402d5eceb5c9aac605ec35be1e1472065c5957744d")
--setManifestid(2093471,"2183861751417116698")
addappid(2089204,0,"8625f32d3553641912c8e6c97eed5970c301520ecfc170e018c3f772f71471c0")
--setManifestid(2089204,"3212282336664992685")
addappid(2089205,0,"54e67466bb3606e951a5f6ddb846b3159a0b73582073c796363d13e2bb360252")
--setManifestid(2089205,"7667399819722123074")
addappid(1985829,0,"2b6b1d8abec6994607bf4394341b325c1dd425fd72c986f611206d9300a893fb")
--setManifestid(1985829,"3849524285081379673")
addappid(2093473,0,"4fe0d0b758650510deea545bba19d84e1d1e13797c94da5bafbc5ddca8aff4bc")
--setManifestid(2093473,"1119029176337778758")
addappid(2093474,0,"2627af54db95fea8d873d9d647282120fd41d0ffd22fe9d8088aee937edd8de2")
--setManifestid(2093474,"3706151115402636505")
addappid(2093480,0,"bda9eb0c1344e1d84794c33b6cbfae18fdf39826ceca6c1b8631bd5a225166ae")
--setManifestid(2093480,"2848936690765968861")
addappid(2093478,0,"9e40c24c2b909c7f821e117389155df730d1823f2702bf4c69ca662b4bf03ec3")
--setManifestid(2093478,"2594615187251252853")
addappid(2093484,0,"1b16780788f7c897de6cfb84e9e48d00840173ad686584e1b45bd7c53b1a8575")
--setManifestid(2093484,"4754256537128088080")
addappid(2093475,0,"08534fa3535c2662d0d6098f4b70eca2f12b139553b79cf936c19b394b638f4a")
--setManifestid(2093475,"2919749160357006710")
addappid(2093476,0,"2a07077ccdcff78939de555edac41c0c1ea6ee8bb0e1fe3dc1f087f6389d515e")
--setManifestid(2093476,"3568969356523392663")
addappid(2093485,0,"099306c4b71bf84636ba390b1939bbd967ee17b201cfab937156784039928e9e")
--setManifestid(2093485,"5035808175532081895")
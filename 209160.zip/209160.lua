-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 209160's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:52 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 2
-- Total DLCs: 0
-- Blacklisted Depots: 10
--   Depot 20913: Blacklisted
--   Depot 2091333: Blacklisted
--   Depot 2091021: Blacklisted
--   Depot 20912: Blacklisted
--   Depot 2091331: Blacklisted
--   Depot 2091332: Blacklisted
--   Depot 20910: Blacklisted
--   Depot 20911: Blacklisted
--   Depot 209101: Blacklisted
--   Depot 2091501: Blacklisted

addappid(209160)
addappid(209161,0,"6c5f97d6127289ac53c5c62d467652ef5ac48c597a8cdc0eccb13c2e0fc61520")
--setManifestid(209161,"2184173331509504109")
addappid(209163,0,"add37e1da3d2ec3cbab0a8976f8bc8bf6ee91f7f3f80e33f2855434803b7dc3d")
--setManifestid(209163,"4970028369212033415")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2901520's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:01:20 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 5
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(2901520)
addappid(2901520,0,"3426e28f85ca04a3ad324f222bc14d30bbbf2bab04ee35c953f1ad8caac040ba")
addappid(3058410)
addappid(3592130)
addappid(3058411,0,"ef73e60b02704954409f5cf035298ecbe25d819a104630c1054a015221f98109")
--setManifestid(3058411,"6964705162311298701")
addappid(2901521,0,"b64fd4299573b07dd83ba1acf4fd83b90c27372919b8fd1d8038b98ae79df954")
--setManifestid(2901521,"6245682149211276732")
addappid(3592130,0,"98a605c120bfbf438467d0a7a1496df45373b97c697cc2e3345720f7e7f44e9b")
--setManifestid(3592130,"3951730502008911791")
addappid(3592131,0,"f22d7b483575259af6ad36c0fd144172376029ef2d01e8243287f340236c46eb")
--setManifestid(3592131,"5343438711221333819")
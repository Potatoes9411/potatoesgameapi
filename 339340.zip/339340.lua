-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 339340's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:28 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 14
-- Blacklisted Depots: 1
--   Depot 3393381: Blacklisted

addappid(339340)
addappid(381710,0,"ad086aff51fa29ecb7fd9e505054a2eea1a4d7ec52ab5e375278abeb78a7e16e")
--setManifestid(381710,"64352183134533440")
addappid(381711,0,"8983531cfd5d11e8574db04b0e6b0b9fff62a72b1c96d3a49c0eec8d6cb3229b")
--setManifestid(381711,"2539166499240446273")
addappid(381712,0,"75c7d7d7a3b9d267b81318fb7cfd61f1cd78d4b757e70f71efecde5fff153bcf")
--setManifestid(381712,"8981484900505289106")
addappid(381713,0,"0af8b8434f59751b16e7c4980fc31ddde20b0741487216fe779580ee28d05215")
--setManifestid(381713,"6723286139049539008")
addappid(381715,0,"92073fe5f9583ca8f8e27e4d617d3ddc7c176b70414bc280d6deb6d35b9340c8")
--setManifestid(381715,"2879115187161328365")
addappid(381716,0,"6af532d95f2f01b2de58c0a23d03e6c3b8f875653e8ccbc33babf6befe8e47b4")
--setManifestid(381716,"796528297318074013")
addappid(381717,0,"163ac07f7433ca64c56ce7d4d5f6fa0d65c0862254216b4d9a204ecbdc3db355")
--setManifestid(381717,"8576500298965902497")
addappid(401340,0,"8e6a4bf9ab74870f1642a94165c0895fa1411c8e95d72b64709ea95bfef3bbf9")
--setManifestid(401340,"9028079802819383357")
addappid(401341,0,"fba6c3da84f60705a9fe3e0fecb0b7e74a4daef175c06b245e83fade94bc3c31")
--setManifestid(401341,"7727255681251125193")
addappid(406140,0,"c898f781e3b9add2cec64f7b3f0b7d4ca3f0860aa0693fca4284b8e172cd9d1d")
--setManifestid(406140,"5500713755257879385")
addappid(430390,0,"2b2af9d49810ca216a15e3163cc022d8aa1c4ce0e5c1117226180fc04113ae1b")
--setManifestid(430390,"6770061075741675048")
addappid(339341,0,"e9299de2069122e5731bd097c02d35efe353b7dc40f59ca9ab568a382f3753c9")
--setManifestid(339341,"8625797949261159340")
addappid(339342,0,"5152d943dbe7913f463d7f9deab9da7bc6fcd382c8cb835b83182e1b7ef6ba46")
--setManifestid(339342,"556683354567652030")
addappid(339343,0,"b456cf099ef9aad38ad0d36862366f12cb1543773c88d783a5da7a0e545a4256")
--setManifestid(339343,"3074649547682433474")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3898860's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:50 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 8
-- Blacklisted Depots: 0

addappid(3898860)
addappid(4234230)
addappid(4251950)
addappid(4251960)
addappid(4251970)
addappid(4251980)
addappid(4251990)
addappid(4252000)
addappid(3898861,0,"71ad346d898697f9c9b91f93d981fce8aa2981cf1e9b3ac3bb93f28565967c9a")
--setManifestid(3898861,"6542438242789650661")
addappid(4234230,0,"88aaa6e98c508dce9c073ea49833ceb5df500c742dd5b8a7b0c390dda3ab07ea")
--setManifestid(4234230,"1196947010588116500")
addappid(4251950,0,"c3f17e92579871e1da88a97077d11bf12a92a3aa080ba5bcc7a8bd4de56dd06c")
--setManifestid(4251950,"2596808944728895757")
addappid(4251960,0,"4aa5e8a2a869296c21b3bb7ccc4559e837115bf74093d343577864048bcb6866")
--setManifestid(4251960,"1179715486451469762")
addappid(4251970,0,"9f6fad2694d7fb91d1ad05a55a83983900416f537eb2ab81b2c4377aa3024aa6")
--setManifestid(4251970,"8613448515560307952")
addappid(4251980,0,"a696a54c284e7b9eed57bd224943dd1ae606002006af99a9449ff99af572b32b")
--setManifestid(4251980,"8697786623633373367")
addappid(4251990,0,"68aa4fa58b2c1a08f3c8bcb99b398714dbcf00f9200ab2d6b7166b4e9197a60e")
--setManifestid(4251990,"1150940663089962115")
addappid(4252000,0,"915fcff956e5b1b962e6653c3c256d85f883d1fc9103a7603a219ec677560038")
--setManifestid(4252000,"2979775162299010810")
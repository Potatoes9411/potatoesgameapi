-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2090370's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:51 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 1
-- Total DLCs: 0
-- Blacklisted Depots: 16
--   Depot 20906: Blacklisted
--   Depot 209002: Blacklisted
--   Depot 209001: Blacklisted
--   Depot 20905: Blacklisted
--   Depot 20907: Blacklisted
--   Depot 209003: Blacklisted
--   Depot 209004: Blacklisted
--   Depot 20908: Blacklisted
--   Depot 20909: Blacklisted
--   Depot 209006: Blacklisted
--   Depot 20903: Blacklisted
--   Depot 209005: Blacklisted
--   Depot 20902: Blacklisted
--   Depot 20904: Blacklisted
--   Depot 2090850: Blacklisted
--   Depot 20901: Blacklisted

addappid(2090370)
addappid(2090371,0,"d2925727102be0f0da096477b638f5adabb7999fc500aeff19a7e8adf2d8dc12")
--setManifestid(2090371,"9121931378403128661")
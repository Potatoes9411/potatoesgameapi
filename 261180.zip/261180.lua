-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 261180's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:00:18 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 2611740: Blacklisted

addappid(261180)
addappid(261181,0,"00fcf997d4736a229775d41c0352b2aa27b1166f0503b22beab0165525cd28e6")
--setManifestid(261181,"8139535435715100688")
addappid(261183,0,"f64af6cec3fc66a4c9fe1288c0607dcb316ad7df8296d2f677ffdbb02f824c16")
--setManifestid(261183,"6841789313969051756")
addappid(261184,0,"23371550348f06f1782ffe3c3f2d54f817ff6da28dae910f1306bc57a56c474c")
--setManifestid(261184,"6098241712489772654")
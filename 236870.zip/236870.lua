-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 236870's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:59:16 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 31
-- Total DLCs: 0
-- Blacklisted Depots: 3
--   Depot 2368932: Blacklisted
--   Depot 2368931: Blacklisted
--   Depot 2368520: Blacklisted

addappid(236870)
addappid(236871,0,"2de838ec83d98e736989092808474d70af55ddf15eb08122e54fe38451b04c7d")
-- setManifestid(236871,"479376489240449529")
addappid(439870,0,"c43880b8b441e2429590725792c758a92c1ee1b63cc110afd1391eb44d6d276d")
-- setManifestid(439870,"6834277322727092982")
addappid(439890,0,"aa0273ab826d89f6671518f891def9b0eee1c6bf7112e2eebf51f842d1586252")
-- setManifestid(439890,"3263213159443066946")
addappid(440930,0,"3ae1fa25b75e751f8a3fe905cf26c13dbdd4a73b3a142ed118377007bd0791fe")
-- setManifestid(440930,"6777623673180176712")
addappid(440940,0,"7f2818da1d44d8a28b4d096b0ef909c38ec02c9f398f3ccf8e30151044fe09de")
-- setManifestid(440940,"3542367381410610127")
addappid(440960,0,"529181ef456c7412ddb10cca56603c0d82c5560161118dc4f6b184e3dd7fec5c")
-- setManifestid(440960,"2168860919225748938")
addappid(440961,0,"31462634e309ba9b1687399499772792bcccfc2e214d325253923a1bbf696ae6")
-- setManifestid(440961,"6285522717088315890")
addappid(440962,0,"5fc5ef7bdb07d204a9232c5ef366ccf5543c181e5879e37058146c276512c555")
-- setManifestid(440962,"1244185953429904578")
addappid(236872,0,"4ed1955cd3a2d5def0c25c50f11c5ebb780b4deab42a3967cd2fc2fc49bac6da")
-- setManifestid(236872,"6736842542478520837")
addappid(236873,0,"93161066f87db43964c32c4b8ac9130f6083e7d59f4483a948d5843283fc60d5")
-- setManifestid(236873,"3855457328270897829")
addappid(236874,0,"3bdb5d46746b0842e551ae258b6723832bab6c06cdccf7bda2c37fd8861a03e2")
-- setManifestid(236874,"3041633335861056856")
addappid(236875,0,"26d52f2e15ad58c9f05d288dd8300c352443eda3afef6f14880c91cfaf5a57df")
-- setManifestid(236875,"5538792601411096702")
addappid(236876,0,"b98a854b3fff724c0a3dfc5bac62bcacf4e94d5fce47faacf307be78cfd1466c")
-- setManifestid(236876,"7526628104964653061")
addappid(236877,0,"6093fdca9bb874382304367e1d3354f2512d5631f2e18809295e0a237305f2cf")
-- setManifestid(236877,"5052773020688596848")
addappid(236878,0,"deb9060e8ac82221985df2699dc56be17dca4085ea1b1832de3c2a283c09aa68")
-- setManifestid(236878,"4328284732373948883")
addappid(236879,0,"aa417badfaaf72b9016f28eca4701d82404d018f58ed972e95aa612cdbdfe22d")
-- setManifestid(236879,"2714601223055104071")
addappid(236883,0,"c28e33392c5912f70b4fe432b0df3d0c9c8891774545dfc9e3e249d9cdf41f1a")
-- setManifestid(236883,"4448279716539132890")
addappid(236884,0,"35a388fad7fd6115f2564a7e2b7c4b3bd3012095530c6c4bf2ada4c2a53588c7")
-- setManifestid(236884,"2334290686193376020")
addappid(236885,0,"8b21b33b1c4bb407fbbc20039e30be509a2bf27d2079aeafa8865838c08e2308")
-- setManifestid(236885,"6214064271344984203")
addappid(236886,0,"73c2eb95156dbe8248fabfbca68b70d5c90a14af3a19050df8c874c51bcf1cce")
-- setManifestid(236886,"3598659049715409778")
addappid(236887,0,"a06d3f78206fd791ec91d4ddb253034baef27091f7359eb5231ab08c4541ebff")
-- setManifestid(236887,"8544876509718405590")
addappid(236888,0,"54cf4bdcd3c6d0799a85c377977b3678ff070282d374b6e37f58d08b3423b924")
-- setManifestid(236888,"8912645530396539731")
addappid(236889,0,"ec4fe9e7238b3a6fa9de6dfef4ecff27a81649f1651621999dec4a9454112854")
-- setManifestid(236889,"8992117470935183226")
addappid(439871,0,"b3867060fe4bc8dad2ceb61427dc7de0720326c1581e4b2c6cfc63767353a55f")
-- setManifestid(439871,"8982177735565685292")
addappid(439875,0,"777ca39a220710d9ba47abeeba19c9f3abce2dd4cc12388d4df26cf21c52c731")
-- setManifestid(439875,"417635438486014670")
addappid(439876,0,"6fac2cf64b0613ad5ad711b0c537c379869914eea121c7c6bf665deee20561d4")
-- setManifestid(439876,"5346417764696232652")
addappid(588780,0,"e2440c584822a985a159570032d6949d9dd12de070eef3ae674697a5e213e859")
-- setManifestid(588780,"1991671708182243981")
addappid(664270,0,"6e46f1a9c242980bf3e69dd263df2420094f45ff2da1020573ae087d107a7590")
-- setManifestid(664270,"4105664812304455128")
addappid(439877,0,"8529e82a3ecad50db02c788cf9c39d4acb58c353c96ba5c7a27310c80057036e")
-- setManifestid(439877,"2694692517465846132")
addappid(439878,0,"c7baeb600c911bb1b60ca1442d7d9d99b43d24fe4451007d5b1adb78bea69c4e")
-- setManifestid(439878,"7183489376538521296")
addappid(439879,0,"8da1304231c1a271dda5f99c2a4335c2747ae66c3adaa3f5d37c7191709e0fcf")
-- setManifestid(439879,"5731779362152881525")
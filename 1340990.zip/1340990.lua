-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1340990's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:44 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 9
-- Blacklisted Depots: 0

addappid(1340990)
addappid(3355660)
addappid(1340991,0,"6fdac6ccd9ebadf5c61e1c34ec225a8bc687cab591d28cc5ade262e9a65ae393")
--setManifestid(1340991,"5032043067359059522")
addappid(1340992,0,"7c7e86cec8a1f874213799a3eb2db858af7a8e28c72d7792330cc7b28f580793")
--setManifestid(1340992,"8097777051056268960")
addappid(1340993,0,"50234d9ac0cda0a23d385d3c086560656cc037de4dcb3d743e960f416ed5c69d")
--setManifestid(1340993,"9075053198374038770")
addappid(1340994,0,"747729b8ffcd2e18673252e55284cc050dbecbff88ab7ef91b69cd71d941084f")
--setManifestid(1340994,"7767196483143147196")
addappid(1340995,0,"e57b64d9b5f9e584a87a9832529c0e1f901f699e690b4b5637fec2b2e1fbf2aa")
--setManifestid(1340995,"943949358035404765")
addappid(1340996,0,"2aca517d8dece95e0cbfce99e8e6b937dd56dee06fc84b510bcfe0fa09538d9d")
--setManifestid(1340996,"3841686798722160883")
addappid(1340997,0,"37138487eef65143ea189a388085037e84de8519cef8b35cf5486474b5df15d4")
--setManifestid(1340997,"2178159606363813413")
addappid(1340998,0,"7e685022588dcde7a3b5ee6627e0a250e8641a8bbd123bf7377b2e9e990c42fe")
--setManifestid(1340998,"8952393605010619144")
addappid(1340999,0,"bb4b2b9bca194610993a7f32ee52f074460b0d0b54fb37099580e2d512e35728")
--setManifestid(1340999,"9058506243337526886")
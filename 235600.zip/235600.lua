-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 235600's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:13 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 18
-- Blacklisted Depots: 0

addappid(235600)
addappid(235610)
addappid(235611)
addappid(249070)
addappid(249730)
addappid(256270)
addappid(235601,0,"78ea432b4857e24cab2c7196fe5e966dfb796373b535a17a7a775f0981b92630")
--setManifestid(235601,"3816548349952076037")
addappid(235602,0,"655bb6d6ee34763808b3516806ed91659d059725518cd8391ede0d7013a71ec8")
--setManifestid(235602,"86956880485774713")
addappid(235603,0,"d82018947576d249dadda598eba22d9ab11cd51859f840d60d00e1d0594aa552")
--setManifestid(235603,"7652913053855692537")
addappid(235604,0,"746d392be58bfa4516a82a8662af0da14a91d6b8c776e42d76c4fd52ad762f54")
--setManifestid(235604,"7330374006663711986")
addappid(235605,0,"b80f8e584dd4eec3f003296f4808b5750212903484a5c80c2c4c0db94b748220")
--setManifestid(235605,"1196586746484452990")
addappid(235606,0,"ca373da02fa98879a4e9843844c1316ec3d6873aa7b883963fd8313cd3e9769e")
--setManifestid(235606,"515511056331753560")
addappid(235607,0,"f6789fd0244721b268444e145f500934026ca5f7d81f5b608d2a5092cfa49a08")
--setManifestid(235607,"102954817457275542")
addappid(235608,0,"3cd4350eba735f68bae20a16f52a5069a552c00dabdd5b6982b1a7fc6d1138b1")
--setManifestid(235608,"3639441065997868791")
addappid(235609,0,"4dd75a79f1beaf9310ddf3f4eff29956dff97b6f51e817aed77a5cb3ba13ca59")
--setManifestid(235609,"3754999306053529334")
addappid(235612,0,"06dd43ca542886d722e45299d02bcc3c065e461736d3b16d1493bdfa266b3dd9")
--setManifestid(235612,"2081345709618426915")
addappid(235613,0,"e9d032471ea68c615e6f6652a7824a05aeac190e37da4a15ee1ccd476ce5856c")
--setManifestid(235613,"2558172026288358966")
addappid(235614,0,"f95154ec2fd405ef1599b17b019cb521fdbd74bfdce08093a160af813d576c9b")
--setManifestid(235614,"5027305275327641162")
addappid(235615,0,"efd57157ee8312eea8dff693b9a1b03960ddb12b479f695daf2a9c6bb2ee6409")
--setManifestid(235615,"7209099170545482046")
addappid(235616,0,"307c524ddb7e4ceae3aee62b4837373f62fa225bb05310b59f8d9c186a15bf8e")
--setManifestid(235616,"2868303669918550110")
addappid(235617,0,"bb3605d60a6e072c928103bb09210624881cc39e6e9644dbb6d21ced4cdf8ee4")
--setManifestid(235617,"3077447066159169283")
addappid(235618,0,"1ddc481d4a3f573c40ad6b906444666150827c02eddabe0c1e0164608cf71655")
--setManifestid(235618,"8832352002329787704")
addappid(235619,0,"76384412abf9cebc27efa72d14241dda8bd48ea01027d0f4ff928a34da9fb176")
--setManifestid(235619,"1750342785474537329")
addappid(1716751,0,"84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
--setManifestid(1716751,"8055867430366823504")
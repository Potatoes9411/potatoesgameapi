-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1978720's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:27 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 4
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(1978720)
addappid(1978721,0,"c96e53b578cd0f6a533c9d82aef22990c5d8ae7a0625cbfad49bd3a0eff808fc")
--setManifestid(1978721,"716315920327177642")
addappid(2436880,0,"30aabeca75c1a99444db3744e3942f2c04c85f0af6b3992ecb7ed504010c670e")
--setManifestid(2436880,"8950426244924249066")
addappid(2444360,0,"57265a62990b1959b8bf9ed272e37da31fdf2580937dfc340e5ceaf52af97e3e")
--setManifestid(2444360,"5820591128768548634")
addappid(1978720,0,"ac2f9b6844c8a54a5c7cf85d7bba5b5f4cdaa49b314ae15e79abd5f399901954")
addappid(2444360)
addappid(2436880)
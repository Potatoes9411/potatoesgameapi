-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2569670's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:00:10 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 2569750: Blacklisted

addappid(2569670)
addappid(3287820)
addappid(4553090)
addappid(2569671,0,"ec134e28be1330625eaa14ca31746901115f91b2350216524873b0e45bf97f3d")
--setManifestid(2569671,"4843622564610419133")
addappid(3287820,0,"5c797e49fc1bea3832192814383d54552b71932f13e6f6dc5056ef02ea8e925a")
--setManifestid(3287820,"7687712714039141840")
addappid(4553090,0,"c2c7b36cfb4935e7754f6d269d48e1ca809db2daa30fbc923c274a95c09f0d20")
--setManifestid(4553090,"4309897858944987277")
-- Made by F1uxin, Discord ID:965053505901588521 | Discord Server (TGP | The Galaxy of Pirates): https://discord.gg/VfCxRsFyFe

-- If you're interested in distributing these files please dm me on discord (UserID:965053505901588521) 
-- (I don't care if you send them to a friend or to help someone, just if you add them in your bot or have them widely available then i would like to know.)

-- Socials: https://guns.lol/f1uxin

-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid", save the file, then add the lua file, (i think you can add the manifests too but I would just add the lua file to ensure it works).

-- If you have any questions feel free to dm on discord (UserID:965053505901588521)


-- Main stuff to actually add the game, DLCs, & depots.
addappid(9200) -- RAGE
addappid(9238, 1, "6213fecaa065e9205b9fc482c3cf0ceea982498e4a9bc7257e93a9f16ef1f12c") -- RagePatch1Depot
setManifestid(9238, "1134475541588682318", 111451616)
addappid(9239, 1, "307b7e677c646ea5a666b04005f8e96a41a6182312f6ab52ce66a6233788fb0e") -- RAGE_EXEDepot
setManifestid(9239, "2192536432093289675", 74983376)
addappid(9201, 1, "fde52c57f81e8ed2418c891a3319d9ab1dd9d3015e0c906b4b59d3e8f8cd2ee7") -- RAGEDepot
setManifestid(9201, "5014086925005544231", 21985244755)
addappid(9202, 1, "38f50478576731d599793a54fbffbb63a162e64feeeaf97bdb60d408753ca144") -- RAGE english
setManifestid(9202, "652919118430181975", 313833536)
addappid(9203, 1, "b14ae900bad92ab4502ade5f35974e813ee3d065062c287ee46c34d220a47beb") -- RAGE french
setManifestid(9203, "3132828894800769040", 368574916)
addappid(9204, 1, "d772ad0446d661b0fa2b2d100e72b0d26430c6f32821fd80b77b0eafab5a3ca0") -- RAGE spanish
setManifestid(9204, "3091342104257094113", 351207890)
addappid(9205, 1, "0305ad4b001b281b36c837cd6a41a4f6077c0f635cfcae1582aafcab23aa572b") -- RAGE italian
setManifestid(9205, "8552145441007216975", 358826520)
addappid(9206, 1, "1f019e84d82908f9dffe4b354cd491eac05467abc1d3148cbc760aafbf116252") -- RAGE german
setManifestid(9206, "8926712750756301819", 358268414)
addappid(9207, 1, "c3fd309e8240930e4f6bfe10aae95d29d92c29b86e2e07294583a081dbcd4b29") -- RAGE Japanese
setManifestid(9207, "3206213912991923981", 368681358)
addappid(9208, 1, "07cffb3595e3df394ae8a98f635194be0d11a7e365481b7d0435dd08df473398") -- RAGE Russian
setManifestid(9208, "2782040233682929048", 668951322)
addappid(9209, 1, "52f2982f07465b03a17b4e2964695b1a77e23725f6019a0433cc1a479894140d") -- RAGE Czech
setManifestid(9209, "7213651268791022776", 313833536)
addappid(9210, 1, "de793b286e0b7f81a6bc7c0e9f6196aebbf4c6c5a1a3828ece9d9b9b846b7216") -- RAGE Polish
setManifestid(9210, "7428280759344227078", 711086556)
addappid(209461, 1, "4a51585577aa0bbfc50449b26c7ddf01635617e80f8706217e2c16f7d81e0622") -- RAGE DLC3 English
setManifestid(209461, "2804468988412701931", 32923960)
addappid(209462, 1, "9ad1616e273d091248353dbe53acc6253cc7b8589ccaccaa5b612a597c6f9bfb") -- RAGE DLC3 Japanese
setManifestid(209462, "6403013120691826479", 31935736)
addappid(209463, 1, "16c5c2a3cfea987ca1b11c50a19a4134142f57695d15049334751e12bde2bc25") -- RAGE DLC3 German
setManifestid(209463, "4867636502702572494", 30722500)
addappid(209464, 1, "ad27298aa5cd97820b134fa464971fe8c4d54cab041dffad19fc5b0d598a15a0") -- RAGE DLC 3 Italian
setManifestid(209464, "1654492910131275170", 31554234)
addappid(209465, 1, "c239fba6dc32013b78ffc6f55ea3d65c1c71f134a5fecddde2f6d2261e028d89") -- RAGE DLC 3 French
setManifestid(209465, "2269150281815593717", 31689926)
addappid(209466, 1, "5003a3a6209658fb5b23cce28c3057f8bcee12599bf2a40271195b5570f283f3") -- RAGE DLC 3 Spanish
setManifestid(209466, "6530481533304193433", 31696992)
addappid(452290, 1, "0a01c7677b15a391f3ff388a75d8d45ee44e48739bbd10466e33677e5f39891b") -- Rage Soundtrack (452290) Depot
setManifestid(452290, "774619414026232849", 127869217)
addappid(9240)
addappid(9240, 1, "c7ed5e6ce95bea30dcab30fdddf1ae08633be35de9cc3f10ef9a8ac170933b04") -- Rage Authority Pack DLC - Rage Authority Pack DLC
setManifestid(9240, "3534751769982747012", 163)
addappid(9241)
addappid(9241, 1, "b0474ff43d59f4556d5d4dd159dc2edcf40a1bef819881300160c8dde91b6399") -- Rage Sewers DLC - Rage Sewers DLC
setManifestid(9241, "3180194860248291517", 342012803)
addappid(209460)
addappid(209460, 1, "9557d54b1772a60fda0c291d8270153c0b9644af4ba732c7c030f483e0629928") -- RAGE The Scorchers DLC - RAGE DLC3 Content
setManifestid(209460, "2966935643055876643", 2122276900)
addappid(209470) -- FunGame2
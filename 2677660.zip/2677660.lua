-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2677660's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:28 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 14
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 2677941: Blacklisted

addappid(2677660, 1, "4b22dac540d24fab8fe0ce68b7166d192bd13bb6488c9a18de875706c9b32011")
addtoken(2677660, "11743623575295112529")
addappid(2677661, 1, "0abf0860b7a1d53e5ae7b3ed8d7e97e668fa5619be6a6ad74c140c53871868bd") 
-- setManifestid(2677661, "1223798241005513044", 124652462329)
addappid(2677662, 1, "b4089fc44110008f2b07bc97f30e298c1ae457fa69964cdb239f480259baec84") 
-- setManifestid(2677662, "6807073924334951956", 410482600)
addappid(2830501, 1, "43cf88c0f48b755f8cb8d54bf6f3a04a2ed5551120d29b81c8ae098f26edbb0e") 
-- setManifestid(2830501, "6601360459876353050", 224920844)
addappid(2830502, 1, "c9fbb0008c00893bad5a3815793a4439d6a7d3ebcdc9bc6fe187a30f2ab326c7") 
-- setManifestid(2830502, "8007413738434142917", 307966856)
addappid(2830503, 1, "02d24f8070e356ac90fac5df5692432ee3e0ea0c1558e6bb78e76aade721cf68") 
-- setManifestid(2830503, "830671202293683776", 318175389)
addappid(2830504, 1, "ab46ce36b2648707946bc7ff2e1562491060503e25487e60fcc60e4a692f5c7b") 
-- setManifestid(2830504, "6629109004288775421", 316924506)
addappid(2830505, 1, "3a2de50a20a1204b2d32c00deb6b5f5082560e4e7ef80e78236b4a25299a5486") 
-- setManifestid(2830505, "2755672558638797836", 307566930)
addappid(2830506, 1, "1de09055224b1a241e117533dccab28c234008abe60653c30cd44f9ebf48e9f5") 
-- setManifestid(2830506, "3017367679564545429", 323221633)
addappid(2830507, 1, "fbde4f908358404a6544359f9c8c402bb8a40a336fb00fa92074cf4bf30143b2") 
-- setManifestid(2830507, "278507716317809228", 311372114)
addappid(2830508, 1, "f1808e29d18c4de5461e51d4e7d3f65b9a7eee466b91359150ad4588bdbbabe6") 
-- setManifestid(2830508, "6454515309235511181", 306280503)
addappid(2830509, 1, "7d4266463917726e639937e41582b2ba629c710a3a415dfaea90997ffd35e241") 
-- setManifestid(2830509, "6972604076386304594", 304321401)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853")
-- setManifestid(228989, "3514306556860204959", 39590283)
addappid(2830500)
addappid(2830500, 1, "c51fae5748ae85fe9a754c5e7cb2bb783d4602005897d3401b00104492820eef") 
-- setManifestid(2830500, "2708321643392777102", 9416176109)
addappid(2830510) 
addappid(2830520) 
addappid(2832880) 
addappid(3138470) 
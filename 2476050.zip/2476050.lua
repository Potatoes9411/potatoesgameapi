-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2476050's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:20 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(2476050)
addappid(2476051,0,"2c4941d79d544dcfaaec62552e59723e20dae8a36a008430f9b2a357decc3962")
-- setManifestid(2476051,"2547042928307316200")
addappid(2476052,0,"e1e214413a6fc9ec375e6536ecb10c66707b9f04d59d6cdd5e3998648a10b85b")
-- setManifestid(2476052,"7690074683308742347")
addappid(2476053,0,"3bce3b74fcd21b23909c5d5236014dc0a2ad74715fb6be8e6d5a14a4d1c82eee")
-- setManifestid(2476053,"3229154151580063523")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3027490's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:42 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 1
-- Blacklisted Depots: 0

addappid(3027490)
addappid(3241050)
addappid(3249620)
addappid(3443690)
addappid(3773040)
addappid(3780130)
addappid(3782850)
addappid(3788460)
addappid(3795530)
addappid(3808530)
addappid(3813100)
addappid(3818210)
addappid(3820600)
addappid(3872020)
addappid(3875430)
addappid(3920570)
addappid(3927640)
addappid(4036610)
addappid(4036620)
addappid(4047770)
addappid(3027491,0,"39b81b647faf9c9072df74f4511a1faf74df5c285510a21252b1f71c21e5bdaf")
--setManifestid(3027491,"122233439886654131")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1296610's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:56:14 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 4
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 1296401: Blacklisted

addappid(1296610)
addappid(4528840)
addappid(1296612,0,"c49de821f253df8466134db36c94c7808fd1ecb08b35b78580339be9e89663c5")
--setManifestid(1296612,"8459934023698745257")
addappid(1296613,0,"fb761a5ae924f7b0b79fd004dd2f05cda227b78400202d0c24b03197beb72263")
--setManifestid(1296613,"5391678834528278574")
addappid(1296614,0,"8a12d17a3edba3d6cf982ceea529e1dfb0d92750fc88897ad0f553ab7664ba2c")
--setManifestid(1296614,"68669935642240860")
addappid(1296615,0,"69d4dde7164fff357b48e7935dc14348d966ff0a3bfc2af37f2a888e531fb517")
--setManifestid(1296615,"4639281162184984631")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 801800's Lua and Manifest Created by Potatoes9411
-- Atomfall
-- Created: May 17, 2026 at 07:00:06 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 5
-- Blacklisted Depots: 0

addappid(801800)
addappid(3047130)
addappid(3047140)
addappid(3047150)
addappid(3252020)
addappid(3607720)
addappid(801801,0,"90c65d444ba102f30b701ec00443031dc75907d1a98526fa98597697012055c6")
--setManifestid(801801,"8400971978754919400")
addappid(801802,0,"d5a28674f8d766073a2923af03b553720f7878451afad54be20e9c24d62406a0")
--setManifestid(801802,"1398041519600569249")
addappid(801803,0,"d7049ae7ee8ee2e9451254724c7169645ba6022a1d72446e2ac621c0e9eb8dbb")
--setManifestid(801803,"7265483314431453939")
addappid(3047140,0,"7ebc92e9ae8bd45b1a68f502a093ee8f8769f3c27184c88438c5e202e89bc995")
--setManifestid(3047140,"8053094571818646338")
addappid(3252020,0,"8b3001891ce408235534800ccb914ef87e74704cc6c906c34873e447cb8e5c29")
--setManifestid(3252020,"1656463850248702710")
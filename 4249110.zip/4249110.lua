-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 4249110's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:55 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(4249110)
addappid(4249111,0,"7e6d6cb1a6e136160805cc707943680e3b949fcd4614a89874f8f9005c22f69f")
--setManifestid(4249111,"4162242548040861635")
addappid(4249112,0,"f311e48330d6eb5320456deb32ff0dfc4afa77462ab3ef4f03c712976fd27013")
--setManifestid(4249112,"2015999630805652938")
addappid(4249113,0,"4e7a4a237210d1cd940175c55d7e47eed5cd69489edafba115a6477d2f15123b")
--setManifestid(4249113,"733389168188405052")
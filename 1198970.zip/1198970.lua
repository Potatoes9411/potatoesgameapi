-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1198970's Lua and Manifest Created by Potatoes9411
-- I Am Jesus Christ
-- Created: May 16, 2026 at 04:45:45 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 10
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(1198970, 1, "Unknown")
addappid(1198971, 1, "Unknown")
setManifestid(1198971, "5560213372378290284", 0)
addappid(1198972, 1, "Unknown")
setManifestid(1198972, "Unknown", 0)
addappid(1198973, 1, "Unknown")
setManifestid(1198973, "Unknown", 0)
addappid(1198974, 1, "Unknown")
setManifestid(1198974, "Unknown", 0)
addappid(1198975, 1, "Unknown")
setManifestid(1198975, "Unknown", 0)
addappid(1198976, 1, "Unknown")
setManifestid(1198976, "Unknown", 0)
addappid(1198977, 1, "Unknown")
setManifestid(1198977, "Unknown", 0)
addappid(1198978, 1, "Unknown")
setManifestid(1198978, "Unknown", 0)
addappid(1198979, 1, "Unknown")
setManifestid(1198979, "Unknown", 0)
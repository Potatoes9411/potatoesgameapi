-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 463530's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 07:00:00 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 8
-- Blacklisted Depots: 0

addappid(463530)
addappid(3402420,0,"d38fba59cfa07acbbbde76ba76e404d66924c9af533c727158dfda0295ebe53d")
--setManifestid(3402420,"8879606912417303801")
addappid(3402630,0,"7e357e77cf247a88ee09e9b0316e424dcf790c29998d90cdf003e980f37ce804")
--setManifestid(3402630,"364949301199105940")
addappid(463531,0,"913b6f7c71e6b2453f127bfaa8581883b1fda1fa980ddbe4b1ef1b3f9b6c9cef")
--setManifestid(463531,"7787557233285996150")
addappid(463532,0,"f933bfcc5faca765720f0b113d3ca3048cec73afc259ec932c39cd7980444066")
--setManifestid(463532,"8740411461507035877")
addappid(463533,0,"ee2baffa6fd92a5208e990513c71a8ea15fe00f12c67f74b6a45cc1b993f8191")
--setManifestid(463533,"3792045331447871181")
addappid(463534,0,"d1d941eebf6e7e6d5b934828293a9707500d04c17bc3424e2120d7eb5bd29cea")
--setManifestid(463534,"4928343751148336280")
addappid(3402421,0,"675e99a0c64273da53414a089742e4a957b854368a68ac7f159f7bd5a50cf60e")
--setManifestid(3402421,"1766900370664986161")
addappid(3402631,0,"983320607be10bce900732aa790408c9c2abdcd205be4f97f081709f9391de86")
--setManifestid(3402631,"7799287742573219158")
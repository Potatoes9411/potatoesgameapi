-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 387990's Lua and Manifest Created by Potatoes9411
-- Scrap Mechanic
-- Created: May 17, 2026 at 06:59:49 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 1
--   Depot 3879491: Blacklisted

addappid(387990)
addappid(387990,0,"0187df8e448332ced59790fcebde38720853500b8af881c5490a5ed379265508")
addappid(387992,0,"a2b344f494b0b5375bf3c405e8b3de97923659c663d583eee57993952d363761")
--setManifestid(387992,"4615519036154398529")
addappid(387993,0,"93137be5385ff98af9981124f0adeb9e8d55b91d0eab1c8a2f9ab417034a3243")
--setManifestid(387993,"1969835134401920665")
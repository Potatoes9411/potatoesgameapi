-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3215050's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:21 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(3215050)
addappid(3215050,0,"0c12d7c521db27fbcb262b9dceaf4515edc8461a750843e31bd2cc70aecc0d32")
addappid(3889420)
addappid(3889470)
addappid(3215051,0,"528e1024e8c79853eb462f95a4032f940ecfe198d66e55d5941e6b3607aa6261")
--setManifestid(3215051,"8093101630679845738")
addappid(3215052,0,"36502842caf9feaf6353ca0352b3a67c56dadb515b72f3ae130716975e906cb3")
--setManifestid(3215052,"7065484184381193797")
addappid(3889420,0,"8395176ed107aae69fa70d830384ab151bc7d9a58ecd8b5514f4448c9ec260d5")
--setManifestid(3889420,"7541429626211443468")
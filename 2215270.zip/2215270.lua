-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2215270's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:58:21 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 4
-- Total DLCs: 0
-- Blacklisted Depots: 9
--   Depot 2215201: Blacklisted
--   Depot 2215432: Blacklisted
--   Depot 2215391: Blacklisted
--   Depot 2215434: Blacklisted
--   Depot 2215431: Blacklisted
--   Depot 2215437: Blacklisted
--   Depot 2215436: Blacklisted
--   Depot 2215435: Blacklisted
--   Depot 2215438: Blacklisted

addappid(2215270)
addappid(2215271,0,"deea5e1c1b2c2cc9465e2b2021549012af5030f69e0b6a14f2d271aa71d1df96")
--setManifestid(2215271,"3374454790946250145")
addappid(2215272,0,"eee9e1ce6edf78d9cc6e27ca0957f7d384fe0a28b4735120db4547c6733c83ea")
--setManifestid(2215272,"1118034240558968351")
addappid(2215273,0,"4c100d0a9426ae78c0fa6cc1d616b96893097ee422c14131149ffc6823b474d9")
--setManifestid(2215273,"7955860482884919036")
addappid(2215274,0,"8d734405f2d7d7f67220f1b88eb80c2a0cca10f287e3f824f7b3f261c3044a0b")
--setManifestid(2215274,"5788936320567499581")
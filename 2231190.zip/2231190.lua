-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2231190's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:58:42 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 1
-- Total DLCs: 0
-- Blacklisted Depots: 20
--   Depot 2231392: Blacklisted
--   Depot 2231389: Blacklisted
--   Depot 2231391: Blacklisted
--   Depot 2231388: Blacklisted
--   Depot 2231397: Blacklisted
--   Depot 2231413: Blacklisted
--   Depot 2231412: Blacklisted
--   Depot 2231382: Blacklisted
--   Depot 2231385: Blacklisted
--   Depot 2231396: Blacklisted
--   Depot 2231387: Blacklisted
--   Depot 2231386: Blacklisted
--   Depot 2231384: Blacklisted
--   Depot 2231415: Blacklisted
--   Depot 2231393: Blacklisted
--   Depot 2231398: Blacklisted
--   Depot 2231414: Blacklisted
--   Depot 2231399: Blacklisted
--   Depot 2231394: Blacklisted
--   Depot 2231395: Blacklisted

addappid(2231190)
addappid(2231191,0,"48e7e0796ba1b96f1722c7e298aa7138ade390af6f1421c5fafd6d31b73ebafa")
--setManifestid(2231191,"4936812658395698998")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 919360's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 07:00:08 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 7
-- Blacklisted Depots: 0

addappid(919360)
addappid(2068930)
addappid(2069000)
addappid(3320650)
addappid(3697680)
addappid(3697690)
addappid(3697700)
addappid(3697710)
addappid(3756420)
addappid(919361,0,"58d9c2d65e5d967a7ce16b9e794a0a8b6e87aa144979e0d34b27fe259c768672")
--setManifestid(919361,"8349196694424749471")
addappid(2068930,0,"f581679c56f68de7d1e62b8c7dc34a949747904ea8a4f695d64fba37a2e51425")
--setManifestid(2068930,"6983843641291875533")
addappid(2069000,0,"ae302e8ed3c4358ace72617d7f43b3a1af7494dff96d7e45e64fa92447dee14d")
--setManifestid(2069000,"3317276015570110280")
addappid(3697680,0,"f454559851b5b2e5e02cc1fc2bdbbc963f18f325e60b900afa4d9d1d2ea6906f")
--setManifestid(3697680,"7115590758299740613")
addappid(3697690,0,"4e2c7b81bdc9d7ab2abfda82d1e516f558e22d7a0a4c666bb08b49256a6dd9ee")
--setManifestid(3697690,"4554326912595740994")
addappid(3697700,0,"bef4bd9227f58e6c6939efa6a483c9898300ceee517efe1ea234085d8648c7b2")
--setManifestid(3697700,"8944762483567832505")
addappid(3697710,0,"0622ea57f3a42684095ac3bdc1610b8f06896631405608ef60bbc20033f48dec")
--setManifestid(3697710,"4440935810086855093")
-- Made by F1uxin, Discord ID:965053505901588521 | Discord Server (TGP | The Galaxy of Pirates): https://discord.gg/VfCxRsFyFe

-- If you're interested in distributing these files please dm me on discord (UserID:965053505901588521) 
-- (I don't care if you send them to a friend or to help someone, just if you add them in your bot or have them widely available then i would like to know.)

-- Socials: https://guns.lol/f1uxin

-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid", save the file, then add the lua file, (i think you can add the manifests too but I would just add the lua file to ensure it works).

-- If you have any questions feel free to dm on discord (UserID:965053505901588521)


-- Main stuff to actually add the game, DLCs, & depots.
addappid(2629230, 1, "bcad38d41b88872ac31f3c00b622af223e8aab3c99036b18e66360dfd5f38da2") -- The Adventures of Sir Kicksalot
addappid(2629231, 1, "531e9fb4aec7de2c570cd5deacfcf0dfbe6c43116d4809c97a1ffe76d9a369b5") -- Depot 2629231
setManifestid(2629231, "2196654294790648680", 258168104)
addappid(2629232, 1, "f40df32d47524c0a6f41f79e9d2278d1760a93429edef3ea1044fe30493b8ad1") -- Depot 2629232
setManifestid(2629232, "2412932166888997477", 290981856)
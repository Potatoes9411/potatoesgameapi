-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3059520's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:44 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 6
-- Blacklisted Depots: 0

addappid(3059520)
addappid(3059520,0,"74712f7ff33f8367396d6daccbdb2683ce1a5d574dee4bc060144d5b9db95bc4")
addappid(3335200)
addappid(3335210)
addappid(3335220)
addappid(3335250)
addappid(3335260)
addappid(3493790)
addappid(3493820)
addappid(3493830)
addappid(3546340)
addappid(3601380)
addappid(3059521,0,"69b468d1904c13ad60ff37077c6c6350439f3e70a1df3afcfc075f41325f6b8b")
--setManifestid(3059521,"9127470954646405702")
addappid(3059522,0,"136b91fa8f220638f0a95077f481dbcb9c6f8d5a936401ec0222ddc2cc73de68")
--setManifestid(3059522,"7252096692503727991")
addappid(3059523,0,"0fefd33650cc16731c9eaa7582b567f5ab2e1dfe22480ba457f704740cb59275")
--setManifestid(3059523,"7682588688250372302")
addappid(3059524,0,"0f267a629c6d00a85bbea9fcadd7a8031d68da2504ea8e24821967b15c695e01")
--setManifestid(3059524,"819093926359800446")
addappid(3893181,0,"7f675c2fe8e758d16f3cf8d3b493956afaee78e96d78cdb668a5edb8ac1580f6")
--setManifestid(3893181,"5841062713806441202")
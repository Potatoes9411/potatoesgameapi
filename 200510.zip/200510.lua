-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 200510's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:58 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 41
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(200510)

addappid(200511,1,"e455cd62bf461e9f883d8faeee86d33e3967e0d475eca2f26107d25f2a41aae2")

--setManifestid(200511,"5977328163283230731",0)

addappid(200512,1,"83dbfade7377dca868dcceda30d58a43884ce3ff591fb405714370cd16fb627e")

--setManifestid(200512,"4267564546177814784",0)

addappid(200513,1,"e3d7fe96cccc7e33f6b943e02c35c77030b9116691acd20587f09cfbb9f616ee")

--setManifestid(200513,"3099687951329262850",0)

addappid(200514,1,"a2be649e305a5becfb95269a0d7b8622eb50e7f06cdb58b460be665f189425be")

--setManifestid(200514,"6212317035773467878",0)

addappid(200515,1,"7774fff1b32b1eca2bf1d2d76bb914465dbdb27714561c685fbcc1936dadc540")

--setManifestid(200515,"1577923318058709357",0)

addappid(200516,1,"62ab9794d60d1b9285505b4eace4d63c650bad8c04c531d291610fcce634f957")

--setManifestid(200516,"6026286414314080611",0)

addappid(200517,1,"f625be22eb1f6ee6624555bb9e0377ce899fa329235f7af8fc353d1477544749")

--setManifestid(200517,"5677229579223170801",0)

addappid(200518,1,"2cb56152d99ecb035b4892315748c4d039b41101a5e9bb936f48d40d7621dd71")

--setManifestid(200518,"2886096942775221998",0)

addappid(200519,1,"26cfd0e39f2572989283cca5508c77d7913da2c14bbc505e73f196012360510d")

--setManifestid(200519,"5296737344089529933",0)

addappid(200520,1,"7f9c771b7ce7b63722b905fddaacb594a4bde10994c0b67ddcdfdfa2a0555e62")

--setManifestid(200520,"5911100840774877922",0)

addappid(200521,1,"45df4c3789d4f0b70da1caa58b2043722f5171d3425ee5514133f85b00b9b1ae")

--setManifestid(200521,"6630944259194067348",0)

addappid(200522,1,"9f2b9f6f1a628171fee0f1269369bc4229725fd2d3daaea710d1beca34d40543")

--setManifestid(200522,"4371073319003322090",0)

addappid(200523,1,"17857eb01df5e05db364cdfb810635fd24fd8b9ae80d8f64b0fd66a86a198733")

--setManifestid(200523,"1165427881625931821",0)

addappid(200525,1,"ba2234f5c1f0a3b1171f975bebd77f62d2c00a2d1e3eeef2fd0faf4b50761cca")

--setManifestid(200525,"181782921911158240",0)

addappid(200526,1,"3d351cc8a342ffcdb7ccbe6b6b70d5b3f60099f1a5a9e5d9c9d58be657393bba")

--setManifestid(200526,"1629131137455360719",0)

addappid(200528,1,"c4256f8dd9b5c04136d6fa47f3f3be87ce4c46ff6ef5e206a75fd92207826488")

--setManifestid(200528,"6842305425258267873",0)

addappid(209811,1,"fdfdddec0471eeba89e96103d2c59d4d7568ef43e781e5632ae286e90274c65c")

--setManifestid(209811,"7634295903848040649",0)

addappid(209818,1,"c63c10685fb1517ad0bd907e3569f0c9cfed81ba04d2e0d574401fa33166d2d3")

--setManifestid(209818,"2935536691900693364",0)

addappid(209819,1,"cdf1887913156acb4791a6a225524372a6b272d6706ac2a3f27b92d48c0a6ab0")

--setManifestid(209819,"8733079840784680818",0)

addappid(209820,1,"57e4a6268ff029fe0d5a90117859be9c0d1866b241ffa24e2a2d00bc39dc5cbe")

--setManifestid(209820,"3787224929468610693",0)

addappid(209821,1,"e8bb47202123550b2b8771542794a5ea9c1e8c18d422158c8ae9814edf6e0592")

--setManifestid(209821,"3927655542541842475",0)

addappid(209822,1,"802cedc86c50c80789f4471cdc1feec9a611e094ecfa82a7c31a0a2b79262d80")

--setManifestid(209822,"4036213561552691770",0)

addappid(209823,1,"cc29dec2511b1cf919041c5902e4de996138310716865beebcc122d9ee3b7200")

--setManifestid(209823,"9180666064602220386",0)

addappid(209824,1,"2d6ae6b50ef4740fe6132bfef531dad3419ba3ad29f2cac64abe7a7a0c22885f")

--setManifestid(209824,"2391596403993175906",0)

addappid(209825,1,"995fdbacc413b664de0bdfcfc301c4dd5e8b6feff774e98a4871048c3352d371")

--setManifestid(209825,"3194485471142706381",0)

addappid(209826,1,"8efbab51b4428d845645d683a99060c80278e23981092be3c8938ebfda832219")

--setManifestid(209826,"2902298679741921499",0)

addappid(209827,1,"2577bcca47833d2e4cade933162e46a361e83fe5d9f9ac1253580d940ba03c79")

--setManifestid(209827,"595784257312450039",0)

addappid(209828,1,"c81e32f0a8910c7fb2609cc4097dc04cb6a92d5ba392ee74cb146fb8ec149639")

--setManifestid(209828,"4610943139475535667",0)

addappid(239611,1,"66bb9f24d796cf4cd9a673c4593058d9fd6137fb0c6b385f28a747a2a685ed7a")

--setManifestid(239611,"768224438854273196",0)

addappid(239613,1,"31a98ea8097a41b794604c1b93e2d7f9402729ac75e474ea13151eb12e4ed0f6")

--setManifestid(239613,"5664537082215991606",0)

addappid(239614,1,"63cbb16f8f1b141d19d8d3d0965435f908b96371756d5a27e0d8b692e49329af")

--setManifestid(239614,"4444569306026236615",0)

addappid(239615,1,"5606ccf044557210e3e1aa43b8316864d6eca6830086cda23032a3305d183da5")

--setManifestid(239615,"2088330805415867293",0)

addappid(239616,1,"6ceaee828bcd3b23cee4468f8cc39c3bfcfd86b7537df7a294b3ba9ee2881bc2")

--setManifestid(239616,"284753000885733139",0)

addappid(239617,1,"128da91ad702bc055ccb40531473719759d09025b19dbee1ce2cc71103c3c216")

--setManifestid(239617,"384780111558113330",0)

addappid(239618,1,"256190f8a15ed2aa199a0001e3a261f09ca677fbe6d1b2129d9d8acb485c420e")

--setManifestid(239618,"116357021336944192",0)

addappid(239619,1,"407b0fbdae0d9d894e6142a161d7a5e5ed3a726ca8bb69d99df264436d696c1e")

--setManifestid(239619,"28728337118389002",0)

addappid(239620,1,"069d997286ce11dbb3667fa0a5f682178d92e792df76d9aa8bb81d22a0df8676")

--setManifestid(239620,"104805678445749475",0)

addappid(239621,1,"3e88f52782c3aee295c7c425d0b3e54df23409a3b79f5839d99146deaf90dca7")

--setManifestid(239621,"1044082872451034769",0)

addappid(239622,1,"0b1b3cc2eb34111edcb06159fcdec1f1d9bf4d1dae18ba3a2e2b5fea2ff30d45")

--setManifestid(239622,"393954813390701020",0)

addappid(239623,1,"ffdb257655505f7a4f910de3af14c626e0d8ce7f6148dec3761ad4eabd67b46e")

--setManifestid(239623,"2643480763377385141",0)

addappid(239624,1,"f306a6b1d38e2eaf7c7863af04cb26be3c9c2d207f6e96b77453a7c0efc38bdb")

--setManifestid(239624,"712864875086334265",0)


-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1196590's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:40 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 11
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(1196590, 1, "5540e7492fe9a6b06aa86fcac6251b512b4bbb781df477b6b0a3db1ff677dae7") 
addappid(1196591, 1, "7ccf761ec4f6be4f36416cd1304044deb8b419204f823cae95c9d9f64f94297c") 
-- setManifestid(1196591, "8301329562625085851", 32304909827)
addappid(1196593, 1, "95a6023be95ec2186ae5340ee6b7e84f093106e5944e1c8ca09b884622dc41e6") 
-- setManifestid(1196593, "8057676274449618598", 709364981)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") 
-- setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") 
-- setManifestid(228990, "1829726630299308803", 102931551)
addappid(1456360)
addappid(1456360, 1, "ba65fa909516f46db9fd95fb6a0e266c4d244b386d260346272290642726b63e") 
-- setManifestid(1456360, "3932673717585863523", 102217264)
addappid(1456361)
addappid(1456361, 1, "c847c83484f69cc3195464a7153560fafdd9ec985afb7bf13e2e48ea552dee6d") 
-- setManifestid(1456361, "5314093679455010857", 69036400)
addappid(1456362)
addappid(1456362, 1, "46bff99e18ca51b8748333d1dafa1f759b59ca126d648bba42ec8ad386d83827") 
-- setManifestid(1456362, "7205803887098070804", 804371)
addappid(1456363)
addappid(1456363, 1, "39be524780f16cc175cb4e9813d4d4bb50152d4f72be6a4ea0cb23cf7f4669d3")
-- setManifestid(1456363, "9200672067094795390", 4344)
addappid(1731080)
addappid(1731080, 1, "caa8356d4e747e982b77b28cfcb1df9095bea681dfae768c0a727a3cd96a9279") 
-- setManifestid(1731080, "767965597380462013", 7314185482)
addappid(1731081)
addappid(1731081, 1, "69638321e164cb5fd216b2ab217bffa7073fce678124665c60934e972bcf0c2e") 
-- setManifestid(1731081, "3897428114068735554", 77053219)
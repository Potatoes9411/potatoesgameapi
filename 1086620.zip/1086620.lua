-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1086620's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:55:28 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 1
-- Total DLCs: 0
-- Blacklisted Depots: 12
--   Depot 1086942: Blacklisted
--   Depot 1086943: Blacklisted
--   Depot 1086946: Blacklisted
--   Depot 1086948: Blacklisted
--   Depot 1086949: Blacklisted
--   Depot 1086945: Blacklisted
--   Depot 108604: Blacklisted
--   Depot 108603: Blacklisted
--   Depot 1086944: Blacklisted
--   Depot 108602: Blacklisted
--   Depot 1086947: Blacklisted
--   Depot 1086941: Blacklisted

addappid(1086620)
addappid(1086621,0,"6e4e3de29233e4ee26c94144b2cdbf6678f449e985835a13f6c857ab11f593c3")
--setManifestid(1086621,"9146747282350940132")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3562530's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:35 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(3562530)
addappid(3562531,0,"d482b3a57c0ee88ebad19f82c9786d6e6b9b3e9cda42465c9949afd5517b9fdb")
--setManifestid(3562531,"6745345482013875014")
addappid(3562532,0,"f8ac6abfeedac6ccfed3633fd00b5566f99d59959800c6601c1db04728508d8d")
--setManifestid(3562532,"6414297668449590645")
addappid(3562533,0,"9b152945f6b5bf942e87860556df53d10a40d6a24c30881553571171cd5fd4e5")
--setManifestid(3562533,"6804411021134696060")
addappid(3562534,0,"c73113d412c0a05e421d5430ecc9bc25254e1cd6f513fe95ba0939680cddd533")
--setManifestid(3562534,"237087048085646399")
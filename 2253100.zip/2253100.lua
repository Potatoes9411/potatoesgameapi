-- Made by F1uxin, Discord ID:965053505901588521 | Discord Server (TGP | The Galaxy of Pirates): https://discord.gg/VfCxRsFyFe

-- If you're interested in distributing these files please dm me on discord (UserID:965053505901588521) 
-- (I don't care if you send them to a friend or to help someone, just if you add them in your bot or have them widely available then i would like to know.)

-- Socials: https://guns.lol/f1uxin

-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid", save the file, then add the lua file, (i think you can add the manifests too but I would just add the lua file to ensure it works).

-- If you have any questions feel free to dm on discord (UserID:965053505901588521)


-- Main stuff to actually add the game, DLCs, & depots.
addappid(2253100, 1, "bafa86ed69bf723901710b88a0148adce598bb3962c68b5c69b8a949a77c9b2f") -- Everwind
addappid(2253101, 1, "2549c73b78694079c57a8417dd02f5d6e4c6c6286a0483187a49bdbdf9857241") -- Depot 2253101
setManifestid(2253101, "3820126301736318537", 2028359043)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(4321300)
addappid(4321300, 1, "63429df6fefe15855a53aa1c67b10e3058181615b7a28a498670309c125c0553") -- Everwind - Supporter Pack - Depot 4321300
setManifestid(4321300, "4236541669611483898", 525907946)
addappid(4351900) -- Capybara Edition Upgrade
addappid(4434900) -- Everwind - Early Access Thank-You Gift
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3870580's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:49 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(3870580)
addappid(4203930,0,"958c93468e03eef6f616017fa0f79545c5128da9c0681908aaeca945f130c840")
-- setManifestid(4203930,"6426055927881689570")
addappid(4203940,0,"b8bee274035d6879db826571df8d8bc1eb2089da819a3fd673179180c4d223d5")
-- setManifestid(4203940,"3151926734915614097")
addappid(4203960,0,"e38a283f1fe722ab7420015e7a3536854bd7f3423438bf18699b3630574e8484")
-- setManifestid(4203960,"23842501879476391")
addappid(3870581,0,"c3d471463ecbb3d56f72425d97b8a15cb18c311c46ea88d5854392f9b1521af4")
-- setManifestid(3870581,"8757836272753780789")
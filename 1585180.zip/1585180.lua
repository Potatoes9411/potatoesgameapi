-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1585180's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:56:43 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 4
-- Total DLCs: 0
-- Blacklisted Depots: 2
--   Depot 1585221: Blacklisted
--   Depot 1585222: Blacklisted

addappid(1585180)
addappid(1585180,0,"8c7c416113de482ba6d04c627f3da230066d1305b14dd95a62945b6d5d9f0eee")
addappid(1585181,0,"fc3dcbcad5592e37ca4820226a3f1468ca1a204ae9eb531251f35720d446a33d")
--setManifestid(1585181,"3719719989725870479")
addappid(1585182,0,"e3f3f5b9271ecc5008846fdb91f891cfec142053bee010982ef6927466254c52")
--setManifestid(1585182,"1042647645754703020")
addappid(1585183,0,"4f32074c64c045394d23435667cba9c4f623b6beab4b60d5cd63d1f72bb26576")
--setManifestid(1585183,"2896645357887985741")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2714970's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:00:43 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 2
-- Total DLCs: 0
-- Blacklisted Depots: 24
--   Depot 271481: Blacklisted
--   Depot 271423: Blacklisted
--   Depot 271443: Blacklisted
--   Depot 271428: Blacklisted
--   Depot 271411: Blacklisted
--   Depot 271412: Blacklisted
--   Depot 271424: Blacklisted
--   Depot 271414: Blacklisted
--   Depot 271430: Blacklisted
--   Depot 271480: Blacklisted
--   Depot 271417: Blacklisted
--   Depot 271418: Blacklisted
--   Depot 271466: Blacklisted
--   Depot 271441: Blacklisted
--   Depot 271422: Blacklisted
--   Depot 271413: Blacklisted
--   Depot 271442: Blacklisted
--   Depot 271429: Blacklisted
--   Depot 271416: Blacklisted
--   Depot 271479: Blacklisted
--   Depot 271427: Blacklisted
--   Depot 271426: Blacklisted
--   Depot 271446: Blacklisted
--   Depot 271410: Blacklisted

addappid(2714970)
addappid(2714970,0,"6d16544a747d217e97e23743b53278101aca1497163ab5f633ded3af343112a8")
addappid(2714971,0,"ab4bc4223396ff5d6b91856b16a2f239cf1ca363f100362049154f2b54d3e3a7")
--setManifestid(2714971,"2923362800947727160")
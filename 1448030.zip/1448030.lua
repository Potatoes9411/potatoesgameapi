-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1448030's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:46 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(1448030)
addappid(1448035,0,"e47d93961f72366198492d6dd2889cf4a9e9c40c50449abd2f8f86466bf6a74f")
--setManifestid(1448035,"5370758374279828432")
addappid(1448036,0,"614649a95b6a0eb7f521527d02b5a4e0971755e712080c059a8e8c3c81a7950d")
--setManifestid(1448036,"7081088648901904876")
addappid(1448037,0,"53fdba3b684d347501ea8ec526b9672c7a5303c91c991823cb8fe2af4dab133e")
--setManifestid(1448037,"9135489272905839219")
addappid(1448038,0,"6aecc5550f2418d93e1e413f955a7d8e44533897ccfccbedbc8b803f007f5532")
--setManifestid(1448038,"1052119468663544041")
addappid(1509410)
addappid(2141110)
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1172710's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:40 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(1172710)
addappid(3596810)
addappid(3596890)
addappid(3596900)
addappid(3596920)
addappid(3596930)
addappid(3604150)
addappid(3604160)
addappid(3604170)
addappid(3604180)
addappid(3604200)
addappid(3604210)
addappid(3604270)
addappid(3604280)
addappid(3796170)
addappid(4156640)
addappid(1172711,0,"fca2f8a025b411ec4d846fe6bf97d1d0589a93bb56a2527fb857a4bfe4aac2b3")
--setManifestid(1172711,"494489597509086960")
addappid(1172719,0,"7b18d5460246bac4620753a4ed05b5f4e42c3c6ad1fce01a9508eb6a9fac5e08")
--setManifestid(1172719,"5406430919118556328")
addappid(3604191,0,"c572ef768fbab850c416f10be050771ed650c63967a64819d1b61d1a34e3cbaa")
--setManifestid(3604191,"1970619944737853826")
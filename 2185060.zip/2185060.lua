-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2185060's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:04 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 14
-- Blacklisted Depots: 0

addappid(2185060)
addappid(2185060,0,"2340a2fa4b9bb44e786eb62e5866d2f8b2b4c5d73c0173273064b5a6424c5d1d")
addappid(2999840)
addappid(2999850)
addappid(3592600)
addappid(3804850)
addappid(2185061,0,"a98101165ba3b99b3d98c5866360aa7cb08eeffd31ec95a9d024a824ff57c792")
--setManifestid(2185061,"7423407547274860665")
addappid(2185062,0,"50e06e5a50d397f8af97494176ecfb9f75bb4082443bbe1fb111f44715c18d61")
--setManifestid(2185062,"3014743437142674605")
addappid(2185063,0,"e68d0e65f0ced4a31e4932edecd8ff65ad2f1b503bff1b0e74faa05ae4d5356c")
--setManifestid(2185063,"6162155711228809402")
addappid(2999841,0,"17c8f80c3b69386aa95d085d8d9acf78ded50c7d234c3fe760843b1854e57d5d")
--setManifestid(2999841,"4641401289589527075")
addappid(2999842,0,"c17024c21617ad2a2c48ab1ef147fa5631840f4a8e92735f4ceddc9bcf4aa2cb")
--setManifestid(2999842,"5701886906430894855")
addappid(2999843,0,"e9ef0ab3c1526da46248fa2d6b362fe47d752025d6737c04217e276330a0f57f")
--setManifestid(2999843,"4483154084420526161")
addappid(2999851,0,"08a857d0c27299f066279413cf450e11262163e9fdd33ed8146402834a75a318")
--setManifestid(2999851,"5303984816366019077")
addappid(2999852,0,"6a30c41e89a00e6dccd56cde848599d00d6f98edb86f68d8ad3ca11a7772fbb7")
--setManifestid(2999852,"8918481798725075022")
addappid(2999853,0,"02e1edb27de1b992bbac282fe43c00b39aced6b5b1ff1e6dce02a711d64adbe4")
--setManifestid(2999853,"3836550410533387658")
addappid(3592601,0,"8fc6c6248dc796e6fd5cc6834560bebbe05cd43fca1209ce06cd28d42a3421b1")
--setManifestid(3592601,"2039674076927037602")
addappid(3592602,0,"f176a616fceffd4977533324e8cbecec75de625ac741be1563f35bc159674382")
--setManifestid(3592602,"7997083216902393500")
addappid(3592603,0,"d0e5329d3415a09f040f4c36085ad1ecbe427e72f8505095a0798f4d0068b0e9")
--setManifestid(3592603,"7356652839589231519")
addappid(3804851,0,"245b7148e9c97035fcc19d3bb6286994fe4bbfec32c17a6803f915ce8704d421")
--setManifestid(3804851,"6399295225169265925")
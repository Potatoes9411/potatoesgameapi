-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3172670's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:19 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 6
--   Depot 3172191: Blacklisted
--   Depot 3172311: Blacklisted
--   Depot 3172312: Blacklisted
--   Depot 3172061: Blacklisted
--   Depot 3172281: Blacklisted
--   Depot 3172313: Blacklisted

addappid(3172670)
addappid(3172671,0,"5af754b4d0fc021eb39db5a02fd4e703a3cf7a7c0c66f35c83294a7f669cb70e")
-- setManifestid(3172671,"5897545056764793688")
addappid(3668750,0,"d7c43b8e21161c326f8f03e272621042c0101e51f4c71f41a79ee24b4ff5bfdc")
-- setManifestid(3668750,"1736418237939953179")
addappid(3668760,0,"84f184304e61490990a3d766d41e0c99ab6f9d09aada14c04468b6f892079830")
-- setManifestid(3668760,"9038966144136096915")
addappid(3668770,0,"64bbdd6bab2889d8d3416d719d1b81825e742002225cff10e069820d7fb73132")
-- setManifestid(3668770,"7032950245739067370")
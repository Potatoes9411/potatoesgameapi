-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1946700's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:24 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 1946740: Blacklisted

addappid(1946700)
addappid(1946701,0,"1855172b9981957be819a2b9bf0465f73a8891dd8b3df1c8f5c058d2e67dd600")
--setManifestid(1946701,"980989031362337119")
addappid(1946702,0,"138424a39d78ff3f8bbffbbab899c050b2d5872b1220105e8a40a17784606cfc")
--setManifestid(1946702,"6660789389922916923")
addappid(2402251,0,"ecfc226980d395722ffa727cb8515aa57d1d3b4e3a3651cf93b21acd4d0c077f")
--setManifestid(2402251,"6631240224102435604")
addappid(2402240)
addappid(2402250)
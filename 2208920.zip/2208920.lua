-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2208920's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:58:18 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 13
-- Total DLCs: 0
-- Blacklisted Depots: 2
--   Depot 2208571: Blacklisted
--   Depot 2208351: Blacklisted

addappid(2208920)
addappid(2210140)
addappid(2210141)
addappid(2210142)
addappid(2210541)
addappid(2210730)
addappid(2210731)
addappid(2210734)
addappid(2210735)
addappid(2210736)
addappid(2210740)
addappid(2210741)
addappid(2216800)
addappid(2216801)
addappid(2216802)
addappid(2216803)
addappid(2216804)
addappid(2247900)
addappid(2251610)
addappid(2253270)
addappid(1716751,0,"84780b728a23b1dabbe8b064807ccd3dbd40c67139ed569101104a418c581675")
--setManifestid(1716751,"4132506267642462151")
addappid(2208921,0,"730d1287dca1022d13b02c888d506c722defbd62ebb8d2e5d63b4b1225c2214a")
--setManifestid(2208921,"2445790618997915167")
addappid(2208922,0,"f63ecfc0cf19563c881154f4f30d417f6e06e8ba36d97ef158b3b3011b4f50a9")
--setManifestid(2208922,"9134213676153211952")
addappid(2208923,0,"f8db6be76c7006843019640140a96b0041a94b0822637ed0a6c4263947677a32")
--setManifestid(2208923,"263026949759441130")
addappid(2208924,0,"6fb2adf9e1c7b80b53a1d54671995dd9643882d572928bb4708152502c97defa")
--setManifestid(2208924,"695868890233753547")
addappid(2208925,0,"9dfe80e165990a0f9897b0e9d8d406d4aaf5686e1b0ab51873ad6720dec85cba")
--setManifestid(2208925,"6857264363759358797")
addappid(2208926,0,"e79a8d81b33f3cee16adf9d5ef9a91234f811ce435f76f7ed4ad6699081feb96")
--setManifestid(2208926,"9087313228259552134")
addappid(2208927,0,"7637d15ea02bb0532437a3e39f2741fb9856fe16c551034b6fa557420133d0d3")
--setManifestid(2208927,"2992301042586024036")
addappid(2208928,0,"59bbbd6d54128c3aa8bb676161987f4a6039aa9a73ef888e3072bcb67671b357")
--setManifestid(2208928,"3952138475651660933")
addappid(2208929,0,"79ad447f1ccd9123e04990015c1ae80ec5b1ed29bd3b8abe427fca13d21cb3e2")
--setManifestid(2208929,"603665797137398867")
addappid(2210143,0,"c0c5f510b0fc245b42abe2178d14c78dcb832353ac2b26a2e6158c656ddd2471")
--setManifestid(2210143,"2642565480194191165")
addappid(2210144,0,"5b4d7f7cf88e57952d1fd1622b39c4655b20f21d3c3f7382a6cb4bf3bfc1cead")
--setManifestid(2210144,"1830309223910627976")
addappid(2210145,0,"7a47174cc2e1deac0c6e920f778139b00568388bacd9fcd70802fedb611fa355")
--setManifestid(2210145,"8504924204849894571")
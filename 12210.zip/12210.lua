-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 12210's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:55:48 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 9
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 1221481: Blacklisted

addappid(12210)
addappid(12211,0,"155186d97af14c948ac35351ac345c108046167384eb2b898802f158bfd111b4")
--setManifestid(12211,"8070600747380932868")
addappid(12212,0,"63df369c3038e5c927f585fc81b41f5b669795976ac9af4d27a2add6c57733ca")
--setManifestid(12212,"5029883714475696364")
addappid(12213,0,"e927e10529530ef0a1798c945c7fea9d3a4bd8cb2bac061587c193afbe0dfeec")
--setManifestid(12213,"7959739752369022030")
addappid(12214,0,"f47f42a9df6c82ac4c134478cd1a0c95bdb32f686a3c4033ee8b9735c3999529")
--setManifestid(12214,"8513070578700495865")
addappid(12215,0,"70a582f0d5f9cbf610ccbac1a905c7d5c8f0f3b420412ee754779141d9a89e77")
--setManifestid(12215,"5596831668192471551")
addappid(12216,0,"ef7603bd0f512678f2832b71bcb340b950fd5d8ed5f52e0129300538727d1787")
--setManifestid(12216,"716802607004606457")
addappid(12217,0,"050c5432482073005c36629ad7372baeafb6d1f63b6b8175936feb4ad8521d1c")
--setManifestid(12217,"703090685957058760")
addappid(12218,0,"3446117408a17195591f5a98c1f64d2ca9a49dcdeb93a90fec8ceb63cb1cf249")
--setManifestid(12218,"5435507331887440070")
addappid(1899671,0,"b7921da5e50d00b2238d0fe870a354cb572bc5d397955fef02a439103f62827b")
--setManifestid(1899671,"2821759503143114834")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1970580's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:57 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(1970580)
addappid(1970580,0,"f520ab5adecff123f4a796fd9bf559bceec91bbba7c47536c0335599b1fe79b9")
addappid(1970581,0,"7bae37e1619e3eaf89e2689a47977fe767293487db2dc87eeea151deb59b4e2a")
--setManifestid(1970581,"3178627114856544901")
addappid(1970582,0,"47cefda381bf839c765b093c9d27e09a805d90509379e96950ab2b9baf93bfb4")
--setManifestid(1970582,"176513439720981009")
addappid(1970583,0,"6218e47340a54721ed75b10918487fc70956b4005f56d5464f48dacf4ad4ef1d")
--setManifestid(1970583,"8957818974901801959")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 233860's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:59:07 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 3
--   Depot 2338512: Blacklisted
--   Depot 2338513: Blacklisted
--   Depot 2338511: Blacklisted

addappid(233860)
addappid(233860,0,"e82fe4a117edac4ddeda231d5e0c962001d3be84eb50bd5d4bbeec2a00068217")
addappid(233870)
addappid(468550,0,"c908f9631d5bdcb41bb85c108c4e64f4cb3f51ff42c5555fe5471ec6ba9b43dd")
--setManifestid(468550,"989505602589646683")
addappid(233861,0,"38568de2647a34cb59498e6eb270d8a8e4a9f6de3761eb6c087de081f8c47273")
--setManifestid(233861,"5962268813919641662")
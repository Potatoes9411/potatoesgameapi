-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1995930's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:33 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 1995521: Blacklisted

addappid(1995930)
addappid(1995931,0,"df776ad38464f9409634f4dda2f3af253a293c04bb5c4017fa2596a9f023eb52")
--setManifestid(1995931,"757011811428979382")
addappid(1995932,0,"b71fea2e1d58e1260dcc1ea0f02afba2cb509c67a20d4e2b093335f7aa3d7ea2")
--setManifestid(1995932,"1904326499340364904")
addappid(1995933,0,"3889db90ddf882f290ae3e60566a218c2cc915295ea3932740ae999a531e5b5f")
--setManifestid(1995933,"7491947554831461472")
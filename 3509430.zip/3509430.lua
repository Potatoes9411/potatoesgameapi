-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3509430's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:33 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(3509430)
addappid(3509431,0,"5928a74b90a30c669867a658c95c09c8cc9e844dfb0a903e787050e956677eab")
--setManifestid(3509431,"7597858160119045727")
addappid(3509432,0,"cc181fd3fa1077e5898bd241c37470288ef2691a97118e2b1612acb772bf7a77")
--setManifestid(3509432,"8687238276080962627")
addappid(3509433,0,"d1f8100476349eb7ee0a9fdf29805001a0dbab48928b995a7624adad5b25f259")
--setManifestid(3509433,"309434957037420276")
addappid(3509434,0,"8d2d5ca1c8ba99beb0f12f5f5ac93f9f700c65729c056c18ca1308de78ea4f83")
--setManifestid(3509434,"403893500982177653")
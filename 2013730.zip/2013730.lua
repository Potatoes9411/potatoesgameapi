-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2013730's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:59 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 3
--   Depot 2013181: Blacklisted
--   Depot 2013641: Blacklisted
--   Depot 2013671: Blacklisted

addappid(2013730)
addappid(2013732,0,"2c478f660defa801ad0c9d613c1db68abdf7e35b83bbc34e3a0fd7e02cbe4e65")
--setManifestid(2013732,"1337982764490682892")
addappid(2013733,0,"4c00e2510d0628116c1e1febff45e65245c374d1271a6024b71944bd2f565593")
--setManifestid(2013733,"835529284428696887")
addappid(2013734,0,"51b218bafef074810883eeeab55738d326d72fa185734640d5e5fcb977d8b790")
--setManifestid(2013734,"2006611591977508756")
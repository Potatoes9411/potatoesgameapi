-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 39210's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:50 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 1
-- Blacklisted Depots: 0

addappid(39210)
addappid(262340)
addappid(262341)
addappid(262342)
addappid(267510)
addappid(267511)
addappid(267512)
addappid(359480)
addappid(376010)
addappid(376011)
addappid(376020)
addappid(376050)
addappid(376070)
addappid(376090)
addappid(582380)
addappid(582381)
addappid(582382)
addappid(596480)
addappid(1016870)
addappid(1016871)
addappid(1016872)
addappid(1016873)
addappid(1592500)
addappid(1592510)
addappid(1592511)
addappid(1592512)
addappid(1939460)
addappid(1939461)
addappid(1939462)
addappid(2649240)
addappid(2649250)
addappid(2649260)
addappid(2649270)
addappid(2649330)
addappid(2649340)
addappid(2649350)
addappid(39211,0,"d0c623233763e6f93f011efe694adc0da08240833523dce4dd7c33452faefd98")
--setManifestid(39211,"8665979780740027235")
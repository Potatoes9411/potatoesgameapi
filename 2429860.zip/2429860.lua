-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2429860's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:17 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 7
-- Blacklisted Depots: 0

addappid(2429860)
addappid(3155140)
addappid(2429861,0,"591782e366a2be7556b05c52c3ebab70bf328172f2277b1fea48b311ac3c8423")
--setManifestid(2429861,"2563026805166856843")
addappid(2429862,0,"ca36c8d20f6726a752664b377430a930b5579b93916c6a88a475a62391f53425")
--setManifestid(2429862,"2208207033562509711")
addappid(2429863,0,"90981bee3efdee85d4251d950a4becc37d8433d2e1f0228a8022ae3f4416dc23")
--setManifestid(2429863,"7504000890197777094")
addappid(3062991,0,"c5ef48bd281fd9fa2a0f58271afb10e00623bdfe534a874521370383625a7175")
--setManifestid(3062991,"2766149779812098901")
addappid(3062992,0,"4cb983f7e363330d3da27cbe4fc083119cc928a0777f22fe93b61e294aae5412")
--setManifestid(3062992,"1029888638983832146")
addappid(3062993,0,"0a73d390eb7dca3a0177c8764144284b272fd58349bfb7b4ff1e4f55552d3cd8")
--setManifestid(3062993,"1853285789711827287")
addappid(3155140,0,"f3c0f43ae4dded6a1c15adbb6cb81d456e280cb4a13c34cf33281784c91f7792")
--setManifestid(3155140,"7490278290563903666")
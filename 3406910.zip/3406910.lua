-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3406910's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:28 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(3406910)
addappid(3725940)
addappid(3857670)
addappid(3406911,0,"3071d68e355b513c2f032ef70401c18b3dc82991b372b61f21a70b25f3bee52b")
--setManifestid(3406911,"458665360814474281")
addappid(3725941,0,"9025c05a3fe3ab52ec4e8f796f28cf5852648ee6b83d235ae3480bf6fd973781")
--setManifestid(3725941,"4668183943968060444")
addappid(3857671,0,"95bdccb66ec1e9c33c35e5e24df7ec2866ad99989733ce86ad8882044700ac3c")
--setManifestid(3857671,"1226249927035328522")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2129530's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:57:58 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 2
-- Total DLCs: 0
-- Blacklisted Depots: 8
--   Depot 212938: Blacklisted
--   Depot 212937: Blacklisted
--   Depot 212932: Blacklisted
--   Depot 212934: Blacklisted
--   Depot 2129751: Blacklisted
--   Depot 212935: Blacklisted
--   Depot 212933: Blacklisted
--   Depot 212931: Blacklisted

addappid(2129530)
addappid(3954470)
addappid(4112550)
addappid(4351720)
addappid(2129531,0,"8c619e3fd74002747f22974390275782dc2b568bc92b52859f0c5688a4a663f7")
--setManifestid(2129531,"4243015198665777936")
addappid(4351720,0,"6dba1be22c2161793226a2567e1ab5d6f153799494d7b26684d00e692ec041be")
--setManifestid(4351720,"1736028932266953005")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3070070's Lua and Manifest Created by Potatoes9411
-- TCG Card Shop Simulator
-- Created: May 16, 2026 at 04:46:01 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 10
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(3070070, 1, "Unknown")
addappid(3070071, 1, "Unknown")
setManifestid(3070071, "4427748193312879234", 0)
addappid(3070072, 1, "Unknown")
setManifestid(3070072, "Unknown", 0)
addappid(3070073, 1, "Unknown")
setManifestid(3070073, "Unknown", 0)
addappid(3070074, 1, "Unknown")
setManifestid(3070074, "Unknown", 0)
addappid(3070075, 1, "Unknown")
setManifestid(3070075, "Unknown", 0)
addappid(3070076, 1, "Unknown")
setManifestid(3070076, "Unknown", 0)
addappid(3070077, 1, "Unknown")
setManifestid(3070077, "Unknown", 0)
addappid(3070078, 1, "Unknown")
setManifestid(3070078, "Unknown", 0)
addappid(3070079, 1, "Unknown")
setManifestid(3070079, "Unknown", 0)
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3056580's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:43 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 3
--   Depot 305621: Blacklisted
--   Depot 305622: Blacklisted
--   Depot 305623: Blacklisted

addappid(3056580)
addappid(3056581,0,"b0356baaaf926fe9395c4eea611a9b4c1fd3e3a46325bf29c4522188faea319a")
--setManifestid(3056581,"2268820602275465222")
addappid(3056582,0,"5c8986d4c03a89e80209e9947cbc40486fd213c89a16574017a7f627407633a1")
--setManifestid(3056582,"6406302952824602371")
addappid(3056583,0,"513638bb5cf7d5121e95d17f840c5eb60a4af75ebe28a11db3837b6c17bde2b0")
--setManifestid(3056583,"2498909914369317807")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 4089600's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:53 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 3
-- Blacklisted Depots: 0

addappid(4089600)
addappid(4089601,0,"56cd5b4220051f60c94fa866d62b8722e6f81551b4e1421e2dd72f3a854c2293")
--setManifestid(4089601,"139519931967183677")
addappid(4089602,0,"db22e84cc0b974f76a4f46c2edd34b582e44a56190ea6dd44111476aec56dee7")
--setManifestid(4089602,"3817123029587569316")
addappid(4089603,0,"66b6b7e1ddf0267d03da623d4ea02f2df4c39872f5cef9f1cf640bc3a4445e4e")
--setManifestid(4089603,"5588129009024453152")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1604250's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:56:45 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 9
-- Blacklisted Depots: 0

addappid(1604250) -- Tortuga - A Pirate's Tale
-- MAIN APP DEPOTS
addappid(1604251, 1, "41284e414962939427477166b3a4d0c7e600b8566092e813dc3d0cbf40c979fd") -- Depot 1604251
--setManifestid(1604251, "1616926273515905881", 63702891)
addappid(1604252, 1, "31a01030d19a45b3cdef82936e66a8888278c59b4c79e48a3d7d70d8ce397659") -- Depot 1604252
--setManifestid(1604252, "6079795127625482009", 3828194880)
addappid(1604253, 1, "78fa27344ed2d161fcecb79db64753384f6a78b19cf605c8ead8eebbdf2f383d") -- Depot 1604253
--setManifestid(1604253, "7465187096468022121", 1469387036)
addappid(1604255, 1, "cb62da326a47cb929c08894ce6ba48029e65f6500cff7c1e3212738b54b9f415") -- Depot 1604255
--setManifestid(1604255, "8280121578566406451", 578026)
addappid(1604256, 1, "e50b736d3d2db06d0fef893b2eac02d80c5a5664707a23aca24e29a2c6371bc6") -- Depot 1604256
--setManifestid(1604256, "563527506548149696", 0)
addappid(2153271, 1, "93f4a5c8460b3b6d29dab7243ba7e016f7d53d1639e3e3152db766b1f65fb11d") -- Depot 2153271
--setManifestid(2153271, "3910610103501478001", 585658)
addappid(2153272, 1, "0546fcf374c390452e76b85525ed1b881cba37bdc89386948c663154e98a1beb") -- Depot 2153272
--setManifestid(2153272, "636061067068452516", 480442)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
--setManifestid(228988, "6645201662696499616", 29212173)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
--setManifestid(228990, "1829726630299308803", 102931551)
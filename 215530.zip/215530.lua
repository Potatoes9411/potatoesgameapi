-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 215530's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:58:04 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 2
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 2155181: Blacklisted

addappid(215530)
addappid(215532)
addappid(215533)
addappid(215534)
addappid(215535)
addappid(215536)
addappid(215537)
addappid(215531,0,"dd9d30db7dbe8932cc1459e72357e927b19c7c7b49fd51555ab56361c3e0498c")
--setManifestid(215531,"2570568719847214863")
addappid(215538,0,"d0685c093ad459e2a05517559c95208eb073cf8d4ab0d59617397619e58088f5")
--setManifestid(215538,"447342929939409609")
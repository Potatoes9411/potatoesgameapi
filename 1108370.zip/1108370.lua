-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1108370's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:55:35 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 6
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(1108370)
addappid(1108371,0,"8b63992c0658294d7859e9fb561e1ca8dc487b49aaec1186beab298f8e2f5426")
--setManifestid(1108371,"5002683260346828991")
addappid(1108372,0,"6f57e567f2a2b924c9d626ad08ffbf92edd382030872267c49991f3af5016184")
--setManifestid(1108372,"241939210361130828")
addappid(1108373,0,"ec7be9ccfd3de84d651d88cc34b352bdfcff65432c09f67a5bbe85ea1b58847b")
--setManifestid(1108373,"1568124630877239603")
addappid(1108374,0,"a4c545a844105896265f69f37b6e7f98a518f9ec0dca8dced77aabf6ebe76818")
--setManifestid(1108374,"8252663011923779695")
addappid(1108375,0,"32fea08e5fa6159e36c4f4e66ca7b6913fa2cbccfb2927e6b405b4bb202fc651")
--setManifestid(1108375,"4923779042496103218")
addappid(1108376,0,"7568b735055676567f3de196ba1929807b51632344c6b7873e5b73d1dac323e3")
--setManifestid(1108376,"192947011741636581")
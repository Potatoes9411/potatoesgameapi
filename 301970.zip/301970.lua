-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 301970's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:41 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(301970)
addappid(324480)
addappid(326500)
addappid(337020)
addappid(352820)
addappid(326510,0,"d9cc56763385b7d66a07f0a0d888403a235bc36a9f7544af4d1a59c71ab918e4")
--setManifestid(326510,"6632375039491034881")
addappid(301971,0,"b6ed32154cb5618765eb9683d2bd231197fed193d83d523868d6a2fac5156c6c")
--setManifestid(301971,"2199459171025243409")
addappid(301972,0,"255a20d718a05a763683520e2cb50b98700a87751833b86191b5ab28e8230cae")
--setManifestid(301972,"8099284668439509006")
addappid(301973,0,"c52ef5006e5a045566e782df05a0b985f569639deae0f474fdf13d9e443093d9")
--setManifestid(301973,"4729197643351555332")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 601840's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 07:00:03 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(601840)
addappid(601840,0,"c23246ca78fd455f5c1d9514508d464491fd1c0a2c9640beee8754d74269681b")
addappid(601841,0,"faab12a8a91e3359c0d31da63864dbaaf5ec4690d70e615e8d925add8072bb9e")
--setManifestid(601841,"8186007050625851555")
addappid(601842,0,"392fa8cd2f75786233de540a828fc6337e320979aad3b2392a3be8f150b8905f")
--setManifestid(601842,"3412191620193152015")
addappid(601843,0,"4124e865d4dfbc67985260d0b33e247c623e71ce9a148622a258e7ef1025fbbe")
--setManifestid(601843,"198799919367503668")
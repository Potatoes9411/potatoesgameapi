-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 3405690's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:28 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 24
-- Blacklisted Depots: 0

addappid(3405690)
addappid(3405710)
addappid(3405720)
addappid(3405830)
addappid(3484390)
addappid(3484440)
addappid(3484530)
addappid(3707320)
addappid(3765110)
addappid(3922840)
addappid(4146820)
addappid(4328110)
addappid(3340991,0,"023daedb070e5af8704dc88ee0af829f5c11923d2e6a42cca11ba5713b9f4491")
--setManifestid(3340991,"2169475907772545910")
addappid(3405691,0,"12a93ecb44c6b853d762578ffef21df60aa702f723232d87f81f485f7e636684")
--setManifestid(3405691,"5540492307739462074")
addappid(3405692,0,"c6ec306084ddbc34166f66738b51806ae01d351b007df9dbfb5a17531575b5b7")
--setManifestid(3405692,"6097359150491910699")
addappid(3405693,0,"684e872bb91267d94cb6b604f3851b322d7f3097347d27a21ba119c822c80ac1")
--setManifestid(3405693,"3580681840901100062")
addappid(3405694,0,"807a1450e4e3200b6fa0ee63b41651b467484775b8b7cd64e1fdd3f32e2ff466")
--setManifestid(3405694,"7270224041361163605")
addappid(3405695,0,"9d8e39a63134b325186f44ee79df6023adbd4585f926ac27d99fd20d2b4689b1")
--setManifestid(3405695,"8825278564540222895")
addappid(3405696,0,"b48a48cfacf2e2e24f564c56bea0624d00744fb79f94bc6470e039dbf783b0fb")
--setManifestid(3405696,"6949678821100202345")
addappid(3405697,0,"05c30614464586cbdaa5cc6d2420004ed85be6113860ed3092acba46190d3e10")
--setManifestid(3405697,"4844662721944454784")
addappid(3405698,0,"d4c795b81851da1cdb29d739abcde82d3af4972dde9e4cfb47afe6f602132713")
--setManifestid(3405698,"3007581258979084325")
addappid(3405699,0,"4bd67983492c731beceea51679510dc6a8f3b8dd30f42b307b61803d305082a7")
--setManifestid(3405699,"7357981876728443366")
addappid(3405701,0,"34125f2eddef4bd7192c97bc6e5daa2280c2f8a2bf449efb544c557bf0c64345")
--setManifestid(3405701,"5550474001377839575")
addappid(3405702,0,"280968368ef276032b87f704f89e4e72c508265b1941279a0fd917cce852ccbb")
--setManifestid(3405702,"2584089910753175862")
addappid(3405703,0,"b4952b326fd29fbc8305521132204db66bf42da6f2a1762ba749fc0dfb19fd51")
--setManifestid(3405703,"5877206266188816649")
addappid(3405704,0,"a9646252767ad1e1b4dadb53f0b3e55aa3f47b24194411c4936119bc38292e13")
--setManifestid(3405704,"5851179230768827635")
addappid(3405705,0,"6beb7e95413777101eb6bcc85a1d4b3cb8944742ac13fd0b763fd767ad45a2bf")
--setManifestid(3405705,"776233339316992835")
addappid(3405706,0,"49e4266b919686a1e009092bebae33ef34e56a40da196671f5caf22f8a0f10fd")
--setManifestid(3405706,"8212980420997304778")
addappid(3405707,0,"474261f80ec08ec0f21ce91b7ce542b3b9a16e0b716191a81d8dc66683b74cdd")
--setManifestid(3405707,"4014529094844380135")
addappid(3405708,0,"5b4b9d2954b602a49dc87189e660332a7b8c81c88fee10b6350dacfd14704572")
--setManifestid(3405708,"7824657149307311165")
addappid(3405709,0,"efcad7fae359a3dbcb0caa0e2a2f21a3f2996e9d90a94b58e40b635a87a85244")
--setManifestid(3405709,"5117051402177534871")
addappid(3405711,0,"a47af223a991d72c48d1af1aa4232265ee7c65ad78a651f5bbd8a7b773a2618a")
--setManifestid(3405711,"933064341633717608")
addappid(3405712,0,"1af2e8bc3d90234bfd55dd6d7273b412568c2cea29e93dbaa1148cb3ea7426fe")
--setManifestid(3405712,"5132319801236525489")
addappid(3405713,0,"9a264107b9f1925d8e91afb72a2d7f8c706ad8db2ac6aab2cdfc64d2c88ee3ab")
--setManifestid(3405713,"8644562274167244306")
addappid(3405714,0,"3d05b44725b01a4b2777e069e593450f655d45a0768d7b25590a71c70a68c64b")
--setManifestid(3405714,"1562426618609528549")
addappid(3893181,0,"7f675c2fe8e758d16f3cf8d3b493956afaee78e96d78cdb668a5edb8ac1580f6")
--setManifestid(3893181,"5841062713806441202")
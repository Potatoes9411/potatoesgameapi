-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2368930's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:15 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 2
-- Blacklisted Depots: 16
--   Depot 236886: Blacklisted
--   Depot 236887: Blacklisted
--   Depot 236872: Blacklisted
--   Depot 236884: Blacklisted
--   Depot 236874: Blacklisted
--   Depot 236888: Blacklisted
--   Depot 236885: Blacklisted
--   Depot 236877: Blacklisted
--   Depot 236879: Blacklisted
--   Depot 236873: Blacklisted
--   Depot 236875: Blacklisted
--   Depot 236883: Blacklisted
--   Depot 236876: Blacklisted
--   Depot 236889: Blacklisted
--   Depot 236871: Blacklisted
--   Depot 236878: Blacklisted

addappid(2368930)
addappid(3508640)
addappid(2368931,0,"924f9db27c7400a1185ba793bbd54719c53dd4c3e1e55aaeb340ab7a34bfd73f")
--setManifestid(2368931,"4937792267950773150")
addappid(2368932,0,"04efe8bda1a28d021b61f31b738f9dfa9ce8639391a73a27c160921e15c4c499")
--setManifestid(2368932,"8768980881530099977")
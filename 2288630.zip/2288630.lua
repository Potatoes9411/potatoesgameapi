-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2288630's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:58:53 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 1
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 2288471: Blacklisted

addappid(2288630)
addappid(2885000)
addappid(2885010)
addappid(2885020)
addappid(2885030)
addappid(2885040)
addappid(2885050)
addappid(2885070)
addappid(2885080)
addappid(2885090)
addappid(2885100)
addappid(2885110)
addappid(2885120)
addappid(2885130)
addappid(2885140)
addappid(2926150)
addappid(3068500)
addappid(3068510)
addappid(3068520)
addappid(3068530)
addappid(3068540)
addappid(3068550)
addappid(3068560)
addappid(3222440)
addappid(3222450)
addappid(3222460)
addappid(3222470)
addappid(3416750)
addappid(3416760)
addappid(3416770)
addappid(3622740)
addappid(3622750)
addappid(3638760)
addappid(3837580)
addappid(3837590)
addappid(3837600)
addappid(3891210)
addappid(3976020)
addappid(3976030)
addappid(3976040)
addappid(4267510)
addappid(2288631,0,"6247e146b14ff88aa5a155f90b42e263de32e1c0b1f6d0a681454ef040c60530")
--setManifestid(2288631,"1093076534238543596")
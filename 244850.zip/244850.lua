-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 244850's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:18 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 6
-- Blacklisted Depots: 1
--   Depot 2448131: Blacklisted

addappid(244850)
addappid(244850,0,"88f1361bc409c0dea1f2aada8667ed87d442eed9a908ddc57994d21ff6808a18")
addappid(573160)
addappid(573900)
addappid(1049790)
addappid(1084680)
addappid(1135960)
addappid(1167910)
addappid(1241550)
addappid(1307680)
addappid(1374610)
addappid(1475830)
addappid(1676100)
addappid(1783760)
addappid(1958640)
addappid(2504720)
addappid(2569770)
addappid(2914120)
addappid(3066290)
addappid(3601770)
addappid(3858380)
addappid(4116960)
addappid(244851,0,"c2a914f1b4a29930055cf542e9061ead9b68a11f83da2bb811ff0bdd6ccd3fc4")
--setManifestid(244851,"440849663180985620")
addappid(573160,0,"90b858382780b17809d769a3c519d42315dec52ac14f62cc36a730028c8c2d55")
--setManifestid(573160,"9117099559520858982")
addappid(573900,0,"4355d154c80000fe9dd53f3d7cee8e668d2f8b838bdaa4fd327f784a740cab10")
--setManifestid(573900,"272427715373238919")
addappid(1241550,0,"0f4349457367949e9aca25e33826ae022cd451a67b5ad5761a719d7838caa2f9")
--setManifestid(1241550,"2661233009194455171")
addappid(2914120,0,"06ee550198fe9a4e3e88e9c2ed6213d32339990e903e5513977b540ae06219ed")
--setManifestid(2914120,"4186353562054498270")
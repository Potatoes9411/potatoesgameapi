-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 317820's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 17, 2026 at 06:59:19 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 6
-- Blacklisted Depots: 0

addappid(317820)
addappid(376810)
addappid(402700,0,"40268cae6e444e5ec31b3587af5b005fd6a34574dc8ab5f77af694c01e0359a5")
--setManifestid(402700,"247453645152087018")
addappid(539040,0,"676845f75d3cf2a120bfb88cb5613f9b96e7f6e0ddee450106434967a14c1d0e")
--setManifestid(539040,"4552260304638611998")
addappid(317821,0,"70178e6061654a05d4a09486971f19b0318b82c9449ed80c6ee6611dcdb725fb")
--setManifestid(317821,"7085822252302088362")
addappid(317822,0,"f1d0c9726973f4f0cd7069a6f224440503b548270d80687b3a30e8c8ae8917e8")
--setManifestid(317822,"6532307428373370035")
addappid(317823,0,"51b0ad4454c12f4c412418b0a2f1ed9362a8b14943bed5227243b0b56bdb5df4")
--setManifestid(317823,"1152005715292738511")
addappid(402701,0,"c2f2d7f4f35875cfbe681004236c7898fc10ecae888e98c7495c2c94033ccace")
--setManifestid(402701,"3471452827774068809")
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 250900's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:59:56 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 12
-- Total DLCs: 0
-- Blacklisted Depots: 2
--   Depot 250960: Blacklisted
--   Depot 2509202: Blacklisted

addappid(250900)
addappid(250900,0,"cb1c1ac5bf12aa887c898dcfcb962eca6ddb2dc729d5e49ee4e41bb24a95ea39")
addappid(401920)
addappid(570660)
addappid(1426300)
addappid(3353470)
addappid(250902,0,"ad8a374561fd8769aac243917372237482caa7a94aafbcdaa45adc4208916b7a")
--setManifestid(250902,"4994611894646808503")
addappid(250903,0,"40e55a223f52c70c427117df402eee6152118a11d9c17f28bc849252cde5337b")
--setManifestid(250903,"367036646469636831")
addappid(250904,0,"210036fb298fd6b8c2d227c9a803614edb0a6e2d9949968b46321c25d298155d")
--setManifestid(250904,"1942665726573884808")
addappid(250905,0,"42e1eb359f37040d6a198d7b0aef616b100b9ac5405667f89c15aeaf217a47ed")
--setManifestid(250905,"1709017229885880564")
addappid(250906,0,"d83d1ccc6ec53ebb8724d9dbaa3fd1b7d417fef3dcf9f9260d5fcd49b3dc771e")
--setManifestid(250906,"274330258716671855")
addappid(250907,0,"748829017a20ec0570ef232ad6b5b12539ebe511fcf85c494ac7856e5015e48a")
--setManifestid(250907,"1258401244940465981")
addappid(250908,0,"5a6d9cc4f7864cadb061e3c6f91f8c3f2ee7509f31db0c926f7c4066ff737366")
--setManifestid(250908,"7333987924869605149")
addappid(250909,0,"80ee47ebd3ec21428656ac288e189aeb671034dbed479347ac2b553f822d5899")
--setManifestid(250909,"5041024818858406088")
addappid(250910,0,"6624d0874bc231a99b0f107bd111eaaaac393405c68773a6641e4e82f1232172")
--setManifestid(250910,"1079085999450784617")
addappid(250911,0,"91f532dc0f4bd27b98705c41e9c5b1171df5c8254c92409b9faf40bbe8708639")
--setManifestid(250911,"7652847940910762229")
addappid(3353471,0,"b1b260b7116c50497bfe54b1df79bc30dbca77c3d8d7d2698f96657fdb2829e8")
--setManifestid(3353471,"229910742625134068")
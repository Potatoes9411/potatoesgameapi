-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1462490's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:46 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 4
-- Blacklisted Depots: 0

addappid(1462490)

addappid(1462494,0,"308b8a220f020a445584b551861d9a395693802620404f0046095a160f3134d2")

--setManifestid(1462494,"2144781035124880339")

addappid(1791472,0,"0a621be81fdfdd19295fc406d907993ed41c39fa4e8dd7395b25a4fb25cd93c7")

--setManifestid(1791472,"6188566279788136822")

addappid(1793600,0,"e00ab1eb5e13e5e3bb59c8ed948a6eb64a20c01c89da659f41d6eb22cdfa11ff")

--setManifestid(1793600,"3342891681311314802")

addappid(1870951,0,"7ec4e5bdbb728df827b9d7c03bb315f53addd7e9c37708ea1c9d4178c5ff5184")

--setManifestid(1870951,"3703725851751235302")
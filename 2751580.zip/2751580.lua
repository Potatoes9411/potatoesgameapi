-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2751580's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 07:00:49 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 1
-- Total DLCs: 0
-- Blacklisted Depots: 13
--   Depot 2751390: Blacklisted
--   Depot 2751380: Blacklisted
--   Depot 2751450: Blacklisted
--   Depot 2751051: Blacklisted
--   Depot 2751410: Blacklisted
--   Depot 2751440: Blacklisted
--   Depot 2751460: Blacklisted
--   Depot 2751400: Blacklisted
--   Depot 2751420: Blacklisted
--   Depot 2751430: Blacklisted
--   Depot 2751001: Blacklisted
--   Depot 2751470: Blacklisted
--   Depot 2751052: Blacklisted

addappid(2751580)
addappid(2751582,0,"03435cc464e2e08a2a465bef846461285242f555ca5e3efef5ddf24e5229d5a1")
--setManifestid(2751582,"4915224513740225298")
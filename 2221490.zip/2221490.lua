-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2221490's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:47:08 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 10
-- Blacklisted Depots: 1
--   Depot 2221841: Blacklisted

addappid(2221490)
addappid(2222560)
addappid(2222570)
addappid(2222571)
addappid(2222580)
addappid(2222730)
addappid(2225120)
addappid(2225121)
addappid(2424600)
addappid(2424601)
addappid(2560550)
addappid(2560560)
addappid(2927620)
addappid(2927630)
addappid(2928970)
addappid(2928980)
addappid(3182470)
addappid(3182480)
addappid(3182490)
addappid(3182500)
addappid(3268800)
addappid(3268810)
addappid(3398640)
addappid(3398650)
addappid(3398660)
addappid(3398680)
addappid(3572100)
addappid(3572110)
addappid(3572140)
addappid(3572150)
addappid(3572160)
addappid(3572170)
addappid(3588070)
addappid(3588080)
addappid(3588090)
addappid(3588100)
addappid(3827270)
addappid(3827280)
addappid(3827290)
addappid(3827300)
addappid(4064190)
addappid(4064200)
addappid(4064210)
addappid(4064220)
addappid(4351500)
addappid(4351510)
addappid(4351520)
addappid(4351530)
addappid(4351540)
addappid(4351550)
addappid(4378130)
addappid(4378150)
addappid(2221491,0,"c1bcc3effbf8f9a08114de2d5d1aa3566e3b6d1598cf0575f174c8a515253d52")
--setManifestid(2221491,"314373291957065989")
addappid(2221493,0,"4a6ca4d7aba34c6bd5610356b9376b677f46bc51626d709798bc62bb259ce9ec")
--setManifestid(2221493,"394834760369063949")
addappid(2221494,0,"e24ec08305a5c93445186239740fbb352895b8d8cc21bf45c896c3022abff8c2")
--setManifestid(2221494,"7121364055889191046")
addappid(2221495,0,"98e9fa9338ab3a9281c906e23368fdbe20981ae5e4cfa8f2e75dd7ccba4d9145")
--setManifestid(2221495,"3473952987736223512")
addappid(2221496,0,"aa48fd4ef9a8e1ac4441333f7663c2bf89b03ce8ebcea88eda787494395a6d1d")
--setManifestid(2221496,"6428592986177078140")
addappid(2221497,0,"cc92f847586fe819ba20318130af261e168540f20df523954079c316f8e2d22d")
--setManifestid(2221497,"8439804797477790255")
addappid(2221498,0,"a69e9ccf948e6813ed344faa6a164e5721b2d301bdb7d3b8901aa2dd68a875ff")
--setManifestid(2221498,"5048866435418771212")
addappid(2221499,0,"bfb3ec4c927afbda0ccc1e5a5707e6695d618f0e3f6ad4168686782d4c8e317d")
--setManifestid(2221499,"5035422979946443176")
addappid(2222561,0,"31b6f8f7aa32fa310f71c9638ac76179d1d87affaec821f64ef5c5fcc6081ef6")
--setManifestid(2222561,"7704843721872287045")
addappid(2222562,0,"0518808cf00b8c1264b30464d91e336d50175ddddf2ca301d6a09fd79b2ac8ca")
--setManifestid(2222562,"3609531878598493602")
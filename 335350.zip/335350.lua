-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 335350's Lua and Manifest Created by Potatoes9411
-- Goat Simulator: Original Soundtrack
-- Created: May 16, 2026 at 04:46:25 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 10
-- Total DLCs: 0
-- Blacklisted Depots: 0

addappid(335350, 1, "Unknown")
addappid(335351, 1, "Unknown")
setManifestid(335351, "Unknown", 0)
addappid(335352, 1, "Unknown")
setManifestid(335352, "Unknown", 0)
addappid(335353, 1, "Unknown")
setManifestid(335353, "Unknown", 0)
addappid(335354, 1, "Unknown")
setManifestid(335354, "Unknown", 0)
addappid(335355, 1, "Unknown")
setManifestid(335355, "Unknown", 0)
addappid(335356, 1, "Unknown")
setManifestid(335356, "Unknown", 0)
addappid(335357, 1, "Unknown")
setManifestid(335357, "Unknown", 0)
addappid(335358, 1, "Unknown")
setManifestid(335358, "Unknown", 0)
addappid(335359, 1, "Unknown")
setManifestid(335359, "Unknown", 0)
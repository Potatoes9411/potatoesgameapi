-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2183900's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:58:10 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 3
-- Total DLCs: 0
-- Blacklisted Depots: 1
--   Depot 2183671: Blacklisted

addappid(2183900)
addappid(3202690,0,"00c47f82b08192958b11307abb87c755003eb8dfae75063373e379c296b26083")
--setManifestid(3202690,"1991092350350856742")
addappid(3212040,0,"e3818ce0f203d78eed2647e6364bd19a702fd8d7a01230f77a038e0fd26b0ffb")
--setManifestid(3212040,"7457655780363166458")
addappid(2183901,0,"8df236a6a5084039477362b31157e7e0eb66554a744762d6782c544ab64d0c4e")
--setManifestid(2183901,"8936086223865720696")
addappid(3871350)
addappid(3871360)
addappid(2486150)
addappid(3871370)
addappid(2792150)
addappid(2792140)
addappid(3274430)
addappid(3871340)
addappid(2792180)
addappid(3274410)
addappid(3871380)
addappid(3871330)
addappid(2792170)
addappid(4247850)
addappid(2792280)
addappid(2792190)
addappid(3871320)
addappid(3212020)
addappid(3274440)
addappid(3274400)
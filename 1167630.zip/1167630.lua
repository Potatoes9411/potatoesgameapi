-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1167630's Lua and Manifest Created by Potatoes9411
-- Teardown
-- Created: June 17, 2026 at 06:54:35 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 14
-- Blacklisted Depots: 0

addappid(1167630, 1, "Unknown")
addappid(1167631, 1, "Unknown")
setManifestid(1167631, "Unknown", 0)
addappid(1167632, 1, "Unknown")
setManifestid(1167632, "Unknown", 0)
addappid(1167633, 1, "Unknown")
setManifestid(1167633, "Unknown", 0)
addappid(1167634, 1, "4e402173b44873473aa98965b7075111059716ebc005137bc93e3e645fe13027")
setManifestid(1167634, "9068277875399153685", 0)
addappid(1167635, 1, "Unknown")
setManifestid(1167635, "Unknown", 0)
addappid(1167636, 1, "Unknown")
setManifestid(1167636, "Unknown", 0)
addappid(1167637, 1, "Unknown")
setManifestid(1167637, "Unknown", 0)
addappid(1167638, 1, "Unknown")
setManifestid(1167638, "Unknown", 0)
addappid(1167639, 1, "Unknown")
setManifestid(1167639, "Unknown", 0)
addappid(2657090, 1, "Unknown")
setManifestid(2657090, "Unknown", 0)
addappid(2657100, 1, "5df4828df3d5422b27c221a29b70af3f0a032c14f71c632237047fb4b2ab2644")
setManifestid(2657100, "7745145493062916830", 0)
addappid(2657060, 1, "Unknown")
setManifestid(2657060, "Unknown", 0)
addappid(2657050, 1, "Unknown")
setManifestid(2657050, "Unknown", 0)
-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 2197120's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: June 17, 2026 at 06:58:14 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 1
-- Total DLCs: 0
-- Blacklisted Depots: 10
--   Depot 2197327: Blacklisted
--   Depot 2197681: Blacklisted
--   Depot 2197326: Blacklisted
--   Depot 2197328: Blacklisted
--   Depot 2197322: Blacklisted
--   Depot 2197324: Blacklisted
--   Depot 2197325: Blacklisted
--   Depot 2197321: Blacklisted
--   Depot 2197320: Blacklisted
--   Depot 2197323: Blacklisted

addappid(2197120)
addappid(2197121,0,"3c418d274bb25185f4c677d45c6b5d00cb6cecb9fbd75bcc75f475278b83276d")
--setManifestid(2197121,"4725394352287117530")
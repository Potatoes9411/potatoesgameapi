-- Made by Potatoes9411 (UserID:892887847873445958), If you would like to join my server if you aren't already in it, here is a link (https://discord.gg/myHf6qmAdj)
-- If you're interested in distributing/sharing these files please dm me on discord (UserID:892887847873445958)
-- And if you have any questions feel free to dm on discord (UserID:892887847873445958)
-- If you are wondering what other games I own, check out my steam here: https://steamcommunity.com/id/Potatoes9411/


-- Socials: https://guns.lol/potatoes9411


-- Also If you want your game to auto update, make the "setManifestid" lines all have "--" infront of them, so they would look like "--setManifestid". 
-- Or you can use a tool a good friend of mine made, heres the link: https://github.com/madoiscool/LuaTools/releases, click the "LuaTools.exe" to download it, then run it, then click patch luas and let it change all your luas to have the "--" stuff, then restart steam and all your games will auto update (P.S. If you add a new game you will need to click patch luas again, or you can drag the zip of the mani and lua files into the box in luatools and will add it and make it auto update.)


-- Main stuff to add your game.
-- ------------------------------------------------------------
-- 1137320's Lua and Manifest Created by Potatoes9411
-- unknown
-- Created: May 16, 2026 at 04:46:39 EDT
-- Website: https://potatoes-dev.com
-- Total Depots: 0
-- Total DLCs: 9
-- Blacklisted Depots: 0

addappid(1137320)
addappid(1137321,0,"7e410e4f56378c0c228b8521b34641b173e1c9dc170f805a15ee2c1ec9437892")
--setManifestid(1137321,"6794844919699335855")
addappid(1137322,0,"0e3968f997a1d8f8c49c56bb8726e6c35700a71e15f05f4c5fbd7962f268e916")
--setManifestid(1137322,"7375152608725329447")
addappid(1137323,0,"99e3d9711aa704b14995b38e81f12602eb6be3baf475dcb6c2a761b23404cfcc")
--setManifestid(1137323,"3855373145408853947")
addappid(1137324,0,"7664f1ffcdb5f2e8b9d3804b28bafe37cf7b3f434bfd0c5159cfc7f0a89ea0a1")
--setManifestid(1137324,"1099944703530496955")
addappid(1137325,0,"fa0ca4ce4d370fc89381c0e4b378ab472d879cb06fff8de916328427e5414e2e")
--setManifestid(1137325,"4466175550792836951")
addappid(1137326,0,"dd9dcb01a9ddb81ab9dbe08b22c532719e7f8ef2781e8f200233f89548bdcd66")
--setManifestid(1137326,"2067534232533408090")
addappid(1137327,0,"0c3bae32d04da9958c53e3edc1d1e1a53bbad2706f9789eecbe6a3807c4539d6")
--setManifestid(1137327,"2292170852909786676")
addappid(1137328,0,"c9c2554bd5ccd1b96f079ba64c7f09ce0e6b04f4f15db3b28e83369deed33647")
--setManifestid(1137328,"718251589017176241")
addappid(1137329,0,"5dc279da73cade1e423313b63a9898cfe4b7461ff6e07597ace6c87f6add8bd7")
--setManifestid(1137329,"1368864056739154450")